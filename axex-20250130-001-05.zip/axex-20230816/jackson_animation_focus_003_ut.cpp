#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"

#include "wEvent.h"
#include "cg_schema.h"

#include "log_001.h"

#include "image_layer_001.h"
#include "settle_grid_001.h"
#include "control_image_layer_010.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_000.h"
#include "winmainthread_005a_001.h"

#include "jackson_animation_focus_003.h"
#include "jackson_animation_focus_003_ut.h"

//
// jackson_animation_focus_003_ut.h
// jackson_animation_focus_003_ut.cpp
//
// control_image_layer_010.h


int initilize_jackson_animation_focus_003_ut () ;
int set_log_debug_message_flag (int df);
ANIMATION_FOCUS_FRAME* initilize_jackson_animation_focus_003_canvas_ut () ;

int set_log_debug_message_flag (int df) {
	log_001.set_debug_log_flg (df);
	return 0;
}



//
int initilize_jackson_animation_focus_003_ut () {


	l_settle_grid.set_log_001(&log_001);
	Set_lot_001_Control_Image_Layer_001 (&log_001);

	return 0;
}

//
ANIMATION_FOCUS_FRAME* initilize_jackson_animation_focus_003_canvas_ut () {
	int a;
	ANIMATION_FOCUS_FRAME* lp_jackson =NULL;

	lp_jackson = (ANIMATION_FOCUS_FRAME*) get_jackson_pointer_animation_thread ();
	if ( lp_jackson->initialized == 1 ) return lp_jackson;


	a = initilize_jackson_animation_focus_003_ut ();

	a = Random_Work_Param () ;
	a = Check_Initialize_Param ();
	a = initialize_ppm_fonts ();
	a = Set_Background_Colour_Rgb ( 128, 128, 255 );
	a = initialize_canvas ();
	a = Set_Background_Colour_Rgb ( 223, 223, 223 );
	a = Set_Background_Rect ( 330, 190, 300, 160 ) ;
	a = set_focus ( 320, 180, 320, 180 );
	a = Set_Grid_Colour_Rgb ( 128, 128, 255 );
	a = lp_jackson->draw_grid();
	lp_jackson->initialized = 1;

	return lp_jackson;
}

