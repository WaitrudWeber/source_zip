#ifndef _SETTLE_GRID_004_H_
#define _SETTLE_GRID_004_H_

typedef struct grid_matrix_struct_004 {
	int width_index = 0;
	int width_index_num = 0;
	int width_index_num_max = 8;
	int height_index = 0;
	int height_index_num = 0;
	int height_index_num_max = 8;
	char***	grid_matrix = NULL;
} GRID_MATRIX_004;

extern int puttheword_004 ( int ii, int jj, char* word ) ;
extern int filesize_004( FILE *fp ) ;
extern int file_all_size ( char* filename, int *file_end ) ;
extern int Set_Logging_read_csv_004 ( Logging* log ) ;
extern char* gettheword_004 ( int ii, int jj ) ;
extern int puttheword_004a ( int ii, int jj, char* word ) ;

#endif
