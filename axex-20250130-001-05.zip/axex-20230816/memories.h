#ifndef _MEMORIES_H_
#define _MEMORIES_H_

extern int wait_sharp_short_time () ;

#endif