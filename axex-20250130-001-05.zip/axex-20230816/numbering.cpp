#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "list_directory.h"

#include "parse.h"
//#include "aToken.h"

int numbering_parse ( char* filename ) ;
int filesize( FILE *fp ) ;
void backward( char *dummy, char *token ) ;
void put_letter_to_file( char char_dummy, char* filename ) ;
void put_int_to_file( int int_dummy, char* filename ) ;

void fput_int_to_file( int int_dummy, FILE *wfp ) ;
void fput_letter_to_file( char char_dummy, FILE *wfp ) ;
void takeout_line_end_after_colon ( char* filename ) ;

int is_number( char char_dummy ) ;
void output_to_stripe ( char* filename ) ;
void write_tag( char* char_string, FILE *wfp ) ;
int numbering_main ( int argc, char *argv[] ) ;
int numbering_main_011 ( int argc, char *argv[] ) ;

int get_file_info ( char *lpcstr_path, char **result ) ;

//
// 20190423
// Only return is all we can return address of pointer, so we cannnot memorize at pointer parameter.
//
int get_file_info ( char *lpcstr_path, char **result ) {

	printf( "get_file_info 001 \r\n" );

	int cnt_array = array_count (lpcstr_path);
	int cnt_directory = m_last_with ( lpcstr_path, "\\" );
	int cnt_asterisk = m_last_with ( lpcstr_path, "*" );
	int cnt_period = m_last_with ( lpcstr_path, "." );

	char* str_directory = substring ( lpcstr_path, 0, cnt_directory );
	char* str_asterisk = substring ( lpcstr_path, 0, cnt_asterisk );
	char* str_period = substring ( lpcstr_path, cnt_period, cnt_array );

	put_memories( str_directory );
	put_memories( str_asterisk );
	put_memories( str_period );

//	result = (char**) malloc ( sizeof(char*) * 3 );

	*(result + 0 ) = str_directory;
	*(result + 1 ) = str_asterisk;
	*(result + 2 ) = str_period; // attributes

//	put_memories( (char *) result );

	printf(" %s %s %s \r\n", str_directory, str_asterisk, str_period );
	printf(" %s %s %s \r\n", *( result + 0), *( result + 1), *( result + 2) );

	printf( "get_file_info 009 \r\n" );

	return 1;
}

int numbering_main_011 ( int argc, char *argv[] ) {

	initialize_parse();

	for ( int i=0; i<argc; i++) {
		printf("argv[%d] %s\r\n", argv[i]);
	}

//	numbering_parse ( argv[1] );

	return 0;
}


//
//
//
//
//
int numbering_main ( int argc, char *argv[] ) {

	initialize_parse();

	printf("%s\r\n", (char*) argv[1] );
	numbering_parse ( argv[1] );

	return 0;
}

//
//
//
//
//
int parse_org ( char* filename ) {
	FILE *fp;
	char dummy[256*256];
	char* w_filename;

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	dummy[0] = '\0';
//	w_filename = m_concat( filename, ".txt");
	w_filename = "C:\\Users\\soresore soreda\\Documents\\java004\\source-000.txt";

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		if ( m_raw == 1 )  {
			put_int_to_file( m_line, w_filename ) ;
		}
		put_letter_to_file( dummy[0], w_filename );
//		printf("line %d raw %d filename %s\r\n", m_line, m_raw, w_filename );
	}

	fclose(fp);
}

//
//
//
//
//
int numbering_parse ( char* filename ) {
	FILE *fp, *wfp;
	char dummy[256*256];
	char* w_filename;

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	dummy[0] = '\0';
//	w_filename = m_concat( filename, ".txt");
	w_filename = "C:\\Users\\soresore soreda\\Documents\\java004\\source-000.txt";
	wfp = fopen( w_filename, "ab");

	// put file name
	int ac =  array_count ( filename );
	fwrite( filename, sizeof(char), ac, wfp);
	fwrite( copyof((char*)"\r\n"), sizeof(char), 2, wfp);

	// first line
	fput_int_to_file( m_line, wfp ) ;

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		fput_letter_to_file( dummy[0], wfp );
		if ( m_raw == 1 && m_line != 0 ) {
			fput_int_to_file( m_line, wfp ) ;
		}

		printf("line %d raw %d filename %s\r\n", m_line, m_raw, w_filename );
	}

	fwrite( copyof((char*)"\r\n"), sizeof(char), 2, wfp);

	fclose(wfp);
	fclose(fp);

	// takeout the line end after colon if it has it.
	// takeout_line_end_after_colon ( w_filename ) ;

	//output_to_stripe ( w_filename ) ;
}

//
//
//
//
//
void output_to_stripe ( char* filename ) {
	FILE *fp, *wfp;
	char dummy[ 256 * 256 ];
	char* w_filename;
	int letter_mode = 0;
	int dark = 0;

	// skip       : 0
	// \r         : 1
	// \n         : 2
	// <td/><td>  : 3
	initialize_parse();

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	dummy[0] = '\0';
	w_filename = m_concat( filename, ".txt");
	wfp = fopen( w_filename, "ab");

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		switch( letter_mode ) {
		case 0:
			if ( dummy[0] == '\r' ) {
				letter_mode = 1;
			} else if ( dummy[0] == '\n' ) {
				letter_mode = 2;
			} else {
				fput_letter_to_file( dummy[0], wfp );
			}
			break;
		case 1:
			switch( dummy[0] ) {
			case '\n':
				letter_mode = 2;
				break;
			default:
				fput_letter_to_file( '\r', wfp );
				fput_letter_to_file( dummy[0], wfp );
				letter_mode = 0;
				break;
			}
			break;
		case 2:
			// fput_letter_to_file( '\r', wfp );
			// fput_letter_to_file( '\n', wfp );
			switch( dark ) {
			case 0:
				write_tag ( "</pre></font></td></tr>\r\n<tr><td bgcolor=\"#FFDDFF\"><font color=\"#000000\"><pre>" , wfp);
				dark = 1;
				break;
			case 1:
				write_tag ( "</pre></font></td></tr>\r\n<tr><td bgcolor=\"#FFEEFF\"><font color=\"#000000\"><pre>" , wfp);
				dark = 0;
				break;
			}
			//exit(-1);
			letter_mode = 0;
			break;
		}
		printf( "output_to_stripe: line %d raw %d filename %s\r\n", m_line, m_raw, w_filename );
	}

	fclose(wfp);
	fclose(fp);
}

//
//
//
//
//
void write_tag( char* char_string, FILE *wfp ) {

	fwrite( char_string, sizeof(char), array_count(char_string), wfp);
}

//
//
//
//
//
void takeout_line_end_after_colon ( char* filename ) {
	FILE *fp, *wfp;
	char dummy[ 256 * 256 ];
	char* w_filename;
	int letter_mode = 0;

	// skip       : 0
	// number     : 1
	// colon : 2
	initialize_parse();

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	dummy[0] = '\0';
	w_filename = m_concat( filename, ".txt");
	wfp = fopen( w_filename, "ab");

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		switch( letter_mode ) {
		case 0:
			if ( is_number ( dummy[0] ) == 1 ) {
				letter_mode = 1;
			}
			fput_letter_to_file( dummy[0], wfp );
			break;
		case 1:
			switch( dummy[0] ) {
			case ' ':
				letter_mode = 1; // still 1.
				break;
			case ':':
				letter_mode = 2; 
				break;
			}
			fput_letter_to_file( dummy[0], wfp );
			break;
		case 2:
			switch( dummy[0] ) {
//			case ' ':
//				fput_letter_to_file( dummy[0], wfp );
//				break;
			case '\r':
				break;
			case '\n':
				letter_mode = 0; 
				break;
			default:
				fput_letter_to_file( dummy[0], wfp );
				break;
			}
			break;
		}
		printf( "line %d raw %d filename %s\r\n", m_line, m_raw, w_filename );
	}

	fclose(wfp);
	fclose(fp);


	output_to_stripe ( w_filename ) ;
}

//
//
//
//
//
int is_number( char char_dummy ) {

	if ( '0' <= char_dummy && '9' >= char_dummy ) return 1;

	return 0;
}

//
//
//
//
//
void fput_int_to_file( int int_dummy, FILE *wfp ) {
	char dummy[256];

	sprintf( dummy, "%5d :", int_dummy );
	// line end is put when put use "a+" and fprintf.
	fwrite( dummy, sizeof(char), 7, wfp);
}

//
//
//
//
//
void put_int_to_file( int int_dummy, char* filename ) {
	FILE *fp;
	char dummy[256];

	sprintf( dummy, "%5d :", int_dummy );

	// line end is put when put use "a+" and fprintf.
	fp = fopen( filename, "ab");
	fwrite( dummy, sizeof(char), 7, fp);

	fclose(fp);
}


//
//
//
//
//
void fput_letter_to_file( char char_dummy, FILE *wfp ) {
	fwrite( &char_dummy, sizeof(char), 1, wfp);
}

//
//
//
//
//
void put_letter_to_file( char char_dummy, char* filename ) {
	FILE *fp;

//	FILE *fp = fopen( filename, "a+");
	fp = fopen( filename, "ab");
	fwrite( &char_dummy, sizeof(char), 1, fp);
	fclose(fp);
}

int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

