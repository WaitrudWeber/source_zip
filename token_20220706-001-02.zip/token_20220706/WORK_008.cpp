#include "WORK_008.h"
#include "WORK_009.h"
void WORK_008::SetWORK_009( WORK009 *lWORK009 ){ 

}
