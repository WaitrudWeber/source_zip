#include "WORK_005.h"
#include "WORK_006.h"
void WORK_005::SetWORK_006( WORK006 *lWORK006 ){ 

}
