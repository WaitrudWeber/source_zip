#ifndef _GRAPH_H_
#define _GRAPH_H_

extern void Draw_Graph ( HDC hDC, SoundEffect* SE) ;

#endif
