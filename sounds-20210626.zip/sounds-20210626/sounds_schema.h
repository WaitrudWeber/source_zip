#ifndef _SOUNDS_SCHEMA_H_
#define _SOUNDS_SCHEMA_H_

extern void sounds_schema ();
extern int initialize_sounds() ;

extern int mm_mode;
extern SoundEffect* sound_000;
extern SoundEffect* sound_001;
extern SoundEffect* sound_002;
extern SoundEffect* sound_003;
extern SoundEffect* sound_004;
extern SoundEffect* sound_005;
extern SoundEffect* sound_006;
extern SoundEffect* sound_007;
extern SoundEffect* sound_008;
extern SoundEffect* sound_009;
extern SoundEffect* sound_010;
extern SoundEffect* sound_011;
extern SoundEffect* sound_012;
extern SoundEffect* sound_013;
extern SoundEffect* sound_014;
extern SoundEffect* sound_015;
extern SoundEffect* sound_016;
extern SoundEffect* sound_017;
extern SoundEffect* sound_018;
extern SoundEffect* sound_019;
extern SoundEffect* sound_020;
extern SoundEffect* sound_021;
extern SoundEffect* sound_022;
extern SoundEffect* sound_023;
extern SoundEffect* sound_024;

#endif
