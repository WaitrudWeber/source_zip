//
#include <tchar.h>
#include <windows.h>
//#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
/*
#include "parse.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
#include "vPointStructure.h"
#include "display_threeD.h"
*/

#include "sounds-011.h"
#include "sounds_schema.h"

int mm_mode = 0;
void m_thread_sleep ();

int sbuffer[ 128 ] ;


//dummy
void play_001();

SoundEffect* sound_000 = nullptr;
SoundEffect* sound_001 = nullptr;
SoundEffect* sound_002 = nullptr;
SoundEffect* sound_003 = nullptr;
SoundEffect* sound_004 = nullptr;
SoundEffect* sound_005 = nullptr;
SoundEffect* sound_006 = nullptr;
SoundEffect* sound_007 = nullptr;
SoundEffect* sound_008 = nullptr;
SoundEffect* sound_009 = nullptr;
SoundEffect* sound_010 = nullptr;
SoundEffect* sound_011 = nullptr;
SoundEffect* sound_012 = nullptr;
SoundEffect* sound_013 = nullptr;
SoundEffect* sound_014 = nullptr;
SoundEffect* sound_015 = nullptr;
SoundEffect* sound_016 = nullptr;
SoundEffect* sound_017 = nullptr;
SoundEffect* sound_018 = nullptr;
SoundEffect* sound_019 = nullptr;
SoundEffect* sound_020 = nullptr;
SoundEffect* sound_021 = nullptr;
SoundEffect* sound_022 = nullptr;
SoundEffect* sound_023 = nullptr;
SoundEffect* sound_024 = nullptr;

void baselootin_000 ();
void baselootin_001 ();
void baselootin_002 ();
void baselootin_003 ();
void baselootin_004 ();
void baselootin_005 ();
void baselootin_006 ();
void baselootin_007 ();
void baselootin_008 ();
void baselootin_009 ();
void baselootin_010 ();
void baselootin_011 ();
void baselootin_012 ();
void baselootin_013 ();
void baselootin_014 ();
void baselootin_015 ();
void baselootin_016 ();
void baselootin_017 ();
void baselootin_018 ();
void baselootin_019 ();
void baselootin_020 ();
void baselootin_021 ();
void baselootin_022 ();
void baselootin_023 ();
void baselootin_024 ();
void baselootin_025 ();
void baselootin_026 ();
void baselootin_027 ();
void baselootin_028 ();
void baselootin_029 ();

int initialize_sounds() ;


// Very Thanks to https://stackoverflow.com/questions/19894384/simple-sounds-in-c?newreg=f9687df41b574a8f8f34db83b5c4a16a
// > mingw32-g++.exe main.o .\sounds-011.o -o winmain_011.exe
int initialize_sounds() {
	err_msg_001("initialize starts.\r\n");

sound_000 = new SoundEffect ( sbuffer, 128, 2200 );
sound_001 = new SoundEffect ( sbuffer, 128, 2383 );
sound_002 = new SoundEffect ( sbuffer, 128, 2566 );
sound_003 = new SoundEffect ( sbuffer, 128, 2749 );
sound_004 = new SoundEffect ( sbuffer, 128, 2933 );
sound_005 = new SoundEffect ( sbuffer, 128, 3116 );
sound_006 = new SoundEffect ( sbuffer, 128, 3299 );
sound_007 = new SoundEffect ( sbuffer, 128, 3483 );
sound_008 = new SoundEffect ( sbuffer, 128, 3666 );
sound_009 = new SoundEffect ( sbuffer, 128, 3849 );
sound_010 = new SoundEffect ( sbuffer, 128, 4033 );
sound_011 = new SoundEffect ( sbuffer, 128, 4216 );
sound_012 = new SoundEffect ( sbuffer, 128, 4399 );
sound_013 = new SoundEffect ( sbuffer, 128, 4583 );
sound_014 = new SoundEffect ( sbuffer, 128, 4766 );
sound_015 = new SoundEffect ( sbuffer, 128, 4949 );
sound_016 = new SoundEffect ( sbuffer, 128, 5133 );
sound_017 = new SoundEffect ( sbuffer, 128, 5316 );
sound_018 = new SoundEffect ( sbuffer, 128, 5499 );
sound_019 = new SoundEffect ( sbuffer, 128, 5683 );
sound_020 = new SoundEffect ( sbuffer, 128, 5866 );
sound_021 = new SoundEffect ( sbuffer, 128, 6049 );
sound_022 = new SoundEffect ( sbuffer, 128, 6233 );
sound_023 = new SoundEffect ( sbuffer, 128, 6416 );
sound_024 = new SoundEffect ( sbuffer, 128, 6599 );

	err_msg_001("initialize ends.\r\n");
	return 0;
}

void m_thread_sleep () {
	Sleep(25);
}


void sounds_schema () {
	switch (mm_mode) {
case 0:
	baselootin_000();
	break;
case 1:
	baselootin_001();
	break;
case 2:
	baselootin_002();
	break;
case 3:
	baselootin_003();
	break;
case 4:
	baselootin_004();
	break;
case 5:
	baselootin_005();
	break;
case 6:
	baselootin_006();
	break;
case 7:
	baselootin_007();
	break;
case 8:
	baselootin_008();
	break;
case 9:
	baselootin_009();
	break;
case 10:
	baselootin_010();
	break;
case 11:
	baselootin_011();
	break;
case 12:
	baselootin_012();
	break;
case 13:
	baselootin_013();
	break;
case 14:
	baselootin_014();
	break;
case 15:
	baselootin_015();
	break;
case 16:
	baselootin_016();
	break;
case 17:
	baselootin_017();
	break;
case 18:
	baselootin_018();
	break;
case 19:
	baselootin_019();
	break;
case 20:
	baselootin_020();
	break;
case 21:
	baselootin_021();
	break;
case 22:
	baselootin_022();
	break;
case 23:
	baselootin_023();
	break;
case 24:
	baselootin_024();
	break;
case 25:
	baselootin_025();
	break;
case 26:
	baselootin_026();
	break;
case 27:
	baselootin_027();
	break;
case 28:
	baselootin_028();
	break;
case 29:
	baselootin_029();
	break;
	}
}

void baselootin_000() {
        err_msg_001(" void baselootin_000() starts. \r\n");
        sound_000->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_000() ends. \r\n");
}
void baselootin_001() {
        err_msg_001(" void baselootin_001() starts. \r\n");
        sound_001->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_001() ends. \r\n");
}
void baselootin_002() {
        err_msg_001(" void baselootin_002() starts. \r\n");
        sound_002->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_002() ends. \r\n");
}
void baselootin_003() {
        err_msg_001(" void baselootin_003() starts. \r\n");
        sound_003->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_003() ends. \r\n");
}
void baselootin_004() {
        err_msg_001(" void baselootin_004() starts. \r\n");
        sound_004->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_004() ends. \r\n");
}
void baselootin_005() {
        err_msg_001(" void baselootin_005() starts. \r\n");
        sound_005->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_005() ends. \r\n");
}
void baselootin_006() {
        err_msg_001(" void baselootin_006() starts. \r\n");
        sound_006->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_006() ends. \r\n");
}
void baselootin_007() {
        err_msg_001(" void baselootin_007() starts. \r\n");
        sound_007->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_007() ends. \r\n");
}
void baselootin_008() {
        err_msg_001(" void baselootin_008() starts. \r\n");
        sound_008->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_008() ends. \r\n");
}
void baselootin_009() {
        err_msg_001(" void baselootin_009() starts. \r\n");
        sound_009->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_009() ends. \r\n");
}
void baselootin_010() {
        err_msg_001(" void baselootin_010() starts. \r\n");
        sound_010->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_010() ends. \r\n");
}
void baselootin_011() {
        err_msg_001(" void baselootin_011() starts. \r\n");
        sound_011->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_011() ends. \r\n");
}
void baselootin_012() {
        err_msg_001(" void baselootin_012() starts. \r\n");
        sound_012->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_012() ends. \r\n");
}
void baselootin_013() {
        err_msg_001(" void baselootin_013() starts. \r\n");
        sound_013->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_013() ends. \r\n");
}
void baselootin_014() {
        err_msg_001(" void baselootin_014() starts. \r\n");
        sound_014->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_014() ends. \r\n");
}
void baselootin_015() {
        err_msg_001(" void baselootin_015() starts. \r\n");
        sound_015->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_015() ends. \r\n");
}
void baselootin_016() {
        err_msg_001(" void baselootin_016() starts. \r\n");
        sound_016->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_016() ends. \r\n");
}
void baselootin_017() {
        err_msg_001(" void baselootin_017() starts. \r\n");
        sound_017->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_017() ends. \r\n");
}
void baselootin_018() {
        err_msg_001(" void baselootin_018() starts. \r\n");
        sound_018->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_018() ends. \r\n");
}
void baselootin_019() {
        err_msg_001(" void baselootin_019() starts. \r\n");
        sound_019->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_019() ends. \r\n");
}
void baselootin_020() {
        err_msg_001(" void baselootin_020() starts. \r\n");
        sound_020->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_020() ends. \r\n");
}
void baselootin_021() {
        err_msg_001(" void baselootin_021() starts. \r\n");
        sound_021->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_021() ends. \r\n");
}
void baselootin_022() {
        err_msg_001(" void baselootin_022() starts. \r\n");
        sound_022->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_022() ends. \r\n");
}
void baselootin_023() {
        err_msg_001(" void baselootin_023() starts. \r\n");
        sound_023->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_023() ends. \r\n");
}
void baselootin_024() {
        err_msg_001(" void baselootin_024() starts. \r\n");
        sound_024->Play();
        m_thread_sleep ();
        err_msg_001(" void baselootin_024() ends. \r\n");
}

//----

void baselootin_025 () {
	err_msg_001("baselootin_025: starts.\r\n");
	err_msg_001("baselootin_025: ends.\r\n");
}

void baselootin_026 () {
	err_msg_001("baselootin_026: starts.\r\n");
	err_msg_001("baselootin_026: ends.\r\n");
}

void baselootin_027 () {
	err_msg_001("baselootin_027: starts.\r\n");
	err_msg_001("baselootin_027: ends.\r\n");
}

void baselootin_028 () {
	err_msg_001("baselootin_028: starts.\r\n");
	err_msg_001("baselootin_028: ends.\r\n");
}

void baselootin_029 () {
	err_msg_001("baselootin_029: starts.\r\n");
	err_msg_001("baselootin_029: ends.\r\n");
}

