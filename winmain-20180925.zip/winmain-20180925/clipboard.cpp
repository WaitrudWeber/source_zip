#include <windows.h>

#include "clipboard.h"

int ReadClip(HWND hwnd, char *str);
int WriteClip(HWND hwnd, char *str);

int Paste(HWND hwnd, char *str);
int pastechar(HWND hwnd, char *str);

int Paste(HWND hwnd, char *str) {
	return ReadClip( hwnd, str );
}


int pastechar(HWND hwnd , char *str ) {

	Paste( hwnd, str );

	return 1;
}

int ReadClip(HWND hwnd, char *str)
{
    HGLOBAL hGlobal;
    LPSTR lpStr;
    int iLength, i;

    if(!IsClipboardFormatAvailable(CF_TEXT)) {
        MessageBox(hwnd, "Could not read clipboard", "Failed", MB_OK);
        return -1;
    }
    OpenClipboard(hwnd);
    hGlobal = (HGLOBAL)GetClipboardData(CF_TEXT);
    if (hGlobal == NULL) {
        CloseClipboard();
        return -2;
    }
    lpStr = (LPSTR)GlobalLock(hGlobal);
    iLength = lstrlen(lpStr) + 1;
    if (iLength > 1024)
        iLength = 1024;
    for (i = 0; i < iLength; i++)
        str[i] = lpStr[i];
    GlobalUnlock(hGlobal);
    CloseClipboard();
    InvalidateRect(hwnd, NULL, TRUE);

    return 0;
}

int WriteClip(HWND hwnd, char *str)
{
    HGLOBAL hGlobal;
    int iLength;
    LPSTR lpStr;
    int i;
    iLength = lstrlen(str);
    if (iLength > 1024)
        iLength = 1024;
    hGlobal = GlobalAlloc(GHND, iLength + 1);
    if (hGlobal == NULL)
        return -1;
    lpStr = (LPSTR)GlobalLock(hGlobal);
    for (i = 0; i < iLength; i++)
        *lpStr++ = *str++;
    GlobalUnlock(hGlobal);
    if (OpenClipboard(hwnd) == 0) {
        GlobalFree(hGlobal);
        return -2;
    }
    EmptyClipboard();
    SetClipboardData(CF_TEXT, hGlobal);
    CloseClipboard();
    return 0;
}
