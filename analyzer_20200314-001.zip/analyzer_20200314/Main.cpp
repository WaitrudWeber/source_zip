//#include "SDL.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctime>

//#include <iostream>
#include <cstdio>

//#include "stdafx.h"
//#include <tchar.h>

#include <windows.h>
// LPSTR

#include "array_counter.h"	// ADD: 20191230
#include "sender.h"			// ADD: 20191230
#include "Print.h"			// ADD: 20191230
#include "parse.h"
#include "aToken.h"

#include "wC_structure.h"
#include "analyzer_C.h"

int main( int argc, char** argv ) {

	level_error_msg = 3;
	log_msg_003 ("main: starts.\r\n" );

	Analyzer* analyzer_C = new Analyzer();
	analyzer_C->analyze_C( argc, argv);

	log_msg_003 ("main: ends.\r\n" );
	return 0;
}

