#ifndef ADEBUG_H
#define ADEBUG_H

extern int DEBUG ( char* f_name, const char* mem, const char* fmt, ...) ;
extern int DEBUG ( char* f_name, const char* fmt, ...) ;

#endif
