//#include "SDL.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctime>

//#include <iostream>
#include <cstdio>

//#include "stdafx.h"
//#include <tchar.h>

#include <windows.h>
// LPSTR


#include "array_counter.h"
#include "sender.h"
#include "Print.h"

//#define __cdecl	1
#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NON_CONFORMING_SWPRINTFS

#define VFMT_PRINTBUFFER	2048
#define MAXLINE 2048

int set_level_error_msg = 0;
int level_error_msg = 3;
int print_socket_msg = 0;

//int __cdecl system(const char *);

// extern "C" {
	char* PrintError(const char* mem, const char* fmt, ...);

	wchar_t* vformat(const char* fmt, va_list args);
	wchar_t* _toChars(char * m_string);

	char* toChars(LPSTR str);

	const wchar_t *GetWC(const char *c);

	static void err_doit(int errnoflag, int error, const char *fmt, va_list ap) ;
	void err_msg(const char *fmt, ...);
	char* err_msg_001(const char *fmt, ...);
	char* err_msg_002(const char *fmt, ...);
	char* err_msg_003(const char *fmt, ...);
	void err_msg_004(const char *fmt, ...);
	void err_msg_005(const char *fmt, ...);
	void err_msg_006(const char *fmt, ...);

	static char* err_doit_001 (int errnoflag, int error, const char *fmt, va_list ap) ;
	static char* err_doit_002(int errnoflag, int error, const char *fmt, va_list ap) ;
	char* copyof ( char* str ) ;


//	char** put_memories ( char* str ) ;

//	char* dummy_allocation;
//	char** dummy_ary;
//	int dummy_ary_index = 0;

	// void print_memories ();
//	char** put_memories ( char* str );


//}

void error(const char* fmt, ...) {
	//	using namespace N;
	va_list ap;
	va_start(ap, fmt);
//	LPSTR ps;

	// printf("%s", vformat(fmt, ap) );
	// printf("%s", vformat(fmt, ap));
	// _tprintf( _toChars("aaa") );
	// _tprintf(L"aaaa");
	// _tprintf( _toChars( (char *)"aaaa" ) );
	// _tprintf(_toChars( fmt));
	// int a = ppp( L"aaa" );
	// toChars( L"aaa" );
	// printf("aaa");
	// std::printf("aaa");
	// printf_s("aaa");

	// write memories
	// x printf("%s", vformat(fmt, ap) );
	char strx[VFMT_PRINTBUFFER];

	// 20181127
//	wsprintf( (LPWSTR)strx, (LPCWSTR)"%s", vformat(fmt, ap));




	wsprintf( (LPSTR) &strx[0], (LPCSTR)"%s", vformat(fmt, ap));

	va_end(ap);
	//	exit(1);
}

/*
#include <windows.h>
#include <string>
#include <vector>

static string utf16ToUTF8( const wstring &s )
{
    const int size = ::WideCharToMultiByte( CP_UTF8, 0, s.c_str(), -1, NULL, 0, 0, NULL );

    vector<char> buf( size );
    ::WideCharToMultiByte( CP_UTF8, 0, s.c_str(), -1, &buf[0], size, 0, NULL );

    return string( &buf[0] );
}
*/


int ppp (LPSTR a) {
	return 0;
}

/*
namespace N {
	class C {
		friend void FriendFunc() {
		}
		friend void AnotherFriendFunc(C* c) {}
	};
}
*/

//
//
//
//
//
char* PrintError(const char* mem, const char* fmt, ...) {

	va_list ap;
	va_start(ap, fmt);
//	char strx[VFMT_PRINTBUFFER];
	char* result;

	wsprintf( (LPSTR) mem, (LPCSTR)"%s", vformat(fmt, ap));
	va_end(ap);

	result = NULL;
	result = (char *) mem;

	return	result;
}

//
//
//
//
//
//char* toChars(wchar_t* str)
char* toChars( LPSTR str )
{
//	char* cptc = (LPSTR )str;
//	char* ptc = const_cast<(char*)>( str );
	char* ptc = (char*)str;

	return ptc;
//	return cptc;
}

//
//
//
//
//
const wchar_t *GetWC(const char *c)
{
	const size_t cSize = strlen(c) + 1;
	wchar_t* wc = new wchar_t[cSize];
	mbstowcs(wc, c, cSize);

	return wc;
}

//
//
//
//
//
wchar_t* _toChars(char* l_string )
{
	// LPSTR lpstr = const_cast<LPSTR>(m_string);
	// x LPCWSTR lpcwstr = const_cast<LPCWSTR>(m_string);
	// LPCWSTR lpcwstr = (LPCWSTR)lpstr;
	// T2A(L"aaa");
	// char *pc = (char*) TEXT( "aaa" );

	return (wchar_t*)GetWC( l_string );

	//wchar_t* wp = (wchar_t*)m_string;

	//return wp;
}

//
//
//
//
//
wchar_t* vformat(const char* fmt, va_list args) {
//	char buf[2000];
	wchar_t* abuf;

	abuf = (wchar_t*) L"aaa";

	// x vswprintf(buf, _toChars((char*)fmt), args);
	// o vswprintf( abuf, L"aaa", args);
	// vswprintf( abuf, _toChars( (char*)fmt ), args);
	// o vswprintf(abuf, _toChars((char*)fmt), args);

	// char *str_org = (char *)"left=%d top=%d right=%d bottom=%d";
	char strx[2000];

	// o wsprintf( (LPWSTR)strx, (LPCWSTR)str_org, 10, 10, 10, 10);
	// o wsprintf( (LPWSTR)strx, (LPCWSTR)str_org, args);

	// 20181127
	// x wsprintf((LPWSTR)strx, (LPCWSTR)fmt, args);
	wsprintf( (LPSTR)strx, (LPCSTR)fmt, args);

	// vsprintf(buf, 2000, _toChars((char*)fmt, args);
	// vswprintf(buf, fmt, args);
	// char* result = toChars( abuf );

	return abuf;
}

/*
std::string vformat(std::string fmt, va_list args) {
	char buf[2000];
	vsprintf(buf, fmt.c_str(), args);
	return std::string(buf);
}
*/

/*
void PrintErrorMsg(const char* fmt, ...);

void PrintErrorMsg(const char* fmt, ...) {

}*/

// https://stackoverflow.com/questions/28768581/using-a-pointer-to-const-char-as-a-second-argument-for-va-start
void err_msg(const char *fmt, ...)
{
    va_list     ap;

	if ( set_level_error_msg <= level_error_msg )
		return;

    va_start(ap, fmt);
    err_doit(0, 0, fmt, ap);
    va_end(ap);
} 

//
//
//
//
//
void err_msg_006(const char *fmt, ...)
{
    va_list ap;
    int argc;
    char** argv;
    int send_success;
	char* result;

	if ( set_level_error_msg <= level_error_msg ) return;

    va_start(ap, fmt);
	result = err_doit_002(0, 0, fmt, ap);
    va_end(ap);

	if ( print_socket_msg != 1 ) return;

	argc = 3;
	argv = (char**) malloc( sizeof(char**) * argc ) ;
	set_sender_default_parameters ( &argc, argv ) ;

	argv[2] = (char *) result;
	send_success = sender_main ( argc, argv ) ;

}

//
//
//
//
//
void err_msg_005(const char *fmt, ...)
{
    va_list ap;

	if ( set_level_error_msg <= level_error_msg ) return;

    va_start(ap, fmt);
    err_doit(0, 0, fmt, ap);
    va_end(ap);
}

//
//
//
//
//
void err_msg_004(const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    err_doit(0, 0, fmt, ap);
    va_end(ap);

}

//
//
//
//
//
char* err_msg_003(const char *fmt, ...)
{
	char* result;
    va_list ap;

    va_start(ap, fmt);
    result = err_doit_001(0, 0, fmt, ap);
    va_end(ap);

	return result;
}

//
//
//
//
//
char* err_msg_002(const char *fmt, ...)
{
	static char* result;
    static va_list ap;

	Sleep(1000);

	if ( set_level_error_msg <= level_error_msg ) return NULL;

    va_start(ap, fmt);
    result = err_doit_001(0, 0, fmt, ap);
    va_end(ap);

	return result;
}

//
//
//
//
//
char* err_msg_001(const char *fmt, ...)
{
	int send_success = 0;
	char** argv; 
	int argc;
	char* result;
    va_list     ap;

    va_start(ap, fmt);
    result = err_doit_001(0, 0, fmt, ap);
    va_end(ap);

	argc = 3;
	argv = (char**) malloc( sizeof(char**) * argc ) ;
	set_sender_default_parameters ( &argc, argv ) ;

	argv[2] = (char *) result;
	send_success = sender_main ( argc, argv ) ;

	return result;
} 

//
//
//
//
//
static char* err_doit_002(int errnoflag, int error, const char *fmt, va_list ap)
{
    char    buf[MAXLINE];
    char *returnable_buf;

    vsnprintf(buf, MAXLINE-1, fmt, ap);
    if (errnoflag)
        snprintf(buf+strlen(buf), MAXLINE-strlen(buf)-1, ": %s",
          strerror(error));

    //strcat(buf, "\n");
    fflush(stdout);     /* in case stdout and stderr are the same */
    fputs(buf, stderr);
    fflush(NULL);       /* flushes all stdio output streams */

	returnable_buf = copyof ( buf );
}


//
//
//
//
//
static void err_doit(int errnoflag, int error, const char *fmt, va_list ap)
{
    char    buf[MAXLINE];

    vsnprintf(buf, MAXLINE-1, fmt, ap);
    if (errnoflag)
        snprintf(buf+strlen(buf), MAXLINE-strlen(buf)-1, ": %s",
          strerror(error));

    strcat(buf, "\n");
    fflush(stdout);     /* in case stdout and stderr are the same */
    fputs(buf, stderr);
    fflush(NULL);       /* flushes all stdio output streams */
}

//
//
//
//
//
static char* err_doit_001 (int errnoflag, int error, const char *fmt, va_list ap)
{
    static char buf[MAXLINE];
    static char *returnable_buf;

	buf[0] = '\0';

    vsnprintf(buf, MAXLINE-1, fmt, ap);
    if (errnoflag)
        snprintf(buf+strlen(buf), MAXLINE-strlen(buf)-1, ": %s\0",
          strerror(error));

	returnable_buf = copyof ( buf );

    fflush(stdout);     /* in case stdout and stderr are the same */
    fputs(buf, stderr);
    fflush(NULL);       /* flushes all stdio output streams */

	return (char*) returnable_buf;
}

//
//
//
//
//
/*char** put_memories ( char* str ) {

	if ( dummy_ary_index == 0 ) {
		dummy_ary = (char **) malloc( sizeof(char*) );
		dummy_ary_index = 1;
		dummy_ary[ 0 ] = str;
	} else {
		dummy_ary_index++;
		dummy_ary = (char **) realloc( dummy_ary, sizeof(char*)*dummy_ary_index );
		dummy_ary[ dummy_ary_index - 1 ] = str;
	}

}*/

