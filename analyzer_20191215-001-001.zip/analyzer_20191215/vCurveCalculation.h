#ifndef _VCURVECALCULATION_H_
#define _VCURVECALCULATION_H_

class vCurveCalculation {

	public:
		vPoint* Position (vPoint p1, vPoint* p2, vPoint *p3, vPoint* p4, float t);

};

#endif
