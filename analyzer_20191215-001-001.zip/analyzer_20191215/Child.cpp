#include "Parent.h"
#include "Child.h"

// Child -> wKickEventThreeD

void wKickEventThreeD::setPid ( int id ) {
	this->pid =id;
}