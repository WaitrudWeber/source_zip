#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"


// p1: Anchor
// p2: setting controls
//
// p3: Anchor(next)
// p4: setting controls
//
vPoint* vCurveCalculation:: Position (vPoint* p1, vPoint* p2, vPoin*t p3, vPoint* p4, float t) {
	vCalculation* calc = nullptr;

	// calculation, revisement
	float tt = t*t;

	vPoint* p5 = calc->multiple ( p1, 1 - tt );
	vPoint* p6 = calc->multiple ( p3, tt );

	vPoint point calc->add ( p5, p6 );

	//consider, p2 and p3 which is controls point.

	return point;
}
