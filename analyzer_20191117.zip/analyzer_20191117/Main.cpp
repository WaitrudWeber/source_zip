#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"

int main ( int argc, char** argv ) {
	vCalculation* calc = nullptr;
	calc = new vCalculation ();

	return 0;
}