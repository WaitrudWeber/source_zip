#include <stdio.h>
#include "print_mouse_move_001.h"
#include "print_mouse_move_002.h"
#include "print_mouse_move_003.h"
#include "print_mouse_move_004.h"

//
int main () {
	int a = print_mouse_move_004 () ;

	return 0;
}

//
int main_001 () {

	for ( int i = 0; i<30; i++ ) {
		printf("void baselootin_%03d ();\r\n", i );
	}

	printf("\r\n\r\n");

	for ( int i = 0; i<30; i++ ) {
		printf("case %d:\r\n", i );
		printf("	baselootin_%03d();\r\n", i );
		printf("	break;\r\n");
	}

	printf("\r\n\r\n");

	for ( int i = 0; i<30; i++ ) {
		printf("void baselootin_%03d () {\r\n", i );
		printf("	printf(\"baseliitin_%03d: starts.\");\r\n", i );
		printf("	printf(\"baseliitin_%03d: ends.\");\r\n", i );
		printf("}\r\n\r\n");
	}
	return 0;
}

