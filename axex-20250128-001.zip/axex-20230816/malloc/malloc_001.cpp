#include <stdio.h>
#include <stdlib.h>

#include "malloc_001.h"

char* mallocation_001_a = (char*) "001-mallocation_001_a-001\.ntxt";
static char*** dummy_str_aa = NULL;

char*** mallocation_001_02 ( int width, int height ) ;

char*** mallocation_001_02 ( int width, int height ) {
	int i, j;
	FILE * fp;

	fp = fopen( mallocation_001_a , "wt" );
	if ( fp == NULL ) {
		printf("fp is null.\r\n" );
		exit(-1);
	}

	dummy_str_aa = (char***) malloc ( sizeof(char**) * width );
	if ( dummy_str_aa == NULL ) {
		fprintf( fp, "(char***) is null, so, allocation error.\r\n" );
	}
	fprintf( fp, "|%p|\r\n", dummy_str_aa );

	for ( i=0; i<width; i++ ) {
		dummy_str_aa[i] = (char**) malloc ( sizeof(char*) * height );
		if ( dummy_str_aa[i] == NULL ) {
			fprintf( fp, "(char**) is null, so, allocation error.\r\n" );
		}
		fprintf( fp, "[%d]=|%p|\r\n", i, &dummy_str_aa[i] );
	}

	for ( j=0; j<height; j++ ) {
		for ( i=0; i<width; i++ ) {
			dummy_str_aa[i][j] = NULL;
			fprintf( fp, "[%d][%f]=|%p|(char*)%s|\r\n", i, j, &dummy_str_aa[i][j], dummy_str_aa[i][j] );
		}
	}

	fclose(fp);
	return dummy_str_aa;
}


