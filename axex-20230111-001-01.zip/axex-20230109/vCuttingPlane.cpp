#include <tchar.h>
#include <windows.h>
//#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
#include "vPointStructure.h"

#include "vCuttingPlane.h"

vLine** vCuttingPlane::gevLine() {

	return this->lines;
}

