#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "parse.h"

//extern int m_count;
//extern int m_size;
//char* token;

int m_mode = 0; // start outside class

/*

	0: libraries
	1: class
	2: method
	3: 

*/


int parse ( char* filename );
int parse_origin ( char* filename );

int parse_slash ( int index, int file_end, FILE *fp );

int parse_libraries ( FILE *fp, int file_end  );
int parse_class ( FILE *fp, int file_end );
int parse_method ( FILE *fp, int file_end );


int token_check( );
int filesize( FILE *fp );
int analyze ( char* tkn );

int main ( int argc, char *argv[] ) {

	initialize_parse();
	parse ( argv[1] );

	//token_check ();

	return 0;
}

int token_check( ) {

	token[0] = 'a';

	printf("%d\n", token[0]);

	return 0;
}

int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

int parse_libraries ( FILE *fp, int file_end ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		fread ( dummy, 1, 1, fp);

		switch ( dummy[0] ) {
		case ' ':
			break;
		case '/':
			break;
		}
	}

	return 1;
}


int parse_class ( FILE *fp, int file_end  ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		fread ( dummy, 1, 1, fp);

		switch ( dummy[0] ) {
		case ' ':
			break;
		case '/':
			break;
		}
	}

	return 1;
}

int parse_method ( FILE *fp, int file_end  ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		fread ( dummy, 1, 1, fp);

	
		switch ( dummy[0] ) {
		case ' ':
			break;
		case '/':
			break;
		}
	}

	return 1;
}

int parse ( char* filename ) {

	FILE *fp;
//	char dummy[1];

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );


	for( int i=0; i<file_end; i++ ) {
		switch ( m_mode ) {
		case 0:
			parse_libraries ( fp, file_end );
			break;
		case 1:
			parse_class ( fp, file_end );
			break;
		case 2:
			parse_method ( fp, file_end );
			break;
		}
	}

	fclose(fp);

	return 1;
}

int parse_origin ( char* filename ) {

	FILE *fp;
	fp = fopen ( filename, "rb" );
	char dummy[1];

	int file_end = filesize ( fp );

	for( int i=0; i<file_end; i++ ) {

		fread ( dummy, 1, 1, fp);

		switch( dummy[0] ) {
		case ' ':
			analyze ( token ) ;
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		token = put_token ( dummy[0] );
//		printf( "%d %d\n", *token, token);
		printf ("dummy=%s token=%s token[%d]=%d token[%d]=%d\n", dummy, token, i, token[i], i + 1, token[ i + 1] );
	}

	printf("token=%s\n", token);

	for( int i=0; i<file_end; i++ ) {

		switch( dummy[0] ) {
		case ' ':
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		printf( "%d\n", token[i] );
	}

	fclose(fp);

	return 0;
}

int analyze ( char* tkn ) {

	m_mode = 0;
	
	switch(m_mode) {
	case 0:
		// keyword outside class
		printf("%s\n", tkn );
		exit( -1 );
		//analyze_libraries( tkn );
		break;
	case 1:
		// name outside class
		break;
	case 2:
		break;
	}

	return 0;
}

int parse_slash ( int index, int file_end, FILE *fp ) {

	char dummy[1];

	for( int i=index; i<file_end; i++ ) {

		fread ( dummy, 1, 1, fp);
	}

	return 0;
}



