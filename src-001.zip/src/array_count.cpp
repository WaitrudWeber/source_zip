#include <stdio.h>
#include "array_count.h"

int array_count( char *ary );

//int main ( int argc, char *argv[] ) {
//
//	int ac = array_count((char *)"abcdefg");
//
//	printf("count=%d\n", ac );
//
//	return 0;
//}

int array_count( char *ary )
{
	char c;
	int count = 0;
	for ( ;; ) {
		c = *ary;
		if ( c == '\0' ) {
			break;
		}
		ary++;
		count++;
	}

	return count;
}


