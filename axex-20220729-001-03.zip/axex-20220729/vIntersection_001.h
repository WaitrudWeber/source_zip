#ifndef _VINTERSECTION_001_H_
#define _VINTERSECTION_001_H_

class vIntersection_001 {

	public:
		int OtherSide = 0;

	private:

	public:
		vIntersection_001 ( );
		vPoint* Intersect_001 ( vTriangle tri, vPoint eye, vPoint ray );
		// 20210609
		double Depth ( vTriangle tri, vPoint eye, vPoint ray ) ;

	private:

};

#endif

