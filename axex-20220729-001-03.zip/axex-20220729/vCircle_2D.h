#ifndef _VCIRCLE_2D_H_
#define _VCIRCLE_2D_H_

using namespace std;

class vCircle_2D {

public:
	float x, y, r;

public:
	vCircle_2D () {}
	vCircle_2D (float xx, float yy,float rr) {

		this->x = xx;
		this->y = yy;
		this->r = rr;
	}


public:
	vCircle_2D* to_vCircle_2D () ;



};

#endif
