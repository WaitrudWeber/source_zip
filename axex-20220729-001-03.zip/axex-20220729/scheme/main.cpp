#include <stdio.h>

int main_001 (FILE* fp) ;
int main_002 () ;
int main_003 () ;


int main () {
	int i, j, k;
	char* tab = "	";
	char* tab_002 = "		";
	float x, y, z;
	double theta, r;
	double m_pi = 3.1415926535;
	double xx, yy;

	j = 0;
	r = 50.0;
	theta +=  ( m_pi * j )/ 16.0;

	for ( i = 'A'; i<'z'; i++ ) {
		xx = r * sin(theta);
		yy = r * cos(theta);
		printf("%scase %d:\r\n", tab, i );
		printf("%sbreak;\r\n", tab_002 );
		j++;
	}
}

int main_003 () {
	FILE *fp;
	int a;

	fp = (FILE*)fopen ("001-switch-case-20220306-001.txt", "w");

	a = main_001 (fp) ;

	return 0;
}

int main_002 () {
	int i;

	for ( i =0; i<10; i++ ) {
		printf("case: %d // %c\r\n", i, (char)i );
	}
}

int main_001 (FILE* fp) {
	int i, j, k, l;
	char *tab = "	";
	int tabnum = 3;

	for( k=0; k<2; k++ )
		fprintf( fp,"%s", tab);
	fprintf( fp,"switch(SLOT_Number) {\r\n");

	for ( l=0; l<10; l++ ) {
		// case start
		for( k=0; k<2; k++ )
			fprintf( fp,"%s", tab);
		fprintf( fp,"case %d:\r\n", l);


		for( k=0; k<3; k++ )
			fprintf( fp,"%s", tab);
		fprintf( fp,"switch(Cursol_Number) {\r\n");

		// a: 65
		for ( i =0; i<4; i++ ) {

			for( k=0; k<3; k++ )
				fprintf( fp,"%s", tab);
			fprintf( fp,"case %d:\r\n", i);

			for( k=0; k<4; k++ )
				fprintf( fp,"%s", tab);

			fprintf( fp,"switch(WM_KEYUP) {\r\n");
			for ( j =65; j<65 + 26; j++ ) {
				for( k=0; k<4; k++ )
					fprintf( fp,"%s", tab);
				fprintf( fp,"case %d: // %c: cursol %d: slot %d:\r\n", j, j, i, l);

				for( k=0; k<4; k++ )
					fprintf( fp,"%s", tab);
				fprintf( fp,"break;\r\n");

			}
			for( k=0; k<4; k++ )
				fprintf( fp,"%s", tab);
			fprintf( fp,"}\r\n");

			for( k=0; k<3; k++ )
				fprintf( fp,"%s", tab);
			fprintf( fp,"break;\r\n");
		}
		for( k=0; k<3; k++ )
			fprintf( fp,"%s", tab);
		fprintf( fp,"}\r\n");

		// break; case end
		for( k=0; k<2; k++ )
			fprintf( fp,"%s", tab);
		fprintf( fp,"break;\r\n");

	}

	for( k=0; k<2; k++ )
		fprintf( fp,"%s", tab);
	fprintf( fp,"}\r\n");


	return 0;
}