#ifndef _FILEWRITER_003_
#define _FILEWRITER_003_
//...
extern int filewriter_003 ();
extern int set_filewriter_003 ();
extern int initialize_filewriter_003 ();
#endif
