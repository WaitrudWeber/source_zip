#ifndef _CONTROL_IMG_LAYER_008_
#define _CONTROL_IMG_LAYER_008_
//...
extern int control_img_layer_008 ();
extern int set_control_img_layer_008 (int ii, int jj, char* word);
extern int initialize_control_img_layer_008 (int ii, int jj, char* word);
#endif
