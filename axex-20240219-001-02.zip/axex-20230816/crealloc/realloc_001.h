#ifndef _REALLOC_001_
#define _REALLOC_001_

extern int reallocation_001 (char** argv, int argc) ;
extern int reallocation_001_02 (char** argv, int argc) ;
extern int reallocation_001_02_loop_1000 (char** argv, int argc) ;

#endif
