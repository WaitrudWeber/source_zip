#ifndef _FILE_NUMBERING_001_H_
#define _FILE_NUMBERING_001_H_

extern int find_numbering_012 (char* filename, int debug_num );
extern int print_param_012 (char* filename, int debug_num );

#endif
