#include <stdio.h>
#include <stdlib.h>

#include "realloc_001.h"

char* reallocation_001_a = (char*) "001-reallocation_001_a-001\.ntxt";
// reslloc_001.cpp
int reallocation_001 (char** argv, int argc) ;
int reallocation_001_02 (char** argv, int argc) ;
int reallocation_001_02_loop_1000 (char** argv, int argc) ;

/*int main (char** argv, int argc) {

	return 0;
}*/

int reallocation_001 (char** argv, int argc) {
	FILE *fp;
	int a, size_num, num, i;
	int* result;

	fp = fopen( reallocation_001_a , "wt" );
	if ( fp == NULL ) {
		printf("fp is null.\r\n" );
		exit(-1);
	}

	num = 14;


	size_num = sizeof(int) * num;
	fprintf( fp,"size_num is %d\r\n", size_num );

	result = (int*) realloc ( result, size_num ) ;

	// allocation size sizeof
	// https://stackoverflow.com/questions/28911789/unable-to-check-memory-allocation-size-with-sizeof
	fprintf( fp, "sizeof ( result ) is %d as sizeof ( result )\r\n", sizeof ( result ) );
	fprintf( fp, "sizeof ( result ) is %d as sizeof ( *result )\r\n", sizeof ( *result ) );
	fprintf( fp, "sizeof ( result ) is %d as sizeof ( sizeof ( *result ) )\r\n", sizeof ( sizeof ( *result ) ) );
	fprintf( fp, "sizeof ( result ) is %d as sizeof ( sizeof ( result ) )\r\n", sizeof ( sizeof ( result ) ) );


	for ( i = 0; i<num; i++ )
		fprintf( fp, " result[%4d]|%p|%d|\r\n", i, &result[i], result[i] );

	fclose(fp );

	return 0;
}


int reallocation_001_02 (char** argv, int argc) {
	FILE *w_fp_02;
	int a, size_num, num, i;
	char* result;

	w_fp_02 = fopen( reallocation_001_a , "wt" );
	if ( w_fp_02 == NULL ) {
		printf("w_fp_02 is null.\r\n" );
		exit(-1);
	}

	num = argc;

	size_num = sizeof(char*) * num;
	fprintf( w_fp_02,"size_num is %d\r\n", size_num );

	result = (char*) realloc ( argv, size_num ) ;

	// allocation size sizeof
	// https://stackoverflow.com/questions/28911789/unable-to-check-memory-allocation-size-with-sizeof
	fprintf( w_fp_02, "sizeof ( result ) is %d as sizeof ( result )\r\n", sizeof ( result ) );
	fprintf( w_fp_02, "sizeof ( result ) is %d as sizeof ( *result )\r\n", sizeof ( *result ) );
	fprintf( w_fp_02, "sizeof ( result ) is %d as sizeof ( sizeof ( *result ) )\r\n", sizeof ( sizeof ( *result ) ) );
	fprintf( w_fp_02, "sizeof ( result ) is %d as sizeof ( sizeof ( result ) )\r\n", sizeof ( sizeof ( result ) ) );

	for ( i = 0; i<num; i++ )
		fprintf( w_fp_02, " result[%4d]|%p|%d|\r\n", i, &result[i], result[i] );

	fclose(w_fp_02 );

	return 0;
}

int reallocation_001_02_loop_1000 (char** argv, int argc) {
	int i, a;
	for ( i=0; i<1000; i++ ) {
		a = reallocation_001_02 ( argv, 2 * i + 14 );
	}
}
