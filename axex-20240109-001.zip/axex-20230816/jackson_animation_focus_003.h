#ifndef _JACSON_ANIMATION_FOCUS__003_
#define _JACSON_ANIMATION_FOCUS__003_

struct struct_animation_focus {
	int start_x;
	int start_y;
	int width;
	int height;
};

struct struct_read_ppm {
	int** ppm_canvas = NULL;
	struct_animation_focus focus;
};

struct struct_animation_fonts_frame {
	int** fonts_sheet = NULL;
	struct_animation_focus focus;
};

struct struct_animation_focus_frame {
	void* draw_number;
	void* draw_effects;
	void* draw_model_frame;
	void* draw_grid;
	void* initialize_parameters_all;
	int **canvas;
	int thread_sleep_real_animation = 33;
	int thread_animation_times = 60;
	int initialized = 0;
	struct_animation_focus focus;
};

typedef struct_animation_focus_frame ANIMATION_FOCUS_FRAME;
typedef struct_animation_focus_frame ANIMATION_FOCUS;
typedef struct_read_ppm READ_PPM;
typedef struct_animation_fonts_frame ANIMATION_FONTS;

int bruch_functions_all ();

int initialize_ppm_fonts () ;
int read_ppm (char* filename, READ_PPM* read_ppm) ;
int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, int** canvas ) ;
int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) ;
int char_ppm_width_height ( char* print_dummy, int num, int* width, int* height ) ;

#endif