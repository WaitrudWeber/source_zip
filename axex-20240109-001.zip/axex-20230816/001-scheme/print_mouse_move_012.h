#ifndef _PRINT_MOUSE_012_
#define _PRINT_MOUSE_012_

extern int print_return_zero () ;
extern int print_return_zero (char* stored_buffer, char* filename, int i, char* buffer_function ) ;
extern int set_stored_buffer (char* lsb);
extern int set_stored_buffer (char* lf);
extern int set_stored_buffer (char* bf);

#endif
