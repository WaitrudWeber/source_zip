#ifndef _READ_CSV__003_
#define _READ_CSV__003_
//...
extern int read_csv_000a_003 ();
extern int set_read_csv_000a_003 (char** argv, int argc);
extern int initialize_read_csv_000a_003 (char** argv, int argc);
#endif
