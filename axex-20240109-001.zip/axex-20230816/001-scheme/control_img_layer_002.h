#ifndef _CONTROL_IMG_LAYER_002_
#define _CONTROL_IMG_LAYER_002_
//...
extern int control_img_layer_002 ();
extern int set_control_img_layer_002 (int ii, int jj, char* word);
extern int initialize_control_img_layer_002 (int ii, int jj, char* word);
#endif
