#ifndef

//
//
int get_cooordinates_on_screen ( vPoint lp, float* lx, float* ly ) ;

#endif
