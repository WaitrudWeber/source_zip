#include "wKickEvent.h"
#include "wKickEventDisplayThreeD.h"
//#include "wKickEventDisplayThreeD.h"
//#include "wKickEventDisplayThreeD.h"

void wKickEventDisplayThreeD::setPid ( int id ) {
	this->pid =id;
}