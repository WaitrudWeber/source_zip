#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "array_counter.h"

int array_count( char *ary );
char* concat( char *head, char *tail );

//int main ( int argc, char *argv[] ) {
//
//	int ac = array_count((char *)"abcdefg");
//
//	printf("count=%d\n", ac );
//
//	return 0;
//}

int array_count( char *ary )
{
	char c;
	int count = 0;
	for ( ;; ) {
		c = *ary;
		if ( c == '\0' ) {
			break;
		}
		ary++;
		count++;
	}

	return count;
}

char* concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
	char ch, ct;

	nh = array_count(head);
	nt = array_count(tail);
	// o if ( nh + nt == 6 ) exit(-1);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		}
		break;
	}

	if ( alloc == 0 ) {
		alloc = 1;
		head = (char *) realloc( head , sizeof( char ) * ( nh + nt ) );
		// x *(head) = 0;
		// o head = tail;
		alloc = 0;
	}

// o	head = tail;
// x	*head = *tail;
// o	ch = *head;
//	exit(-1);

	head += nh;
	for( int i=0; i<nt; i++ ) {
		// x head[ nh + i ] = tail[ i ];
		// x head[ 0 ] = tail[ i ];
		// x *(head + nt + i) = *( tail + i);
		// x *(head + nt + i) = *( tail);
		// x *(head + nt + i) = 0;
		// o head = tail;
		// x *head = *tail;
		// x *head = 0;
		// x *(head) = 0;

		ch = *head;
		ct = *tail;

		// o *(head + 3) = ct;
		// x *( head + nh + i ) = ct;
		// x *head = ct;

		head = tail;

		tail++;
		head++;
	}

//	exit(-1);


	return head;
}


