#ifndef _V_DISPLAY_cONTROLLER_H_
#define _V_DISPLAY_cONTROLLER_H_

#include "vBox.h"
#include "wCanvasController.h"

class vDisplayController {

	private:
		vLine** lines = nullptr;
		vLine** lines_2D = nullptr;
		vAxex_2D AXEX_2D_002[30];
		vAxex_2D** AXEX_2D_001 = nullptr;
		vLine** Line_AXEX = nullptr;
		vCalculation Calc;
		vScreen* screen_001;
		vScreenCG screen_006;
		wCanvasController* canvas = nullptr;
		vPoint* points = nullptr;
		vPoint bones[10];
		int bones_max = 10;
		int bones_max_index = 0;
		vLine** axex_line_3d_002 = nullptr;
		int axex_line_max = 3;

//		vBox box( 0.0f, 0.0f, 100.0f, 100.0f );

	public:
		void Set_Lines (vLine** l );
		void Set_Lines_2D (vLine** l );
		int Approach_vAxex_2D( vPoint* ap ) ;
		int DisplaytheBox() ;
		int DisplayThreeBoxes() ;
		int SetCanvas ( wCanvasController *l_canvas ) ;
		int DisplayTenTriangles () ;
		int DisplayTenTriangles_001 () ;
		int DisplayBones () ;
		int DisplayBones_001 () ;
		int DisplayBones_002 () ;
		int DeleteSelectedPoint ( int number ) ;
		int DeleteSelectedPoint_001 ( int number ) ;
		int MoveSelectedPoint ( int number, int direction ) ;
		int MoveSelectedPoint_001 ( int number, int direction ) ;
		int MoveSelectedPoint_002 ( int number, int direction ) ;
		int DisplayBaseAxex ();
		int SetBaseAxex () ;
		int Set_Caption () ;


} ;

#endif

