#ifndef _CG_SCHEMA_
#define _CG_SCHEMA_

extern void cg_schema ();
extern int *cg_m_mode;
extern int *cg_display; //display or not
extern int *cg_command_char;
extern int *cg_command_keyup;

extern wEvent *p_evt;
extern void cg_setEvent ( wEvent* p_evt );
// 
//
//
//
//


#endif
