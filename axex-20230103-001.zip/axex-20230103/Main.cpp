#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "wTextarea.h"
#include "clipboard.h"
#include "Print.h"	//ADD: 20191228

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"
#include "vCurveCalculation.h"

#include "vIntersection_001.h"
#include "vIntersection.h"

#include "vScreenCG.h"
#include "vScreen.h"
//#include "vLine.h"
//#include "vCircle.h"

#include "vCalculation.h"

#include "vAxex_2D.h"
#include "vDisplayController.h"


#include "vPointStructure.h"
#include "vPointLinear.h"
#include "display_threeD.h"

#include "v3dCalculation.h"

#include "ReturnableParam.h"



int main( int argc, char** argv ) {
	printf("main starts.\r\n");

	v3dCalculation* calc = new v3dCalculation ();
	//calc->calculation_thread_019();
	//calc->calculation_thread_020();
	//calc->calculation_thread_021();
	//calc->calculation_thread_022();
	//calc->calculation_thread_023();
	// x calc->calculation_thread_024();
	// x calc->calculation_thread_025();
	// o calc->calculation_thread_026();
	// o  calc->calculation_thread_027();
	// x  calc->calculation_thread_028();
	// x  calc->calculation_thread_029();
	// x  calc->calculation_thread_030();
	//    calc->calculation_thread_031();
	// o calc->calculation_thread_032();
//	calc->calculation_thread_033();
//	calc->calculation_thread_034();

//	calc->calculation_thread_015();
//	calc->calculation_thread_014();
//	calc->calculation_thread_013();
//	calc->calculation_thread_012();
//	calc->calculation_thread_011();
//	calc->calculation_thread_007();
//	calc->calculation_thread_006();
//	calc->calculation_thread_005();
//	calc->calculation_thread_004();
//	calc->calculation_threed_003();
//	calc->calculation_threed_002();
//	calc->calculation_threed();

//	Sleep(3000);


// o	calc->calculation_thread_035();
// o	calc->calculation_thread_036();
// o	calc->calculation_thread_037();
// o	calc->calculation_thread_038();
// o	calc->calculation_thread_039();
// x 	calc->calculation_thread_040();
// o 	calc->calculation_thread_041();
// o	calc->calculation_thread_042();
// o	calc->calculation_thread_043();
// o	calc->calculation_thread_044();
// o	calc->calculation_thread_045();
// o	calc->calculation_thread_046();
// o	calc->calculation_thread_047();
// o	calc->calculation_thread_048();
		calc->calculation_thread_049();
// o	calc->calculation_thread_050();

	print_point_memories ();
	print_memories_vLine ();

	printf("main ends.\r\n");
	return 0;
}


