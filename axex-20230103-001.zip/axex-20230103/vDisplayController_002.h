#ifndef _V_DISPLAY_cONTROLLER_002_H_
#define _V_DISPLAY_cONTROLLER_002_H_

#include "vBox.h"
#include "wCanvasController.h"

// 1. copy vDisplayController_001.h vDisplayController_001.cpp.
// 2. renumber by use of replace vDisplayController_001 to vDisplayController_002 in them above.
// 3. add Makefile vDisplayController_001.cpp.

class vDisplayController_002 {

	private:
		vPoint bones_001[10];
		int bones_max = 10;
		int bones_max_index = 0;
		wCanvasController* canvas = nullptr;
		vCalculation Calc;
		vScreenCG screen_006;
		vLine** axex_line_3d_002 = nullptr;
		int axex_line_max = 3;
		char* ppm_filename = NULL;
		float*** ppm_img = NULL;
		int ppm_width, ppm_height;

//		vBox box( 0.0f, 0.0f, 100.0f, 100.0f );

	public:

	private:
		int Set_Canvas_Bones () ;
//		int SetCanvasBones_002 () :
//		int SetCanvasBones () :


	public:
		int SetCanvas ( wCanvasController *l_canvas ) ;
		int PrintBones () ;
		int PrintBones_001 () ;
		int DisplayBones_002 () ;
		int DisplayPillar () ;
		int DisplayAxex () ;
		int DisplayLightHouse () ;
		int DisplayBonesGear () ;
		int MoveSelectedPoint_002 () ;
		int MoveSelectedPoint_003 () ;
		int MoveSelectedPoint_004 (int number) ; // 1:up 2:right: depth
		int SetBaseAxex () ;
		int DisplayBaseAxex () ;
		int DisplayBaseAxexFixed () ;
		int SetEye (float x, float y, float z) ;
		int write_ppm_002 (char* filename, float*** img, int width, int height, int flag) ;
		int read_ppm_002 (char* filename, float*** img, int* width, int* height, int flag) ;
		int init_buffer (char* buffer, int size, int flag) ;
		int draw_line_002 (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) ;
		int create_img_buffer (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) ;
		int create_img_buffer_002 (char* filename, int width, int height, int flag) ;
		int create_img_buffer_print_its_adress (char* filename, int width, int height, int flag) ;
		int draw_canvas_buffer () ;
		int DisplaySolid (vPoint center ) ;
		int param_int (char* head, int* width, int* height);
		int param_int ( char* head, int* density );
		char* rechar_string (char* string_002, int num);
		char* mchar_string (char* string_002, int num);
		int mchar_string_001 (char* string_002, int num);
		int mchar_string_002 (char* string_002, int num);
		int realloc_main ();
		int malloc_main ();
		int malloc_main_001 ();
		int malloc_main_002 ();
		int Reflection_Figure (vTriangle *tri, vPoint eye, vPoint direction, vPoint **points, vLine **lines);
		int Reflection_Figure_with_Screen ( ) ;
		int Reflection_Figure_Setting (vTriangle *tri ) ;
		int Reflection_Figure (vTriangle *tri, ReturnableParam *result) ;
		vLine** CreateTriangleLine( vPoint p1, vPoint p2, vPoint p3, vPoint p4, vPoint p5, vPoint p6, ReturnableParam *result );
		int Reflection_Figure_Check_Triangle (vTriangle *tri, ReturnableParam *result) ;
		int Reflection_Figure_Play ();
		int Reflection_Figure_Play_001 ();
} ;

#endif

