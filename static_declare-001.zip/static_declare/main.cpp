#include <stdio.h>
#include <stdlib.h>

#include "main.h"

int** controls = NULL;

int main () {

	controls = (int**) malloc ( sizeof(int*) * 3 );

	return 0;
}

