#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"

vScreen *Lscreen = nullptr;

// We must use 3S-info as Global-info, so, we could touch it everywhere.
//
// Necesarily the below:
// ray:
// screen_tri:
// 
//
//
int get_cooordinates_on_screen ( vPoint lp, float* lx, float* ly ) {
	vCalculation calc;
	vTriangle screen_tri;
	vPoint ray;

	ray = calc.subtract( lp, Lscreen->eye);
	ray = calc.normal(ray);
	// if ( ray.x == 0 && ray.y == 0 && ray.z == 0 ) return -1;

	screen_tri.p1 = Lscreen->C;
	screen_tri.p2 = calc.add( Lscreen->C, Lscreen->U );
	screen_tri.p3 = calc.add( Lscreen->C, Lscreen->V );

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	vPoint point_intersection = intersection->Intersect( screen_tri, Lscreen->eye, ray );

	printf("intersection = ");
	point_intersection.print();
//
//	vPoint result;
//	screen->setPoint(lp);
//	screen->OntheScreen( lp, &result );

	int result = Lscreen->OntheScreen( point_intersection, lx, ly );

	return 0;
}
