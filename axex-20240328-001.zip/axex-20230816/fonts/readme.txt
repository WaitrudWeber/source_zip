freedownload
URL: https://www.dafont.com/bitmap.php
https://www.dafont.com/bitmap.php
C:\Users\Beneton\Documents\source\cg\axex-20230816\fonts\vcr_osd_mono
