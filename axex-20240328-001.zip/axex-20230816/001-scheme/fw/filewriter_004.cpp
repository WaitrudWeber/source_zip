int filewriter_004 ();

filewriter_004 () {
nreturn 1;

}


