int filewriter_007 ();

filewriter_007 () {
nreturn 1;

}


