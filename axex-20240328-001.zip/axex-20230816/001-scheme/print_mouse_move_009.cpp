#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// https://www.ibm.com/docs/ja/i/7.1?topic=ssw_ibm_i_71/rtref/strcat.html

typedef struct build_class_struct {
	char* class_unit_name;
	char* bing_unit_name;
	build_class_struct* sibling = NULL;
	build_class_struct* children = NULL;
} BUILD_CLASS;

int print_mouse_move_009 () ;
extern const char *byte_to_binary_009( int x );

int create_build_class_009 (BUILD_CLASS* bc ) ;
int create_build_class_009 (BUILD_CLASS* bc, char* grp_name ) ;
BUILD_CLASS* recreate_build_class_009 (BUILD_CLASS* bc ) ;

//
int print_mouse_move_009 () {
	int i, a;
	FILE* fp;
	BUILD_CLASS bc;
	BUILD_CLASS* bc_001 = NULL;

	fp = fopen ( "w", "001-filename-001\.txt");

	bc_001 = recreate_build_class_009(bc_001);

	a = create_build_class_009 ( &bc, (char*) "SettleGrid");
	a = create_build_class_009 ( bc_001, (char*) "SettleGrid");

	for ( i = 0; i< 9; i++ ) {
		fprintf ( fp, "%d\r\n", i );
	}

	fclose (fp);
	return 0;
}

//
int create_build_class_009 (BUILD_CLASS* bc, char* grp_name ) {
	int i;
	int c;
	for ( i=0; i<100; i++ ) {
		c = *(grp_name + i );
		printf("c|%4d|%c|%4d|\r\n", c, c, i );
		if ( c == '\0' ) break;
	}

	bc->class_unit_name = (char*) grp_name ;

	return 0;
}

//
BUILD_CLASS* recreate_build_class_009 (BUILD_CLASS* bc ) {

	bc = (BUILD_CLASS*) realloc ( bc, sizeof(BUILD_CLASS) );
	return bc;
}


// https://stackoverflow.com/questions/111928/is-there-a-printf-converter-to-print-in-binary-format
const char *byte_to_binary009
(
    int x
)
{
    static char b[33];
    b[0] = '\0';

    unsigned int z;
    unsigned long z_start;
    z_start = 256*256*256*128;

//    printf("z_start %d\r\n", z_start);

    for (z = 256*256*256*128; z > 0; z >>= 1)
    {
//   	printf("x %d z %d\r\n", x, z );
        strcat(b, ((x & z) == z) ? "1" : "0");
    }

	printf("b%s\r\n", b);
    return b;
}


