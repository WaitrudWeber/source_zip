#ifndef _PRINT_MOUSE_010_
#define _PRINT_MOUSE_010_
int print_mouse_move_010 () ;
int print_mouse_move_010_a (int argc, char** argv ) ;
#endif
