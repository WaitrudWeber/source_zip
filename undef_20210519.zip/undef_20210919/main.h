#ifndef _MINGW_CONFIG_H_
#define _MINGW_CONFIG_H_

#undef t_pid
#define t_pid int

#endif
