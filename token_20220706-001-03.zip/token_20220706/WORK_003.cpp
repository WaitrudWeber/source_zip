#include "WORK_003.h"
#include "WORK_004.h"
void WORK_003::SetWORK_004( WORK004 *lWORK004 ){ 

}
