#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_002.h"
#include "read_csv_003.h"
#include "read_csv_004.h"

static Logging* log_001;
static LOG_001* dlog_001 = NULL;

static char* filename_002 = NULL;
static FILE* rfp = NULL;

int csv_once (int *index, int *end_index ) ;
char get_char_002 (int *index) ;
int endline_002 ( char bc, char c) ;
int puttheword_002 ( int ii, int jj, char* word_002 ) ;
char* m_concat_c_002 ( char* word_002 , int c ) ;
int Set_Logging_read_csv_002 ( Logging* log ) ;
char* gettheword_002_c () ;


char* word_002  = NULL;
char* word_002_c = NULL;

// Add; mode and quotes
// example
int csv_once_002 (int *index, int *end_index ) {
	int i;
	int ii, jj;
	int mode;
	int count = 0;
	char c, bc;
	int word_002_cnt;
	int continued_flg = 0;
	char msg[255];

	dlog_001 = log_001->update_log ( (char*)"int csv_once_002 (int *index, int *end_index ) starts." );

	mode = 0;
	ii=0; jj=0;

	for ( i = *index; i< 10 + *index && i < *end_index; i++ ) {
		count++;
		c = get_char_002 (&i);

		if ( mode == 11 && c == '\"' ) {
			// double quote
			mode = 10;
		} else if ( mode == 0 && c == '\"' ) {
			// double quote
			mode = 11;
			continued_flg = 1;
		} else if ( mode == 10 && c == endline_003 ( bc, c) ) {
			mode = 0;
		} else if ( mode == 10 && c == '\,' ) {
			mode = 0;
			continued_flg = 0;
		} else if ( mode == 0 && c == '\,' ) {
			continued_flg = 1;
		} else if ( mode == 0 && endline_003 ( bc, c) ) {
			continued_flg = 2;
		} 

		bc = c;

		if ( continued_flg != 0 ) {
			word_002_cnt = array_count (word_002);
			if (word_002_cnt > 0 ) word_002[ word_002_cnt - 1 ] = '\0';

			sprintf( msg, "msg continued %d mode %d ii %d jj %d word_002 |%s|\0\0", continued_flg, mode, ii, jj, word_002 );
			dlog_001 = log_001->update_log ( (char*) msg );
			puttheword_004 ( ii, jj, (char*) word_002 );

			if ( continued_flg == 1 ) { ii++; }
			if ( continued_flg == 2 ) { ii =0; jj++; }

			word_002 = NULL;
			continued_flg = 0;
			continue;
		}

		word_002_c = (char*) m_concat_c_002 ( (char*) word_002 , (int) c );
		aFree(word_002);
		word_002 = word_002_c;

		sprintf( msg, "count %d word_002 |%s| word_002_c |%s| c|%d|", count, word_002, word_002_c, c );
		dlog_001 = log_001->update_log ( (char*)msg );
	}

	*index += count;
	dlog_001 = log_001->update_log ( (char*)"int csv_once_002 (int *index, int *end_index ) ends." );
}


//
char get_char_002 (int *index_r ) {
	char dummy[255];
	char rc;
	char msg[255];

	rfp = (FILE*) fopen( filename_002, "rb" );
	if (rfp == NULL) {
		exit(-1);
	}

	sprintf( msg, "SEEK index_r |%d|", *index_r );
	dlog_001 = log_001->update_log ( (char*)msg );

	fseek( rfp, *index_r, SEEK_SET);
	fread ( dummy, 1, 1, rfp );

	fclose(rfp);
	rc = dummy[0];
	return rc;
}

int endline_002 ( char bc, char c) {
	return 0;
}

char* gettheword_002_c () {
	dlog_001 = log_001->update_log ( (char*)"char* gettheword_002_c () starts." );
	dlog_001 = log_001->update_log ( (char*) m_concat( (char*) "word_002_c:", word_002_c ) );
	dlog_001 = log_001->update_log ( (char*)"char* gettheword_002_c () ends." );
	return word_002_c;
}

int puttheword_002 ( int ii, int jj, char* word_002 ) {
	return 0;
}


char* m_concat_c_002 ( char* word_002 , int c ) {
	static char* dummy = NULL;
	char cc;
	char msg[255];

	cc = (char)c;

	if ( dummy == NULL ) {
		dummy = (char*) malloc ( sizeof(char) * 4 );
		if ( dummy == NULL ) return NULL;
	}
	dummy[0] = c;
	dummy[1] = '\0';

	sprintf( msg, "msg dummy |%s| c|%d|", dummy, c );
	dlog_001 = log_001->update_log ( (char*)msg );

	return m_concat( word_002, dummy );
}

//
int Set_Logging_read_csv_002 ( Logging* log ) {
	log_001 = (Logging*)log;
	return 0;
}

int Set_Filename_002 ( char* filename ) {
	filename_002 = (char*)filename;
	return 0;
}
