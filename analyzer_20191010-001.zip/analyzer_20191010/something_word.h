
extern int keyup_something_word ( HWND hwnd, int key, int* mode );
extern int something_word_escape();
extern int something_word_initialize ();
extern void paint_something_word_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern void getchar_something_word_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern int wmpaint_somtehing_word_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam );

