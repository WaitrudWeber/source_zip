#include <windows.h>
#include <iostream>

#include "array_counter.h"
#include "parse.h"

#include "list_directory.h"

using namespace std;

void stack_lootin( int depth, char* char_string ) ;
void concat_tests () ;

//
//
//
//
//
int main ( int argc, char** argv ) {

//	concat_tests();
//
//	char* char_string = m_concat ("a", "b" );
//	printf("char_string:%s\r\n", char_string );
//	stack_lootin( 1, char_string );

	char* c_a = (char*)"c:\\aaa\\*";
	int n = 0;

//	char** split_a = split("*.php", '*', &n );
//	for ( int i=0; i<n; i++ ) {
//		printf("i: %d %s\r\n", i, split_a[i] );
//	}

	int start_index = m_start_with( c_a, (char*)"\\" );
	printf("start_index: %d\r\n", start_index );

	FileControler fc;
	//fc.List_Files( ".\\*" );
	//fc.List_Files( (char *)"C:\\laravel_src\\blog\\*" );
	//fc.print_strings ();

	char** files = (char**) fc.get_files ( ".\\*" );
	fc.print_strings ();

	// fc.List_Files( "C:\\laravel_src\\blog\\*" );
	// fc.List_Files( "c:\\aaa\\*" );
	exit( -1 );

	int index = m_last_with( c_a, (char*)"\\" );
	printf("index: %d\r\n", index );

	// substring ( start, length ) ;
	char* string_directory = substring( c_a, 0, index );
	printf("string_directory: %s\r\n", string_directory );

	// filename
	printf ( "%d\r\n", file_type( "filename.php", "*.php" ) );		// 1
	printf ( "%d\r\n", file_type( "filename.php-", "*.php" ) );  	// -1
	printf ( "%d\r\n", file_type( "filename.php-", "*.php*" ) ); 	// 1

//
//	int a_index = m_aaa();
//	m_aaa();
//

	// 
	// copy by windows api
	// https://docs.microsoft.com/en-us/windows/desktop/api/winbase/nf-winbase-copyfile
	CopyFile( "specification.txt", "tmp-specification.txt", TRUE );
	return 0;
}

void concat_tests () {
	char* m_a;
	m_a = m_concat ( "C:\\laravel_src\\blog\\app\\", "Console" );
	printf("m_a:%s\r\n", m_a  );
}

void stack_lootin( int depth, char* char_string ) {

	if ( depth >= 1000 ) {
		return;
	}
	printf( "depth: %d char_string: %s\r\n", depth, char_string );

	depth++;
	char* char_concat = m_concat ( char_string, "g" );
	stack_lootin ( depth, char_concat );
}




