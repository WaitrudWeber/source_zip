#include <windows.h>
#include <math.h>
#include <iostream>
#include <mmsystem.h>
//#include <amstream.h>
//#include <mmstream.h>

#include "array_counter.h"
#include "sender.h"
#include "Print.h"

#include "sounds-011.h"

//#pragma comment(lib, "Winmm.lib")

using namespace std;
//dummy
HWAVEOUT am_waveOut; // Handle to sound card output
WAVEFORMATEX am_waveFormat; // The sound format
WAVEHDR am_waveHeader; // WAVE header for our sound data
HANDLE am_done; // Event Handle that tells us the sound has finished being played.


int sbuffer[11025 * 2];

//dummy
void play_001();

SoundEffect* sound_000 = nullptr;
SoundEffect* sound_001 = nullptr;
SoundEffect* sound_002 = nullptr;
SoundEffect* sound_003 = nullptr;
SoundEffect* sound_004 = nullptr;
SoundEffect* sound_005 = nullptr;
SoundEffect* sound_006 = nullptr;
SoundEffect* sound_007 = nullptr;
SoundEffect* sound_008 = nullptr;
SoundEffect* sound_009 = nullptr;
SoundEffect* sound_010 = nullptr;
SoundEffect* sound_011 = nullptr;
SoundEffect* sound_012 = nullptr;
SoundEffect* sound_013 = nullptr;
SoundEffect* sound_014 = nullptr;
SoundEffect* sound_015 = nullptr;
SoundEffect* sound_016 = nullptr;
SoundEffect* sound_017 = nullptr;
SoundEffect* sound_018 = nullptr;
SoundEffect* sound_019 = nullptr;
SoundEffect* sound_020 = nullptr;
SoundEffect* sound_021 = nullptr;
SoundEffect* sound_022 = nullptr;
SoundEffect* sound_023 = nullptr;
SoundEffect* sound_024 = nullptr;

// Very Thanks to https://stackoverflow.com/questions/19894384/simple-sounds-in-c?newreg=f9687df41b574a8f8f34db83b5c4a16a
// > mingw32-g++.exe main.o .\sounds-011.o -o winmain_011.exe
int main() {
	err_msg_001("main starts.\r\n");

sound_000 = new SoundEffect ( sbuffer, 2200 * 2 );
sound_001 = new SoundEffect ( sbuffer, 2383 * 2 );
sound_002 = new SoundEffect ( sbuffer, 2566 * 2 );
sound_003 = new SoundEffect ( sbuffer, 2749 * 2 );
sound_004 = new SoundEffect ( sbuffer, 2932 * 2 );
sound_005 = new SoundEffect ( sbuffer, 3115 * 2 );
sound_006 = new SoundEffect ( sbuffer, 3298 * 2 );
sound_007 = new SoundEffect ( sbuffer, 3481 * 2 );
sound_008 = new SoundEffect ( sbuffer, 3664 * 2 );
sound_009 = new SoundEffect ( sbuffer, 3847 * 2 );
sound_010 = new SoundEffect ( sbuffer, 4030 * 2 );
sound_011 = new SoundEffect ( sbuffer, 4213 * 2 );
sound_012 = new SoundEffect ( sbuffer, 4396 * 2 );
sound_013 = new SoundEffect ( sbuffer, 4579 * 2 );
sound_014 = new SoundEffect ( sbuffer, 4762 * 2 );
sound_015 = new SoundEffect ( sbuffer, 4945 * 2 );
sound_016 = new SoundEffect ( sbuffer, 5128 * 2 );
sound_017 = new SoundEffect ( sbuffer, 5311 * 2 );
sound_018 = new SoundEffect ( sbuffer, 5494 * 2 );
sound_019 = new SoundEffect ( sbuffer, 5677 * 2 );
sound_020 = new SoundEffect ( sbuffer, 5860 * 2 );
sound_021 = new SoundEffect ( sbuffer, 6043 * 2 );
sound_022 = new SoundEffect ( sbuffer, 6226 * 2 );
sound_023 = new SoundEffect ( sbuffer, 6409 * 2 );
sound_024 = new SoundEffect ( sbuffer, 6592 * 2 );
sound_000->Play();
//sound_001->Play();
sound_002->Play();
sound_003->Play();
//sound_004->Play();
sound_005->Play();
//sound_006->Play();
sound_007->Play();
sound_008->Play();
//sound_009->Play();
sound_010->Play();
sound_011->Play();
sound_012->Play();
sound_013->Play();
sound_014->Play();
sound_015->Play();
sound_016->Play();
sound_017->Play();
sound_018->Play();
sound_019->Play();
sound_020->Play();
sound_021->Play();
sound_022->Play();
sound_023->Play();
sound_024->Play();

	printf("main ends.\r\n");
	err_msg_001("main ends.\r\n");
	return 0;
}


void play_001()
{
	if (waveOutOpen(&am_waveOut, 0, &am_waveFormat, (DWORD) am_done, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) 
	{
		 cout << "Sound card cannot be opened." << endl;
		return;
	}
}

//https://docs.microsoft.com/en-us/previous-versions/windows/desktop/api/mmstream/nn-mmstream-imultimediastream
//https://docs.microsoft.com/en-us/windows/win32/directshow/audio-streaming-sample-code
//https://www.exefiles.com/en/h/amstream-h/
//https://www.exefiles.com/en/h/mmstream-h/
/*HRESULT RenderStreamToDevice(IMultiMediaStream *pMMStream)
{
    WAVEFORMATEX wfx;
    #define DATA_SIZE 5000

    IMediaStream        *pStream = NULL;
    IAudioStreamSample  *pSample = NULL;
    IAudioMediaStream   *pAudioStream = NULL;
    IAudioData          *pAudioData = NULL;

    HRESULT hr = pMMStream->GetMediaStream(MSPID_PrimaryAudio, &pStream);
    if (FAILED(hr))
    {
        return hr;
    }

	return S_OK;
}*/
