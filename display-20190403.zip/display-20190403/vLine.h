#ifndef _VLINE_H_
#define _VLINE_H_
class vLine {
	public :
		vPoint *p1, *p2;

	public:
		vLine ();
		void setLine ( vPoint* ap1, vPoint* ap2 ) ;
		void print () ;

};

#endif