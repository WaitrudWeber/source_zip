#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"

int main () {

	int a = read_csv(".\\001-csv-20210210-001\.txt");
	int b = replace_csv ( ".\\001-form-20210211-001\.txt");

	return 0;
}
