#ifndef _VSCHEEN_H_
#define _VSCHEEN_H_

#include "vPoint.h"
#include "vTriangle.h"

class vScreen {

	public:
		vScreen ( );
		// vPoint Intersect( vTriangle tri, vPoint eye, vPoint ray );
		void put_U ( vPoint a) ;
		void put_V ( vPoint b) ;
		void put_C ( vPoint c) ;
		void put_Up ( vPoint up) ;
		void LookAt ( vPoint lookat );
		void setEye ( vPoint eye );
		void subtract( vPoint a, vPoint b, vPoint* result);
		void normal( vPoint *a );
		vPoint cross ( vPoint a, vPoint b);
		void setWidth( int w );
		void setHeight( int h );
		int getWidth();
		int getHeight();
		vPoint getRight();
		void calculation_uv_up ();
		void calculation ();
		void calculation_up_UV ();
		int OntheScreen ( vPoint lp, float* x, float* y ) ;
		int OntheScreen ( vPoint lp, vPoint* result ) ;
		void OntheScreen ( float* x, float* y);
		void OntheScreen ( vPoint* x, vPoint* y);
		void Set_HowFarFrmEye (float howfarfrmeyee);
		int get_cooordinate_on_screen ( vPoint lp, float* lx, float* ly ) ;

	private:
		vCalculation* this_calc = nullptr;
		//vPoint C;
		vPoint X; // SCREEN( X, Y )
		vPoint Y;
		vPoint u, v; // w is up.
		float width = 0.0f, height = 0.0f;

	public:
		vPoint C;
		vPoint U;
		vPoint V;
		vPoint eye;
		vPoint up;
		vPoint lookat;
		vPoint LeftTop;
		vPoint RightBottom;
		vTriangle screen_tri;
		float HowFarFromEye;

};

#endif

