#include <stdio.h>
#include "vSoundBuffer_001.h"

//
char vSoundBuffer_001::getBuffer( int index ) {
	return SoundBuffer[index];
}



