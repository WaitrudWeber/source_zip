#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "log_001.h"

#include "csv_text_001.h"
#include "settle_grid_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_002.h"
#include "winmainthread_005a_001.h"
#include "winmainthread_005a_000.h"

#include "winmainthread_005a_003.h"

extern char* filename_winmainthread_005a_003_ = (char*)"winmainthread_005a_003.txt";
extern char* filename_winmainthread_005a_003_01_ = (char*)"winmainthread_005a_003-01.txt";
extern char* filename_winmainthread_005a_003_02_ = (char*)"winmainthread_005a_003-02.txt";

int winmainthread_005a_003 ();
int set_winmainthread_005a_003 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_003 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int Initialize_firstset_winmainthread_005a_01 () ;
int Caribration_winmainthread_005a_01 () ;
int Create_base_funcs_winmainthread_005a_01 () ;
int Create_base_cls_winmainthread_005a_01 ( char* clsname_h_cpp ) ;
int Log_Add ( char* func_name_log ) ;

int winmainthread_005a_003 () {
	return 1;

}


int winmainthread_005a_set_003 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_003 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int Initialize_firstset_winmainthread_005a_01 () {
	Log_Add( "int Initialize_firstset_winmainthread_005a_01 () starts.\r\n");

	log_001.init_log ();
	log_001.start_log ();
	log_001.Set_Filename( (char*)".\\001-filename-20230710-001\.txt");

	Set_Logging_read_csv_004 (&log_001);
	Set_Logging_read_csv_002 (&log_001);
	Set_Logging_read_csv_005 (&log_001);
	Set_Param_005a_log (&log_001);
	Set_Param_005a_base( (char***)&param_d[0][0][0] );

	Log_Add( "int Initialize_firstset_winmainthread_005a_01 () ends.\r\n");
	return 1;
}



int Caribration_winmainthread_005a_01 () {
	Log_Add( "int Caribration_winmainthread_005a_01 () starts.\r\n");

	index = 0;
	Set_Logging_read_csv_004 (&log_001);
	Set_Logging_read_csv_002 (&log_001);
	file_all_size ( "001-filename-20231002-01-b\.txt", &end_index ) ;
	Set_Filename_002 ( "001-filename-20231002-01-b\.txt" );
	puttheword_004 ( 1, 1, (char*) "aaa" ) ;
	puttheword_004 ( 8, 8, (char*) "bbb" ) ;
	Set_Read_Bar () ;

	Log_Add( "int Caribration_winmainthread_005a_01 () ends.\r\n");

	return 0;
}



int Create_base_funcs_winmainthread_005a_01 () {
	FILE *fp;
	int i, j, k, num;
	Log_Add ("int Create_base_cls_winmainthread_005a_01 ( char* clsname_h_cpp ) starts.");

	fp = fopen ( filename_winmainthread_005a_003_01_, "w");

	for ( i = 0; i<10; i++ ) {
		for ( j = 0; j<10; j++ ) {
			for ( k = 0; k<10; k++ ) {
				num = i*100 + j*10 + k;
				fprintf( fp, "void functionn_name_%05d () {\r\n", num ) ;
				fprintf( fp, "	//($key_up, %d, %d, %d)\r\n", i , j, k ) ;
				fprintf( fp, "}\r\n", num ) ;
			}
		}
	}

	fclose (fp);


	Log_Add ("int Caribration_winmainthread_005a_01 () ( char* clsname_h_cpp ) ends.");
	return 0;
}

int Create_base_cls_winmainthread_005a_01 ( char* clsname_h_cpp )  {
	FILE *fp;
	int i, j, k, num;

	Log_Add ("int Create_base_cls_winmainthread_005a_01 ( char* clsname_h_cpp ) starts.");

	fp = fopen ( filename_winmainthread_005a_003_02_, "w");
	for ( i = 0; i<10; i++ ) {
		for ( j = 0; j<10; j++ ) {
			for ( k = 0; k<10; k++ ) {
				num = i*100 + j*10 + k;
				fprintf( fp, "%s_%05d :: clsname_%05d () {\r\n", clsname_h_cpp, i*10 + j , num ) ;
				fprintf( fp, "	return 0;\r\n" ) ;
				fprintf( fp, "}\r\n" ) ;
			}
		}
	}

	fclose (fp);

	Log_Add ("int Create_base_cls_winmainthread_005a_01 ( char* clsname_h_cpp ) ends.");
}

int Log_Add ( char* func_name_log ) {
	FILE *log_fp;
	log_fp = fopen ( filename_winmainthread_005a_003_, "a");
	fprintf( log_fp, "|%s|\r\n", func_name_log ) ;
	fclose (log_fp);
}

