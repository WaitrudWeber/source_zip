#ifndef _WINMAINTHREAD__000_
#define _WINMAINTHREAD__000_
//...
extern int winmainthread_005a_000 ();
extern int set_winmainthread_005a_000 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_winmainthread_005a_000 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

extern int Get_Param_005a( int i, int j, char** param  ) ;
extern int Set_Param_005a( int i, int j, char* param  ) ;
extern int Set_Param_005a_base( char*** lp ) ;
extern int Set_Param_005a_log( Logging* llog ) ;

extern int Inc_param_a ();
extern int Dec_param_a ();

#endif
