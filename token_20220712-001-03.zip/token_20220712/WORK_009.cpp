#include "WORK_009.h"
#include "WORK_000.h"
void WORK_009::SetWORK_000( WORK000 *lWORK000 ){ 

}
