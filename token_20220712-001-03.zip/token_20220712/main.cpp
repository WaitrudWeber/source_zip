#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include <stdlib.h>
#include <time.h>


#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"
#include "replace_main.h"

typedef struct html_struct {
	int a;
	int b;
	char* tagname =NULL;
	char* between =NULL;
	char* inside =NULL;
	html_struct* next =NULL;
	html_struct* prev =NULL;
} HTMLTAG;

int replace_main (int argc, char** argv ) ;
int copyof_test () ;
int initialize_parse_test () ;
int read_sourcecode (char* filename ) ;

int main_002_test (int argc, char** argv ) ;
int main_006 (int argc, char** argv );
int main_007 (int argc, char** argv );
int main_008 (int argc, char** argv );
int main_009 (int argc, char** argv );
int main_010 (int argc, char** argv );
int main_011 (int argc, char** argv );
int main_012 (int argc, char** argv );
int main_013 (int argc, char** argv );
int main_014 (int argc, char** argv );
int main_015 (int argc, char** argv );
int main_016 (int argc, char** argv );
int main_017 (int argc, char** argv );
int main_018 (int argc, char** argv );
int main_019 (int argc, char** argv );
int main_020 (int argc, char** argv );
int main_021 (int argc, char** argv );
int main_022 (int argc, char** argv );
int main_023 ( int argc, char** argv ) ;
int main_024 ( int argc, char** argv ) ;
int main_025 ( int argc, char** argv ) ;
int main_026 ( int argc, char** argv ) ;
int main_027 ( int argc, char** argv ) ;
int main_028 ( int argc, char** argv ) ;
int main_029 ( int argc, char** argv ) ;
int main_030 ( int argc, char** argv ) ;
int main_031 ( int argc, char** argv ) ;
int main_032 ( int argc, char** argv ) ;
int main_033 ( int argc, char** argv ) ;
int main_034 ( int argc, char** argv ) ;

int read_html (char* filename ) ;
int read_html_001 (char* filename ) ;
int read_source_cpp (char* filename ) ;
int read_source_cpp_001 (char* filename ) ;
int read_source_cpp_002 (char* filename ) ;
int read_source_cpp_003 (char* filename ) ;
int read_source_cpp_004 (char* filename ) ;

char* allocation = NULL;

char* html_tag[255];
HTMLTAG** b_html=NULL;
int b_html_count = 0;
HTMLTAG a_html_001;


int print_function_001 ( int i ) ;
int print_function_002 ( int i ) ;
int print_function_cpp ( int i ) ;

// 20200407
int fileallsize ( char* filename ) ;
int read_html_tag(char* filename ) ;
int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) ;

// 20220408
// 20220409
int analyze_html_inside( char* inside, HTMLTAG* html, int* result ) ;

// 20220410
int analyze_html_between ( char* between, HTMLTAG* html, STRUCT_FILE* structure_fp ) ;

// 20220413
int read_html_tag_001(char* filename ) ;
int get_between( char* key_buffer, int max_buffer, HTMLTAG* html, STRUCT_FILE* sfp ) ;

// 20220419
int suits_tagname( char* k_buffer, char* tagname ) ;

int a_function (char* html_string, HTMLTAG* tag_html) ;
char* get_array_string (char* a_string, int num) ;
int a_get_inside( char* key_buffer, int max_buffer, char* end_string, char* tag_string ) ;
int a_get_between( char* key_buffer, int max_buffer, HTMLTAG* html, char* html_tag ) ;

int a_function (char* html_string, HTMLTAG* tag_html) ;
int b_function (char* html_string, HTMLTAG* tag_html) ;

int read_html_tag_002(char* filename ) ;
char* get_array_string_001 (char* a_string, int num, int length ) ;
char* get_array_string_002 (char* a_string, int index, int length ) ;
char* get_array_string_003(char* a_string, int index, int length ) ;
char* get_array_string_004(char* a_string, int index, int length ) ;

char* translation_001 (char* a_string, int index, int length ) ;

//
// get_array_string_003->get_array_string_004
int main ( int argc, char** argv ) {

	char* string_all = read_all ( ".\\001-i-block-20220712-001\.txt" );
	printf("string_all: |%p|\r\n%s\r\n", string_all, string_all );

	char* string_all_001 = read_all (".\\001-for-20220712-001\.txt");
	printf("string_all_001: |%p|\r\n%s\r\n", string_all_001, string_all_001 );

//	char* c_replace = m_replace( string_all_001, "(i block)", string_all );
//	printf("c_replace:\r\n %s\r\n", c_replace );

	return 0;
}

// get_array_string_003->get_array_string_004
int main_034 ( int argc, char** argv ) {
	// call onece next reset.
	int a = read_html_tag_002(".\\001-20220407-002.txt");

	printf("b_html |%d| b_html_count |%d|\r\n", b_html, b_html_count );
	for ( int i=0; i<b_html_count; i++ ) {
		if ( b_html[i] != NULL )
			printf("b_html[%d]=|%p| next|%p|\r\n", i, b_html[i], b_html[i]->next );
	}

	return 0;
}

//
int main_033 ( int argc, char** argv ) {

	// get_array_string_003
	char* a = get_array_string_004 ( (char*)"<p>message is well.</p>", 3, 7 );
	printf("a|%s|\r\n", a );

	return 0;
}

//x
int main_032 ( int argc, char** argv ) {
	print_socket_msg = 0;
	level_error_msg = 3;

	net_msg_101("err_msg_002: int main ( int argc, char** argv ) starts. \r\n");
	net_msg_101("err_msg_002: int main ( int argc, char** argv ) ends. \r\n");

	printf("it is written by use of printf.\r\n");

	return 0;
}

// x
int main_031 ( int argc, char** argv ) {
	print_socket_msg = 0;
	level_error_msg = 3;

	err_msg_002("err_msg_002: int main ( int argc, char** argv ) starts. \r\n");
	err_msg_002("err_msg_002: int main ( int argc, char** argv ) ends. \r\n");

	printf("it is written by use of printf.\r\n");

	return 0;
}


int main_030 ( int argc, char** argv ) {
	print_socket_msg = 0;
	level_error_msg = 3;

//	err_msg_001("int main ( int argc, char** argv ) starts. \r\n");
//	err_msg_001("int main ( int argc, char** argv ) ends. \r\n");

//	err_msg_002("err_msg_002: int main ( int argc, char** argv ) starts. \r\n");
//	err_msg_002("err_msg_002: int main ( int argc, char** argv ) ends. \r\n");

//	err_msg_003("err_msg_003: int main ( int argc, char** argv ) starts. \r\n");
//	err_msg_003("err_msg_003: int main ( int argc, char** argv ) ends. \r\n");

//	err_msg_101("err_msg_101: int main ( int argc, char** argv ) starts. \r\n");
//	err_msg_101("err_msg_101: int main ( int argc, char** argv ) ends. \r\n");

	err_msg_004("err_msg_004: int main ( int argc, char** argv ) starts. \r\n");
	err_msg_004("err_msg_004: int main ( int argc, char** argv ) ends. \r\n");

	return 0;
}

int main_029 ( int argc, char** argv ) {

	// call onece next reset.
	int a = read_html_tag_002(".\\001-20220407-002.txt");

	printf("b_html |%d|\r\n", b_html );
	for ( int i=0; i<b_html_count; i++ ) {
		if ( b_html[i] != NULL )
			printf("b_html[%d]=|%p| next|%p|\r\n", i, b_html[i], b_html[i]->next );
	}

	return 0;
}


int main_028 ( int argc, char** argv ) {

	STRUCT_FILE structure_fp;
	int file_end;
	FILE* fp;
	char* p_dummy;
	int i;
	int result;
	char key_buffer[255];
	HTMLTAG* html=NULL;
	HTMLTAG** a_html=NULL;
	int html_count = 0;
	int html_max_count = 0;

	printf("int read_html_tag(char* filename ) starts.\r\n");

	fp = fopen("001-20220702-001.txt", "rb");
	printf("1 fp|%d|\r\n", fp);
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	printf("file_size:%d\r\n", file_end);
	printf("2 fp|%d|\r\n", fp);


	if (fp == NULL ) {
		printf("fp is NULL , so, it exits.\r\n");
		exit(-1);
	}

	for ( i =0; i<file_end; i++ ) {
		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
	}

	return 0;
}

int main_027 ( int argc, char** argv ) {

	for ( int i=0; i<10; i++ ) {
		printf("	scheme_\[%03d\].txt_value = \"001-20220612-%03d.txt\";\r\n", i, i + 60 );
		printf("	scheme_\[%03d\].case_value  = \"case %d:\";\r\n", i, i + 60 );
	}

	return 0;
}

int main_025 ( int argc, char** argv ) {

	//char* a = translation_001 ( (char*)"<p>message is well.</p>", 3, 7 );
	char* a = get_array_string_003 ( (char*)"<p>message is well.</p>", 3, 7 );
	printf("a|%s|\r\n", a );

	return 0;
}

//
int main_026 ( int argc, char** argv ) {

	// call onece next reset.
	int a = read_html_tag(".\\001-20220407-002.txt");
//	int a = read_html_tag_002(".\\001-20220407-002.txt");

	printf("b_html |%d|\r\n", b_html );
	for ( int i=0; i<b_html_count; i++ ) {
		if ( b_html[i] != NULL )
			printf("b_html[%d]=|%p| next|%p|\r\n", i, b_html[i], b_html[i]->next );
	}

	return 0;
}

int main_024 ( int argc, char** argv ) {

	//char* a = translation_001 ( (char*)"<p>message is well.</p>", 3, 7 );
	char* a = get_array_string_003 ( (char*)"<p>message is well.</p>", 3, 7 );
	printf("a|%s|\r\n", a );

	return 0;
}

//
char* get_array_string_003(char* a_string, int index, int length ) {
	char dummy[255];
	char* result = NULL;
	int i;
	err_msg_001("char* get_array_string_003(char* a_string, int index, int length ) starts.\r\n");
	err_msg_001("|%s|%d|%d|\r\n", a_string, index, length );

	int max = array_count(a_string);
	for ( i=index; i<max && i<255 && i<index + length; i++) {
		dummy[ i - index ] = a_string[i];
	}

	dummy[ i - index ] = '\0';
	err_msg_001("|%s|%d|%d|%d|\r\n", a_string, i, index, length );
	result = (char*)copyof ( dummy );
	err_msg_001("result:|%s|\r\n", result);

	err_msg_001("char* get_array_string_003(char* a_string, int index, int length ) ends.\r\n");
	return result;
}

//
char* get_array_string_004(char* a_string, int index, int length ) {
	char dummy[255];
	char* result = NULL;
	int i;
	printf("char* get_array_string_004(char* a_string, int index, int length ) starts.\r\n");
	printf("|%s|%d|%d|\r\n", a_string, index, length );

	int max = array_count(a_string);
	for ( i=index; i<max && i<255 && i<index + length; i++) {
		dummy[ i - index ] = a_string[i];
	}

	dummy[ i - index ] = '\0';
	printf("|%s|%d|%d|%d|\r\n", a_string, i, index, length );
	result = (char*)copyof_002 ( dummy );
	printf("result:|%s|\r\n", result);

	printf("char* get_array_string_004(char* a_string, int index, int length ) ends.\r\n");
	return result;
}


//
char* translation_001(char* a_string, int index, int length ) {

	printf("|%s|%d|%d|\r\n", a_string, index, length );

	return NULL;
}


int main_023 ( int argc, char** argv ) {

	// call onece next reset.
	int a = read_html_tag_002(".\\001-20220407-002.txt");

	printf("b_html |%d|\r\n", b_html );
	for ( int i=0; i<b_html_count; i++ ) {
		if ( b_html[i] != NULL )
			printf("b_html[%d]=|%p| next|%p|\r\n", i, b_html[i], b_html[i]->next );
	}

	return 0;
}

int main_022 ( int argc, char** argv ) {

	// call onece next reset.
	int a = read_html_tag(".\\001-20220407-002.txt");

	printf("b_html |%d|\r\n", b_html );
	for ( int i=0; i<b_html_count; i++ ) {
		if ( b_html[i] != NULL )
			printf("b_html[%d]=|%p| next|%p|\r\n", i, b_html[i], b_html[i]->next );
	}

	return 0;
}

// https://waitrudweber.hatenablog.com/entry/2022/05/02/080153
// https://waitrudweber.hatenablog.com/entry/2022/05/01/120200?_ga=2.214514839.1097983736.1651373956-1099287052.1648278363
// int a = read_html_tag(".\\001-20220407-002.txt");
int main_021 ( int argc, char** argv ) {

	char* string_all = read_all ( ".\\001-elements-20220501-032\.txt" );
	printf("string_all:%s\r\n", string_all);

	char* c_replace = m_replace( string_all, "create_img_buffer_002 (\"", "create_img_buffer_003 (\"" );

	printf("c_replace:%s\r\n", c_replace);

	return 0;
}

// https://waitrudweber.hatenablog.com/entry/2022/05/01/120200?_ga=2.214514839.1097983736.1651373956-1099287052.1648278363
int main_020 ( int argc, char** argv ) {

	char* string_all = read_all ( ".\\001-elements-20220501-032\.txt" );
	printf("string_all:%s\r\n", string_all);

	char* c_replace = m_replace( string_all, "\"", "|" );

	printf("c_replace:%s\r\n", c_replace);

	return 0;
}

// https://waitrudweber.hatenablog.com/entry/2022/05/01/120200?_ga=2.214514839.1097983736.1651373956-1099287052.1648278363
int main_019 ( int argc, char** argv ) {

	char* string_all = read_all ( ".\\001-elements-20220501-032\.txt" );
	printf("string_all:%s\r\n", string_all);

// x	char* c_replace = m_replace( string_all, "create_img_buffer_002 (\".\\001-20220426-001\.txt\", 320, 180, 1) ;", "create_img_buffer_003 (\".\\001-20220426-001\.txt\", 320, 180, 1) ;" );
	char* c_replace = m_replace( string_all, "create_img_buffer_002", "create_img_buffer_003" );
//	char* c_replace = m_replace( string_all, "bb", "dd" );

	for ( int i=0; i<10; i++ ) {
		printf("i=%d\r\n", i);
	}

	printf("c_replace:%s\r\n", c_replace);

	return 0;
}

int main_018 ( int argc, char** argv ) {

	int a = read_html_tag(".\\001-20220407-002.txt");

	return 0;
}


int main_017 ( int argc, char** argv ) {
	char* char_string;
	char four_string[4];
	float b;
	float *pb;
	int a;
	FILE *wfp;
	HTMLTAG htag;
	HTMLTAG *phtag;

	b= 187.938267f;
// x	four_string = (char [4])b;
	char_string = (char*) four_string;
// x	char_string = (char*) b;
// x	htag=(HTMLTAG)b;
// *	phtag=(HTMLTAG*)b;

	phtag = (HTMLTAG*)&b;
// x	four_string = (const char*)&b;
	char_string = (char*)&b;

	a = 0xFE;
	wfp = fopen(".\\001-20220407-002.fb", "wb");
	fwrite( char_string, sizeof(char), array_count(char_string), wfp);
	fwrite( &b, sizeof(float), 1, wfp);
	fwrite( &a, sizeof(int), 1, wfp);

	fclose(wfp);

	return 0;
}

int main_016 ( int argc, char** argv ) {
	int a = read_html_tag(".\\001-20220407-002.txt");
	return 0;
}

int main_015 ( int argc, char** argv ) {
	int a = fileallsize(".\\001-20220407-001.txt");
	return 0;
}


//
int read_html_tag_002(char* filename ) {

	printf("int read_html_tag_002(char* filename ) starts.\r\n");

	char* string_all = read_all_002 ( filename );

	int a = a_function ( string_all, &a_html_001);
	//int b = b_function ( string_all, &a_html);

	printf("int read_html_tag_002(char* filename ) ends.\r\n");
	return 0;
}

//
int b_function (char* html_string, HTMLTAG* tag_html) {
	int i;
	char* p_dummy;
	int file_end;

	printf("int b_function (char* html_string, HTMLTAG* tag_html) starts.\r\n");
	file_end = array_count(html_string);
	for ( i =0; i<file_end - 4; i++ ) {
		err_msg_001("i %d |%s|\r\n", i, html_string );
		p_dummy = (char*)get_array_string_003 ( html_string, i, 4); // replace of a file pointer.
		p_dummy[4] = '\0';
		printf("p_dummy|%s| i: %d/%d\r\n", p_dummy, i, file_end);
	}

	printf("int b_function (char* html_string, HTMLTAG* tag_html) ends.\r\n");
	return 0;
}


//
int a_function (char* html_string, HTMLTAG* tag_html) {
	int file_end;
	FILE* fp;
	char* p_dummy;
	int i;
	int result;
	char key_buffer[255];
	HTMLTAG* html=NULL;
	HTMLTAG** a_html=NULL;
	int html_count = 0;
	int html_max_count = 0;
	int max_buffer = 0;

	printf("int a_function (char* html_string, HTMLTAG* tag_html) starts.\r\n");

	file_end = array_count(html_string);

	for ( i =0; i<file_end; i++ ) {
		p_dummy = (char*)get_array_string_003 ( html_string, i, 4); // replace of a file pointer.
		p_dummy[4] = '\0';
		printf("p_dummy|%s| i: %d/%d\r\n", p_dummy, i, file_end);

		if ( m_start_with ( (char*)p_dummy, "<" ) == 1 ) {
			printf("We found the |<| index %d fp|%d|.\r\n", i, fp );
			result = a_get_inside( key_buffer, 255, ">", html_string ); // replace of a file info.
			printf("key_buffer |%s| result |%d|\r\n", key_buffer, result );
			printf("001 html_count %d >= html_max_count %d\r\n", html_count, html_max_count );
			// alloc max count
			if ( html_count >= html_max_count ) {
				if (html_max_count==0) html_max_count=8;
				else html_max_count *= 2;
				a_html = (HTMLTAG**) realloc ( a_html, sizeof(HTMLTAG*) * html_max_count );
				if ( a_html == NULL ) {
					printf("it cannot allocate the memory for the a_html(HTMLTAG**).\r\n");
					exit(-1);
				}
				printf("realloc: html_count %d / html_max_count %d\r\n", html_count, html_max_count );
			}

			html = (HTMLTAG*) malloc ( sizeof(HTMLTAG) );
			if ( html == NULL ) {
				printf("it cannot allocate the memory for the html(HTMLTAG*).\r\n");
				exit(-1);
			}
			a_html[html_count] = html;
			html->inside = (char*)copyof( (char*) key_buffer);
			analyze_html_inside( html->inside, html, &result );
			printf("result %d\r\n", result);

			printf("002 html_count %d >= html_max_count %d\r\n", html_count, html_max_count );
			switch(result) {
			case 1:
				printf("Next is going to be the between <%s> and </%s>\r\n", html->tagname, html->tagname);
				max_buffer = array_count ( html_string );
				result = a_get_between( key_buffer, max_buffer, html, html_string ); // replace of a file info.
				printf("html|%p| result %d\r\n", html, result );
				if ( result == 1 ) {
					html->between = (char*) copyof(key_buffer);
					html_count++;
					printf("tagname|%s| between|%s| html_count|%d|\r\n", html->tagname, html->between, html_count );
					if ( html_count > 10 ) exit(-1);
				}
				break;
			case 2:
				printf("case 2: \r\n");
				exit(-1);
				break;
			default:
				printf("default: \r\n");
				exit(-1);
			}
			printf("003 html_count %d >= html_max_count %d\r\n", html_count, html_max_count );
			exit(-1);
		}
		aFree(p_dummy);
	}

	printf("a_html |%d| html_count %d\r\n", a_html, html_count );

	b_html = a_html;
	b_html_count = html_count;

	printf("int a_function (char* html_string, HTMLTAG* tag_html) ends.\r\n");
	return 0;
}


int read_html_tag_001(char* filename ) {
	STRUCT_FILE structure_fp;
	int file_end;
	FILE* fp;
	char* p_dummy;
	int i;
	int result;
	char key_buffer[255];
	HTMLTAG* html=NULL;

	printf("int read_html_tag(char* filename ) starts.\r\n");

	fp = fopen(filename, "rb");
	printf("1 fp|%d|\r\n", fp);
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	printf("file_size:%d\r\n", file_end);
	printf("2 fp|%d|\r\n", fp);

	for ( i =0; i<file_end; i++ ) {
		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';
		printf("p_dummy|%p|%s| ", p_dummy, p_dummy);
		aFree(p_dummy);
		printf("and free p_dummy|%p|%s|\r\n", p_dummy, p_dummy);
	}

	printf("int read_html_tag(char* filename ) ends.\r\n");
	return 0;
}

int read_html_tag(char* filename ) {
	STRUCT_FILE structure_fp;
	int file_end;
	FILE* fp;
	char* p_dummy;
	int i;
	int result;
	char key_buffer[255];
	HTMLTAG* html=NULL;
	HTMLTAG** a_html=NULL;
	int html_count = 0;
	int html_max_count = 0;

	printf("int read_html_tag(char* filename ) starts.\r\n");

	fp = fopen(filename, "rb");
	printf("1 fp|%d|\r\n", fp);
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	printf("file_size:%d\r\n", file_end);
	printf("2 fp|%d|\r\n", fp);

	for ( i =0; i<file_end; i++ ) {
		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';
		if ( m_start_with ( (char*)p_dummy, "<" ) == 1 ) {
			printf("We found the |<| index %d fp|%d|.\r\n", i, fp );
			result = get_inside( key_buffer, 255, ">", &structure_fp );
			printf("key_buffer |%s|\r\n", key_buffer );


			// alloc max count
			if ( html_count >= html_max_count ) {
				if (html_max_count==0) html_max_count=8;
				else html_max_count *= 2;
				a_html = (HTMLTAG**) realloc ( a_html, sizeof(HTMLTAG*) * html_max_count );
				if ( a_html == NULL ) {
					printf("it cannot allocate the memory for the a_html(HTMLTAG**).\r\n");
					exit(-1);
				}
				printf("realloc: html_count %d / html_max_count %d\r\n", html_count, html_max_count );
			}


			html = (HTMLTAG*) malloc ( sizeof(HTMLTAG) );
			if ( html == NULL ) {
				printf("it cannot allocate the memory for the html(HTMLTAG*).\r\n");
				exit(-1);
			}
			a_html[html_count] = html;
			html->inside = (char*)copyof( (char*) key_buffer);
			analyze_html_inside( html->inside, html, &result );
			printf("result %d\r\n", result);

			switch(result) {
			case 1:
				printf("Next is going to be the between <%s> and </%s>\r\n", html->tagname, html->tagname);
				result = get_between( key_buffer, 255, html, &structure_fp );
				printf("html|%p| result %d\r\n", html, result );
				if ( result == 1 ) {
					html->between = (char*) copyof(key_buffer);
					html_count++;
					printf("tagname|%s| between|%s| html_count|%d|\r\n", html->tagname, html->between, html_count );
				}
				break;
			case 2:
				break;
			default:
				exit(-1);
			}

		}
		aFree(p_dummy);
	}

	printf("a_html |%d| html_count %d\r\n", a_html, html_count );

	b_html = a_html;
	b_html_count = html_count;

	printf("int read_html_tag(char* filename ) ends.\r\n");
	return 0;
}

//
int a_get_between( char* key_buffer, int max_buffer, HTMLTAG* html, char* html_tag ) {
	int array_max;
	char* p_dummy;
	int result;
	char k_buffer[255];
	int returnable_key = 0;
	printf("int a_get_between( char* key_buffer, int max_buffer, HTMLTAG* html, char* html_tag ) starts.\r\n");

	array_max = array_count(html_tag );
	printf("010: html_tag: %s\r\n", html_tag );

	for(int i=0; i<max_buffer && i< array_max; i++ ) {
//		p_dummy = (char*)get_array_string_003 ( key_buffer, i, 4); // replace of a file pointer.
		p_dummy = (char*)get_array_string_004 ( html_tag, i, 4); // replace of a file pointer.
		if (p_dummy == NULL ) {
			printf("012: p_dummy|%s| i: %d/%d\r\n", p_dummy, i, array_max);
			exit(-1);
		}
		p_dummy[4] = '\0';
		printf("011: p_dummy|%s| i: %d/%d\r\n", p_dummy, i, array_max);
//		exit(-1);
		if ( m_start_with ( (char*)p_dummy, "<" ) == 1 ) {
			key_buffer[i] ='\0';
			printf("We found the |<| index %d/%d.\r\n", i, array_max );
			printf("key_buffer |%s| is becoming the between possible.\r\n", key_buffer );
			returnable_key = i;

			// Keep buffer because key_buffer is going next to be changed.

			result = a_get_inside( k_buffer, 255, ">", html_tag ); // replace of a file pointer string
			printf("k_buffer |%s| is becoming the end tag inside possible for |%s|.\r\n", k_buffer, html->tagname );
			printf("key_buffer |%s| is still becoming the between possible for |%s|.\r\n", key_buffer, html->tagname );
			printf("index %d / %d\r\n", i, array_max );

//			exit(-1);
			if ( suits_tagname( k_buffer, html->tagname ) == 1 ) {
				printf("int a_get_between( char* key_buffer, int max_buffer, HTMLTAG* html, char* html_tag ) returns 1.\r\n");
				return 1;
			}
			printf("end for if is still continued.\r\n");
		}
		key_buffer[i] = p_dummy[0];
		aFree(p_dummy);
		printf("end of for is still continued.\r\n");
	}

	printf("the between <%s> and </%s> string count %d\r\n", html->tagname, html->tagname, array_max);
	printf("int a_get_between( char* key_buffer, int max_buffer, HTMLTAG* html, char* html_tag ) ends.\r\n");
	exit(-1);
	return 0;
}

//int get_between( char* key_buffer, int max_buffer, HTMLTAG* html, STRUCT_FILE* sfp ) ;
//
int get_between( char* key_buffer, int max_buffer, HTMLTAG* html, STRUCT_FILE* sfp ) {
	int index;
	char* p_dummy;
	int result;
	char k_buffer[255];
	int returnable_key = 0;
	printf("int get_between( char* key_buffer, int max_buffer, HTMLTAG* html, STRUCT_FILE* sfp ) starts.\r\n");

	for(int i=0; i<max_buffer; i++ ) {
		sfp->index++;
		p_dummy = get_string( *sfp , 5);
		if ( m_start_with ( (char*)p_dummy, "<" ) == 1 ) {
			key_buffer[i] ='\0';
			printf("We found the |<| index %d fp|%d|.\r\n", sfp->index, sfp->fp );
			printf("key_buffer |%s| is becoming the between possible.\r\n", key_buffer );
			returnable_key = sfp->index;

			// Keep buffer because key_buffer is going next to be changed.

			result = get_inside( k_buffer, 255, ">", sfp );
			printf("k_buffer |%s| is becoming the end tag inside possible for %s.\r\n", k_buffer, html->tagname );
			printf("key_buffer |%s| is still becoming the between possible for %s.\r\n", key_buffer, html->tagname );
			printf("sfp->index %d / sfp->file_end_index %d\r\n", sfp->index, sfp->file_end_index);

			if ( suits_tagname( k_buffer, html->tagname ) == 1 ) {
				printf("int get_between( char* key_buffer, int max_buffer, HTMLTAG* html, STRUCT_FILE* sfp ) returns 1.\r\n");
				return 1;
			}
		}
		key_buffer[i] = p_dummy[0];
	}

	printf("int get_between( char* key_buffer, int max_buffer, HTMLTAG* html, STRUCT_FILE* sfp ) ends.\r\n");
	return 0;
}

//
int suits_tagname( char* k_buffer, char* tagname ) {
	int kac, tac;
	char kc, tc;
	int fk, ft;
	int match;
	printf("int suits_tagname( char* k_buffer, char* tagname ) starts.\r\n");

	match =0;
	fk = 0;
	ft = 0;
	kac = array_count ( k_buffer );
	tac = array_count ( tagname );
	for ( int i=0; i<kac; i++ ) {
		kc = k_buffer[i];

		if ( fk == 1 && kc == ' ' )
			break;

		if ( fk == 0 && kc != ' ' )
			fk++;


		if ( fk==2 ) {
			for ( int j=0; j<tac; j++ ) {
				tc = tagname[j];

				if ( ft == 0 && tc == ' ' ) {
					ft++;
					break;
				}

				if ( ft == 0 && tc != ' ' )
					ft++;

				if ( ft == 1 ) {
					printf("|%c| and |%c|\r\n", kc, tc );
				}

				if ( ft == 1 && kc == tc ) {
					match++;
					break;
				}

				if ( ft == 1 && kc != tc ) {
					printf("int suits_tagname( char* k_buffer, char* tagname ) return -1.\r\n");
					return -1;
				}


				if ( ft == 0 && kc != ' ' )
					ft++;

			}
		}

		// k_buffer first letter is '/'
		if ( fk==1 && kc == '/' ) {
			fk++;
			printf("fk = %d\r\n", fk);
		}

		if ( ft == 2 ) break;
	}

	if ( match > 0 ) {
		printf("match %d \r\n", match);
		printf("int suits_tagname( char* k_buffer, char* tagname ) return 1.\r\n");
		return 1;
	}

	printf("int suits_tagname( char* k_buffer, char* tagname ) ends.\r\n");
	return -1;
}

int analyze_html_between ( char* between, HTMLTAG* html, STRUCT_FILE* structure_fp ) {
	int i;
	char* p_dummy;
	printf("int analyze_html_between ( char* between, HTMLTAG* html ) starts.\r\n");

	for ( i =structure_fp->index; i<structure_fp->file_end_index; i++ ) {
		printf("i %d structure_fp->file_end_index %d\r\n" , i, structure_fp->file_end_index);
		structure_fp->index++;
		p_dummy = get_string( *structure_fp , 5);
		p_dummy[5] = '\0';

		if ( m_start_with ( (char*)p_dummy, "<" ) == 1 ) {
			printf("tag name |%s| between |%s| p_dummy |%s|\r\n", html->tagname, between, p_dummy );
			exit(-1);
		}
		aFree(p_dummy);
	}

	printf("int analyze_html_between ( char* between, HTMLTAG* html ) ends.\r\n");
	exit(-1);
	return 0;
}

int analyze_html_inside( char* inside, HTMLTAG* html, int* result ) {
	char key_buffer[255];
	int break_index = 0;

	printf("int analyze_html_inside( char* inside, HTMLTAG* html, int* result ) starts.\r\n");
	int ac = array_count ( inside );
	printf("ac(array count) %d\r\n", ac);
	for ( int i=0; i<ac; i++ ) {
		printf("i %d starts.\r\n", i);
		if (inside[i] == ' ' ) {
			key_buffer[i] = '\0';
			break_index = i; // copy
			break;
		}
		key_buffer[i] = inside[i];
		key_buffer[i+1] = '\0';
		printf("i %d ends.\r\n", i);
	}
	html->tagname = (char*) copyof(key_buffer);
	printf("tag=|%s|\r\n", html->tagname );

	// end_tag
	for ( int i = ac - 1; i>=0; i-- ) {
		switch(inside[i]) {
		case '/':
			*result = 2;
			printf("We found '/' from end. %d/%d *result=%d\r\n", i, ac, *result);
			printf("int analyze_html_inside( char* inside, HTMLTAG* html, int* result ) return 1.\r\n");
			return 1;
		default:
			break;
		}
	}

	*result = 1;
	// inside proerty

	if ( break_index!= 0 && break_index < ac ) {
		printf("inside string has still remained.\r\n");
		exit(-1);
	}

	printf("*result = %d\r\n", *result);
	printf("int analyze_html_inside( char* inside, HTMLTAG* html, int* result ) ends.\r\n");
	return 0;
}



int a_get_inside( char* key_buffer, int max_buffer, char* end_string, char* tag_string ) {
	char* p_dummy;
	int count, start;
	printf("int a_get_inside( char* key_buffer, int max_buffer, char* end_string, char* tag_string ) starts.\r\n");

	printf("max_buffer %d\r\n tag_string:\r\n %s\r\n", max_buffer, tag_string);
	count = array_count( tag_string );

	if ( 1<= max_buffer && key_buffer[0] == '<' ) start = 1;

	printf("start %d\r\n", start );

	for(int i=start; i<max_buffer; i++ ) {
//		p_dummy = (char*)get_array_string_003 ( key_buffer, i, 4); // replace of a file pointer.
		p_dummy = (char*)get_array_string_004 ( key_buffer, i, 4); // replace of a file pointer.
		p_dummy[4] = '\0';
		printf("p_dummy|%s| i: %d/%d\r\n", p_dummy, i, max_buffer);
		if ( m_start_with ( (char*)p_dummy, end_string ) == 1 ) {
			key_buffer[i - start] ='\0';
			printf("We found the |>| index %d/ %d.\r\n", i, count );
			printf("key_buffer |%s|\r\n", key_buffer );
			aFree(p_dummy);
			printf("int a_get_inside( char* key_buffer, int max_buffer, char* end_string, char* tag_string ) returns 1.\r\n");
//			exit(-1);
			return 1;
		}
		key_buffer[i - start] = p_dummy[0];
		aFree(p_dummy);
	}

	printf("int a_get_inside( char* key_buffer, int max_buffer, char* end_string, char* tag_string ) ends.\r\n");
//	exit(-1);
	return 0;
}

char* get_array_string_002 (char* a_string, int index, int length ) {

	printf("index %d length %d\r\n");

	return NULL;
}


//
char* get_array_string_001 (char* a_string, int num, int length ) {
	char dummy[255];
	char* result = NULL;
	int i;
	printf("char* get_array_string (char* a_string, int num) starts.\r\n");

	int max = array_count(a_string);
	for ( i=num; i<max && i<255 && i<num + length; i++) {
		dummy[i] = a_string[i];
	}

	printf("i:%d/%d(num)\r\n", i, num);
	result = (char*)copyof ( dummy );
	printf("result:%s.\r\n", result);

	printf("char* get_array_string (char* a_string, int num) ends.\r\n");
	return result;
}

char* get_array_string (char* a_string, int num) {
	char dummy[255];
	char* result = NULL;

	printf("char* get_array_string (char* a_string, int num) starts.\r\n");

	int max = array_count(a_string);
	for ( int i=0; i<max && i<255 && i<num; i++) {
		dummy[i] = a_string[i];
	}

	result = (char*)copyof ( dummy );
	printf("result:%s.\r\n");

	printf("char* get_array_string (char* a_string, int num) ends.\r\n");
	return result;
}

int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) {
	int index;
	char* p_dummy;
	printf("int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) starts.\r\n");

	for(int i=0; i<max_buffer; i++ ) {
		sfp->index++;
		p_dummy = get_string( *sfp , 5);
		if ( m_start_with ( (char*)p_dummy, end_string ) == 1 ) {
			key_buffer[i] ='\0';
			printf("We found the |>| index %d fp|%d|.\r\n", sfp->index, sfp->fp );
			printf("key_buffer |%s|\r\n", key_buffer );
			printf("int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) returns 1.\r\n");
			return 1;
		}
		key_buffer[i] = p_dummy[0];
	}

	printf("int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) ends.\r\n");
	return 0;
}

int fileallsize ( char* filename ) {
	STRUCT_FILE structure_fp;
	int file_end;
	FILE* fp;

	fp = fopen(filename, "rb");
	err_msg_001("1 fp|%d|\r\n", fp);
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	err_msg_001("file_size:%d\r\n", file_end);
	err_msg_001("2 fp|%d|\r\n", fp);

	return 0;
}

int main_014 ( int argc, char** argv ) {

	char* bstring = (char*)"aaabbcccc";
	char* bfrom = (char*)"bb";
	char* bto = (char*)"dddd";

	char* cfrom = (char*)"ccc";
	char* cto = (char*)"eeee";

	for ( int i = 0; i<1000; i++ ) {
		char* a = m_replace((char*)bstring, (char*)bfrom, (char*)bto);
		printf("%d: string:%s bstring:%s from:%s to:%s\r\n", i, a, bstring, bfrom, bto);
		a = (char*)m_replace((char*)bstring, (char*)cfrom, (char*)cto);
		printf("%d: string:%s bstring:%s from:%s to:%s\r\n", i, a, bstring, cfrom, cto);
	}
	return 0;
}

int main_013 ( int argc, char** argv ) {

	// main_001.cpp
//	int a = read_source_cpp_001 ("main_001.cpp") ; 
//	int a = read_source_cpp_002 ("main_001.cpp") ; 
	int a = read_source_cpp_004 ("main_001.cpp") ; 

	return 0;
}

int main_012 ( int argc, char** argv ) {

	// 001-form-20210317-001.html
	int a = read_source_cpp ("001-form-20210317-001.html") ; 

	return 0;
}

int read_source_cpp_004 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_cpp[5] = { "int", "void", "char*", "float", "double" };
	int mode = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;
		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';

		printf("dummy %s\r\n", p_dummy);

		switch ( mode ) {
		case 0:
			break;
		default:
			printf("any other if the mode = 0.\r\n");
			exit(-1);
		}
		for ( int j = 0; j<5; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_cpp[j] ) == 1 ) {
				printf("We found the primitive of the return values %s in cpp source code %s at %s index: %d line %d raw %d\r\n", match_cpp[j], filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}

int read_source_cpp_003 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_cpp[5] = { "int", "void", "char*", "float", "double" };
	int mode = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1; i++ ) {
		raw++;
		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';

		printf("dummy %s\r\n", p_dummy);

		switch ( mode ) {
		case 0:
			break;
		default:
			printf("any other if the mode = 0.\r\n");
			exit(-1);
		}
		for ( int j = 0; j<5; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_cpp[j] ) == 1 ) {
				printf("We found the primitive of the return values %s in cpp source code %s at %s index: %d line %d raw %d\r\n", match_cpp[j], filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}


int read_source_cpp_002 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_cpp[5] = { "int", "void", "char*", "float", "double" };
	int mode = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;
		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';

		switch ( mode ) {
		case 0:
			break;
		default:
			printf("any other if the mode = 0.\r\n");
			exit(-1);
		}
		for ( int j = 0; j<5; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_cpp[j] ) == 1 ) {
				printf("We found the primitive of the return values %s in cpp source code %s at %s index: %d line %d raw %d\r\n", match_cpp[j], filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}

int read_source_cpp_001 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_cpp[5] = { "int", "void", "char*", "float", "double" };
	int mode = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;
		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';

		switch ( mode ) {
		case 0:
			break;
		default:
			printf("any other if the mode = 0.\r\n");
			exit(-1);
		}
		for ( int j = 0; j<5; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_cpp[j] ) == 1 ) {
				printf("We found the primitive of the return values %s in cpp source code %s at %s index: %d line %d raw %d\r\n", match_cpp[j], filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}


int read_source_cpp (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_html[2] = { "<", ">" };

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		for ( int j = 0; j<2; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_html[j] ) == 1 ) {
				printf("We found the primitive of the all tags in html at %s index: %d line %d raw %d\r\n", filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}

int read_html_001 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_html[2] = { "<", ">" };

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		for ( int j = 0; j<2; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_html[j] ) == 1 ) {
				printf("We found the primitive of the all tags in html at %s index: %d line %d raw %d\r\n", filename, i, line, raw );
				m_thread_sleep ();
			}


		}
/*
		if ( m_start_with ( (char*)p_dummy, match_html[0] ) == 1) {
			printf("We found the primitive '<' in html at %s index: %d line %d\r\n", filename, i, line );
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread = 2;
		} else if ( m_start_with ( (char*)p_dummy, match_html[1] ) == 1 ) {
			printf("We found the primitive '>' in html at %s index: %d line %d\r\n", filename, i, line );
			printf("tag_line: %s\r\n", p_dummy_token );
			html_tag[k] = copyof (p_dummy_token);
			k++;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread = 1;
		}
*/
		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

		if ( canread == 2 )
			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	for ( i=0; i<k; i++ ) {
		printf("html_tag[%d]=%s\r\n", i, html_tag[i] );
	}

	return 0;
}


int main_011 ( int argc, char** argv ) {
	for( int i = 0; i<=10; i++) {
		print_function_002 ( i );
		print_function_cpp ( i );
	}
	return 0;
}

int print_function_cpp ( int i ) {
	char* ifndef_buffer = "WORK";
	char print_ifndef_start_buffer[255]; 
	char print_ifndef_end_buffer[255]; 
	FILE *fp;
	char filename[255];
	int ii, iip;

	printf("int print_function_cpp ( int i ) starts.\r\n");

	iip = ( i + 1 ) % 10;
	ii = i;

	sprintf( filename, "%s_%03d.cpp", ifndef_buffer, ii );
	fp = fopen( filename, "wb");

	// ii include
	sprintf(print_ifndef_start_buffer, "#include \"%s_%03d.h\"\r\n", ifndef_buffer, ii );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);

	// iip include
	sprintf(print_ifndef_start_buffer, "#include \"%s_%03d.h\"\r\n", ifndef_buffer, iip );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);


	sprintf(print_ifndef_start_buffer, "void %s_%03d::Set%s_%03d( %s%03d *l%s%03d ){ \r\n\r\n", ifndef_buffer, ii, ifndef_buffer, iip, ifndef_buffer, iip,  ifndef_buffer, iip  );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "}\r\n" );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);

	fclose(fp);

	printf("int print_function_cpp ( int i ) ends.\r\n");
	return 0;
}


//
//
//
//
int print_function_002 ( int i ) {
	char* ifndef_buffer = "WORK";
	char print_ifndef_start_buffer[255]; 
	char print_ifndef_end_buffer[255]; 
	FILE *fp;
	char filename[255];
	int ii, iip;

	printf("int print_function_002 ( int i ) starts.\r\n");

	iip = ( i + 1 ) % 10;
	ii = i;

	sprintf( filename, "%s_%03d.h", ifndef_buffer, ii );
	fp = fopen( filename, "wb");

	sprintf(print_ifndef_start_buffer, "#ifndef _%s_%03d_H_\r\n#define _%s_%03d_H_\r\n", ifndef_buffer, ii, ifndef_buffer, ii );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp, "%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "class %s_%03d { \r\n	public:\r\n		%s_%03d *i%s_%03d=nullptr;\r\n\r\n", ifndef_buffer, ii, ifndef_buffer, iip, ifndef_buffer, ii   );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp, "%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "	public:\r\n		Set%s_%03d( %s%03d *l%s%03d ); \r\n\r\n", ifndef_buffer, iip, ifndef_buffer, iip,  ifndef_buffer, iip  );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "};\r\n", ifndef_buffer, ii  );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp, "%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_end_buffer, "#endif\r\n" );
	printf("%s", print_ifndef_end_buffer);
	fprintf( fp, "%s", print_ifndef_end_buffer);

	fclose(fp);

	printf("int print_function_002 ( int i ) ends.\r\n");
	return 0;
}

//
//
//
//
//
int print_function_001 ( int i ) {
	char* ifndef_buffer = "WORK";
	char print_ifndef_start_buffer[255]; 
	char print_ifndef_end_buffer[255]; 

	printf("int print_function_001 ( int i ) starts.\r\n");

	sprintf(print_ifndef_start_buffer, "#ifndef _%s_%03d_H_\r\n#define _%s_%03d_H_\r\n", ifndef_buffer, i, ifndef_buffer, i );
	printf("print_ifndef_start_buffer: %s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "class %s_%03d{ \r\n	public:\r\n	%s_%03d *i%s_%03d=nullptr;\r\n", ifndef_buffer, i, ifndef_buffer, i + 1, ifndef_buffer, i   );
	printf("print_ifndef_start_buffer: %s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "public:\r\n	Set%s_%03d( %s%03d *l%s%03d ); \r\n", ifndef_buffer, i + 1, ifndef_buffer, i + 1,  ifndef_buffer, i + 1  );
	printf("print_ifndef_start_buffer: %s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "}\r\n", ifndef_buffer, i  );
	printf("print_ifndef_start_buffer: %s", print_ifndef_start_buffer);

	sprintf(print_ifndef_end_buffer, "#endif\r\n" );
	printf("print_ifndef_end_buffer: %s", print_ifndef_end_buffer);

	printf("int print_function_001 ( int i ) ends.\r\n");
	return 0;
}




int main_010 ( int argc, char** argv ) {
//	int a = initialize_parse_test ();
//	print_memories();


	if ( argc < 1 ) {
		printf("argc %d\r\n", argc );
		return 0;
	}

	printf(" argc[i] filename = %s\r\n", (char*)argv[1]);
	int a = read_html ( argv[1] );


	print_memories ();
}

int main_009 ( int argc, char** argv ) {
//	int a = initialize_parse_test ();
//	print_memories();


	if ( argc < 1 ) {
		printf("argc %d\r\n", argc );
		return 0;
	}

	printf(" argc[i] filename = %s\r\n", (char*)argv[1]);
	int a = read_csv_010 ( argv[1] );

	int b = print_csv ();

// 1: char** csv
// 2: char* form_file
// int b = replace_csv ( argv[2], argv[3] );


	print_memories ();
}


int read_html (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 0;
	char* match_html[2] = { "<", ">" };

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		for ( int j = 0; j<2; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_html[j] ) == 1 ) {
				printf("We found the primitive of the all tags in html at %s index: %d line %d\r\n", filename, i, line );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, match_html[0] ) == 1) {
			printf("We found the primitive '<' in html at %s index: %d line %d\r\n", filename, i, line );
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread = 2;
		} else if ( m_start_with ( (char*)p_dummy, match_html[1] ) == 1 ) {
			printf("We found the primitive '>' in html at %s index: %d line %d\r\n", filename, i, line );
			printf("tag_line: %s\r\n", p_dummy_token );
			html_tag[k] = copyof (p_dummy_token);
			k++;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread = 1;
		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
		}

		if ( canread == 2 )
			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	for ( i=0; i<k; i++ ) {
		printf("html_tag[%d]=%s\r\n", i, html_tag[i] );
	}

	return 0;
}



int main_008  ( int argc, char** argv ) {
	int a = 0;

	printf("main: check if char_string_010 works well or not. : START\r\n");

	print_memories ();

	srand(time(NULL));   // Initialization, should only be called once.
//	int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.

	for ( int i=0; i<100; i++) {
		a = rand() % 256;
		printf("a = %d\r\n", a );
		allocation = char_string_010 ( a );
		put_memories (allocation);
		printf("allocation=|%p| |%s| array count=%d\r\n", allocation, allocation, array_count(allocation));
	}

	print_memories ();

	printf("main: check if char_string_010 works well or not. : END\r\n");
	return 0;
}

int main_007( int argc, char** argv ) {
//	int a = initialize_parse_test ();
//	print_memories();


	if ( argc < 1 ) {
		printf("argc %d\r\n", argc );
		return 0;
	}

	printf(" argc[i] filename = %s\r\n", (char*)argv[1]);
	int a = read_csv( argv[1] );
	print_memories ();
}

int main_006 (int argc, char** argv ) {
	int a = initialize_parse_test ();

//	int b = read_sourcecode(".\main_001.cpp");
//	int b = replace_main ( argc, argv) ;
	print_memories();
//	exit(-1);

	char* string = "<img src=\"\$00\">";
	char* url = "http://img-cdn.jg.jugem.jp/cf3/3928048/20210521_2120204.jpg";
	char* c_replace = m_replace( string, "\$00", url );

	printf("string|%s|\r\n", string);
	printf("url|%s|\r\n", url);
	printf("replaced|%s|\r\n", c_replace);

	print_memories();
	return 0;
}

int main_002_test (int argc, char** argv ) {
	int a = initialize_parse_test ();

//	int b = read_sourcecode(".\main_001.cpp");
//	int b = replace_main ( argc, argv) ;

	char* string = "aaabbcccc";
	char* c_replace = m_replace( string, "bb", "dddd" );

	printf("string|%s|\r\n", string);
	printf("replaced|%s|\r\n", c_replace);

	print_memories();
	return 0;
}


int main_001 (int argc, char** argv ) {
	int a = initialize_parse_test ();
//	int a = copyof_test ();
//	int a = replace_main ( argc, argv);
	print_memories();
	return 0;
}


int initialize_parse_test () {
	printf("copyof_test () starts.\r\n");
	initialize_parse_001 ();
	printf("copyof_test () ends.\r\n");
	return 0;
}

//
int copyof_test () {
	char* p_dummy_alocation_001 = NULL;
	char aa[100];
	char* p_dummy_alocation_002 = NULL;

	printf("copyof_test () starts.\r\n");
	initialize_parse ();
	aa[0] = 'a';
	for ( int j =0; j<10; j++ ) { 
		printf("j=%d\r\n", j);
		for ( int i=0; i<10; i++ ) {
			printf("i=%d\r\n", i);
			p_dummy_alocation_001 = put_token( aa[0] );
		}
		p_dummy_alocation_002 = copyof_001(p_dummy_alocation_001);
		printf("|%p|%p| = ", p_dummy_alocation_001, p_dummy_alocation_002);
		printf("p_dummy_alocation_002=||%p|%s|", p_dummy_alocation_002, p_dummy_alocation_002);
		aFree(p_dummy_alocation_001);
		clear_token();
	}
	printf("copyof_test () ends.\r\n");
	return 0;
}

int replace_main (int argc, char** argv ) {
	printf("replace_main starts.\r\n");

//	char* a_001 = (char*)"a$00<><></>$00bbb\r\ncc$01c";
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$00", (char*)"ee" );
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$01", (char*)"ffff" );
//	printf("a_001 |%s|\r\n", a_001);

	if ( argc != 4 ) {
		printf("csv_replace {input-csv-file} {form-html-file} {output-html-file}\r\n");
	}

//	int a = read_csv(".\\001-csv-20210317-001\.txt");
//	int b = replace_csv ( ".\\001-form-20210317-001\.html", ".\\001-html-20210317-001\.txt");

	printf("input-csv: %s form-html-file: %s output-html-file: %s\r\n", argv[1], argv[2], argv[3]);
	sleep(2);

	int a = read_csv( argv[1] );
	print_memories ();
//	exit ( -1 );

//	int b = replace_csv ( argv[2], argv[3] );

//	char* string_all = read_all ( ".\\001-form-20210317-001\.html" );
//	printf("string_all:%s\r\n", string_all);

	printf("replace_main ends.\r\n");

	return 0;
}
