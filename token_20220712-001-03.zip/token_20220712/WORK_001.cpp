#include "WORK_001.h"
#include "WORK_002.h"
void WORK_001::SetWORK_002( WORK002 *lWORK002 ){ 

}
