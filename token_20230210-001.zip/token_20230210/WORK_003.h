#ifndef _WORK_003_H_
#define _WORK_003_H_
class WORK_003 { 
	public:
		WORK_004 *iWORK_003=nullptr;

	public:
		SetWORK_004( WORK004 *lWORK004 ); 

};
#endif
