extern int key_print(char* string_key1, char* string_key2, char** string_keys3, int num ) ; 
extern int key_print_fp(FILE* fp, char* string_key1, char* string_key2, char** string_keys3, int num ) ;
extern int match_001( FILE *fp, int *index, char* string_key1) ;
extern int test_match_001 () ;
extern int test_match_002 () ;

