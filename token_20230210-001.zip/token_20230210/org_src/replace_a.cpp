#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include <stdlib.h>
#include <time.h>
#include "timestamp.h"


#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"
#include "replace_001.h"
#include "replace_a.h"
#include "replace_main.h"
// #include "sounds-work-001.h"
// #include "sounds-011.h"

int test_match_a () ;

int test_match_a () {
	FILE* fp;
	int index, i, a, flg_minus;
	char* string_key = NULL;
	char* string_key_001 = (char*)"aab";
	char* string_key_002 = (char*)"smld";
	char* string_key_003 = (char*)"5";
	int exits = 0;

	printf("int test_match_a () starts.\r\n");

	fp = fopen("001-20230207-001.txt", "rb");
	if ( fp == NULL ) {
		printf("fp is null and so it exits.\r\n");
		exit(-1);
	}

	printf("exits=%d\r\n", exits);
	string_key = string_key_001;
	flg_minus = 0;
	index = 0;
	for ( i =0; i<100; i++ ) {
		printf("001 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );
		a = match_001( fp, &index, string_key ) ;

		printf("002 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );

		if ( a == 1 ) flg_minus++;
		else {
			printf("a|%d| and does not match.\r\n", a);
		}
		switch(flg_minus) {
		case 0:
			break;
		case 1:
			index -= 2;
			i -= 2;
			string_key = string_key_002 ;
			break;
		case 2:
			string_key = string_key_003 ;
			break;
		case 3:
			exits = 1;
			break;
		}

		printf("003 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );

		if ( i < -1 || exits ) break;
	}

	printf("i %d flg_minus %d a %d string_key |%s| fp|%d|\r\n", i, flg_minus, a, string_key, fp );
	fclose(fp);
	printf("fp |%d|\r\n", fp);

	printf("int test_match_a () ends.\r\n");
	return 0;
}
