#include <math.h>

#include "vPoint.h"
#include "vCalculation.h"

vPoint vCalculation::cross ( vPoint p1, vPoint p2) {

	vPoint p3;

	cross( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(p3.x), &(p3.y), &(p3.z) );

	return p3;
}

void vCalculation::cross ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = z1*y2 - y1*z2;
	*y3 = x1*z2 - z1*x2;
	*z3 = x1*y2 - y1*x2;

}

vPoint vCalculation::subtract ( vPoint p1, vPoint p2) {

	vPoint result;

	subtract( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &result.x, &result.y, &result.z );

	return result;
}

void vCalculation::subtract ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = x2 - x1;
	*y3 = y2 - y1;
	*z3 = z2 - z1;

}

vPoint vCalculation::add ( vPoint p1, vPoint p2) {

	vPoint result;

	add( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &result.x, &result.y, &result.z );

	return result;
}

void vCalculation::add ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = x2 + x1;
	*y3 = y2 + y1;
	*z3 = z2 + z1;

}

vPoint vCalculation::scale ( vPoint p1, float w_scale ) {

	vPoint result;

	scale ( p1.x, p1.y, p1.z, w_scale, &result.x, &result.y, &result.z );

	return result;
}

void vCalculation::scale ( float x1, float y1, float z1, float scale, float* x3, float* y3, float* z3) {

	*x3 = scale * x1;
	*y3 = scale * y1;
	*z3 = scale * z1;

}

vPoint vCalculation::normal ( vPoint p1 ) {

	vPoint p2;
	double scale;

	scale = normal( p1.x, p1.y, p1.z, &p2.x, &p2.y, &p2.z );

	return p2;
}

double vCalculation::normal ( float x1, float y1, float z1, float* x2, float* y2, float* z2 ) {

	double scale = x1*x1 + y1*y1 + z1*z1;
	scale = sqrt( scale );

	double x3 = (( double ) x1) / scale;
	double y3 = (( double ) y1) / scale;
	double z3 = (( double ) z1) / scale;

	*x2 = x3;
	*y2 = y3;
	*z2 = z3;

	return scale;
}

//
double vCalculation::length ( vPoint lp ) {

	return length ( lp.x, lp.y, lp.z );
}

//
double vCalculation::length ( float x1, float y1, float z1) {

	double scale = x1*x1 + y1*y1 + z1*z1;
	scale = sqrt( scale );

	return scale;
}

