#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "array_counter.h"
#include "client.h"

typedef struct struct_garbage_collenction {

	char** stock;
	int stock_index = 0;
	int stock_max = 10;

} GarbageCollection;

int array_count( char *ary );
char* concat( char *head, char *tail );
char* set_array(char *arry, int n, char c);
void print_string( char *head );


//int main ( int argc, char *argv[] ) {
//
//	int ac = array_count((char *)"abcdefg");
//
//	printf("count=%d\n", ac );
//
//	return 0;
//}

GarbageCollection garbage;

void show_garbage_collection () ;
void put_garbage_collection (char* put_char_string ) ;
void show_garbage_collection ();
void show_garbage_collectionA ();

static char* dummy_allocation;
int printable_garbage = 0;

int array_count( char *ary )
{
	char c;
	if ( ary == nullptr ) return 0;

	int count = 0;
	for ( ;; ) {
		c = *ary;
		if ( c == '\0' ) {
			break;
		}
		ary++;
		count++;
	}

	return count;
}


void put_garbage_collection (char* put_char_string ) {

	char** g_dummy;

	if ( garbage.stock_index == 0 ) {
		g_dummy = (char **) malloc( sizeof(char*) * garbage.stock_max );
		garbage.stock = g_dummy;
	}

	garbage.stock_index++;
	if ( garbage.stock_index >= garbage.stock_max ) {
		garbage.stock_max *=2;
		garbage.stock = (char**) realloc( garbage.stock, sizeof(char*) * garbage.stock_max );
	}

	garbage.stock[garbage.stock_index] = put_char_string;
}

void show_garbage_collectionA () {
//	char** argv = nullptr;
	printf("show_garbage_collectionA\r\n");

//	argv = (char **) malloc( sizeof(char*) * 2 );

//	argv[0] = (char*)"***.***.***.***";
//	argv[1] = (char*)"192.168.1.2";

//	client_main( 2, argv);
//	sleep(1000);

//	do {
//		printf("show_garbage_collectionA\r\n");
//	} while( print_server > 0 )

}

void show_garbage_collection () {
	for ( int i=0; i<garbage.stock_index; i++ ) {
		printf("garbage: %3d: %s\r\n", i, garbage.stock[i]);
	}
}

char* m_concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
//	char ch, ct;
	char* c_head;

	nh = array_count( head );
	nt = array_count( tail );
	// o if ( nh + nt == 6 ) exit(-1);
	//	printf("array_count: %d %d\n", nh, nt);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		}
		break;
	}

//	printf("alloc=%d\n", alloc);

	if ( alloc == 0 ) {
		alloc = 1;
		dummy_allocation = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
//		printf("allocation blocks( array_count( dummy_allocation ) ) = %d\n", array_count(dummy_allocation) );
		alloc = 0;
	}

	for( int i=0; i< nh; i++ )
		*( dummy_allocation + i ) = *(head + i);

	for( int i=0; i< nt; i++ )
		*( dummy_allocation + nh + i ) = *(tail + i);

	*( dummy_allocation + nh + nt ) = '\0';

//	print_string(dummy_allocation);

	put_garbage_collection(head);
	put_garbage_collection(tail);
	put_garbage_collection(dummy_allocation);

	return dummy_allocation;
}


void print_string( char *head )
{
	int nh;
	char a[1];

	nh = array_count( head );
	for( int i=0; i<nh; i++ ) {
		a[0] = *(head + i);
		printf( "|%s|%3d|\n", a, a[0] );
	}
}

// do not use realloc in under sublootin.
// better solution usually by use of macro of realloc in C.
//
// use global value for allocation.
char* concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
	char ch, ct;
	char* c_head;

	nh = array_count( head );
	nt = array_count( tail );
	// o if ( nh + nt == 6 ) exit(-1);

	printf("array_count: %d %d\n", nh, nt);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		}
		break;
	}

	printf("alloc=%d\n", alloc);

	if ( alloc == 0 ) {
		alloc = 1;
//		c_head = (char *) realloc( head , sizeof( char ) * ( nh + nt + 1) );
		c_head = (char *) realloc( head , 100 );

		dummy_allocation = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
//		dummy_allocation = (char *) malloc( sizeof(char *) * ( nh + nt + 1 ) );
//		dummy_allocation = (char *) malloc( 100 * ( nh + nt + 1 ) );

//		*( head + nh + nt) = '\0';
		// x *(head) = 0;
		// o head = tail;
		printf("allocation blocks(head)=%d\n", sizeof( head ) );
		printf("allocation blocks(*head)=%d\n", sizeof( *head ) );
//		printf("allocation blocks(array_count(head))=%d\n", array_count(head) );

		printf("allocation blocks(c_head)=%d\n", sizeof( c_head ) );
		printf("allocation blocks(tail)=%d\n", sizeof( tail ) );

		// x *(head + 3 ) = ' ';
		//set_array( head, 3, ' ');
		printf("allocation blocks(array_count(head))=%d\n", array_count(head) );


//		*( dummy_allocation + nh + nt ) = '\0';
		*( dummy_allocation + 1 ) = '\0';
		printf("allocation blocks( dummy_allocation )=%d\n", sizeof( dummy_allocation ) );
		printf("allocation blocks( array_count( dummy_allocation ) ) = %d\n", array_count(dummy_allocation) );

		alloc = 0;
	}

	

// o	head = tail;
// x	*head = *tail;
// o	ch = *head;
//	exit(-1);

	head += nh;
	for( int i=0; i<nt; i++ ) {
		// x head[ nh + i ] = tail[ i ];
		// x head[ 0 ] = tail[ i ];
		// x *(head + nt + i) = *( tail + i);
		// x *(head + nt + i) = *( tail);
		// x *(head + nt + i) = 0;
		// o head = tail;
		// x *head = *tail;
		// x *head = 0;
		// x *(head) = 0;

		ch = *head;
		ct = *tail;

		// o *(head + 3) = ct;
		// x *( head + nh + i ) = ct;
		// x *head = ct;

		head = tail;

		tail++;
		head++;
	}

//	exit(-1);

	return head;
}

char* set_array(char *arry, int n, char c) {

	static char *returnable;

	returnable = arry;
	arry++;
	*arry = c;
	////arry = c;
	//arry = returnable;

	return returnable;
}


