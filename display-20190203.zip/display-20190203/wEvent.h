

class wEvent {

	public :
		HWND hWnd = nullptr;
		UINT uMsg = 0;
		WPARAM wParam = 0;
		LPARAM lParam = 0;
		int main_mode = 0; // button number
		HDC hDc = nullptr;
		PAINTSTRUCT* ps = nullptr;

};

