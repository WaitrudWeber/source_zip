#ifndef _VSCHEEN_
#define _VSCHEEN_

#include "vPoint.h"

class vScreen {

	public:
		vScreen ( );
		// vPoint Intersect( vTriangle tri, vPoint eye, vPoint ray );
		void put_U ( vPoint a) ;
		void put_V ( vPoint b) ;
		void put_C ( vPoint c) ;
		vPoint subtract( vPoint a, vPoint b);
		vPoint normal( vPoint a );
		vPoint cross ( vPoint a, vPoint b);
		void calculation_uvw ();
		void calculation ();
		int OntheScreen ( vPoint lp, float* x, float* y ) ;
		int OntheScreen ( vPoint lp, vPoint* result ) ;
		void OntheScreen ( float* x, float* y);
		void OntheScreen ( vPoint* x, vPoint* y);

	private:
		vCalculation* this_calc = nullptr;
		vPoint U;
		vPoint V;
		vPoint C;
		vPoint X; // SCREEN( X, Y )
		vPoint Y;
		vPoint u, v, w; // w is up.

};

#endif

