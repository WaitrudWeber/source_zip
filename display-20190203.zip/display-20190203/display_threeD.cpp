#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "wTextarea.h"
#include "clipboard.h"

#include "vPoint.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h";
#include "vScreen.h"

#include "display_threeD.h"

int display_threeD_initialize () ;
int getchar_something_word_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
int wmpaint_display_threeD_proc_org ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
int wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam );

void GamePaint_006(HDC hDC) ;
void GamePaint_007(HDC hDC) ;
void GamePaint_008(HDC hDC, POINT* points) ;

vTriangle atri;
static vPoint eye;
vPoint ray;
vPoint point_intersection;
float g_x, g_y;
int display_3d = 0;

vScreen* screen = nullptr;
HWND hWindow;

int display_threeD_initialize () {
	//vCalculation calc;

	//vPoint* p1 = new vPoint( 100.0f, 100.0f, 100.0f );
	//vPoint* p2 = new vPoint( 100.0f,   0.0f, 100.0f );
	//vPoint* p3 = new vPoint(   0.0f,   0.0f, 100.0f );

	//vPoint* p_eye = new vPoint ( 0.0f, 0.0f, -100.0f);

	//eye = *p_eye;
	//atri.p1 = *p1;
	//atri.p2 = *p2;
	//atri.p3 = *p3;

	printf("display_threeD_initialize\r\n");

	eye.setPoint( 0.0f, 0.0f, -100.0f);

	atri.p1.setPoint( 100.0f, 100.0f, 100.0f );
	atri.p2.setPoint( 100.0f,   0.0f, 100.0f );
	atri.p3.setPoint(   0.0f,   0.0f, 100.0f );

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	point_intersection = intersection->Intersect( atri, eye, ray );

	screen = new vScreen ();
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen->put_U ( *U );
	screen->put_V ( *V );
	screen->calculation();
	screen->OntheScreen( &g_x, &g_y );

	display_3d = 1;
	return 0;
}

//
//
//
int get_cooordinate_on_screen ( vPoint lp, float* lx, float* ly ) {
	vCalculation calc;

	ray = calc.subtract( lp, eye);
	printf("Ray= ");
	ray.print();
	ray = calc.normal(ray);

	// if ( ray.x == 0 && ray.y == 0 && ray.z == 0 ) return -1;

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	vPoint point_intersection = intersection->Intersect( atri, eye, ray );

//	vPoint result;
//	screen->setPoint(lp);
//	screen->OntheScreen( lp, &result );

	int result = screen->OntheScreen( point_intersection, lx, ly );

	return 0;
}

int getchar_display_threeD_proc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	return 0;
}

int wmpaint_display_threeD_proc_org ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	HDC     hDC;
	PAINTSTRUCT ps;
	hDC = BeginPaint( hWnd, &ps);

	GamePaint_007( hDC );

	EndPaint(hWnd, &ps);
	return 0;
}

//
//
//
//
int wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	float lx, ly;
	POINT points[3];

	if ( display_3d == 0 ) return -1;

	printf("atri.p1=");
	atri.p1.print();

	get_cooordinate_on_screen ( atri.p1, &lx, &ly );
	points[0] = { (LONG)lx, (LONG)ly };

	printf( "l(%f,%f)\r\n", lx, ly);

	get_cooordinate_on_screen ( atri.p2, &lx, &ly );
	points[1] = { (LONG)lx, (LONG)ly };

	printf( "l(%f,%f)\r\n", lx, ly);

	get_cooordinate_on_screen ( atri.p3, &lx, &ly );
	points[2] = { (LONG)lx, (LONG)ly };

	printf( "l(%f,%f)\r\n", lx, ly);

	GamePaint_008( hDC, (POINT*) points );

	return 0;
}


// Very Thanks to: http://www.informit.com/articles/article.aspx?p=328647&seqNum=3
// int FillRect(HDC hDC, CONST RECT *lprc, HBRUSH hbr);
// BOOL Rectangle(HDC hDC, int xLeft, int yTop, int xRight, int yBottom);
// BOOL MoveToEx(HDC hDC, int x, int y, LPPOINT pt);
// BOOL LineTo(HDC hDC, int x, int y);
// BOOL TextOut(HDC hDC, int x, int y, LPCTSTR szString, int iLength);
// HPEN CreatePen(int iPenStyle, int iWidth, COLORREF crColor);
// HPEN hBluePen = CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
// HBRUSH hPurpleBrush = CreateSolidBrush(RGB(255, 0, 255));
// HPEN hPen = SelectObject(hDC, hBluePen);
// SelectObject(hDC, hPen);
// DeleteObject(hBluePen);
// HBRUSH hBrush = SelectObject(hDC, hPurpleBrush);
//  // *** Do some drawing here! ***
//  SelectObject(hDC, hBrush);
//  DeleteObject(hPurpleBrush);

// case WM_PAINT:
//  HDC     hDC;
//  PAINTSTRUCT ps;
//  hDC = BeginPaint(hWindow, &ps);

//  // Paint the game
//  GamePaint(hDC);
//
// EndPaint(hWindow, &ps);
// return 0;
//
//
//
//

//
//
//
//
//
void GamePaint_000(HDC hDC)
{
	MoveToEx(hDC, 0, 0, NULL);
	LineTo(hDC, 50, 50);
}

void GamePaint_001(HDC hDC)
{
	TextOut(hDC, 10, 10, TEXT("Michael Morrison"), 16);
}

void GamePaint_002(HDC hDC)
{
	RECT rect;
	GetClientRect(hWindow, &rect);
	DrawText(hDC, TEXT("Michael Morrison"), -1, &rect,
	DT_SINGLELINE | DT_CENTER | DT_VCENTER);
}

void GamePaint_003(HDC hDC)
{
	MoveToEx(hDC, 10, 40, NULL);
	LineTo(hDC, 44, 10);
	LineTo(hDC, 78, 40);
}

void GamePaint_004(HDC hDC)
{
	Rectangle(hDC, 16, 36, 72, 70);
	Rectangle(hDC, 34, 50, 54, 70);
}

void GamePaint_005(HDC hDC)
{
	Ellipse(hDC, 40, 55, 48, 65);
}

void GamePaint_006(HDC hDC)
{
	POINT points[3];
	points[0] = { 305, 10 };
	points[1] = { 355, 50 };
	points[2] = { 325, 55 };
	Polygon( hDC, points, 3 );
}

void GamePaint_007(HDC hDC) {
	RECT msg_clip;

	SetRect ( &msg_clip, 300, 0, 400, 50);
//	DrawText( hdc, TEXT( m_pastestr ), -1, &msg_clip, DT_NOCLIP);
	DrawText( hDC, TEXT( "GamePaint_007" ), -1, &msg_clip, DT_NOCLIP);
}

// 3 points :triangle
void GamePaint_008(HDC hDC, POINT* points)
{
	POINT p = points[0];
	printf("point 1: %ld %ld\r\n", p.x, p.y );
	Polygon( hDC, points, 3 );
}
