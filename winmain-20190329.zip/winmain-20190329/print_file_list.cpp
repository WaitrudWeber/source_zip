#include<stdarg.h>
#include<stdio.h>
//#include<iostream>
#include <windows.h>

#include "array_counter.h"
#include "sender.h"
#include "Print.h"
#include "aDebug.h"
#include "list_directory.h"
#include "parse.h"
#include "print_file_list.h"

char** print_file_list ( char* path, int* number) ;
char* print_file_list_char_string ( char* path) ;


//https://stackoverflow.com/questions/3919850/conversion-from-myitem-to-non-scalar-type-myitem-requested
//
char** print_file_list ( char* path, int* number) {

	FileControler* fc = nullptr;
	fc = new FileControler;

	return fc->get_files( path, number);
}

//
//
//
//
//
char* print_file_list_char_string ( char* path) {
	int* number;
	char* result;
	
	number = (int*) malloc ( sizeof (int) );

	FileControler* fc = nullptr;
	fc = new FileControler;

	char **fl = (char**)fc->get_files( path, number);
	fc->print_strings();

	printf("number: %d \r\n", *number );
	for(int i=0; i<*number; i++ ) {
		printf("fl: %3d %s", i, (char*) *( fl + i ));
		result = m_concat( result, (char*) *( fl + i ) );
		result = m_concat( result, copyof( (char*) "\r\n") );
	}

	put_memories(result);

	free(number);

	return result;
}

