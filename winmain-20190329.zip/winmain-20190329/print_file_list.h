#ifndef _PRINT_FILE_LIST_H_
#define _PRINT_FILE_LIST_H_

char** print_file_list ( char* path, int* number) ;
char* print_file_list_char_string ( char* path) ;

#endif
