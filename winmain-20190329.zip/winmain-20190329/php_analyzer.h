#ifndef _PHP_ANALYZER_H_
#define _PHP_ANALYZER_H_

extern FILE *write_fp;
extern int php_parse ( char* filename );

#endif

