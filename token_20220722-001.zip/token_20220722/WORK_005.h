#ifndef _WORK_005_H_
#define _WORK_005_H_
class WORK_005 { 
	public:
		WORK_006 *iWORK_005=nullptr;

	public:
		SetWORK_006( WORK006 *lWORK006 ); 

};
#endif
