// getip.c

#include <stdio.h>
#include <winsock.h>

int WSAStartup(
  WORD wVersionRequested,
  LPWSADATA lpWSAData
);

WORD MAKEWORD(
  BYTE bLow, 
  BYTE bHigh 
);

typedef struct WSAData {
  WORD                  wVersion;
  WORD                  wHighVersion;
  char                  szDescription[WSADESCRIPTION_LEN+1];
  char                  szSystemStatus[WSASYS_STATUS_LEN+1];
  unsigned short        iMaxSockets;
  unsigned short        iMaxUdpDg;
  char FAR *            lpVendorInfo;
} WSADATA, *LPWSADATA; 

int gethostname(
  char FAR *name,  
  int namelen       
);

struct hostent FAR *gethostbyname(
  const char FAR *name  
);

struct hostent {
  char FAR *       h_name;
  char FAR * FAR * h_aliases;
  short            h_addrtype;
  short            h_length;
  char FAR * FAR * h_addr_list;
};

struct in_addr {
  union {
          struct { u_char s_b1,s_b2,s_b3,s_b4; }   S_un_b;
          struct { u_short s_w1,s_w2; }            S_un_w;
          u_long                                   S_addr;
  } S_un;
};

typedef struct in_addr IN_ADDR;

char FAR * inet_ntoa(
  struct   in_addr in  
);


int main()
{
    HOSTENT *lpHost;
    IN_ADDR inaddr;
    WSADATA wsadata;
    char szBuf[256], szIP[256];

    if (WSAStartup(MAKEWORD(1, 1), &wsadata)) {
        printf("WSAStartup�֐����s�ł�\n");
        return -1;
    }
    printf("wVersion = %u\n", wsadata.wVersion);
    printf("wHighVersion = %u\n", wsadata.wHighVersion);
    printf("szDescription = %s\n", wsadata.szDescription);
    printf("szSystemStatus = %s\n", wsadata.szSystemStatus);
    printf("iMaxSockets = %d\n", wsadata.iMaxSockets);
    printf("iMaxUdpDg = %d\n", wsadata.iMaxUdpDg);
    gethostname(szBuf, (int)sizeof(szBuf));
    printf("\n�z�X�g��=%s\n", szBuf);
    lpHost = gethostbyname(szBuf);
    memcpy(&inaddr, lpHost->h_addr_list[0], 4);
    strcpy(szIP, inet_ntoa(inaddr));
    printf("IP�A�h���X=%s\n", szIP);
    WSACleanup();

    return 0;
}
