

extern int pastechar (HWND hwnd, char *str);

extern int ReadClip(HWND hwnd, char *str);
extern int WriteClip(HWND hwnd, char *str);

extern int Paset(HWND hwnd, char *str);


