#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"	// ADD: 20200125
#include "sender.h"			// ADD: 20200125
#include "Print.h"			// ADD: 20200125

#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vCalculation.h"

#include "creation_of_objects.h"

vCircle_2D** vCircle_2D_001;

int initialize_vCircle_2D_001() ;

int initialize_vCircle_2D_001() {

	vCircle_2D_001 = (vCircle_2D** ) malloc (sizeof(vCircle_2D*) * 30 );
	if ( vCircle_2D_001 == nullptr ) {
		printf("we cannot malloc memories as vCircle_2D_001.\r\n");
	}
	vCircle_2D_001[0] = new vCircle_2D ( 196.177856, 330.639984, 17.162390 );
	vCircle_2D_001[1] = new vCircle_2D ( 449.388702, 342.417664, 15.045014 );
	vCircle_2D_001[2] = new vCircle_2D ( 518.609558, 209.156769, 13.782769 );
	vCircle_2D_001[3] = new vCircle_2D ( 290.321350, 165.883972, 6.710410 );
	vCircle_2D_001[4] = new vCircle_2D ( 129.066437, 45.601978, 8.822290 );
	vCircle_2D_001[5] = new vCircle_2D ( 204.771881, 213.697922, 14.892423 );
	vCircle_2D_001[6] = new vCircle_2D ( 281.395294, 104.900665, 17.151402 );
	vCircle_2D_001[7] = new vCircle_2D ( 518.472839, 218.224426, 3.640248 );
	vCircle_2D_001[8] = new vCircle_2D ( 9.179968, 470.976288, 13.345744 );
	vCircle_2D_001[9] = new vCircle_2D ( 265.574524, 267.019867, 1.450850 );
	vCircle_2D_001[10] = new vCircle_2D ( 590.916443, 5.654469, 16.121708 );
	vCircle_2D_001[11] = new vCircle_2D ( 510.894501, 256.326172, 3.551744 );
	vCircle_2D_001[12] = new vCircle_2D ( 147.738876, 4.438612, 13.783990 );
	vCircle_2D_001[13] = new vCircle_2D ( 393.644836, 195.225677, 8.499405 );
	vCircle_2D_001[14] = new vCircle_2D ( 247.878662, 172.080444, 12.828761 );
	vCircle_2D_001[15] = new vCircle_2D ( 249.753723, 139.091156, 16.729027 );
	vCircle_2D_001[16] = new vCircle_2D ( 583.396729, 330.669281, 8.098392 );
	vCircle_2D_001[17] = new vCircle_2D ( 284.227417, 129.671921, 18.904385 );
	vCircle_2D_001[18] = new vCircle_2D ( 5.605640, 195.254990, 7.635121 );
	vCircle_2D_001[19] = new vCircle_2D ( 412.571198, 339.839478, 4.308603 );
	vCircle_2D_001[20] = new vCircle_2D ( 217.799622, 146.283768, 1.037629 );
	vCircle_2D_001[21] = new vCircle_2D ( 266.238586, 204.747452, 16.559343 );
	vCircle_2D_001[22] = new vCircle_2D ( 383.644531, 15.937986, 19.224831 );
	vCircle_2D_001[23] = new vCircle_2D ( 362.862640, 406.872772, 8.213752 );
	vCircle_2D_001[24] = new vCircle_2D ( 582.478699, 64.586929, 18.546099 );
	vCircle_2D_001[25] = new vCircle_2D ( 478.745087, 190.787079, 9.773858 );
	vCircle_2D_001[26] = new vCircle_2D ( 302.724091, 56.031982, 15.673086 );
	vCircle_2D_001[27] = new vCircle_2D ( 207.408676, 274.959564, 4.710227 );
	vCircle_2D_001[28] = new vCircle_2D ( 296.727814, 144.965363, 4.088870 );
	vCircle_2D_001[29] = new vCircle_2D ( 503.687256, 20.376598, 2.978606 );

	return 0;
}

