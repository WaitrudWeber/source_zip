#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <cstdio>
#include <windows.h>

#include "Print.h"
#include "vPoint.h"

vPoint::vPoint ( ) {
}

vPoint::vPoint ( float xx, float yy, float zz) {
	this->x = xx;
	this->y = yy;
	this->z = zz;
}

vPoint::setPoint ( float xx, float yy, float zz) {
	this->x = xx;
	this->y = yy;
	this->z = zz;
}

vPoint vPoint::subtract( vPoint a, vPoint b ) {
	vPoint result;

	return result;
}

void vPoint::print( ) {

	err_msg_001("p|%p|( %f, %f, %f)\r\n", this, this->x, this->y, this->z );
}

