#include <stdio.h>
#include <stdlib.h>

#include "log_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"


extern char* filename_read_csv_000a_013_ = (char*)"read_csv_000a_013.txt";

int read_csv_000a_013 ();
int set_read_csv_000a_013 (char** argv, int argc);
int initialize_read_csv_000a_013 (char** argv, int argc);
int caribration_memoreies_013 () ;

int memories_width_013 ( int from_w_i, int width, int height, char*** mem ) ;
int memories_height_013 ( int width, int height, char*** mem ) ;
char**	realloc_char_002_01_013 ( char** restr, int num ) ;
char***	realloc_char_003_01_013 ( char*** restr, int num ) ;

int read_csv_000a_013 () {
	return 1;

}


int read_csv_000a_set_013 (char** argv, int argc) {
 	return 1;
 
}

int initialize_read_csv_000a_013 (char** argv, int argc) {
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"int initialize_read_csv_000a_013 (char** argv, int argc) starts.", 0 ) ;
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"int initialize_read_csv_000a_013 (char** argv, int argc) ends.", 1 ) ;
 	return 1;
 
}

int caribration_memoreies_013 () {
	int a, i, j, count;
	char*** mem;
	FILE *fp;

	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"int caribration_memoreies_013 () starts.", 1 ) ;
	a = memories_width_013 ( 0, 16, 16, (char***) mem ) ;
	a = memories_height_013 ( 16, 16, (char***) mem ) ;

	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"Loop csvfree starts.", 0 ) ;
	for ( int j=0; i<16; i++ ) 
	for ( int j=0; j<16; j++ ) {
		sprintf( logmsg, "memaddress |%p|i|%d|j|%d| %s\0", (char**)&mem[i][j],  i, j, (char*)mem[i][j] );
		Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;

		csvafree_005 ( mem[i][j] );

		sprintf( logmsg, "memaddress |%p|i|%d|j|%d| %s\0", (char**)&mem[i][j],  i, j, (char*)mem[i][j] );
		Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;
	}

	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"int caribration_memoreies_013 () ends.", 1 ) ;
 	return 1;
}


int memories_width_013 ( int from_w_i, int width, int height, char*** mem ) {

	int i, j;
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"int memories_width_013 ( int from_w_i, int width, int height, char*** mem ) starts.", 1 ) ;

	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"mem = (char***) realloc_char_003_01 ( mem, width ); before:", 1 ) ;
	mem = (char***) realloc_char_003_01_013 ( mem, width );
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"mem = (char***) realloc_char_003_01 ( mem, width ); after:", 1 ) ;

	for ( i = from_w_i; i<width; i++ ) {
		sprintf( logmsg, "memaddress (char***)|%p|i|%d| (char**)|%p|\0", (char***)&mem[i],  i, (char**)mem[i] );
		Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;
		mem[i] = (char**) realloc_char_002_01_013  ( mem[i], height );
		for ( j=0; j<height; j++ ) {
			sprintf( logmsg, "memaddress |%p|i|%d|j|%d| %s\0", (char**)&mem[i][j],  i, j, (char*)mem[i][j] );
			Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;
			if ( &mem[i][j] != NULL ) mem[i][j] = (char*)csvcopyof_005 ( (char*)"-" );
			sprintf( logmsg, "memaddress |%p|i|%d|j|%d| %s\0", (char**)&mem[i][j],  i, j, (char*)mem[i][j] );
			Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;
		}
	}

	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"int memories_width_013 ( int from_w_i, int width, int height, char*** mem ) ends.", 1 ) ;
	return 0;
}

int memories_height_013 ( int width, int height, char*** mem ) {

	int i,j;

	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"int memories_height_013 ( int width, int height, char*** mem ) starts.", 1 ) ;
	mem = (char***) realloc_char_003_01_013 ( mem, width );
	for ( i = 0; i<width; i++ ) {
		mem[i] = (char**) realloc_char_002_01_013  ( mem[i], height );
		for ( j=0; j<height; j++ ) {
			sprintf( logmsg, "memaddress |%p|i|%d|j|%d| %s\0", (char**)&mem[i][j],  i, j, (char*)mem[i][j] );
			Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;
		}
	}

	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"int memories_height_013 ( int width, int height, char*** mem ) ends.", 1 ) ;
	return 0;
}


//
char**	realloc_char_002_01_013 ( char** restr, int num ) {
	char** result;
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"char**	realloc_char_002_01_013 ( char** restr, int num ) starts.", 1 ) ;

	sprintf( logmsg, "result|%s| restr|%s|\0", result, restr );
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;

	result = (char**)realloc ( restr, sizeof (char*) * num ) ;

	sprintf( logmsg, "result|%s| restr|%s|\0", result, restr );
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;
	if ( result == NULL ) {
		result = restr;
	}

	sprintf( logmsg, "result|%s| restr|%s|\0", result, restr );
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;
	if (result == NULL ) {
		Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"We cannot allocate the result. re 002_01_013.", 1 ) ;
		exit(-1);
	}

	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"char**	realloc_char_002_01_013 ( char** restr, int num ) ends.", 1 ) ;
	return result;
}


char***	realloc_char_003_01_013 ( char*** restr, int num ) {
	char*** result;
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"char***	realloc_char_003_01_013 ( char*** restr, int num ) starts.", 1 ) ;

	result = (char***)realloc ( restr, sizeof (char**) * num ) ;

	sprintf( logmsg, "result|%s| restr|%s|\0", result, restr );
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;
	if ( result == NULL ) {
		result = restr;
	}

	sprintf( logmsg, "result|%s| restr|%s|\0", result, restr );
	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)logmsg, 1 ) ;
	if (result == NULL ) {
		Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"We cannot allocate the result. re 003_01_013.", 1 ) ;
		exit(-1);
	}

	Log_Add ( (char*) filename_read_csv_000a_013_, (char*)"char***	realloc_char_003_01_013 ( char*** restr, int num ) ends.", 1 ) ;
	return result;
}
