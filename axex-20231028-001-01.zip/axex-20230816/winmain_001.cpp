// https://github.com/WaitrudWeber/source_zip/blob/master/winmain-20190109.zip
// https://docs.microsoft.com/en-us/windows/desktop/dataxchg/using-the-clipboard

//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>

// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-hProcess-in-mingw-what-to-use-instead
// #include <strsafe.h>

//#include <mmdeviceapi.h>

#include "resource.h"

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"

#include "clipboard.h"

#include "button.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "display_threeD.h"
#include "vPointStructure.h"


#include "vSoundBuffer_001.h"


#include "wEvent.h"
#include "wEventListener.h"

#include "wJavaStructure.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

#include "wTextarea.h"
#include "wTextareaController.h"

#include "something_word.h"
#include "thread_print.h"


#include "wDisplayController.h"
//#include "wParamSynse_003.h"
#include "wCanvasController.h"

#include "cg_schema.h"


#include "ReturnableParam.h"

#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "winmainthread_001.h"
#include "winmainthread_002.h"
#include "winmainthread_003.h"


#define _DRAW_PARAM_00000000000000000000000000000001_ 1
#define _DRAW_PARAM_00000000000000000000000000000010_ 2
#define _DRAW_PARAM_00000000000000000000000000000100_ 4
#define _DRAW_PARAM_00000000000000000000000000001000_ 8
#define _DRAW_PARAM_00000000000000000000000000010000_ 16
#define _DRAW_PARAM_00000000000000000000000000100000_ 32
#define _DRAW_PARAM_00000000000000000000000001000000_ 64
#define _DRAW_PARAM_00000000000000000000000010000000_ 128
#define _DRAW_PARAM_00000000000000000000000100000000_ 256
#define _DRAW_PARAM_00000000000000000000001000000000_ 512
#define _DRAW_PARAM_00000000000000000000010000000000_ 1024
#define _DRAW_PARAM_00000000000000000000100000000000_ 2048
#define _DRAW_PARAM_00000000000000000001000000000000_ 4096
#define _DRAW_PARAM_00000000000000000010000000000000_ 8192
#define _DRAW_PARAM_00000000000000000100000000000000_ 16384
#define _DRAW_PARAM_00000000000000001000000000000000_ 32768
#define _DRAW_PARAM_00000000000000010000000000000000_ 65536
#define _DRAW_PARAM_00000000000000100000000000000000_ 131072
#define _DRAW_PARAM_00000000000001000000000000000000_ 262144
#define _DRAW_PARAM_00000000000010000000000000000000_ 524288



//------------------------------------------------
// Macro for switch
//------------------------------------------------
#define CASE        break;case
#define DEFAULT     break;default

//------------------------------------------------
// Constant for Screen
//------------------------------------------------
#define SCREEN_STYLE        (WS_OVERLAPPEDWINDOW ^ (WS_THICKFRAME|WS_MAXIMIZEBOX))
#define SCREEN_WIDTH        (640)       // Screen Width (32dot x 20)
#define SCREEN_HEIGHT       (480)       // Screen Height (32dot x 15)

//------------------------------------------------
// Define Error message
//------------------------------------------------
#define ERRMSG_TITLE        TEXT("WinMain Function")
#define ERRMSG_WINREG       TEXT("Window Class can not be set.")
#define ERRMSG_CREATE       TEXT("Window can not be created.")

#define BOX_ELLIPSE  0 
#define BOX_RECT     1 
 
#define CCH_MAXLABEL 80 
#define CX_MARGIN    12 

DEFINE_GUID(IID_IMMDeviceEnumerator, 0xa95664d2, 0x9614, 0x4f35, 0xa7,0x46, 0xde,0x8d,0xb6,0x36,0x17,0xe6);

 typedef struct tagLABELBOX {  // box 
    RECT rcText;    // coordinates of rectangle containing text 
    BOOL fSelected; // TRUE if the label is selected 
    BOOL fEdit;     // TRUE if text is selected 
    int nType;      // rectangular or elliptical 
    int ichCaret;   // caret position 
    int ichSel;     // with ichCaret, delimits selection 
    int nXCaret;    // window position corresponding to ichCaret 
    int nXSel;      // window position corresponding to ichSel 
    int cchLabel;   // length of text in atchLabel 
    TCHAR atchLabel[CCH_MAXLABEL]; 
} LABELBOX, *PLABELBOX;

wButton button1((char *)"File Open - o -");
wButton button2((char *)"Something Sentence - s -");
wButton button3((char *)"Something Word - w -");
wButton button4((char *)"Animation - a -");
wButton button5((char *)"Web Link - l -");
wButton button6((char *)"Print Html - p -");
wButton button7((char *)"Exit - e -");
wButton button8((char *)"Edit - Ctl -");
wButton button9((char *)"Display 3D - 3 -");

wButton button11((char *)"bExit - e -");
wButton button12((char *)"bMusicValume - Ctl -");
wButton button13((char *)"bDisplay 3D - 3 -");

wButton button21((char *)"Image Load - i -");
wButton button22((char *)"Number Line - n -");
wButton button23((char *)"Distance Line - d -");


char* m_button_select;
int m_button_number_select;
HHOOK hMyHook;

void ButtonSelectDown ();
void ButtonSelectUp ();
// light = 0 means non-select
// light = 1 means select
void ButtonLight( int light, int bn );


void MyHookStart(HWND hWnd) ;
void MyHookEnd(HWND hWnd) ;
LRESULT CALLBACK MyHookProc(int nCode, WPARAM wp, LPARAM lp) ;
static void paintWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
void escape_action( int mode );

void wm_char( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, int m_mode, int btc_CursolNumber, int call_once_key, int key_w );
void paint_clipboard () ;
void ReplaceSelection (HWND hwnd, PLABELBOX pbox, LPTSTR lptstr) ;

VOID WINAPI EditPasteA(VOID) ;
VOID WINAPI EditPaste(VOID) ;


// 20210325
//DWORD WINAPI Animation_5times_thread ( HDC *hdc, UINT *uMsg, WPARAM *wParam, LPARAM *lParam,  PAINTSTRUCT *ps_001) ;
DWORD WINAPI Animation_5times_thread ( LPVOID hdc ) ;
int Animation_5times_thread_011 ( HDC *hdc ) ;
static LRESULT CALLBACK mainWindowProc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
static LRESULT CALLBACK mainWindowProc_012 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
static LRESULT CALLBACK mainWindowProc_013 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
static LRESULT CALLBACK mainWindowProc_014 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
static LRESULT CALLBACK mainWindowProc_015 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
static LRESULT CALLBACK mainWindowProc_016 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
static LRESULT CALLBACK mainWindowProc_017 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
static LRESULT CALLBACK mainWindowProc_018 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
static LRESULT CALLBACK mainWindowProc_019 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
static void paintWindowProc_011( HWND hWnd, HDC* hdc, UINT uMsg, WPARAM wParam, LPARAM lParam,  PAINTSTRUCT *ps_001);

// 20210325
int animation_times = 5;
int process_call_times = 0;

const char* wichStandardClipboardFormatsIsAvailable();

// char* concat( char *head, char *tail ) ;
char m_string[256];
int once_hook = 0;

WPARAM key_w;
LPARAM key_l;
int num_btn;

int key_state;

wButtonController btc;
wButtonController btc2;
wButtonController btc3;
wCanvasController canvas;
int call_once = 0;
int call_once_001 = 0;
int call_once_key = 0;

int written_x = 0;
int written_y = 0;

// x CString aaa;

// int m_mode = -1; in parse.h

//filename
TCHAR m_szDir[MAX_PATH];

char* m_pastestr;
char* m_replace_selection;

int succ_paste = 0;

UINT uFormat = (UINT)(-1);
UINT uLabelFormat = (UINT)(-1);

HWND hwnd;
HGLOBAL hglb;
HWND hwndOwner;
LPRECT lprc;
HWND hWnd;

HWND hwndSelected;
HWND hwndMain;
HINSTANCE hInstanceMain;
int cyText = 10;

//
// handle of triger
int hTriger = 0;

char* char_sub_window = copyof("TextWindow");
HINSTANCE sub_hInstance = GetModuleHandle( char_sub_window );

int once_cg_schema = 0;

int Cursol_Number = 1;
int refreshtimes = 0;

vDisplayController display_001;
vDisplayController display_002;
vDisplayController_001 display_003;
vDisplayController_002 display_004;

static int modes[5];
static int operations[5];
static int animation_times_001 = 0;
static int log_index = 0;

// (same as static) int modes[4];
// (same as static) int operations[4];
// (same as static) int animation_times_001 = 0;

static RECT RefreshRect;

wTextareaController wtextareacontroller;
vSoundBuffer_001 vsoundbuffer001;

void list_directory () {
	WIN32_FIND_DATA ffd;
	HANDLE hFind;
	TCHAR szDir[MAX_PATH];
	BOOL b;

	hFind = INVALID_HANDLE_VALUE;
	//hFind = FindFirstFile(szDir, &ffd);
	//hFind = FindFirstFile("c:\\aaa\\*", &ffd);
	hFind = FindFirstFile("c:\\*", &ffd);
	strcpy( m_szDir, ffd.cFileName  );
	strcat( m_szDir, " : " );

	b = FindNextFile( hFind, &ffd);
	strcat( m_szDir, ffd.cFileName  );
	strcat( m_szDir, " : " );

	b = FindNextFile( hFind, &ffd);
	strcat( m_szDir, ffd.cFileName  );
	strcat( m_szDir, " : " );

	// _tprintf(TEXT("  %s   <DIR>\n"), ffd.cFileName );
	//	_tcscpy_s(m_szDir, _countof(m_szDir), _T("Hello"));

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-h-in-mingw-what-to-use-instead
// #include <strsafe.h>
// StringCchCopy(szDir, MAX_PATH, ffd.cFileName);

	FindClose(hFind);
}





//
//
//
//
//
void initialize( int m ) {

	switch( btc.CursolNumber ) {
	case 0:
		list_directory ();
		break;
	case 2:
		something_word_initialize ();
		break;
	case 9:
		// 20210306
		//display_threeD_initialize ();
		break;
	default:
		break;
	}
}

// 20220416
DWORD WINAPI Animation_5times_thread ( LPVOID hdc ) {
	char l_buffer[255];
	RECT msg_key_001;
	static HFONT hFont, hFont2;
	int x1, x2, y1, y2;

	printf("Animation_5times_thread starts.\r\n");
	DWORD hdc_011 = *(DWORD*)hdc;

	for ( int i = 0; i<5; i++ ) {
		switch( i ) {
		case 0:
			break;
		case 1:
			display_004.DisplayBones_002 ();
			break;
		case 2:
			display_004.SetBaseAxex ();
			break;
		case 3:
			display_004.SetEye ( -1000.0f, 1000.0f, -1000.0f);
			break;
		}

		switch(modes[ log_index % 5 ]) {
		case 29:
			switch(operations[ log_index % 5 ]) {
			case 80: //p
				display_004.DisplayBones_002 ();
				break;
			case 81: //q
				display_004.SetBaseAxex ();
				break;
			case 82: //r
				display_004.SetEye ( -1000.0f, 1000.0f, -1000.0f) ;
				break;
			case 83: //s
				display_004.SetEye ( -1000.0f, -1000.0f, -1000.0f) ;
				break;
			case 84: //t
				display_004.SetEye ( 1000.0f, -1000.0f, -1000.0f) ;
				break;
			}
			break;
		}

		written_x += 20;
		written_y += 20;

		InvalidateRect( hWnd, &RefreshRect, TRUE);
		animation_times--;
		Sleep(333);
	}

	printf("Animation_5times_thread ends.\r\n");
	return 0;
}

// 20210325
//DWORD WINAPI Animation_5times_thread ( HDC *hdc, UINT *uMsg, WPARAM *wParam, LPARAM *lParam,  PAINTSTRUCT *ps_001) {
DWORD WINAPI Animation_5times_thread_validate ( LPVOID hdc ) {
	char l_buffer[255];
	RECT msg_key_001;
	static HFONT hFont, hFont2;
	int x1, x2, y1, y2;

	printf("Animation_5times_thread starts.\r\n");
	DWORD hdc_011 = *(DWORD*)hdc;

	for ( int i = 0; i<5; i++ ) {
		//Last Messaegs:
		hFont = CreateFont (50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject((HDC)(hdc_011), hFont);

		x1 = written_x + 300;
		y1 = written_y + 200;
		x2 = written_x + 400;
		y2 = written_y + 350;

		SetRect( &msg_key_001, x1, y1, x2, y2 );
		sprintf( l_buffer, "l_buffer %d ", animation_times );
		DrawText( (HDC)(hdc_011), TEXT( l_buffer ), -1, &msg_key_001, DT_NOCLIP );
		printf("|%s| %d %d %d %d\r\n", l_buffer, x1, y1, x2, y2 );
		SelectObject((HDC)(hdc_011), hFont2);
		DeleteObject(hFont);

		written_x += 20;
		written_y += 20;

		//InvalidateRect( hWnd, &RefreshRect, TRUE);
		ValidateRect( hWnd, &RefreshRect);
		animation_times--;
		Sleep(333);
	}

	printf("Animation_5times_thread ends.\r\n");
	return 0;
}

// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
static LRESULT CALLBACK mainWindowProc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = 0;
	static HDC     hDC;
	static PAINTSTRUCT ps_001;
	static char x_b[255];
	static char y_b[255];
	static RECT rect_x, rect_y;
	static HFONT hFont, hFont2;
	static int flg_paint = 0;
	static int DRAW_PARAM = 0;
	static RECT rect_xy[20];

	if ( p_evt == nullptr ) {
		p_evt = new wEvent ();
	}

	p_evt->hWnd = hWnd;
	p_evt->uMsg = &uMsg;
	p_evt->wParam = wParam;
	p_evt->lParam = lParam;
	p_evt->main_mode = m_mode;
	wtextareacontroller.setEvent ( p_evt );

	// Code Block 1 - 01:
	p_evt->Type = uMsg;

	switch (uMsg) {
	case WM_CREATE:
		SetRect( &rect_x, 300, 300, 450, 350 );
		SetRect( &rect_y, 405, 300, 600, 350 );
		SetRect( &rect_xy[0], 10, 60, 10, 60 );
		SetRect( &rect_xy[1], 60, 110, 10, 60 );
		SetRect( &rect_xy[2], 110, 160, 10, 60 );
		SetRect( &rect_xy[3], 160, 210, 10, 60 );
		SetRect( &rect_xy[4], 210, 260, 10, 60 );
		SetRect( &rect_xy[5], 260, 310, 10, 60 );
		SetRect( &rect_xy[6], 310, 360, 10, 60 );
		SetRect( &rect_xy[7], 360, 410, 10, 60 );
		SetRect( &rect_xy[8], 410, 460, 10, 60 );
		SetRect( &rect_xy[9], 460, 510, 10, 60 );
		SetRect( &rect_xy[10], 510, 560, 10, 60 );
		SetRect( &rect_xy[11], 560, 610, 10, 60 );
		SetRect( &rect_xy[12], 610, 660, 10, 60 );
		SetRect( &rect_xy[13], 10, 60, 60, 110 );
		SetRect( &rect_xy[14], 60, 110, 60, 110 );
		SetRect( &rect_xy[15], 110, 160, 60, 110 );
		SetRect( &rect_xy[16], 160, 210, 60, 110 );
		SetRect( &rect_xy[17], 210, 260, 60, 110 );
		SetRect( &rect_xy[18], 260, 310, 60, 110 );
		SetRect( &rect_xy[19], 310, 360, 60, 110 );
		break;
	case WM_MOUSEMOVE: //512
;		sprintf( x_b, "x %d ", GET_X_LPARAM ( lParam ) );
		sprintf( y_b, "y %d ", GET_Y_LPARAM ( lParam ) );
		b_Processed = 1;
		InvalidateRect( hWnd, &rect_x, FALSE);
		InvalidateRect( hWnd, &rect_y, FALSE);
		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d\r\n", WM_MOUSEMOVE, flg_paint );
		break;
	case WM_PAINT: //15
		hDC = BeginPaint( hWnd, &ps_001 );
		p_evt->hDc = hDC;
		p_evt->ps = &ps_001;
		hFont = CreateFont (30, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);

		SetTextColor( hDC, RGB(0 ,0, 255) );

		DrawText( (HDC) hDC, TEXT( x_b ), -1, &rect_x, DT_NOCLIP );
		DrawText( (HDC) hDC, TEXT( y_b ), -1, &rect_y, DT_NOCLIP );

		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000000000000001_ ) {
//$00000000000000000000000000000001
			printf("00000000000000000000000000000001\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000000000000010_ ) {
//$00000000000000000000000000000010
			printf("00000000000000000000000000000010\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000000000000100_ ) {
//$00000000000000000000000000000100
			printf("00000000000000000000000000000100\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000000000001000_ ) {
//$00000000000000000000000000001000
			printf("00000000000000000000000000001000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000000000010000_ ) {
//$00000000000000000000000000010000
			printf("00000000000000000000000000010000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000000000100000_ ) {
//$00000000000000000000000000100000
			printf("00000000000000000000000000100000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000000001000000_ ) {
//$00000000000000000000000001000000
			printf("00000000000000000000000001000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000000010000000_ ) {
//$00000000000000000000000010000000
			printf("00000000000000000000000010000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000000100000000_ ) {
//$00000000000000000000000100000000
			printf("00000000000000000000000100000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000001000000000_ ) {
//$00000000000000000000001000000000
			printf("00000000000000000000001000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000010000000000_ ) {
//$00000000000000000000010000000000
			printf("00000000000000000000010000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000000100000000000_ ) {
//$00000000000000000000100000000000
			printf("00000000000000000000100000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000001000000000000_ ) {
//$00000000000000000001000000000000
			printf("00000000000000000001000000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000010000000000000_ ) {
//$00000000000000000010000000000000
			printf("00000000000000000010000000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000000100000000000000_ ) {
//$00000000000000000100000000000000
			printf("00000000000000000100000000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000001000000000000000_ ) {
//$00000000000000001000000000000000
			printf("00000000000000001000000000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000010000000000000000_ ) {
//$00000000000000010000000000000000
			printf("00000000000000010000000000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000000100000000000000000_ ) {
//$00000000000000100000000000000000
			printf("00000000000000100000000000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000001000000000000000000_ ) {
//$00000000000001000000000000000000
			printf("00000000000001000000000000000000\r\n");
		} 
		if ( DRAW_PARAM && _DRAW_PARAM_00000000000010000000000000000000_ ) {
//$00000000000010000000000000000000
			printf("00000000000010000000000000000000\r\n");
		} 
		b_Processed = 2;
		flg_paint = 1;
		printf("WM_PAINT=uMsg=%d flg_paint=%d hDC %d\r\n", WM_PAINT, flg_paint, hDC );
		break;
	case WM_KEYUP:
		InvalidateRect( hWnd, &RefreshRect, TRUE);
		InvalidateRect( hWnd, &rect_x, FALSE);
		b_Processed = 1;
		printf("WM_KEYUP=uMsg=%d flg_paint=%d\r\n", WM_KEYUP, flg_paint );
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		printf("WM_KEYDOWN=uMsg=%d flg_paint=%d\r\n", WM_KEYDOWN, flg_paint );
		break;
	}

	switch (uMsg) {
	case WM_PAINT: //15
		SelectObject((HDC)(hDC), hFont2);
		DeleteObject(hFont);
		EndPaint( hWnd, &ps_001 );	
//		wtextareacontroller.stack_number_free ();
		break;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
static LRESULT CALLBACK mainWindowProc_019 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = 0;
	static HDC     hDC;
	static PAINTSTRUCT ps_001;
	static char x_b[255];
	static char y_b[255];
	static RECT rect_x, rect_y;
	static HFONT hFont, hFont2;
	static int flg_paint = 0;

	if ( p_evt == nullptr ) {
		p_evt = new wEvent ();
	}

	p_evt->hWnd = hWnd;
	p_evt->uMsg = &uMsg;
	p_evt->wParam = wParam;
	p_evt->lParam = lParam;
	p_evt->main_mode = m_mode;
	wtextareacontroller.setEvent ( p_evt );

	// Code Block 1 - 01:
	p_evt->Type = uMsg;

	switch (uMsg) {
	case WM_CREATE:
		SetRect( &rect_x, 300, 300, 450, 350 );
		SetRect( &rect_y, 405, 300, 600, 350 );
//		SetRect( &RefreshRect, 0, 0, 640, 480);
		break;
	case WM_MOUSEMOVE: //512
;		sprintf( x_b, "x %d ", GET_X_LPARAM ( lParam ) );
		sprintf( y_b, "y %d ", GET_Y_LPARAM ( lParam ) );
		b_Processed = 1;
		InvalidateRect( hWnd, &rect_x, FALSE);
		InvalidateRect( hWnd, &rect_y, FALSE);
//		InvalidateRect( hWnd, &RefreshRect, FALSE);
//		wtextareacontroller.setTextarea( 0, GET_X_LPARAM ( lParam ) );
//		wtextareacontroller.setTextarea( 1, GET_Y_LPARAM ( lParam )  );
//		wtextareacontroller.SetStackNumber( 2 );
		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d\r\n", WM_MOUSEMOVE, flg_paint );
		break;
	case WM_PAINT: //15
		hDC = BeginPaint( hWnd, &ps_001 );
		p_evt->hDc = hDC;
		p_evt->ps = &ps_001;
		hFont = CreateFont (30, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);

		SetTextColor( hDC, RGB(0 ,0, 255) );

		DrawText( (HDC) hDC, TEXT( x_b ), -1, &rect_x, DT_NOCLIP );
		DrawText( (HDC) hDC, TEXT( y_b ), -1, &rect_y, DT_NOCLIP );
		b_Processed = 2;

//		ValidateRect( hWnd, &rect_x);
//		ValidateRect( hWnd, &rect_y);


		flg_paint = 1;
		printf("WM_PAINT=uMsg=%d flg_paint=%d hDC %d\r\n", WM_PAINT, flg_paint, hDC );
		break;
	case WM_KEYUP:
		InvalidateRect( hWnd, &RefreshRect, TRUE);
		InvalidateRect( hWnd, &rect_x, FALSE);
//		InvalidateRect( hWnd, &rect_y, FALSE);
		b_Processed = 1;
		printf("WM_KEYUP=uMsg=%d flg_paint=%d\r\n", WM_KEYUP, flg_paint );
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		printf("WM_KEYDOWN=uMsg=%d flg_paint=%d\r\n", WM_KEYDOWN, flg_paint );
		break;
//	default:
//		if ( flg_paint == 0 ) b_Processed = 0;
//		else b_Processed = 1; 
//		break;
	}



//	wtextareacontroller.Process_001 ();

	switch (uMsg) {
	case WM_PAINT: //15
		SelectObject((HDC)(hDC), hFont2);
		DeleteObject(hFont);
		EndPaint( hWnd, &ps_001 );	
//		wtextareacontroller.stack_number_free ();
		break;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
static LRESULT CALLBACK mainWindowProc_018 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = 0;
	static HDC     hDC;
	static PAINTSTRUCT ps_001;
	static char x_b[255];
	static char y_b[255];
	static RECT rect_x, rect_y;
	static HFONT hFont, hFont2;
	static int flg_paint = 0;

	switch (uMsg) {
	case WM_CREATE:
		SetRect( &rect_x, 300, 300, 450, 350 );
		SetRect( &rect_y, 405, 300, 600, 350 );
//		SetRect( &RefreshRect, 0, 0, 640, 480);
		break;
	case WM_MOUSEMOVE: //512
;		sprintf( x_b, "x %d ", GET_X_LPARAM ( lParam ) );
		sprintf( y_b, "y %d ", GET_Y_LPARAM ( lParam ) );
		b_Processed = 1;
		InvalidateRect( hWnd, &rect_x, FALSE);
		InvalidateRect( hWnd, &rect_y, FALSE);
//		InvalidateRect( hWnd, &RefreshRect, FALSE);
		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d\r\n", WM_MOUSEMOVE, flg_paint );
		break;
	case WM_PAINT: //15
		hDC = BeginPaint( hWnd, &ps_001 );
		hFont = CreateFont ( 50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);

		SetTextColor( hDC, RGB(0 ,0, 255) );

		DrawText( (HDC) hDC, TEXT( x_b ), -1, &rect_x, DT_NOCLIP );
		DrawText( (HDC) hDC, TEXT( y_b ), -1, &rect_y, DT_NOCLIP );
		b_Processed = 2;

//		ValidateRect( hWnd, &rect_x);
//		ValidateRect( hWnd, &rect_y);

		SelectObject((HDC)(hDC), hFont2);
		DeleteObject(hFont);

		flg_paint = 1;
		printf("WM_PAINT=uMsg=%d flg_paint=%d\r\n", WM_PAINT, flg_paint );
		break;
	case WM_KEYUP:
//		InvalidateRect( hWnd, &RefreshRect, TRUE);
		InvalidateRect( hWnd, &rect_x, FALSE);
//		InvalidateRect( hWnd, &rect_y, FALSE);
		b_Processed = 1;
		printf("WM_KEYUP=uMsg=%d flg_paint=%d\r\n", WM_KEYUP, flg_paint );
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		printf("WM_KEYDOWN=uMsg=%d flg_paint=%d\r\n", WM_KEYDOWN, flg_paint );
		break;
//	default:
//		if ( flg_paint == 0 ) b_Processed = 0;
//		else b_Processed = 1; 
//		break;
	}



	wtextareacontroller.Process_001 ();

	switch (uMsg) {
	case WM_PAINT: //15
		EndPaint( hWnd, &ps_001 );	
		break;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
static LRESULT CALLBACK mainWindowProc_017 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = 0;
	static HDC     hDC;
	static PAINTSTRUCT ps_001;
	static char x_b[255];
	static char y_b[255];
	static RECT rect_x, rect_y;
	static HFONT hFont, hFont2;
	static int flg_paint = 0;

	switch (uMsg) {
	case WM_CREATE:
		SetRect( &rect_x, 300, 300, 350, 350 );
		SetRect( &rect_y, 350, 300, 400, 350 );
		break;
	case WM_MOUSEMOVE: //512
		InvalidateRect( hWnd, &RefreshRect, FALSE);
		sprintf( x_b, "x param %d ", GET_X_LPARAM ( lParam ) );
		sprintf( y_b, "y param %d ", GET_Y_LPARAM ( lParam ) );
		b_Processed = 1;
		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d\r\n", WM_MOUSEMOVE, flg_paint );
		break;
	case WM_PAINT: //15
		hFont = CreateFont (50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);

		SetTextColor( hDC, RGB(0 ,0, 255) );

		DrawText( (HDC) hDC, TEXT( x_b ), -1, &rect_x, DT_NOCLIP );
		DrawText( (HDC) hDC, TEXT( y_b ), -1, &rect_y, DT_NOCLIP );
		b_Processed = 2;

		ValidateRect( hWnd, &rect_x);
		ValidateRect( hWnd, &rect_y);

		SelectObject((HDC)(hDC), hFont2);
		DeleteObject(hFont);

		flg_paint = 1;
		printf("WM_PAINT=uMsg=%d flg_paint=%d\r\n", WM_PAINT, flg_paint );
		break;
	case WM_KEYUP:
		InvalidateRect( hWnd, &RefreshRect, FALSE);
		b_Processed = 1;
		printf("WM_KEYUP=uMsg=%d flg_paint=%d\r\n", WM_KEYUP, flg_paint );
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		printf("WM_KEYDOWN=uMsg=%d flg_paint=%d\r\n", WM_KEYDOWN, flg_paint );
		break;
//	default:
//		if ( flg_paint == 0 ) b_Processed = 0;
//		else b_Processed = 1; 
//		break;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
static LRESULT CALLBACK mainWindowProc_016 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = 0;
	static HDC     hDC;
	static PAINTSTRUCT ps_001;
	static char x_b[255];
	static char y_b[255];
	static RECT rect_x, rect_y;
	static HFONT hFont;
	static int flg_paint = 0;

	if ( flg_paint == 0 && ( uMsg == WM_CREATE || uMsg == WM_MOUSEMOVE || uMsg == WM_KEYUP || uMsg == WM_KEYDOWN ) ) {
		hDC = BeginPaint( hWnd, &ps_001 );
		flg_paint = 1;
	}

	switch (uMsg) {
	case WM_CREATE:
		SetRect( &rect_x, 300, 300, 350, 350 );
		SetRect( &rect_y, 350, 300, 400, 350 );
		hFont = CreateFont (50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		break;
	case WM_MOUSEMOVE: //512
		sprintf( x_b, "x param %d ", GET_X_LPARAM ( lParam ) );
		sprintf( y_b, "y param %d ", GET_Y_LPARAM ( lParam ) );
		DrawText( (HDC) hDC, TEXT( x_b ), -1, &rect_x, DT_NOCLIP );
		DrawText( (HDC) hDC, TEXT( y_b ), -1, &rect_y, DT_NOCLIP );
		//InvalidateRect( hWnd, &RefreshRect, TRUE);
		ValidateRect( hWnd, &rect_x );
		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d\r\n", WM_MOUSEMOVE, flg_paint );
		break;
	case WM_PAINT: //15
		printf("WM_PAINT=uMsg=%d flg_paint=%d\r\n", WM_PAINT, flg_paint );
		break;
	case WM_KEYUP: //256
		printf("WM_KEYUP=uMsg=%d flg_paint=%d\r\n", WM_KEYUP, flg_paint );
		break;
	case WM_KEYDOWN: //257
		printf("WM_KEYDOWN=uMsg=%d flg_paint=%d\r\n", WM_KEYDOWN, flg_paint );
		break;
	}

	if ( flg_paint == 1 && uMsg == WM_PAINT ) {
		EndPaint(hWnd, &ps_001);
		flg_paint = 0;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
static LRESULT CALLBACK mainWindowProc_015 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = 0;
	static HDC     hDC;
	static PAINTSTRUCT ps_001;
	static char x_b[255];
	static char y_b[255];
	static RECT rect_x, rect_y;
	static HFONT hFont, hFont2;
	static int flg_paint = 0;

	switch (uMsg) {
	case WM_CREATE:
		SetRect( &rect_x, 300, 300, 350, 350 );
		SetRect( &rect_y, 350, 300, 400, 350 );
		break;
	case WM_MOUSEMOVE: //512
		sprintf( x_b, "x param %d ", GET_X_LPARAM ( lParam ) );
		sprintf( y_b, "y param %d ", GET_Y_LPARAM ( lParam ) );
		b_Processed = 1;
		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d\r\n", WM_MOUSEMOVE, flg_paint );
		break;
	case WM_PAINT: //15
		hFont = CreateFont (50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);

		DrawText( (HDC) hDC, TEXT( x_b ), -1, &rect_x, DT_NOCLIP );
		DrawText( (HDC) hDC, TEXT( y_b ), -1, &rect_y, DT_NOCLIP );
		b_Processed = 2;
		ValidateRect( hWnd, &rect_x);
		ValidateRect( hWnd, &rect_y);

		SelectObject((HDC)(hDC), hFont2);
		DeleteObject(hFont);
		flg_paint = 1;
		printf("WM_PAINT=uMsg=%d flg_paint=%d\r\n", WM_PAINT, flg_paint );
		break;
	case WM_KEYUP:
		b_Processed = 1;
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		break;
//	default:
//		if ( flg_paint == 0 ) b_Processed = 0;
//		else b_Processed = 1; 
//		break;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
static LRESULT CALLBACK mainWindowProc_014 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = 0;
	static HDC     hDC;
	static PAINTSTRUCT ps_001;
	static char x_b[255];
	static char y_b[255];
	static RECT rect_x, rect_y;
	static HFONT hFont;
	static int flg_paint = 0;

	if ( flg_paint == 0 && ( uMsg == WM_CREATE || uMsg == WM_MOUSEMOVE || uMsg == WM_KEYUP || uMsg == WM_KEYDOWN ) ) {
		hDC = BeginPaint( hWnd, &ps_001 );
		flg_paint = 1;
	}

	switch (uMsg) {
	case WM_CREATE:
		SetRect( &rect_x, 300, 300, 350, 350 );
		SetRect( &rect_y, 350, 300, 400, 350 );
		hFont = CreateFont (50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		break;
	case WM_MOUSEMOVE: //512
		sprintf( x_b, "x param %d ", GET_X_LPARAM ( lParam ) );
		sprintf( y_b, "y param %d ", GET_Y_LPARAM ( lParam ) );
		DrawText( (HDC) hDC, TEXT( x_b ), -1, &rect_x, DT_NOCLIP );
		DrawText( (HDC) hDC, TEXT( y_b ), -1, &rect_y, DT_NOCLIP );
		//InvalidateRect( hWnd, &RefreshRect, TRUE);
		ValidateRect( hWnd, &RefreshRect);
		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d\r\n", WM_MOUSEMOVE, flg_paint );
		break;
	case WM_PAINT: //15
		printf("WM_PAINT=uMsg=%d flg_paint=%d\r\n", WM_PAINT, flg_paint );
		break;
	case WM_KEYUP:
		break;
	case WM_KEYDOWN:
		break;
	}

	if ( flg_paint == 1 && uMsg == WM_PAINT ) {
		EndPaint(hWnd, &ps_001);
		flg_paint = 0;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
static LRESULT CALLBACK mainWindowProc_013 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = -1;
	int b_call_once = 0;
	static HDC     hDC;
	PAINTSTRUCT ps_001;
	static char x_b[255];
	static char y_b[255];
	static RECT rect_x, rect_y;

	printf("001 hWnd|%d| uMsg|%d| wParam|%d| lParam|%d| b_Processed=%d\r\n", hWnd, uMsg, wParam, lParam, b_Processed );

	if ( uMsg != WM_PAINT && uMsg != WM_CREATE  ) {
		hDC = BeginPaint( hWnd, &ps_001 );
	} else {
		EndPaint( hWnd, &ps_001 );
	}

	printf("002 hWnd|%d| uMsg|%d| wParam|%d| lParam|%d| b_Processed=%d\r\n", hWnd, uMsg, wParam, lParam, b_Processed );
	printf("WM_CREATE %d WM_MOUSEMOVE %d WM_PAINT %d WM_KEYUP %d WM_KEYDOWN %d\r\n", WM_CREATE, WM_MOUSEMOVE , WM_PAINT, WM_KEYUP, WM_KEYDOWN);
	switch (uMsg) {
	case WM_CREATE:
		SetRect( &rect_x, 300, 300, 350, 350 );
		SetRect( &rect_y, 350, 300, 400, 350 );
		b_Processed = 1;
		b_call_once = 1;
		break;
	case WM_MOUSEMOVE:
		sprintf( x_b, "x param %d ", GET_X_LPARAM ( lParam ) );
		sprintf( y_b, "y param %d ", GET_Y_LPARAM ( lParam ) );
		DrawText( (HDC) hDC, TEXT( x_b ), -1, &rect_x, DT_NOCLIP );
		DrawText( (HDC) hDC, TEXT( y_b ), -1, &rect_y, DT_NOCLIP );
		b_Processed = 1;
		break;
	case WM_PAINT:
		b_Processed = 2;
		break;
	case WM_KEYUP:
		b_Processed = 1;
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		break;
	}
	printf("005 hWnd|%d| uMsg|%d| wParam|%d| lParam|%d| b_Processed=%d call_once=%d\r\n", hWnd, uMsg, wParam, lParam, b_Processed, call_once );

	if ( b_call_once == 2 ) {
		exit(-1);
	}

	if ( b_call_once == 1 ) {
		b_call_once = 2;
		exit(-1);
	}

	printf("005-01 hWnd|%d| uMsg|%d| wParam|%d| lParam|%d| b_Processed=%d\r\n", hWnd, uMsg, wParam, lParam, b_Processed );

	if ( b_call_once == 0 ) {
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	}

	printf("005-02 hWnd|%d| uMsg|%d| wParam|%d| lParam|%d| b_Processed=%d\r\n", hWnd, uMsg, wParam, lParam, b_Processed );

	switch ( b_Processed ) {
	case 0:
		break;
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	printf("006 hWnd|%d| uMsg|%d| wParam|%d| lParam|%d| b_Processed=%d\r\n", hWnd, uMsg, wParam, lParam, b_Processed );
	return 0;
}


//
int Animation_5times_thread_011 ( HDC *hdc ) {
	char l_buffer[255];
	static RECT msg_key;

	printf("Animation_5times_thread starts.\r\n");

	animation_times--;

	//Last Messaegs:
	SetRect( &msg_key, 300, 200, 400, 350 );
	sprintf( l_buffer, "l_buffer %d ", animation_times );
	DrawText( (HDC)(*hdc), TEXT( l_buffer ), -1, &msg_key, DT_NOCLIP );
	printf("|%s|\r\n", l_buffer);
//	Sleep(1000);

	printf("Animation_5times_thread ends.\r\n");
	return 0;
}


//
static void paintWindowProc_011( HWND hWnd, HDC* hdc, UINT uMsg, WPARAM wParam, LPARAM lParam,  PAINTSTRUCT *ps_001)
{
	static char ex_str[2048];
	static char str[2048];
	static char num_str[2048];
	static char pastestr[1024];
//	char *cstr;
//	int l_keystate = -1;

	RECT msg_key, msg_clip, msg_replace;
	FILE * pFile;
	RECT msg;
	int succ;
	DWORD ThreadId;
	HANDLE ThreadHandle;

	switch ( m_mode ) {

	// Explicit
	// Fully and clearly expressed; leaving nothing implied: 
	// That means curly braces.
	case -1:
	{
		itoa(key_w, num_str, 10);
		strcpy( str, "p key param: ");
		strcat( str, num_str );

		itoa(key_l, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );

		itoa(key_state, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );

		itoa(btc.CursolNumber, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );

		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 255, 0 ) );

		SelectObject(*hdc, hPen);

		// 100
		SetRect( &msg_key, 300, 100, 400, 250 );
//		SetTextColor( *hdc, RGB( 0, 0, 0) );
		DrawText( *hdc, TEXT( str ), -1, &msg_key, DT_NOCLIP );

		// 200
		SetRect(&msg_clip, 300, 200, 400, 250);
		DrawText( *hdc, TEXT( m_pastestr ), -1, &msg_clip, DT_NOCLIP);

		// 300
//		m_replace_selection = (char*)"m_replace_selectionA";
		SetRect(&msg_replace, 300, 300, 400, 350);
		DrawText( *hdc, TEXT( m_replace_selection ), -1, &msg_replace, DT_NOCLIP);
//		DrawText( hdc, TEXT( "m_replace_selectionA" ), -1, &msg_clip, DT_NOCLIP);

		// message
		SetRect( &msg, 300, 400, 400, 450);
		if ( succ == -1 ) {

			DrawText( *hdc, TEXT( "Could not read clipboard" ), -1, &msg, DT_NOCLIP);
		} else {

			ex_str[0] = '\0';
			itoa( btc.CursolNumber, num_str, 10);
			strcat( num_str, ":" );
			strcat( ex_str, num_str );
			itoa( succ_paste, num_str, 10);
			strcat( ex_str, num_str );
			DrawText( *hdc, TEXT( ex_str ), -1, &msg, DT_NOCLIP);
		}

		btc.drawButtons( *hdc );
		EndPaint(hWnd, ps_001);
		break;
	}
	case 0:
	{
		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );

		SelectObject(*hdc, hPen);
		SetRect(&msg_clip, 300, 300, 400, 350);
		SetTextColor(*hdc, RGB( 0, 0, 0));
		DrawText( *hdc, TEXT( "Could you push Escape until this works." ), -1, &msg_clip, DT_NOCLIP);
		SetRect(&msg_clip, 300, 350, 400, 400);
		DrawText( *hdc, m_szDir, -1, &msg_clip, DT_NOCLIP);
		break;
	}
	case 2:
	{
		paint_something_word_proc ( hWnd, uMsg, wParam, lParam);
		break;
	}
	case 3:
	{
		// 20210325
		printf("WM_PAINT 012-03: uMsg: %d starts.\r\n", uMsg);
		Animation_5times_thread_011 ( hdc );

		//20200402
		gDisplayControls_wmpaint_display_threeD_proc ( hWnd, *hdc, ps_001, uMsg, wParam, lParam );

		int a = spin_screen();

		//Last Messaegs:
		SetRect( &msg_key, 300, 150, 400, 300 );
		DrawText( *hdc, TEXT( "3: Last messages: 20200-4-02" ), -1, &msg_key, DT_NOCLIP );
		printf("WM_PAINT 012-03: uMsg: %d ends.\r\n", uMsg);
		break;
	}
	case 8:
	{
		printf("WM_PAINT 012-08: uMsg: %d starts.\r\n", uMsg);

		if ( process_call_times == 0 ) {
			// wmpaint_display_threeD_proc ( hWnd, hdc, ps_001, uMsg, wParam, lParam );
			gDisplayControls_wmpaint_display_threeD_proc ( hWnd, *hdc, ps_001, uMsg, wParam, lParam );
		}

		//Last Messaegs:
		SetRect( &msg_key, 300, 150, 400, 300 );
		DrawText( *hdc, TEXT( "8: Last messages:" ), -1, &msg_key, DT_NOCLIP );
		printf("WM_PAINT 012-08: uMsg: %d ends.\r\n", uMsg);

		break;
	}
	default:
	{
//		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);
		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );

		SelectObject( *hdc, hPen);
		SetRect(&msg_clip, 300, 300, 400, 350);
		SetTextColor( *hdc, RGB( 0, 0, 0));
		DrawText( *hdc, TEXT( "Could you push Escape until this works." ), -1, &msg_clip, DT_NOCLIP);
		break;
	}

	}
}

// development: 20190413
// this line must be printed on the screen but wa not.
// so, we think, paintWindowProc is not called at least when m_mode = -1.
//
static void paintWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam,  PAINTSTRUCT *ps_001)
{
	static char ex_str[2048];
	static char str[2048];
	static char num_str[2048];
	static char pastestr[1024];
//	char *cstr;
//	int l_keystate = -1;

	PAINTSTRUCT ps;
	RECT msg_key, msg_clip, msg_replace;
	FILE * pFile;
	RECT msg;
	int succ;
	DWORD ThreadId;
	HANDLE ThreadHandle;


	switch ( m_mode ) {

	// Explicit
	// Fully and clearly expressed; leaving nothing implied: 
	// That means curly braces.
	case -1:
	{

		itoa(key_w, num_str, 10);
		strcpy( str, "p key param: ");
		strcat( str, num_str );

		itoa(key_l, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );

		itoa(key_state, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );

		itoa(btc.CursolNumber, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );


		HDC hdc = BeginPaint(hWnd, ps_001);
//		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);
//		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, 0);
		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 255, 0 ) );

		SelectObject(hdc, hPen);

		// 100
		SetRect( &msg_key, 300, 100, 400, 250 );
//		SetTextColor( hdc, RGB( 0, 0, 0) );
		DrawText( hdc, TEXT( str ), -1, &msg_key, DT_NOCLIP );

		// 200
		SetRect(&msg_clip, 300, 200, 400, 250);
		DrawText( hdc, TEXT( m_pastestr ), -1, &msg_clip, DT_NOCLIP);

		// 300
//		m_replace_selection = (char*)"m_replace_selectionA";
		SetRect(&msg_replace, 300, 300, 400, 350);
		DrawText( hdc, TEXT( m_replace_selection ), -1, &msg_replace, DT_NOCLIP);
//		DrawText( hdc, TEXT( "m_replace_selectionA" ), -1, &msg_clip, DT_NOCLIP);

		// message
		SetRect( &msg, 300, 400, 400, 450);
		if ( succ == -1 ) {

			DrawText( hdc, TEXT( "Could not read clipboard" ), -1, &msg, DT_NOCLIP);
		} else {

			ex_str[0] = '\0';
			itoa( btc.CursolNumber, num_str, 10);
			strcat( num_str, ":" );
			strcat( ex_str, num_str );
			itoa( succ_paste, num_str, 10);
			strcat( ex_str, num_str );
			DrawText( hdc, TEXT( ex_str ), -1, &msg, DT_NOCLIP);
		}

		btc.drawButtons( hdc );
		EndPaint(hWnd, ps_001 );
		break;
	}
	case 0:
	{
		HDC hdc = BeginPaint(hWnd, ps_001);
		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );

		SelectObject(hdc, hPen);
		SetRect(&msg_clip, 300, 300, 400, 350);
		SetTextColor(hdc, RGB( 0, 0, 0));
		DrawText( hdc, TEXT( "Could you push Escape until this works." ), -1, &msg_clip, DT_NOCLIP);
		SetRect(&msg_clip, 300, 350, 400, 400);
		DrawText( hdc, m_szDir, -1, &msg_clip, DT_NOCLIP);
		break;
	}
	case 2:
	{
		paint_something_word_proc ( hWnd, uMsg, wParam, lParam);
		break;
	}
	case 3:
	{
		HDC hdc = BeginPaint(hWnd, ps_001);
		// 20210325
		printf("WM_PAINT 012-03: uMsg: %d starts.\r\n", uMsg);

		/* create the thread */
//		ThreadHandle = CreateThread( NULL, /* default security attributes */ 0, /* default stack size */    
//		Animation_5times_thread, /* thread function */ hWnd, uMsg, wParam, lParam, *ps_001, /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId);
//		Animation_5times_thread, /* thread function */ &hdc, &uMsg, &wParam, &lParam, ps_001, /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId);
//		Animation_5times_thread, /* thread function */ (LPVOID)&hdc, /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId);

		/* returns the thread identifier */
//		if (ThreadHandle != NULL){
//			/* now wait for the thread to finish */ WaitForSingleObject(ThreadHandle,INFINITE);
//			/* close the thread handle */
//			CloseHandle(ThreadHandle);
//			printf("wParam = %d\n", wParam);
//		}

		Animation_5times_thread_011( &hdc );

		//Last Messaegs:
		SetRect( &msg_key, 300, 150, 400, 300 );
		DrawText( hdc, TEXT( "3: Last messages:" ), -1, &msg_key, DT_NOCLIP );
		printf("WM_PAINT 012-03: uMsg: %d ends.\r\n", uMsg);
		break;
	}
	case 8:
	{
		printf("WM_PAINT 012-08: uMsg: %d starts.\r\n", uMsg);
		HDC hdc = BeginPaint(hWnd, ps_001);

		if ( process_call_times == 0 ) {
			// wmpaint_display_threeD_proc ( hWnd, hdc, ps_001, uMsg, wParam, lParam );
			gDisplayControls_wmpaint_display_threeD_proc ( hWnd, hdc, ps_001, uMsg, wParam, lParam );
		}

		//Last Messaegs:
		SetRect( &msg_key, 300, 150, 400, 300 );
		DrawText( hdc, TEXT( "8: Last messages:" ), -1, &msg_key, DT_NOCLIP );
		printf("WM_PAINT 012-08: uMsg: %d ends.\r\n", uMsg);

		break;
	}
	default:
	{
		HDC hdc = BeginPaint(hWnd, ps_001);
//		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);
		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );

		SelectObject(hdc, hPen);
		SetRect(&msg_clip, 300, 300, 400, 350);
		SetTextColor(hdc, RGB( 0, 0, 0));
		DrawText( hdc, TEXT( "Could you push Escape until this works." ), -1, &msg_clip, DT_NOCLIP);
		break;
	}

	}
}


//
//
//
static LRESULT CALLBACK mainWindowProc_012 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int succ;
	static HDC     hDC;
	PAINTSTRUCT ps;
	int check_invalidate = 0;
	int check_validate = 0;
	int stop_thread_once_second = 0;
	int b_Processed = 0;
	DWORD ThreadId;
	HANDLE ThreadHandle;
	static HFONT hFont, hFont2;
	int x1, x2, y1, y2;
	char l_buffer[255];
	RECT msg_key_001;

	if ( p_evt == nullptr ) {
		p_evt = new wEvent ();
	}

	p_evt->hWnd = hWnd;
	p_evt->uMsg = &uMsg;
	p_evt->wParam = wParam;
	p_evt->lParam = lParam;
	p_evt->main_mode = m_mode;
	btc.setEvent ( p_evt );
	btc2.setEvent ( p_evt );
	btc3.setEvent ( p_evt );
	canvas.setEvent ( p_evt );
	wtextareacontroller.setEvent ( p_evt );
	cg_setEvent ( p_evt ); // setting is necessary.



	printf("WM_MESSG 000: hWnd %d: uMsg %d: wParam %d: lParam %d: canvas %d: btc %d: *(p_evt->uMsg) %d: \r\n", hWnd, uMsg, wParam, lParam, &canvas, &btc, *(p_evt->uMsg) );

	// Code Block 1 - 01:
	p_evt->Type = uMsg;

	// Code Block 1 - 01:
	if ( animation_times_001 > 0 ) {
		p_evt->wParam = operations[animation_times_001];
		m_mode = modes[animation_times_001];
		p_evt->main_mode = m_mode;
		printf("paint: animation_times_001 %d p_evt->Type: %d p_evt->wParam: %d p_evt->lParam: %d\r\n", animation_times_001, p_evt->Type, p_evt->wParam, p_evt->lParam);
	}
	printf("animation_times_001 %d Type %d WM_PAINT:%d WM_KEYUP:%d check_validate %d check_invalidate %d\r\n", animation_times_001, p_evt->Type, WM_PAINT, WM_KEYUP, check_validate, check_invalidate );
//	if ( animation_times_001!=0 && animation_times_001 <3 ) exit(-1);

	// Code Block 1:
    switch ( p_evt->Type ){
	case WM_CREATE:
		printf("WM_MESSG 001-01: hWnd %d: uMsg %d: wParam %d: lParam %d: canvas %d: btc %d: *(p_evt->uMsg) %d: \r\n", hWnd, uMsg, wParam, lParam, &canvas, &btc, *(p_evt->uMsg) );
		button1.setButton ( 0, 0,    200, 50 );
		button2.setButton ( 0, 50,   200, 50 );
		button3.setButton ( 0, 100,  200, 50 );
		button4.setButton ( 0, 150,  200, 50 );
		button5.setButton ( 0, 200,  200, 50 );
		button6.setButton ( 0, 250,  200, 50 );
		button7.setButton ( 0, 300,  200, 50 );
		button8.setButton ( 0, 350,  200, 50 );
		button9.setButton ( 0, 400,  200, 50 );

		button11.setButton ( 480, 300,  150, 50 );
		button12.setButton ( 480, 350,  150, 50 );
		button13.setButton ( 480, 400,  150, 50 );

		button21.setButton ( 480, 200,  150, 50 );
		button22.setButton ( 480, 250,  150, 50 );
		button23.setButton ( 480, 300,  150, 50 );

		if ( call_once_001 == 0 ) {
			printf("call_once_001=%d\r\n", call_once_001 );
			btc.addButton( &button1 );
			btc.addButton( &button2 );
			btc.addButton( &button3 );
			btc.addButton( &button4 );
			btc.addButton( &button5 );
			btc.addButton( &button6 );
			btc.addButton( &button7 );
			btc.addButton( &button8 );
			btc.addButton( &button9 );

			btc2.addButton( &button11 );
			btc2.addButton( &button12 );
			btc2.addButton( &button13 );

			btc3.addButton( &button21 );
			btc3.addButton( &button22 );
			btc3.addButton( &button23 );


			SetRect(&RefreshRect, 0, 0, 640, 480);

			canvas.AXEX_2D_002_Index = 0;
			canvas.Set_vAxex_2D( 150.0f, 150.0f );
			canvas.Set_vAxex_2D( 200.0f, 200.0f );
			canvas.Set_vAxex_2D( 220.0f, 300.0f );

			canvas.Set_vAxex_2D( 220.0f, 300.0f );

			display_001.SetCanvas( &canvas );
			display_002.SetCanvas( &canvas );
			display_003.SetCanvas( &canvas );
			display_004.SetCanvas( &canvas );

//			operations[3] = 76; // case l:
//			operations[2] = 81; // case u:
//			operations[1] = 71; // case g:
//			operations[0] = 72; // case h:

			operations[3] = 9; // case TAB:
			operations[2] = 9; // case TAB:
			operations[1] = 9; // case TAB:
			operations[0] = 9; // case TAB:

			modes[3] = 8;
			modes[2] = 8;
			modes[1] = 8;
			modes[0] = 8;

			display_004.put_normal_sound_wave_003();

			call_once_001 = 1;
			printf("set call_once_001=%d\r\n", call_once_001 );
			printf("");
//			exit(-1);
		}

//		display_threeD_initialize();
		sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
		p_evt->Type = WM_CREATE; //
		printf("WM_MESSG 001-02: hWnd %d: uMsg %d: wParam %d: lParam %d: canvas %d: btc %d: *(p_evt->uMsg) %d: \r\n", hWnd, uMsg, wParam, lParam, &canvas, &btc, *(p_evt->uMsg) );
		break;
	case WM_CHAR:
		printf("WM_CHAR 002-01: hWnd %d: uMsg %d: wParam %d: lParam %d: canvas %d: btc %d: *(p_evt->uMsg) %d: \r\n", hWnd, uMsg, wParam, lParam, &canvas, &btc, *(p_evt->uMsg) );
		printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
		p_evt->Type = WM_CHAR; //
		printf("WM_CHAR 002-02: hWnd %d: uMsg %d: wParam %d: lParam %d: canvas %d: btc %d: *(p_evt->uMsg) %d: \r\n", hWnd, uMsg, wParam, lParam, &canvas, &btc, *(p_evt->uMsg) );
		break;
   	case WM_KEYUP:
		//  8 Backspace
		//  9 TAB
		// 17 Ctl
		// 13 Enter
		// 27 ESC
		// 37
		// 38
		// 39
		// 40
		printf("WM_KEYUP 002-01: %d *(p_evt->uMsg):%d uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg ); // <- the left changes uMsg.
		printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
		switch ( p_evt->wParam ) {
		case 9: //TAB
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			Cursol_Number = (++Cursol_Number) % 4;
			printf("p_evt->main_mode=%d Cursol_Number %d\r\n", p_evt->main_mode, Cursol_Number);
			break;
		}
		p_evt->Type = WM_KEYUP; // 
		printf("WM_KEYUP 002-02: %d *(p_evt->uMsg):%d uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg ); // <- the left changes uMsg.
   		break;
   	case WM_PAINT:
		printf("WM_PAINT 001: %d *(p_evt->uMsg):%d uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg ); // <- the left changes uMsg.
		p_evt->hDc = BeginPaint( hWnd, &ps ); // p_evt->uMsg should be a pointer;
		p_evt->ps = &ps;
		p_evt->Type = WM_PAINT; // WM_PAINT:15 // we can't miss it.
		printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
		break;
	case WM_MOUSEMOVE:
		int lmx = GET_X_LPARAM ( p_evt->lParam );
		int lmy = GET_Y_LPARAM ( p_evt->lParam );
		wtextareacontroller.setTextarea( 0, lmx );
		wtextareacontroller.setTextarea( 1, lmy );
		wtextareacontroller.setTextarea( 2, refreshtimes++ );
//		int cn = vsoundbuffer001,CursolNumber;
//		int gbi = (refreshtimes) % 255;
//		int gb = (int) vsoundbuffer001,getBuffer(gbi);
//		wtextareacontroller.setTextarea( 3, (int) vsoundbuffer001,getBuffer( (refreshtimes++) % 255 ) );
//		int gb = display_004.get_sound_buffer( 1 );
		int gb = display_004.get_sound_buffer( refreshtimes % 255 );
		wtextareacontroller.setTextarea( 3, gb );
//		display_004.merge_test_099();
//		display_004.DisplayBones_002 ();
		printf("WM_MOUSEMOVE 002-02: %d *(p_evt->uMsg):%d uMsg: %d  %d %d\r\n", uMsg, *(p_evt->uMsg), uMsg, lmx, lmy ); // <- the left changes uMsg.
//		exit(-1);
		break;
    }

	// Code Block 2:
	printf("call_once_001 = %d \r\n", call_once_001 );
	if ( call_once_001 == 0 ) {
		printf("return DefWindowProc( hWnd, uMsg, wParam, lParam );\r\n");
//		return 0;
//		exit(-1);
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	}

	// All processes work.
	printf("WM_MESSG 003-01: btc %d btc2 %d btc3 %d %d *(p_evt->uMsg):%d Cursol_Number:%d\r\n", &btc, &btc2, &btc3, uMsg, *(p_evt->uMsg), Cursol_Number );

	switch ( Cursol_Number ) {
	case 1:
		btc.Process ();
		printf("WM_MESSG 003-02-01: %d *(p_evt->uMsg):%d\r\n", uMsg, *(p_evt->uMsg) );
		break;
	case 2:
		btc.Process ();
		btc2.Process ();
		wtextareacontroller.Process_001 ();
		printf("WM_MESSG 003-02-02-01: uMsg %d *(p_evt->uMsg):%d\r\n", uMsg, *(p_evt->uMsg) );
		break;
	case 3:
		btc.Process ();
		btc3.Process ();
		printf("WM_MESSG 003-02-03: %d *(p_evt->uMsg):%d\r\n", uMsg, *(p_evt->uMsg) );
		break;
	}



	printf("WM_MESSG 003-03-01: %d *(p_evt->uMsg):%d\r\n", uMsg, *(p_evt->uMsg) );
	canvas.Process ();
	printf("WM_MESSG 003-03-02: %d *(p_evt->uMsg):%d\r\n", uMsg, *(p_evt->uMsg) );

	int img_width = 0;
	int img_height = 0;
	float*** img = NULL;

	// Code Block 3:
	// Code Block 3:
	switch ( p_evt->Type ) {
	case WM_KEYUP:
		switch ( p_evt->wParam ) {
		case 70: //f
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 7;
			p_evt->Keep_Keyup = p_evt->wParam;
//			display_004.malloc_main_002 () ;
			canvas.SetPixelCanvas ( 100, 50, 4, 4 );
			canvas.Line_Slope( 10, 10, 50, 20, 0 );
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 71: //g
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 7;
			p_evt->Keep_Keyup = p_evt->wParam;
			canvas.SetPixelCanvas ( 100, 50, 4, 4 );
			canvas.Line_Slope( 50, 20, 20, 50, 1 );
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 72: //h
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 7;
			p_evt->Keep_Keyup = p_evt->wParam;
			canvas.SetPixelCanvas ( 100, 50, 4, 4 );
			canvas.Line_Slope( 20, 50, 10, 10, 2 );
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 73: //i
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 7;
			p_evt->Keep_Keyup = p_evt->wParam;
			canvas.SetPixelCanvas ( 100, 50, 4, 4 );
			canvas.Line_Slope( 10, 10, 50, 20, 0 );
			canvas.Line_Slope( 50, 20, 20, 50, 1 );
			canvas.Line_Slope( 20, 50, 10, 10, 2 );
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 74: //j
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 7;
			p_evt->Keep_Keyup = p_evt->wParam;
			display_004.create_img_buffer_print_its_adress (".\\001-20221023-001\.txt", 320, 180, 1) ;
			// display_004.create_img_buffer_002 (".\\001-20220426-001\.txt", 320, 180, 1) ;
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 75: //k
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 7;
			p_evt->Keep_Keyup = p_evt->wParam;
			display_004.read_ppm_002 (".\\001-image\.ppm", img, &img_width, &img_height, 1) ;
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 76: //l
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 7;
			p_evt->Keep_Keyup = p_evt->wParam;
			display_004.Draw_Line_001 ( ) ;
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 77: //m
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 7;
			p_evt->Keep_Keyup = p_evt->wParam;
			display_004.param_print = 1;
			display_004.Create_Paint_Triangle ( ) ;
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 78: //n
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 29;
			p_evt->Keep_Keyup = p_evt->wParam;
//			display_004.draw_canvas_buffer () ;
			display_004.merge_test () ;
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 79: //o
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 7;
			p_evt->Keep_Keyup = p_evt->wParam;
			display_004.create_img_buffer_002 (".\\001-20220426-001\.txt", 320, 180, 1) ;
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 80: //p
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 29;
			p_evt->Keep_Keyup = p_evt->wParam;
			display_004.DisplayBones_002 ();
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 81: //q
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 29;
			p_evt->Keep_Keyup = p_evt->wParam;
			display_004.SetBaseAxex ();

			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 82: //r
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 29;
			p_evt->Keep_Keyup = p_evt->wParam;
			display_004.SetEye ( -1000.0f, 1000.0f, -1000.0f) ;

			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 83: //s
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 29;
			p_evt->Keep_Keyup = p_evt->wParam;
			display_004.SetEye ( -1000.0f, -1000.0f, -1000.0f) ;

			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 84: //t
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 29;
			p_evt->Keep_Keyup = p_evt->wParam;
			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
//			display_004.SetEye ( 1000.0f, -1000.0f, -1000.0f) ;
			display_004.SetEye ( 688.165527, 523.997192, -501.851746 );
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 85: //u
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			animation_times = 5;
			p_evt->main_mode = 29;
			// https://docs.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createthread
			// https://bituse.info/winapi/14
			// https://docs.microsoft.com/ja-jp/windows/win32/procthread/creating-threads
			/* create the thread */
			ThreadHandle = CreateThread( NULL, /* default security attributes */ 0, /* default stack size */    
				Animation_5times_thread, /* thread function */ (LPVOID)&(p_evt->hDc), /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId);

			operations[ log_index % 5 ] = p_evt->Keep_Keyup;
			modes[ log_index % 5 ] = p_evt->main_mode;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
		case 86: //v
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 30;
			display_004.SetEye ( 1000.0f, -1000.0f, -1000.0f) ;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		case 87: //w
			printf("p_evt->wParam: %d\ p_evt->lParam: %d\r\n", p_evt->wParam, p_evt->lParam);
			p_evt->main_mode = 30;
			display_001.Find_Files () ;
			printf("p_evt->main_mode=%d\r\n", p_evt->main_mode);
			break;
		}
		if ( p_evt->main_mode == 29 ) {
			log_index++;
			log_index %= 5;
		}
		break;
	case WM_PAINT:
		//Last Messaegs:
		hFont = CreateFont (10, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject((HDC)(p_evt->hDc), hFont);

		x1 = written_x + 200;
		y1 = written_y + 0;
		x2 = written_x + 300;
		y2 = written_y + 50;

		SetRect( &msg_key_001, x1, y1, x2, y2 );
		sprintf( l_buffer, "l_buffer %d log_index %d", animation_times, log_index );
		DrawText( (HDC)(p_evt->hDc), TEXT( l_buffer ), -1, &msg_key_001, DT_NOCLIP );
		printf("|%s| %d %d %d %d\r\n", l_buffer, x1, y1, x2, y2 );

		SelectObject((HDC)(p_evt->hDc), hFont2);
		DeleteObject(hFont);
		break;
	}


	m_mode = p_evt->main_mode;
	printf("WM_MESSG 003: p_evt %p %d (p_evt->main_mode):%d *(p_evt->uMsg):%d uMsg:%d p_evt->uMsg: %d &uMsg: %d \r\n", p_evt->main_mode, p_evt, uMsg, *(p_evt->uMsg), uMsg, p_evt->uMsg, &uMsg );

//	cg_schema ();


	// Code Block 4:
	printf("WM_MESSG 004-01: %d *(p_evt->uMsg):%d uMsg:%d p_evt->uMsg: %d &uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg, p_evt->uMsg, &uMsg );
    switch ( p_evt->Type ){
   	case WM_PAINT:
		printf("WM_PAINT 004-02: %d *(p_evt->uMsg):%d uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg );
		EndPaint(hWnd, &ps);
		printf("WM_PAINT 004-03: %d *(p_evt->uMsg):%d uMsg: %d btc.Process %d\r\n", uMsg, *(p_evt->uMsg), uMsg,  btc.Processed );
		wtextareacontroller.stack_number_free ();
		b_Processed = 1;
		// We do not call "ValidateRect" in the type of "WM_PAINT:".
		// if ( animation_times_001 > 0 ) check_validate = 1;
		// if ( check_validate == 1 ) {
		// 	// https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-validaterect
		// 	printf("ValidateRect: starts.\r\n");
		// 	ValidateRect( hWnd, &RefreshRect);
		// 	check_validate = 0;
		// 	check_invalidate = 0;
		// 	printf("ValidateRect: ends.\r\n");
		// }
		// https://learn.microsoft.com/en-us/windows/win32/gdi/wm-paint
		// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-validaterect
		// The BeginPaint function automatically validates the entire client area. Neither the ValidateRect nor ValidateRgn function should be called if a portion of the update region must be validated before the next WM_PAINT message is generated.
		break;
   	case WM_KEYUP:
		if ( (p_evt->wParam >= 37 && p_evt->wParam <= 40) || p_evt->wParam == 9 ) {
			//  9 TAB
			// 37 LEFT
			// 38 UP
			// 38 RIGHT
			// 40 DOWN
			check_invalidate = 1;
		} else if ( canvas.ProcessedKeyup == 1 ) {
			canvas.ProcessedKeyup = 0;
			check_invalidate = 1;
		}
		b_Processed = 1;
		break;
	case WM_CREATE:
		b_Processed = 1;
		break;
	case WM_CHAR:
		b_Processed = 1;
		break;
	case WM_CLOSE:
		b_Processed = 1;
		break;
	case WM_COMMAND:
		b_Processed = 1;
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		break;
	case WM_DESTROY:
		b_Processed = 1;
		break;
	case WM_ENDSESSION:
		b_Processed = 1;
		break;
	case WM_LBUTTONDOWN:
		b_Processed = 1;
		break;
	case WM_LBUTTONDBLCLK:
		b_Processed = 1;
		break;
	case WM_RBUTTONDBLCLK:
		b_Processed = 1;
		break;
	case WM_SIZE:
		b_Processed = 1;
		break;
	case WM_MOUSEMOVE:
		b_Processed = 1;
		check_invalidate = 1;
		break;
	default:
		b_Processed = 2;
		break;
	}
	// http://7ujm.net/C++/dbuff.html
	// https://dixq.net/forum/viewtopic.php?t=9667
	// https://teratail.com/questions/61205
	// http://shopping2.gmobb.jp/htdmnr/www08/windows/tips/doublebuffering01.html
	// http://kaitei.net/winapi/gdi-drawing/
	if ( check_invalidate == 1 ) {
		printf("InvalidateRect: starts.\r\n");
		InvalidateRect( hWnd, &RefreshRect, FALSE);
		check_invalidate = 0;
		printf("InvalidateRect: ends.\r\n");
	}

	printf("stop_thread_once_second: %d\r\n", stop_thread_once_second);

	if ( stop_thread_once_second == 1 ) {
		printf("Sleep starts.\r\n");
		Sleep(1000);
		stop_thread_once_second = 0;
		printf("Sleep ends.\r\n");
	}

	switch ( b_Processed ) {
	case 0:
		break;
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

//------------------------------------------------
// Window Procedure
//------------------------------------------------
static LRESULT CALLBACK mainWindowProc_001( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	//wEvent evt;
	static wEvent *p_evt = nullptr;
	int succ;
	HDC     hDC;
	PAINTSTRUCT ps;

	// 20190403
	if ( p_evt == nullptr ) {
		p_evt = new wEvent () ;
		put_memories ( (char *) p_evt );
	}
	p_evt->hWnd = hWnd;
	p_evt->uMsg = &uMsg;
	p_evt->wParam = wParam;
	p_evt->lParam = lParam;
	p_evt->main_mode = m_mode;
	btc.setEvent ( p_evt );
	canvas.setEvent ( p_evt );
	wtextareacontroller.setEvent ( p_evt );

	// commented out 20190403
	/* evt.hWnd = hWnd;
	evt.uMsg = uMsg;
	evt.wParam = wParam;
	evt.lParam = lParam;
	evt.main_mode = m_mode;
	btc.setEvent ( &evt );
	canvas.setEvent ( &evt ); */
	printf("WM_MESSG 000: hWnd %d: uMsg %d: wParam %d: lParam %d: canvas %d: btc %d: *(p_evt->uMsg) %d: \r\n", hWnd, uMsg, wParam, lParam, &canvas, &btc, *(p_evt->uMsg) );

    switch ( uMsg ){
	case WM_CREATE:
		button1.setButton ( 0, 0,    200, 50 );
		button2.setButton ( 0, 50,   200, 50 );
		button3.setButton ( 0, 100,  200, 50 );
		button4.setButton ( 0, 150,  200, 50 );
		button5.setButton ( 0, 200,  200, 50 );
		button6.setButton ( 0, 250,  200, 50 );
		button7.setButton ( 0, 300,  200, 50 );
		button8.setButton ( 0, 350,  200, 50 );
		button9.setButton ( 0, 400,  200, 50 );
		exit(-1); // ROOT: X

		if ( call_once_001 == 0 ) {
			btc.addButton( &button1 );
			btc.addButton( &button2 );
			btc.addButton( &button3 );
			btc.addButton( &button4 );
			btc.addButton( &button5 );
			btc.addButton( &button6 );
			btc.addButton( &button7 );
			btc.addButton( &button8 );
			btc.addButton( &button9 );


			canvas.Set_vAxex_2D( 150.0f, 150.0f );
			canvas.Set_vAxex_2D( 160.0f, 160.0f );
			canvas.Set_vAxex_2D( 170.0f, 170.0f );

			call_once_001 = 1;
			printf("cakk_once_001=%d\r\n", call_once_001);
			exit(-1); // ROOT: X
		}

		sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
		break;
	case WM_CHAR:
		p_evt->Type = WM_CHAR; // 
		break;
   	case WM_KEYUP:
		p_evt->Type = WM_KEYUP; // 
   		break;
   	case WM_PAINT:
		printf("WM_PAINT 001: %d *(p_evt->uMsg):%d uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg ); // <- the left changes uMsg.
		p_evt->hDc = BeginPaint( hWnd, &ps ); // p_evt->uMsg should be a pointer;
		p_evt->ps = &ps;

		// commented out 20190403
		// btc.setEvent ( &evt ); // If you put this here, it works well. And, I don't know the reason. in 20180202
		//canvas.setEvent ( p_evt );

		p_evt->Type = WM_PAINT; // WM_PAINT:15
		printf("WM_PAINT 002: %d *(p_evt->uMsg):%d uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg );
		break;
    }

	printf("WM_MESSG 003: %d *(p_evt->uMsg):%d\r\n", uMsg, *(p_evt->uMsg) );
	btc.Process ();
//	canvas.Process ();
	m_mode = p_evt->main_mode;
	printf("WM_MESSG 004: %d *(p_evt->uMsg):%d uMsg:%d p_evt->uMsg: %d &uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg, p_evt->uMsg, &uMsg );

	//wmpaint_display_threeD_proc ( hWnd, uMsg, wParam, lParam );

	// 20190201
	// conformed this program goes through WM_PAINT in Process
	//if ( canvas.Processed == 1 ) {
	//	exit(-1);
	//}


    switch ( uMsg ){
   	case WM_PAINT:
		// event.hDc = BeginPaint( hWnd, &ps);
		// wmpaint_display_threeD_proc ( hWnd, &hDC, &ps, uMsg, wParam, lParam );
		// btc.Process ();
		printf("WM_PAINT 005: %d *(p_evt->uMsg):%d uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg );
		EndPaint(hWnd, &ps);
		printf("WM_PAINT 006: %d *(p_evt->uMsg):%d uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg );
		break;
   	case WM_KEYUP:
		InvalidateRect( hWnd, NULL, TRUE);
		break;

    }

	switch ( btc.Processed ) {
	case 0:
		break;
	case 1:
		btc.Processed = 0;
		return 0;
	case 2:
		btc.Processed = 0;
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;

	// development: 20190403
	// the reason is the below.
	//
	// the below doesn't matter.
    switch ( uMsg ){
	case WM_CHAR:
		break;
	case WM_CLOSE:
		DestroyWindow( hWnd );
		break;
	case WM_DESTROY:
		PostQuitMessage( 0 );
		break;
	case WM_PAINT:
		paintWindowProc( hWnd, uMsg, wParam, lParam );
		paint_clipboard();
		break;
	case WM_COMMAND:
		uLabelFormat = LOWORD(wParam);
		uFormat = LOWORD(wParam);
		if ( once_hook == 0 ) {

			sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
			once_hook = 1;
	        MessageBox(hWnd, "WM_COMMAND", "Inside", MB_OK);
			MyHookStart ( hWnd );

		}

		switch(LOWORD(wParam)) {
		case IDR_MYMENU:
			// SendMessage(hWnd, WM_CLOSE, 0, 0L);
			break;
		case ID_FILE_EXIT:
			break;
		case ID_STUFF_GO:
			break;
		}
		break;
//        CASE WM_SYSCOMMAND:
//        {
//			if ( once_hook == 0 ) {
//
//		        MessageBox(hWnd, "WM_SYSCOMMAND", "Inside", MB_OK);
//				sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
//				once_hook = 1;
//				MyHookStart ( hWnd );
//
//			}
//
//        }
        CASE WM_KEYUP:
        {
//			if ( call_once_key == 1 ) {
//				call_once_key = 0;
//				break;
//			}

			switch ( m_mode ) {
			case 2:
				// keyup_something_word ( hWnd, key_w, &m_mode );
				keyup_something_word ( hWnd, key_w, &m_mode );
				break;
			default:
				//  8 Backspace
				// 17 Ctl
				// 13 Enter
				// 27 ESC
				switch ( key_w ) {
				case 13:
					m_mode = btc.CursolNumber;
					initialize( m_mode );
					call_once_key = 1;
					break;
				case 17: // Changing mode to command mode means select button because it equals expectancy of events, in this case edit command.
					btc.selectButton( (char *) "Edit - Ctl -");
					break;
				case 27:
					escape_action( m_mode );
					//m_mode = -1; // means 
					// screen.
					call_once_key = 1;
					break;;
				case 37:
					exit(-1);
					break;
				case 38:
					btc.CursolNumber--;
					btc.selectButton( );
					call_once_key = 1;
					break;
				case 39:
					break;
				case 40:
					btc.CursolNumber++;
					btc.selectButton( );
					call_once_key = 1;
					break;
				}
				break;
			}

			InvalidateRect(hWnd, NULL, TRUE);
		}
        CASE WM_KEYDOWN:
        {
		// when key_w means arrow.
		// 37 left
		// 38 up
 		// 39 right
		// 40 down

		// 65 A
		// 97 a

//			ButtonSelectDown () ;
// o		key_state = GetKeyState(VK_MENU) ;
//			key_state = GetKeyState(VK_LEFT) ;

// do not write here. write under wm\char if you want to get arrow.

			key_w = wParam;
			key_l = lParam;
			//InvalidateRect(hWnd, NULL, TRUE);

		}
        CASE WM_ENDSESSION:
			PostMessage( hWnd, WM_CLOSE, 0, 0 );
			//printf("aag");
        CASE WM_LBUTTONDOWN:
        {
//			if (GetKeyState(VK_MENU) & 0x8000))
//			{
//				// ALT key is down.
//			}

			// x key_state = GetKeyState(VK_LEFT);
			// x key_state = ( GetKeyState(VK_LEFT) & 0x8000 );
			// x key_state = ( GetKeyState(VK_MENU) & 0x8000 );
			key_state = GetKeyState(VK_MENU) ;


//			if ( GetKeyState(VK_LEFT) & 0x8000))
//			{
//			}
//
//			SendMessage( hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
//			printf("aah");
        }
        CASE WM_LBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_TOPMOST,   0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
			//printf("aah");
        CASE WM_RBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
			//printf("aai");
		CASE WM_SIZE:
			if (uFormat == CF_OWNERDISPLAY) 
            { 
                hwndOwner = GetClipboardOwner(); 
                hglb = GlobalAlloc(GMEM_MOVEABLE, sizeof(RECT)); 
                lprc = (LPRECT)GlobalLock(hglb); 
                GetClientRect(hwnd, lprc); 
                GlobalUnlock(hglb); 
 
                SendMessage(hwndOwner, WM_SIZECLIPBOARD, 
                    (WPARAM) hwnd, (LPARAM) hglb); 
 
                GlobalFree(hglb); 
            } 
        DEFAULT:
			printf("DEFAULT\r\n");
            return DefWindowProc( hWnd, uMsg, wParam, lParam );

		// for check parameter
		// key_w = wParam;
		// key_l = lParam;

    }

    return 0;
}

void paint_clipboard () {
   static HWND hwndNextViewer; 

    HDC hdc; 
    HDC hdcMem; 
    PAINTSTRUCT ps; 
    LPPAINTSTRUCT lpps; 
    RECT rc; 
//    LPRECT lprc; 
    HGLOBAL hglb; 
    LPSTR lpstr; 
    HBITMAP hbm; 
    HENHMETAFILE hemf; 
    HWND hwndOwner; 
 
	switch (uFormat) 
	{
		case CF_OWNERDISPLAY: 
			hwndOwner = GetClipboardOwner(); 
			hglb = GlobalAlloc(GMEM_MOVEABLE, 
                        sizeof(PAINTSTRUCT)); 
			lpps = (LPPAINTSTRUCT)GlobalLock(hglb);
			memcpy(lpps, &ps, sizeof(PAINTSTRUCT)); 
			GlobalUnlock(hglb); 

			SendMessage(hwndOwner, WM_PAINTCLIPBOARD, 
			(WPARAM) hwnd, (LPARAM) hglb); 

			GlobalFree(hglb); 
			m_pastestr = (char *)"CF_OWNERDISPLAY";
			break; 

		case CF_BITMAP: 
			hdcMem = CreateCompatibleDC(hdc); 
			if (hdcMem != NULL) 
			{ 
				if (OpenClipboard(hwnd)) 
				{
					hbm = (HBITMAP) 
					GetClipboardData(uFormat); 
					SelectObject(hdcMem, hbm); 
					GetClientRect(hwnd, &rc); 

					BitBlt(hdc, 0, 0, rc.right, rc.bottom, 
						hdcMem, 0, 0, SRCCOPY); 
					CloseClipboard(); 
				}
				DeleteDC(hdcMem); 
			}
			m_pastestr = (char *)"CF_BITMAP";
			break; 

		case CF_TEXT: 
			if (OpenClipboard(hwnd)) 
			{
				hglb = GetClipboardData(uFormat); 
				lpstr = (LPSTR)GlobalLock(hglb); 

				GetClientRect(hwnd, &rc); 
				DrawText(hdc, lpstr, -1, &rc, DT_LEFT); 

				GlobalUnlock(hglb); 
				CloseClipboard(); 
			}
			m_pastestr = (char *)"CF_TEXT";
			break; 
		case CF_ENHMETAFILE: 
			if (OpenClipboard(hwnd)) 
			{ 
				hemf = (HENHMETAFILE)GetClipboardData(uFormat); 
				GetClientRect(hwnd, &rc); 
				PlayEnhMetaFile(hdc, hemf, &rc); 
				CloseClipboard(); 
			}
			m_pastestr = (char *)"CF_ENHMETAFILE";
			break; 
		case 0: 
			GetClientRect(hwnd, &rc); 
			DrawText(hdc, "The clipboard is empty.", -1, 
						&rc, DT_CENTER | DT_SINGLELINE | 
						DT_VCENTER); 
			m_pastestr = (char *)"CF_ZERO";
			break; 

		default: 
			GetClientRect(hwnd, &rc); 
			DrawText(hdc, "Unable to display format.", -1, 
						&rc, DT_CENTER | DT_SINGLELINE | 
						DT_VCENTER); 
			EndPaint(hwnd, &ps);
			m_pastestr = (char *)"CF_DEFAULT";
//			    else if (uFormat == uLabelFormat) 
//			hglb = GlobalAlloc(GMEM_MOVEABLE, sizeof(LABELBOX)); 
//			if (hglb == NULL) 
//				return; 
//			pbox = GlobalLock(hglb); 
//			memcpy(pbox, pboxLocalClip, sizeof(LABELBOX)); 
//			GlobalUnlock(hglb); 
//			SetClipboardData(uLabelFormat, hglb); 
//			break;
	}
}

void wm_char( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, int m_mode, int btc_CursolNumber, int call_once_key, int key_w )
{
	int succ;

	//
	// Send wTriger tp ButtonController
	btc.setTriger( hTriger );

	switch( m_mode ) {
		case 0:
			break;
		case 1:
			break;
		case 2:
			getchar_something_word_proc( hWnd, uMsg, wParam, lParam );
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		case 8:
			// do not write anything
			break;
		case 9:
			//getchar_display_threeD_proc( hWnd, uMsg, wParam, lParam );
			break;
	}

	// for Edit
	if ( btc.CursolNumber == 7 ) {

		switch( key_w ) {
		case 'v':
			//succ_paste = ReadClip ( hWnd, m_pastestr );
			EditPaste();
			m_pastestr = m_concat(m_pastestr, ":did paste");
			break;
		case 'r':
			// show_garbage_collection () ;
			// m_pastestr = "show_garbage_collection () ;";
			// multithread_print();
			break;
		default:
			break;
		}

		if ( call_once_key == 1 ) {
			call_once_key = 0;
			//break;
		}


		switch( key_w ) {
		case 'o':
			btc.selectButton( (char *) "File Open - o -");
			break;
		case 's':
			btc.selectButton( (char *) "Something Sentence - s -");
			break;
		case 'w':
			btc.selectButton( (char *) "Something Word - w -");
			break;
		case 'd':
			btc.selectButton( (char *) "Dictionary Link - d -");
			break;
		case 'l':
			btc.selectButton( (char *) "Web Link - l -");
			break;
		case 'p':
			btc.selectButton( (char *) "Print Html - p -");
			break;
		case 'e':
			btc.selectButton( (char *) "Exit - e -");
			break;
		case '3':
			btc.selectButton( (char *) "Display 3D - 3 -");
			break;
		}


	}

	call_once_key = 1;
}

//
//
//
//
//
//
VOID WINAPI EditPasteA(VOID) 
{
    PLABELBOX pbox; 
    HGLOBAL   hglb; 
    LPTSTR    lptstr; 
    PLABELBOX pboxCopy; 
    int cx, cy; 
    HWND hwnd; 
	char num_str[1024];

    LPCTSTR atchClassChild = TEXT("Lesson5WndClass");

    pbox = hwndSelected == NULL ? NULL : 
        (PLABELBOX) GetWindowLong(hwndSelected, 0); 

    // If the application is in edit mode, 
    // get the clipboard text. 

	m_replace_selection = (char*)"DefaultA:";

    if (pbox != NULL && pbox->fEdit) 
    { 
		m_replace_selection = (char*)"DefaultB";
        if (!IsClipboardFormatAvailable(CF_TEXT)) 
            return; 
        if (!OpenClipboard(hwndMain)) 
            return; 

		m_replace_selection = (char*)"DefaultB";

        hglb = GetClipboardData(CF_TEXT); 
        if (hglb != NULL) 
        { 
			m_replace_selection = (char*)"DefaultC";
            lptstr = (LPTSTR)GlobalLock(hglb);
            m_replace_selection = lptstr;
            if (lptstr != NULL) 
            { 
                // Call the application-defined ReplaceSelection 
                // function to insert the text and repaint the 
                // window. 
 
                ReplaceSelection(hwndSelected, pbox, lptstr); 
                GlobalUnlock(hglb); 
            } 
        } 
        CloseClipboard(); 

        return; 
    } 

	m_replace_selection = (char*)"DefaultD";

    // If the application is not in edit mode, 
    // create a label window. 
 
    if (!IsClipboardFormatAvailable(uLabelFormat)) 
        return; 

	m_replace_selection = (char*)"DefaultE";

    if (!OpenClipboard(hwnd
    )) 
        return; 

//	m_replace_selection = (char*)"DefaultF";

    hglb = GetClipboardData(uLabelFormat); 
    if (hglb != NULL) 
    { 
        pboxCopy = (PLABELBOX)GlobalLock(hglb); 
        if (pboxCopy != NULL) 
        { 
            cx = pboxCopy->rcText.right + CX_MARGIN; 
            cy = pboxCopy->rcText.top * 2 + cyText; 
 
            hwnd = CreateWindowEx( 
                WS_EX_NOPARENTNOTIFY | WS_EX_TRANSPARENT, 
                atchClassChild, NULL, WS_CHILD, 0, 0, cx, cy, 
                hwndMain, NULL, hInstanceMain, NULL 
            ); 
            if (hwnd != NULL) 
            { 
                pbox = (PLABELBOX) GetWindowLong(hwnd, 0); 
                memcpy(pbox, pboxCopy, sizeof(LABELBOX)); 
                ShowWindow(hwnd, SW_SHOWNORMAL); 
                SetFocus(hwnd); 
            } 
            GlobalUnlock(hglb); 
        } 
    } 
    CloseClipboard();
}

const char* wichStandardClipboardFormatsIsAvailable()
{
	// Standard Clipboard Formats
	// CF_BITMAP			: 2
	// CF_DIB				: 8
	// CF_DIBV5				:17
	// CF_DIF				: 5
	// CF_DSPBITMAP			:0x0082
	// CF_DSPENHMETAFILE	:0x008E
	// CF_DSPMETAFILEPICT	:0x0082
	// CF_DSPTEXT			:0x0081
	// CF_ENHMETAFILE		:14
	// CF_GDIOBJFIRST		:0x0300
	// CF_GDIOBJLAST		:0x03FF
	// CF_HDROP				:15
	// CF_LOCALE			:16
	// CF_METAFILEPICT		:3
	// CF_OEMTEXT			:7
	// CF_OWNERDISPLAY		:0x0080
	// CF_PALETTE			:9
	// CF_PENDATA			:10
	// CF_PRIVATEFIRST		:0x0200
	// CF_PRIVATELAST		:0x02FF
	// CF_RIFF				:11
	// CF_SYLK				:4
	// CF_TEXT				:1
	// CF_TIFF				:6
	// CF_UNICODETEXT		:13
	// CF_PRIVATELAST		:0x02FF
	// CF_WAVE				:12

	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_BITMAP";
	}
	if ( IsClipboardFormatAvailable(CF_DIB) ) {
		return "CF_DIB";
	}
	if ( IsClipboardFormatAvailable(CF_DIBV5) ) {
		return "CF_DIBV5";
	}
	if ( IsClipboardFormatAvailable(CF_DIF) ) {
		return "CF_DIF";
	}
	if ( IsClipboardFormatAvailable(CF_DSPBITMAP) ) {
		return "CF_DSPBITMAP";
	}
	if ( IsClipboardFormatAvailable(CF_DSPENHMETAFILE) ) {
		return "CF_DSPENHMETAFILE";
	}
	if ( IsClipboardFormatAvailable(CF_DSPMETAFILEPICT) ) {
		return "CF_DSPMETAFILEPICT";
	}
	if ( IsClipboardFormatAvailable(CF_HDROP) ) {
		return "CF_HDROP";
	}
	if ( IsClipboardFormatAvailable(CF_GDIOBJFIRST) ) {
		return "CF_GDIOBJFIRST";
	}
	if ( IsClipboardFormatAvailable(CF_GDIOBJLAST) ) {
		return "CF_GDIOBJLAST";
	}
	if ( IsClipboardFormatAvailable(CF_HDROP) ) {
		return "CF_HDROP";
	}
	if ( IsClipboardFormatAvailable(CF_LOCALE) ) {
		return "CF_LOCALE";
	}
	if ( IsClipboardFormatAvailable(CF_METAFILEPICT) ) {
		return "CF_METAFILEPICT";
	}
	if ( IsClipboardFormatAvailable(CF_OEMTEXT) ) {
		return "CF_OEMTEXT";
	}
	if ( IsClipboardFormatAvailable(CF_OWNERDISPLAY) ) {
		return "CF_OWNERDISPLAY";
	}
	if ( IsClipboardFormatAvailable(CF_PALETTE) ) {
		return "CF_PALETTE";
	}
	if ( IsClipboardFormatAvailable(CF_RIFF) ) {
		return "CF_RIFF";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_SYLK";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_TEXT";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_UNICODETEXT";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_PRIVATELAST";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_WAVE";
	}

	return "CF_NOT_STANDARD";
}

VOID WINAPI EditPaste(VOID) 
{
    PLABELBOX pbox; 
    HGLOBAL   hglb; 
    LPTSTR    lptstr; 
    PLABELBOX pboxCopy; 
    int cx, cy; 
    HWND hwnd;
    char num_str[1024];

	BOOL flag_CF_TEXT = true;

    LPCTSTR atchClassChild = TEXT("Lesson5WndClass");

    pbox = hwndSelected == NULL ? NULL : 
        (PLABELBOX) GetWindowLong(hwndSelected, 0); 

	// If the application is in edit mode, 
	// get the clipboard text. 
	m_replace_selection = (char*)"DefaultA:";

//	if (pbox == NULL ) return;
//
//    if (pbox != NULL && pbox->fEdit) 
//    if ( 1 && pbox->fEdit )

	// Add the below 20190111
	m_replace_selection = (char*)wichStandardClipboardFormatsIsAvailable ();
	return;

	if ( 1 )
    {
		m_replace_selection = (char*)"DefaultB";
        if (!IsClipboardFormatAvailable(CF_TEXT)) {
        	flag_CF_TEXT = false;
        }

		if ( flag_CF_TEXT == true ) {

			if (!OpenClipboard(hwndMain)) 
				return; 

			m_replace_selection = (char*)"DefaultC";

			hglb = GetClipboardData(CF_TEXT);
			if (hglb != NULL) 
			{ 
				m_replace_selection = (char*)"DefaultC";
				lptstr = (LPTSTR)GlobalLock(hglb);
				m_replace_selection = lptstr;
				if (lptstr != NULL) 
				{ 
                // Call the application-defined ReplaceSelection 
                // function to insert the text and repaint the 
                // window. 
 
					ReplaceSelection(hwndSelected, pbox, lptstr); 
					GlobalUnlock(hglb); 
				 
				}
				CloseClipboard(); 

				return;
			}
    	}
    }

	m_replace_selection = (char*)"Before uLabelFormat";

    // If the application is not in edit mode, 
    // create a label window. 

	// the below doesn't work well, so I commented out it.
//    if (!IsClipboardFormatAvailable(uLabelFormat)) 
//        return; 

	m_replace_selection = (char*)"DefaultE";

    if (!OpenClipboard(hwndMain)) 
        return; 

	m_replace_selection = (char*)"DefaultF";

// 
// int GetClipboardFormatNameA(
//   UINT  format,
//   LPSTR lpszFormatName,
//   int   cchMaxCount
// );


	int return_format_succeeds = GetClipboardFormatNameA(uLabelFormat, m_replace_selection, 5);
    CloseClipboard();
    return;

//	int return_format_succeeds = GetClipboardFormatNameA(uLabelFormat, m_pastestr, 1024);

    hglb = GetClipboardData(uLabelFormat); 
    if (hglb != NULL) 
    {
		m_replace_selection = (char*)"DefaultG";
        pboxCopy = (PLABELBOX)GlobalLock(hglb); 
        if (pboxCopy != NULL) 
        { 
            cx = pboxCopy->rcText.right + CX_MARGIN; 
            cy = pboxCopy->rcText.top * 2 + cyText; 

            hwnd = CreateWindowEx( 
                WS_EX_NOPARENTNOTIFY | WS_EX_TRANSPARENT, 
                atchClassChild, NULL, WS_CHILD, 0, 0, cx, cy, 
                hwndMain, NULL, hInstanceMain, NULL 
            ); 
            if (hwnd != NULL) 
            { 
                pbox = (PLABELBOX) GetWindowLong(hwnd, 0); 
                memcpy(pbox, pboxCopy, sizeof(LABELBOX)); 
                ShowWindow(hwnd, SW_SHOWNORMAL); 
                SetFocus(hwnd); 
            }
            GlobalUnlock(hglb); 
        }
    } else {
		m_replace_selection = (char*)"DefaultH";
    }

    CloseClipboard();
}

// insert the text and repaint the 
// window. 
void ReplaceSelection (HWND hwnd, PLABELBOX pbox, LPTSTR lptstr) {

// the Lootin came here at 20:14 20180109
//	m_replace_selection = (char*)"path\=ReplaceSelectionA";
	m_replace_selection = lptstr;

//	RECT rect;
//	PAINTSTRUCT ps;

//	HDC hdc = BeginPaint(hwnd, &ps);

//	SetRect( &rect, 200, 200, 400, 400 );
//	SetTextColor( hdc, RGB( 1, 0, 0) );
//	DrawText( hdc, TEXT( lptstr ), -1, &rect, DT_NOCLIP);
//	DrawText( hdc, TEXT( m_pastestr ), -1, &rect, DT_NOCLIP);
//	EndPaint(hwnd, &ps);

}

// 27 ESC
void escape_action( int mode ) {
	int result;

	if ( mode == 2 ) {
		result = something_word_escape ();
		if ( result == 1) {
			// to main window
			m_mode = -1;
		}
		return;
	}

	m_mode = -1; // means main screen.
}

//
//
//
//
//
void ButtonSelectDown () {
	ButtonLight( 0, m_button_number_select );
	m_button_number_select++;
	ButtonLight( 1, m_button_number_select );
}

//
//
//
//
//
void ButtonSelectUp () {
	ButtonLight( 0, m_button_number_select );
	m_button_number_select--;
	ButtonLight( 1, m_button_number_select );
}

// light = 0 means non-select
// light = 1 means select
void ButtonLight( int light, int bn ) {

	switch ( m_button_number_select ) {
	case 1:
		button1.setMode( light );
		break;
	case 2:
		button2.setMode( light );
		break;
	case 3:
		button3.setMode( light );
		break;
	case 4:
		button4.setMode( light );
		break;
	case 5:
		button5.setMode( light );
		break;
	case 6:
		button6.setMode( light );
		break;
	case 7:
		button7.setMode( light );
		break;
	case 8:
		button8.setMode( light );
		break;
	}

}

//------------------------------------------------
// Set Window Procedure
//------------------------------------------------
static ATOM funcWindowClass( HINSTANCE hInstance, LPCTSTR lpClassName )
{
    WNDCLASSEX wcex = { 0 };
    wcex.cbSize         = sizeof(WNDCLASSEX);
    wcex.style          = CS_DBLCLKS;
    wcex.lpfnWndProc    = mainWindowProc_025;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon( NULL, IDI_APPLICATION );
    wcex.hIconSm        = LoadIcon( NULL, IDI_APPLICATION );
    wcex.hCursor        = LoadCursor( NULL, IDC_ARROW );
    wcex.hbrBackground  = (HBRUSH)GetStockObject( WHITE_BRUSH );
    wcex.lpszMenuName   = "IDR_MYMENU";
    wcex.lpszClassName  = lpClassName;
    return RegisterClassEx( &wcex );
}

//------------------------------------------------
// Set Window Size
//------------------------------------------------
static VOID funcSetClientSize( HWND hWnd, LONG sx, LONG sy )
{
    RECT rc1;
    RECT rc2;
    
    GetWindowRect( hWnd, &rc1 );
    GetClientRect( hWnd, &rc2 );
    sx += ((rc1.right - rc1.left) - (rc2.right - rc2.left));
    sy += ((rc1.bottom - rc1.top) - (rc2.bottom - rc2.top));
    SetWindowPos( hWnd, NULL, 0, 0, sx, sy, (SWP_NOZORDER|SWP_NOOWNERZORDER|SWP_NOMOVE) );
}

//------------------------------------------------
// Creation of Window
//------------------------------------------------
static HWND funcCreateWindow( HINSTANCE hInstance, LPCTSTR lpClassName, LPCTSTR lpTitleName, int nCmdShow )
{
    hWnd = CreateWindowEx(
//        0,                  // Expandation of Window Style
        WS_EX_COMPOSITED,
        lpClassName,        // Window Class Name
        lpTitleName,        // Window Title
        SCREEN_STYLE,       // Window Style
        CW_USEDEFAULT,      // Horizental window position
        CW_USEDEFAULT,      // Vertical window position
        CW_USEDEFAULT,      // Window width
        CW_USEDEFAULT,      // Window height
        NULL,               // Parent window handle
        NULL,               // handle of Menu bar
        hInstance,          // handle of Instance
        NULL );             // Put parameter Creation of window

//    hwndMain = hWnd;
    if ( hWnd != NULL ){
        funcSetClientSize( hWnd, SCREEN_WIDTH, SCREEN_HEIGHT );
        ShowWindow( hWnd, nCmdShow );
        UpdateWindow( hWnd );
    }
    return hWnd;
}

//------------------------------------------------
// Main Function
//------------------------------------------------
extern int WINAPI _tWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow )
{

    LPCTSTR lpClassName = TEXT("Lesson5WndClass");
    LPCTSTR lpTitleName = TEXT("Tanion");
    MSG Msg;

    hInstanceMain = hInstance;
    // Set Window Class
    if ( funcWindowClass(hInstance,lpClassName) == 0 ){
        MessageBox( NULL, ERRMSG_WINREG, ERRMSG_TITLE, (MB_OK|MB_ICONERROR) );
        return -1;
    }
    // Creation of Window
    if ( funcCreateWindow(hInstance,lpClassName,lpTitleName,nCmdShow) == NULL ){
        MessageBox( NULL, ERRMSG_CREATE, ERRMSG_TITLE, (MB_OK|MB_ICONWARNING) );
        return -2;
    }
    // Message Loop
    while ( GetMessage(&Msg,NULL,0,0) > 0 ){
        TranslateMessage( &Msg );
        DispatchMessage( &Msg );
    }
    UNREFERENCED_PARAMETER( hPrevInstance );
    UNREFERENCED_PARAMETER( lpCmdLine );
    return Msg.wParam;
}

//------------------------------------------------------------------------------
// End of Lesson5.cpp
//------------------------------------------------------------------------------

void MyHookStart(HWND hWnd)
{
    HINSTANCE hInst;

    hInst = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);
    hMyHook = SetWindowsHookEx(WH_KEYBOARD,
        (HOOKPROC)MyHookProc,
        hInst,
        0);
    if (hMyHook == NULL)
        MessageBox(hWnd, "Failed to hook", "Error", MB_OK);

    return;
}

LRESULT CALLBACK MyHookProc(int nCode, WPARAM wp, LPARAM lp)
{
	sprintf( m_string, "nCode:%d wp:%d\n", nCode, wp );

    if (nCode < 0)
        return CallNextHookEx(hMyHook, nCode, wp, lp);
    if (wp >= 0x30 && wp <=0x39)
        return CallNextHookEx(hMyHook, nCode, wp, lp);

    MessageBeep(MB_OK);
    return TRUE;
}

void MyHookEnd(HWND hWnd)
{
    if (UnhookWindowsHookEx(hMyHook) != 0)
        MessageBox(hWnd, "Delete hook.", "OK", MB_OK);
    else
        MessageBox(hWnd, "Fail to delete hook", "Error", MB_OK);
    return;
}

/**
 *
 *  wParam, one of the: WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, or WM_SYSKEYUP
    lParam: pointer to a KBDLLHOOKSTRUCT structure

    (*) "The hook procedure should process a message in less time than the
    data entry specified in the LowLevelHooksTimeout value in the following registry key: 
    HKEY_CURRENT_USER\Control Panel\Desktop 

    The value is in milliseconds. If the hook procedure does not 
    return during this interval, the system will pass the message to the next hook."

 *
 */

/*
LRESULT CALLBACK
hook_proc( int code, WPARAM wParam, LPARAM lParam )
{
  static long ctrl_cnt = 0;
  static bool mmode = false;
  static DWORD time;

  KBDLLHOOKSTRUCT*  kbd = (KBDLLHOOKSTRUCT*)lParam;

  if (  code < 0
  ||   (kbd->flags & 0x10) // ignore injected events
     ) return CallNextHookEx( thehook, code, wParam, lParam );

  long ret = 1; // by default I swallow the keys
  if (  mmode  ) { // macro mode is ON
    if (  WM_KEYDOWN == wParam  )
      PostMessage(mainwnd, WM_MCR_ACCUM, kbd->vkCode, 0);

    if (  WM_KEYUP == wParam  )
      switch (kbd->vkCode) {
        case VK_ESCAPE:
          mmode = false;
          keys.removeall();
          PostMessage(
          wnd, WM_MCR_HIDE, 0, 0);
          break;

        case VK_RETURN:
          PostMessage(mainwnd, WM_MCR_EXEC, 0, 0);
          break;

        case VK_LCONTROL:
          mmode = false;
          PostMessage(mainwnd, WM_MCR_HIDE, 0, 0);
          PostMessage(mainwnd, WM_MCR_EXEC, 0, 0);
          break;
      }

    // Which non printable keys allow passing?
    switch( kbd->vkCode ) {
      case VK_LCONTROL:
      case VK_CAPITAL:
      case VK_LSHIFT:
      case VK_RSHIFT:
        ret = CallNextHookEx( thehook, code, wParam, lParam );
    }
  }
  else { // macro mode is OFF
    // Ctrl pressed 
    if (  kbd->vkCode == VK_LCONTROL && WM_KEYDOWN == wParam  ) {
      ctrl_cnt = 1;
      time = kbd->time;
    }

    // Prevent ctrl combinations to activate macro mode 
    if (  kbd->vkCode != VK_LCONTROL  )
      ctrl_cnt = 0;

    // Ctrl released 
    if (  ctrl_cnt == 1 && WM_KEYUP == wParam  ) {
      if (  kbd->time - time > 40  ) {
        mmode = true;
        PostMessage(mainwnd, WM_MCR_SHOW, 0, 0);
      }
    }

    ret = CallNextHookEx( thehook, code, wParam, lParam ); // let it pass
  }

  return ret;
}
*/

void SetNumLock( BOOL bState )
   {
      BYTE keyState[256];

      GetKeyboardState((LPBYTE)&keyState);
      if( (bState && !(keyState[VK_NUMLOCK] & 1)) ||
          (!bState && (keyState[VK_NUMLOCK] & 1)) )
      {
      // Simulate a key press
         keybd_event( VK_NUMLOCK,
                      0x45,
                      KEYEVENTF_EXTENDEDKEY | 0,
                      0 );

      // Simulate a key release
         keybd_event( VK_NUMLOCK,
                      0x45,
                      KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP,
                      0);
      }
   }

//------------------------------------------------
// Window Procedeure
//------------------------------------------------
// static LRESULT CALLBACK mainWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
// {
//     switch ( uMsg ){
//         CASE WM_CREATE:
//             /*
//             Initialization
//             */
//         CASE WM_CLOSE:
//             /*
//             Deposition
//             */
//             DestroyWindow( hWnd );
//         CASE WM_DESTROY:
//             PostQuitMessage( 0 );
//         CASE WM_PAINT:
//         {
//             PAINTSTRUCT     ps;
//             HDC             hDC;
//             
//             hDC = BeginPaint( hWnd, &ps );
//             /*
//             Drawing
//             */
//             EndPaint( hWnd, &ps );
//         }
//         CASE WM_ENDSESSION:         PostMessage( hWnd, WM_CLOSE, 0, 0 );
//         CASE WM_LBUTTONDOWN:        SendMessage( hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
//         CASE WM_LBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_TOPMOST,   0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
//         CASE WM_RBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
//         DEFAULT:                    return DefWindowProc( hWnd, uMsg, wParam, lParam );
//     }
//     return 0;
// }


int CreateSubWindow ( )
{
    LPCTSTR sub_lpTitleName = TEXT("SourceEditor");

	// ShowWindow( hWnd, nCmdShow );
	int nCmdShow = SW_SHOWNORMAL; // SW_SHOWNORMAL :1

	// Creation of Window
    if ( funcCreateWindow( sub_hInstance, char_sub_window, sub_lpTitleName,nCmdShow ) == NULL ){
        MessageBox( NULL, ERRMSG_CREATE, ERRMSG_TITLE, (MB_OK|MB_ICONWARNING) );
        return -2;
    }

/*	MSG msg = { }; 

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
*/

	return 0;
}

