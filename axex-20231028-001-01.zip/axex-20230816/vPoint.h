
#ifndef _VPOINT_
#define _VPOINT_

class vPoint {

	public:
		float x, y, z;

	public:
		vPoint ( );
		vPoint ( float xx, float yy, float zz);
		setPoint ( float xx, float yy, float zz);
		void print ();

	private:
		vPoint subtract( vPoint a, vPoint b );


};

#endif
