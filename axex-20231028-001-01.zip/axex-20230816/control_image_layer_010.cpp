#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"

#include "read_csv_004.h"
#include "read_csv_005.h"

#include "control_image_layer_010.h"

GRID_MATRIX_004* im_grid_matrix_010 = NULL;

static Logging* log_001;
static LOG_001* dlog_001 = NULL;


int putthegray_010 ( int ii, int jj, char* word ) ;
int	initialize_im_grid_matrix_010 () ;
int putthegray_010_01 ( int ii, int jj, char* word ) ;
int Set_lot_001_Control_Image_Layer_001 (Logging* logg) ;


// control_image_layer_010.cpp
// size of word is 4.
//
int putthegray_010 ( int ii, int jj, char* word ) {
	int a, i, rmode, ri;
	char msg[255];

	printf("int putthegray_010 ( int ii, int jj, char* word ) starts.\r\n");
	printf("im_grid_matrix_010 |%p| ii %d log_001|%p|\r\n", im_grid_matrix_010, ii, log_001 );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_010 ( int ii, int jj, char* word ) starts." );

	if ( im_grid_matrix_010 == NULL ) {
		a = initialize_im_grid_matrix_010 ();
	}

	printf("int putthegray_010 ( int ii, int jj, char* word ) block 001.\r\n");
	printf("im_grid_matrix_010 |%p| ii %d\r\n", im_grid_matrix_010, ii );
	printf("im_grid_matrix_010->width_index_num_max %d ii %d\r\n", im_grid_matrix_010->width_index_num_max, ii );

	rmode = 0;
	if (im_grid_matrix_010->width_index_num_max <= ii ) {
		rmode = 1;
		ri = im_grid_matrix_010->width_index_num_max;
		for ( i= 0; ii >= im_grid_matrix_010->width_index_num_max; i++ ) {
			im_grid_matrix_010->width_index_num_max *= 2;
		}
		printf("out1 i %d jj %d width_index_num_max %d\r\n", i, jj, im_grid_matrix_010->width_index_num_max );
		im_grid_matrix_010->grid_matrix = (char***)realloc ( im_grid_matrix_010->grid_matrix , sizeof(char**) * im_grid_matrix_010->width_index_num_max );
		for ( i = ri; i< im_grid_matrix_010->width_index_num_max; i++ ) {
			printf("out1-1 i %d / %d matrix|%p| -> ", i, im_grid_matrix_010->width_index_num_max, im_grid_matrix_010->grid_matrix[i] );
			im_grid_matrix_010->grid_matrix[i] = (char**)malloc ( sizeof(char*) * im_grid_matrix_010->height_index_num_max );
			printf(" matrix|%p| \r\n", i, im_grid_matrix_010->width_index_num_max, im_grid_matrix_010->grid_matrix[i] );
		}
	}

	printf("int putthegray_010 ( int %d, int %d, char* word ) block 002.\r\n", ii, jj);

	if (im_grid_matrix_010->height_index_num_max <=jj ) {
		rmode = 2;
		printf("in i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_010->height_index_num_max );
		for ( i= 0; jj >= im_grid_matrix_010->height_index_num_max; i++ ) {
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_010->height_index_num_max );
			im_grid_matrix_010->height_index_num_max *= 2;
		}
		printf("out2 i %d jj %d width_index_num_max %d height_index_num_max %d \r\n", i, jj, im_grid_matrix_010->width_index_num_max, im_grid_matrix_010->height_index_num_max );
		for ( i = 0; i< im_grid_matrix_010->width_index_num_max; i++ ) {
			im_grid_matrix_010->grid_matrix[i] = (char**)realloc ( im_grid_matrix_010->grid_matrix[i], sizeof(char*) * im_grid_matrix_010->height_index_num_max );
			printf("out2-1 im_grid_matrix_010->grid_matrix[%d]|%p|size %d\r\n", i, im_grid_matrix_010->grid_matrix[i], im_grid_matrix_010->height_index_num_max );
		}
	}

	printf("int putthegray_010 ( int %d, int %d, char* word ) block 003.\r\n", ii, jj);

	sprintf( msg, "putthegray_010 %d %d grid matrix %s", ii, jj, (char*) im_grid_matrix_010->grid_matrix[ii][jj]  );
	dlog_001 = log_001->update_log ( (char*) msg );

	csvafree_005(im_grid_matrix_010->grid_matrix[ii][jj]);
	im_grid_matrix_010->grid_matrix[ii][jj] = (char*) csvcopyof_005 ( word );


	printf("int putthegray_010 ( int %d, int %d, char* word ) block 004.\r\n", ii, jj);

	sprintf( msg, "putthegray_010 %d %d word %s", ii, jj, word  );
	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_010 ( int ii, int jj, char* word ) end." );

	printf("int putthegray_010 ( int ii, int jj, char* word ) ends.\r\n");
	return 0;
}

//
int	initialize_im_grid_matrix_010 () {
	int i, j;
	char msg[255];

	printf("int	initialize_im_grid_matrix_010 () starts.\r\n");

	dlog_001 = log_001->update_log ( (char*)"int	initialize_im_grid_matrix_010 () starts." );

	im_grid_matrix_010 = (GRID_MATRIX_004*) malloc ( sizeof (GRID_MATRIX_004) );
	if ( im_grid_matrix_010 == NULL ) {
		exit(-1);
	}

	im_grid_matrix_010->width_index_num_max = 8;
	im_grid_matrix_010->height_index_num_max = 8;

	im_grid_matrix_010->grid_matrix = (char***)malloc ( sizeof(char**) * im_grid_matrix_010->width_index_num_max );

	sprintf( msg, "im_grid_matrix_010->grid_matrix |%p| im_grid_matrix_010->width_index_num_max=%d", im_grid_matrix_010->grid_matrix, im_grid_matrix_010->width_index_num_max );
	dlog_001 = log_001->update_log ( (char*) msg );

	sprintf( msg, "im_grid_matrix_010->grid_matrix |%p| im_grid_matrix_010->height_index_num_max=%d", im_grid_matrix_010->grid_matrix, im_grid_matrix_010->height_index_num_max );
	dlog_001 = log_001->update_log ( (char*) msg );

	for ( i = 0; i< im_grid_matrix_010->width_index_num_max; i++ ) {
		im_grid_matrix_010->grid_matrix[i] = (char**)malloc ( sizeof(char*) * im_grid_matrix_010->height_index_num_max );
		if ( im_grid_matrix_010->grid_matrix[i] == NULL ) {
			exit(-1);
		}
		for ( j = 0; j< im_grid_matrix_010->height_index_num_max; j++ ) {
			im_grid_matrix_010->grid_matrix[i][j] = (char*)csvcopyof_005 ("g");
		}
	}

	dlog_001 = log_001->update_log ( (char*)"int	initialize_im_grid_matrix_010 () ends." );

	printf("int	initialize_im_grid_matrix_010 () ends.\r\n");

	return  0;
}


int putthegray_010_01 ( int ii, int jj, char* word ) {
	int a, i, rmode, ri;
	char msg[255];

	printf("int putthegray_010_01 ( int ii, int jj, char* word ) starts.\r\n");
	printf("im_grid_matrix_010 |%p| ii %d log_001|%p|\r\n", im_grid_matrix_010, ii, log_001 );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_010_01 ( int ii, int jj, char* word ) starts." );

	if ( im_grid_matrix_010 == NULL ) {
		dlog_001 = log_001->update_log ( (char*)"im_grid_matrix_010 is NULL, so, ..." );
		a = initialize_im_grid_matrix_010 ();
	}

	printf("int putthegray_010_01 ( int ii, int jj, char* word ) block 001.\r\n");
	printf("im_grid_matrix_010 |%p| ii %d\r\n", im_grid_matrix_010, ii );
	printf("im_grid_matrix_010->width_index_num_max %d ii %d\r\n", im_grid_matrix_010->width_index_num_max, ii );

	rmode = 0;
	if (im_grid_matrix_010->width_index_num_max <= ii ) {
		rmode = 1;
		ri = im_grid_matrix_010->width_index_num_max;
		for ( i= 0; ii >= im_grid_matrix_010->width_index_num_max; i++ ) {
			im_grid_matrix_010->width_index_num_max *= 2;
		}
		printf("out1 i %d jj %d width_index_num_max %d\r\n", i, jj, im_grid_matrix_010->width_index_num_max );
		im_grid_matrix_010->grid_matrix = (char***)realloc ( im_grid_matrix_010->grid_matrix , sizeof(char**) * im_grid_matrix_010->width_index_num_max );
		for ( i = ri; i< im_grid_matrix_010->width_index_num_max; i++ ) {
			printf("out1-1 i %d / %d matrix|%p| -> ", i, im_grid_matrix_010->width_index_num_max, im_grid_matrix_010->grid_matrix[i] );
			im_grid_matrix_010->grid_matrix[i] = (char**)malloc ( sizeof(char*) * im_grid_matrix_010->height_index_num_max );
			printf(" matrix|%p| \r\n", i, im_grid_matrix_010->width_index_num_max, im_grid_matrix_010->grid_matrix[i] );
		}
	}

	printf("int putthegray_010_01 ( int %d, int %d, char* word ) block 002.\r\n", ii, jj);

	if (im_grid_matrix_010->height_index_num_max <=jj ) {
		rmode = 2;
		printf("in i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_010->height_index_num_max );
		for ( i= 0; jj >= im_grid_matrix_010->height_index_num_max; i++ ) {
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_010->height_index_num_max );
			im_grid_matrix_010->height_index_num_max *= 2;
		}
		printf("out2 i %d jj %d width_index_num_max %d height_index_num_max %d \r\n", i, jj, im_grid_matrix_010->width_index_num_max, im_grid_matrix_010->height_index_num_max );
		for ( i = 0; i< im_grid_matrix_010->width_index_num_max; i++ ) {
			im_grid_matrix_010->grid_matrix[i] = (char**)realloc ( im_grid_matrix_010->grid_matrix[i], sizeof(char*) * im_grid_matrix_010->height_index_num_max );
			printf("out2-1 im_grid_matrix_010->grid_matrix[%d]|%p|size %d\r\n", i, im_grid_matrix_010->grid_matrix[i], im_grid_matrix_010->height_index_num_max );
		}
	}

	printf("int putthegray_010_01 ( int %d, int %d, char* word ) block 003.\r\n", ii, jj);

	sprintf( msg, "putthegray_010_01 %d %d grid matrix %s", ii, jj, (char*) im_grid_matrix_010->grid_matrix[ii][jj]  );
	dlog_001 = log_001->update_log ( (char*) msg );

	csvafree_005(im_grid_matrix_010->grid_matrix[ii][jj]);
	im_grid_matrix_010->grid_matrix[ii][jj] = (char*) csvcopyof_005 ( word );


	printf("int putthegray_010_01 ( int %d, int %d, char* word ) block 004.\r\n", ii, jj);

	sprintf( msg, "putthegray_010_01 %d %d word %s", ii, jj, word  );
	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_010_01 ( int ii, int jj, char* word ) end." );

	printf("int putthegray_010_01 ( int ii, int jj, char* word ) ends.\r\n");
	return 0;
}

int Set_lot_001_Control_Image_Layer_001 (Logging* logg) {

	log_001 = logg;
	return 0;
}