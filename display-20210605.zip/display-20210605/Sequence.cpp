#include <stdio.h>
#include "Sequence.h"

char seqence[60 * 8];
int total_num_seqence = 60 * 8;
float frame_rate = 1.0f/60.0f; // on a second.


int loop_001 () ;

int loop_001 () {

	for ( int i=0; i<total_num_seqence; i++ ) {
		seqence[i] = 0;
	}

	return 0;
}





