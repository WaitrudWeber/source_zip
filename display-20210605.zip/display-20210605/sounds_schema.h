#ifndef _SOUNDS_SCHEMA_H_
#define _SOUNDS_SCHEMA_H_

extern void sounds_schema ();
extern int initialize_sounds() ;

extern int mm_mode;
extern SoundEffect* sound_000;

#endif
