#ifndef _WPOINTSTRUCTURE_H_
#define _WPOINTSTRUCTURE_H_

class vPointStructure {

	public:
		vPoint* Anchor = nullptr;
		vPoint* C1 = nullptr;
		vPoint* C2 = nullptr;

	private:

	public:
		vPointStructure();
		void Set_Anchor( vPoint *anchor) ;
		vPoint additional_position( vPoint c1, vPoint c2, float t ) ;

};

#endif
