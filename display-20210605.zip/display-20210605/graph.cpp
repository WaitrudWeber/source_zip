#include <windows.h>
#include <math.h>
#include <iostream>
#include <mmsystem.h>
//#include <amstream.h>
//#include <mmstream.h>

#include "array_counter.h"
#include "sender.h"
#include "Print.h"

#include "sounds-011.h"
#include "sounds_schema.h"

#define G_WIDTH	500

int g_width = 500;
int g_height = 300;

void Draw_Graph ( HDC hDC, SoundEffect* SE) ;


// HDC is a pointer.
//
void Draw_Graph ( HDC hDC, SoundEffect* SE) {
//	char	BAR[G_WIDTH];
	int on_height = 50 + 300;

	int a = SE->get_BufferSize();
	char* array = SE->get_m_data();
	// the height is 256.

	for ( int i=0; i<a; i++ ) {
		printf("i: %d v %d \r\n", i, array[i]);
		MoveToEx(hDC, i, on_height, NULL);
		LineTo(hDC, i, array[i] + on_height );
	}
}




