

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "wEvent.h"
#include "wButton.h"
#include "wButtonController.h"
#include "wCanvasController.h"

#include "vDisplayController.h"


void vDisplayController::Set_Lines (vLine** l ) {
	lines = l;
}

void vDisplayController::Set_Lines_2D (vLine** l_2D ) {
	lines_2D = l_2D;
}

//
int vDisplayController::Approach_vAxex_2D( vPoint* ap ) {
	printf("002: int Approach_vAxex_2D( vPoint* ap ) starts.\r\n");

	vPoint* to_vector = Calc.subtract( ap, AXEX_2D_002[0].center ) ;
	double distance = Calc.length ( to_vector );

	if ( distance >= 1.0 ) {
		Calc.normal(to_vector);
		vPoint* progress =  Calc.scalize( to_vector, 5.0f );
		vPoint* next_p = Calc.add ( AXEX_2D_002[0].center, progress);
		AXEX_2D_002[0].SetCenter( next_p->x, next_p->y, next_p->z );
		AXEX_2D_002[0].SetDepth ( next_p->x, next_p->y, next_p->z );
		AXEX_2D_002[0].Calculation_Axex_002 ( );
		free_point( progress );
		free_point( next_p );
	}
	free_point( to_vector );

	AXEX_2D_002[0].CheckAxex();

	vPoint* to_vector_001 = Calc.subtract( ap, AXEX_2D_002[1].center ) ;
	distance = Calc.length ( to_vector );
	if ( distance >= 1.0 ) {
		Calc.normal(to_vector_001);
		vPoint* progress_001 =  Calc.scalize( to_vector_001, 5.0f );
		vPoint* next_p_001 = Calc.add ( AXEX_2D_002[1].center, progress_001);
		AXEX_2D_002[1].SetCenter( next_p_001->x, next_p_001->y, next_p_001->z );
		AXEX_2D_002[1].SetDepth ( next_p_001->x, next_p_001->y, next_p_001->z );
		AXEX_2D_002[1].Calculation_Axex_002 ( );
		free_point( progress_001 );
		free_point( next_p_001 );
	}
	free_point( to_vector_001 );

	AXEX_2D_002[1].CheckAxex();

	vPoint* to_vector_002 = Calc.subtract( ap, AXEX_2D_002[2].center ) ;
	distance = Calc.length ( to_vector );
	if ( distance >= 1.0 ) {
		Calc.normal(to_vector_002);
		vPoint* progress_002 =  Calc.scalize( to_vector_002, 5.0f );
		vPoint* next_p_002 = Calc.add ( AXEX_2D_002[2].center, progress_002);
		AXEX_2D_002[2].SetCenter( next_p_002->x, next_p_002->y, next_p_002->z );
		AXEX_2D_002[2].SetDepth ( next_p_002->x, next_p_002->y, next_p_002->z );
		AXEX_2D_002[2].Calculation_Axex_002 ( );
		free_point( progress_002 );
		free_point( to_vector_002 );
		free_point( next_p_002 );
	}
	free_point( to_vector_002 );

	AXEX_2D_002[2].CheckAxex();

	printf("002: int Approach_vAxex_2D( vPoint* ap ) ends.\r\n");
	return 0;
}


int vDisplayController::DisplaytheBox () {
	float x, y;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint* eye = nullptr;
	vBox box( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);

	printf("v3dCalculation:: DisplaytheBox () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int i=0; i<8; i++ ) {
		printf("code block set loop %d starts.\r\n", i);
		int a = screen_006.get_cooordinate_on_screen ( *(box.p[i]), &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		printf("code block set loop %d ends.\r\n", i);
	}

	box.Print();

	printf("v3dCalculation:: DisplaytheBox () ends.\r\n");
}

int vDisplayController::DisplayThreeBoxes () {
	float x, y;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint* eye = nullptr;
	vBox boxes[3];

	boxes[0].SetBox( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f );
	boxes[1].SetBox( 150.0f, 150.0f, 150.0f, 250.0f, 250.0f, 250.0f );
	boxes[2].SetBox( 300.0f, 300.0f, 300.0f, 400.0f, 400.0f, 400.0f );

	printf("v3dCalculation:: DisplaytheBox () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<3; j++ ) {
		for ( int i=0; i<8; i++ ) {
			printf("code block set loop %d starts.\r\n", i);
			int a = screen_006.get_cooordinate_on_screen ( *(boxes[j].p[i]), &x, &y );
			this->canvas->Set_vAxex_2D( x, y );
			printf("code block set loop %d ends.\r\n", i);
		}
	}

	for ( int j=0; j<3; j++ ) {
		boxes[j].Print();
	}

	printf("v3dCalculation:: DisplaytheBox () ends.\r\n");
}

int vDisplayController::DisplayTenTriangles () {
	vTriangle triangles[10];
	float x, y;
	vPoint* eye = nullptr;

	printf("v3dCalculation:: DisplayTenTriangles () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	for ( int j=0; j<10; j++ ) {
		triangles[j].p1.setPoint (  0.0f,  0.0f,    0.0f );
		triangles[j].p2.setPoint ( 100.0f, 10.0f,   0.0f );
		triangles[j].p3.setPoint ( 100.0f, 20.0f, 100.0f );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( triangles[j].p1, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		int b = screen_006.get_cooordinate_on_screen ( triangles[j].p2, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		int c = screen_006.get_cooordinate_on_screen ( triangles[j].p3, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		printf("code block set loop %d ends.\r\n", j);
	}

	for ( int j=0; j<10; j++ ) {
		printf("triangle print %d starts.\r\n", j);
		triangles[j].print();
		printf("triangle print %d ends.\r\n", j);
	}


	printf("v3dCalculation:: DisplayTenTriangles () ends.\r\n");

	return 0;
}

int vDisplayController::DisplayTenTriangles_001 () {
	vTriangle triangles[10];
	float x, y;
	vPoint* eye = nullptr;

	printf("v3dCalculation:: DisplayTenTriangles () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	for ( int j=0; j<10; j++ ) {
		triangles[j].p1.setPoint (  0.0f,  0.0f,    0.0f );
		triangles[j].p2.setPoint ( 100.0f, 10.0f,   0.0f );
		triangles[j].p3.setPoint ( 100.0f, 20.0f, 100.0f );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( triangles[j].p1, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		int b = screen_006.get_cooordinate_on_screen ( triangles[j].p2, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		int c = screen_006.get_cooordinate_on_screen ( triangles[j].p3, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		printf("code block set loop %d ends.\r\n", j);
	}

	for ( int j=0; j<10; j++ ) {
		printf("triangle print %d starts.\r\n", j);
		triangles[j].print();
		printf("triangle print %d ends.\r\n", j);
	}


	printf("v3dCalculation:: DisplayTenTriangles () ends.\r\n");

	return 0;
}

int vDisplayController::SetCanvas ( wCanvasController *l_canvas ) {
	this->canvas = l_canvas;
}
