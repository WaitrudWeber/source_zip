#ifndef WCANVASCONTROLLER_H
#define WCANVASCONTROLLER_H

#include "wEvent.h"

class wCanvasController {

	public:
		int key_wParam_Keyup = 0;
		int Processed = 0;
		int ProcessedKeyup = 0;
		int AXEX_2D_002_Max  = 30;
		int AXEX_2D_002_Index  = 0;
		int AXEX_2D_002_Index_Selected  = 0;

	private:
		int call_once_key = 0;

	private:
		wEvent* event;
//		vDisplayController vDisp;
//		wDisplayController wDisp;
		vAxex_2D vAxex_2D_002[30];

	public:
		wCanvasController ();
		void kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
		void Process ();
		void ProcessWmPaint ();
		void ProcessWmChar ();
		void ProcessWmKeyup ();
		void setEvent( wEvent* evt );
//		void Print_struct(wJavaStructure top ) ;
		void Set_vAxex_2D ( float x, float y );

};


#endif
