#include <stdio.h>
#include <stdlib.h>

#include "image_layer_001.h"

//
void Image_Layer_001::initialize_image_layer () {
	int i, j, k, l;

	printf("void Image_Layer_001::initialize_image_layer () starts.\r\n");

	layer = (Img_001**) malloc ( sizeof(Img_001) * layer_index );

	l = 10;

	for ( i = 0; i<layer_index; i++ ) {
		layer[i] = (Img_001*) malloc ( sizeof(Img_001) );

		layer[i]->x = 100 + l;
		layer[i]->y = 100 + l;
		layer[i]->width = 120;
		layer[i]->height = 100;
		layer[i]->image = (unsigned char***)malloc( sizeof(unsigned char**) * layer[i]->width );
		for ( j = 0; j<layer[i]->width; j++ ) {
			layer[i]->image[j] = (unsigned char**)malloc ( sizeof(unsigned char*) * layer[i]->height );
			for ( k = 0; k<layer[i]->height; k++ )
				layer[i]->image[j][k] = (unsigned char*) malloc ( sizeof(unsigned char) * 4 ); //r,g,b,t
		}
		l += 10;
	}

	printf("void Image_Layer_001::initialize_image_layer () ends.\r\n");
}

//
void Image_Layer_001::set_default_image_layer () {
	int i, j, k, l;
	unsigned char rgbt[4];
	unsigned char base;

	printf("void Image_Layer_001::set_default_image_layer () starts.\r\n");

	l = 0;
	base = 0;
	for ( j=0; j<layer[l]->height; j++ ) {
		for ( i=0; i<layer[l]->width; i++ ) {
			rgbt[0] = base;
			rgbt[1] = 0;
			rgbt[2] = 0;
			rgbt[3] = 128;
			set_image_layer( l, i, j, (unsigned char*)rgbt);
			base++;
		}
	}

	l = 1;
	base = 0;
	for ( j=0; j<layer[l]->height; j++ ) {
		for ( i=0; i<layer[l]->width; i++ ) {
			rgbt[0] = base;
			rgbt[1] = 0;
			rgbt[2] = base;
			rgbt[3] = 128;
			set_image_layer( l, i, j, (unsigned char*)rgbt);
			base++;
		}
	}

	l = 2;
	base = 0;
	for ( j=0; j<layer[l]->height; j++ ) {
		for ( i=0; i<layer[l]->width; i++ ) {
			rgbt[0] = 0;
			rgbt[1] = base;
			rgbt[2] = 0;
			rgbt[3] = 128;
			set_image_layer( l, i, j, (unsigned char*)rgbt);
			base++;
		}
	}

	printf("void Image_Layer_001::set_default_image_layer () ends.\r\n");
}

//
void Image_Layer_001::set_image_layer (int layer_num, int xpos, int ypos, unsigned char* rgbt) {
	int j, k;

	printf("Image_Layer_001::set_image_layer (int layer_num %d, int xpos %d, int ypos %d, unsigned char* rgbt) starts.\r\n", layer_num, xpos, ypos );

	if ( layer[layer_num] == NULL || layer[layer_num]->image[xpos] == NULL || layer[layer_num]->image[xpos][ypos] == NULL ) {
		printf("layer is not allocated well.\r\n");
		exit(-1);
	}

	layer[layer_num]->image[xpos][ypos][0] = rgbt[0];
	layer[layer_num]->image[xpos][ypos][1] = rgbt[1];
	layer[layer_num]->image[xpos][ypos][2] = rgbt[2];
	layer[layer_num]->image[xpos][ypos][3] = rgbt[3];

	for ( j = 0; j<layer[layer_num]->width; j++ ) {
		layer[layer_num]->image[j] = (unsigned char**)malloc ( sizeof(unsigned char*) * layer[layer_num]->height );
		for ( k = 0; k<layer[layer_num]->height; k++ )
			layer[layer_num]->image[j][k] = (unsigned char*) malloc ( sizeof(unsigned char) * 4 ); //r,g,b,t
	}

	printf("Image_Layer_001::set_image_layer (int layer_num, int xpos, int ypos, unsigned char* rgbt) ends.\r\n");
}

//
unsigned char* Image_Layer_001::get_image_layer (int layer_num, int xpos, int ypos) {
	unsigned char* rgbt_001;
	int i, zero_flg;

	printf("unsigned char* Image_Layer_001::get_image_layer (int layer_num, int xpos, int ypos) starts.\r\n");

	rgbt_001 = layer[layer_num]->image[xpos][ypos];

	zero_flg = 0;
	if (rgbt_001 == NULL ) {
		zero_flg = 1;
	} else {
		zero_flg = 0;
		for ( i = 0; i<4; i++ )
			if ( rgbt_001[i] != 0 ) zero_flg = 1;
	}

	if ( zero_flg == 0 ) {
		rgbt_001 = (unsigned char*)malloc( sizeof(unsigned char) * 4);
		if (rgbt_001 == NULL ) {
			printf("allocation error rgbt_001 is NULL\r\n");
			exit(-1);
		}

		rgbt_001[0] = (unsigned char)0;
		rgbt_001[1] = (unsigned char)0;
		rgbt_001[2] = (unsigned char)128;
		rgbt_001[3] = (unsigned char)128;
	}

	printf("unsigned char* Image_Layer_001::get_image_layer (int layer_num, int xpos, int ypos) return |%p|.", rgbt_001);
	return (unsigned char*) rgbt_001;
}

void Image_Layer_001::set_image_layer_size (int layer_num, int lxpos, int lypos, int lwidth, int lheight ) {
	int k, j;
	printf("void Image_Layer_001::set_image_layer_size (int layer_num, int lxpos, int lypos, int lwidth, int lheight ) starts.\r\n" );

	if ( layer[layer_num]->width < lwidth ) {

		layer[layer_num]->image = (unsigned char***) realloc ( layer[layer_num]->image, lwidth );

		for ( j = 0; j<layer[layer_num]->width; j++ ) {
			layer[layer_num]->image[j] = (unsigned char**)realloc ( layer[layer_num]->image[j], sizeof(unsigned char*) * layer[layer_num]->height );
		}

		printf("a \r\n");
	} else {
		// free k
		//[j][k]  <-
		for ( k = layer[layer_num]->height; k < lheight; k++ ) {
			free ( layer[layer_num]->image[j][k] );
		}

		printf("b \r\n");
	}

	if ( layer[layer_num]->height < lheight ) {

		for ( k = layer[layer_num]->height; k<lheight; k++ )
			layer[layer_num]->image[j][k] = (unsigned char*) malloc ( sizeof(unsigned char) * 4 ); //r,g,b,t

		printf("c \r\n");

	} else {

		printf("d \r\n");
	}



	layer[layer_num]->width = lwidth;
	layer[layer_num]->height = lheight;
	layer[layer_num]->x = lxpos;
	layer[layer_num]->y = lypos;

//		layer[layer_num]->image[j] = (unsigned char**)malloc ( sizeof(unsigned char*) * layer[layer_num]->height );

	printf("void Image_Layer_001::set_image_layer_size (int layer_num, int lxpos, int lypos, int lwidth, int lheight ) ends.\r\n" );
}

//
int Image_Layer_001::get_width (int l) {
	return layer[l]->width;
}

//
int Image_Layer_001::get_height (int l) {
	return layer[l]->height;
}

//
int Image_Layer_001::get_posx (int l) {
	return layer[l]->x;
}

//
int Image_Layer_001::get_posy (int l) {
	return layer[l]->y;
}

//
unsigned char* Image_Layer_001::get_image_layer_001 (int layer_num, int xpos, int ypos) {
	unsigned char* rgbt_001;
	int i;

	rgbt_001 = (unsigned char*)malloc( sizeof(unsigned char) * 4);

	rgbt_001[0] = (unsigned char)0;
	rgbt_001[1] = (unsigned char)128;
	rgbt_001[2] = (unsigned char)0;
	rgbt_001[3] = (unsigned char)128;

	return (unsigned char*) rgbt_001;
}
