#ifndef _RETURNABLEPARAM_H_
#define _RETURNABLEPARAM_H_

	class ReturnableParam {
		public:
			vPoint **points;
			vLine **lines;
			int point_num = 0;
			int line_num = 0;

		public:
			void SetPointNum (int pn );
	};

#endif
