#ifndef _FILEWRITER_006_
#define _FILEWRITER_006_
//...
extern int filewriter_006 ();
extern int set_filewriter_006 ();
extern int initialize_filewriter_006 ();
#endif
