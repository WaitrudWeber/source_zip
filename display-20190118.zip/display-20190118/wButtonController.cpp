// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "wButton.h"
#include "wButtonController.h"

// CursolNumber is public.

wButtonController::wButtonController () {

	this->mode = 0;
	this->number_button = 0;
	AryButton = nullptr;
}

void wButtonController::selectButton ( ) {

	if( this->CursolNumber < 0 ) {
		this->CursolNumber = this->number_button -1;
		//return;
	}

	if( this->CursolNumber >= this->number_button ) {
		this->CursolNumber = 0;
		//return;
	}

	for ( int i=0; i<this->number_button; i++ )
		AryButton[ i ]->setMode( 0 );

	AryButton[ this->CursolNumber ]->setMode( 1 );

}

void wButtonController::selectButton ( char* btn_nm ) {
	int ret;

	for ( int i=0; i<this->number_button; i++ ) {
		
		ret = strcmp( AryButton[ i ]->button_name, btn_nm );
		if ( ret == 0 ) {
			CursolNumber = i;
			AryButton[ i ]->setMode( 1 );
		} else
			AryButton[ i ]->setMode( 0 );
	}
}

void wButtonController::addButton ( wButton* b ) {
	if ( this->number_button ==0 || AryButton == nullptr ) {
		AryButton = ( wButton** ) malloc ( sizeof( wButton* ) * 1 );
		AryButton[ this->number_button ] = b;
		this->number_button = 1;
		return;
	}

	this->number_button++;
	AryButton = (wButton **) realloc( AryButton, this->number_button * sizeof(wButton *) );
	AryButton[ this->number_button - 1] = b;

}

void wButtonController::drawButtons ( HDC hdc ) {

	for ( int i=0; i<this->number_button; i++ ) {
		AryButton[ i ]->drawButton( hdc );
	}

}

//( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
//
//
// added 20190118
//
void wButtonController::kickEveentButtons ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	for ( int i=0; i<this->number_button; i++ ) {
		AryButton[ i ]->kickEveentButton( hWnd, uMsg, wParam, lParam );
	}

}



// void
