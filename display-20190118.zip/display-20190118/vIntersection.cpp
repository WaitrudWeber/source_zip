#include "vPoint.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h";

vIntersection::vIntersection() {
}

vPoint vIntersection::Intersect ( vTriangle tri, vPoint eye, vPoint ray ) {

	vCalculation *cal = nullptr;

	cal = new vCalculation ();

	vPoint n = tri.getNormal ();
	double d = -n.x*tri.p1.x - n.y*tri.p1.y - n.z * tri.p1.z;
	double depth = ( d - n.x*eye.x - n.y*eye.y - n.z*eye.z ) / ( n.x*ray.x + n.y*ray.y + n.z*ray.z );

	vPoint scale_ray = cal->scale( ray, depth);
	vPoint intersection = cal->add( eye, scale_ray);

	delete( cal );

	return intersection;
}

