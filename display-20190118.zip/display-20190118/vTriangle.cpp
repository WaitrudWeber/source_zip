#include "vPoint.h"
#include "vTriangle.h"
#include "vCalculation.h"

vTriangle::vTriangle() {
}

vPoint vTriangle::getNormal() {

	vPoint nrml;
	vPoint ap, bp;
	vCalculation *cal = nullptr;

	cal = new vCalculation ();
	ap = cal->subtract( p2 , p1 );
	bp = cal->subtract( p3 , p1 );
	nrml = cal->cross( ap, bp );
	nrml = cal->normal( nrml );

	this->normal = &nrml;

	delete( cal );

	return nrml;
}


