#ifndef _WPOINTSTRUCTURE_H_
#define _WPOINTSTRUCTURE_H_

class vPointStructure {

	public:
		vPoint Anchor;
		vPoint C1;
		vPoint C2;

	private:

	public:
		void Set_Anchor( vPoint anchor) ;
		vPoint additional_position( vPoint c1, vPoint c2, float t ) ;

};

#endif
