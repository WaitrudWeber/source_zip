#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vPointStructure.h"
#include "vPointLinear.h"


void vPointLinear::calculation_array () {

	aPS = new vPointStructure[ 10 ];

}

//
//
//
void vPointLinear::calculation () {
	vPoint	*p1, *p2, *p3, *p4;
	vCalculation* calc = nullptr;

	printf("start: void vPointLinear::calculation () \r\n");

	calc = new vCalculation();
	p1 = new vPoint ( 1.0f, 2.0f, 3.0f );
	p2 = new vPoint ( 1.5f, 2.5f, 3.5f );

	p3 = calc->scale( p1, 5.0f );
	p4 = calc->scale( p2, 5.0f );

	p1->print();
	p2->print();
	p3->print();
	p4->print();

	printf("end: void vPointLinear::calculation () \r\n");
	// exit(-1);
}

//
// 0<= t <= 1
//
vPoint vPointLinear::position( vPoint* c1, vPoint* c2, float t ) {

	//20190505
	double c = 3.0; // 1/length
	vPoint* start = new vPoint();
	vPoint* end = new vPoint();
	vCalculation* calc = nullptr;

//	vPoint a = calc->scale( start, t*t  );
//	vPoint b = calc->scale( end, 1 - t*t  );
//	vPoint c1 = calc->add ( a, b ) ;

	vPoint result;

	return result;
}

//
//
//
//
//
vPoint vPointLinear::additional_positionP( vPoint* c1, vPoint* c2, float t ) {

	//20190505
	double c = 3.0; // 1/length
	vPoint* start = new vPoint();
	vPoint* end = new vPoint();
	vCalculation* calc = nullptr;
	calc = new vCalculation();

	vPoint a = calc->scale( *start, t*t  );
//	vPoint b = calc->scale( end, 1.0 - t*t  );
//	vPoint c1 = calc->add ( a, b );

	vPoint result;

	return result;
}

//
//
//
//
//
vPoint vPointLinear::additional_position (vPointStructure* ps1, vPointStructure* ps2, float t ) {

	vPoint p;

	return p;
}
