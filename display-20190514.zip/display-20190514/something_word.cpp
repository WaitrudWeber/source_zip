#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "list_directory.h"
#include "parse.h"
#include "numbering.h"

#include "wTextarea.h"
#include "clipboard.h"

#include "something_word.h"

int is_alpha ( char a );
int is_empty ( char* a_word );
int is_all_alpha ( char* b );

int something_word_escape();
void paint_something_word_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
void getchar_something_word_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
int something_word_initialize ();
int keyup_something_word ( HWND hwnd, int key, int* mode );
void copy( char *a, char *b, int wc );
char* charater_number ( char* cn, int number );

int wmpaint_somtehing_word_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam );
// void wmpaint_somtehing_word_proc

// o static char *word = nullptr;
static char word_count = 0;
static char *word =nullptr;
static char *explanation;
static char *word_character_number;

static char *print_word = nullptr;


int sthw_call_once_key = 0;

//wTextarea text1( (char *) "word area");

//  8 Backspace  
// 13 Enter
// 27 ESC
// 32 Space
int keyup_something_word ( HWND hwnd, int key, int* mode ) {
	static char key_code[1];
//	char pate[256];
	char* pastestr;
	int succ;

	switch( key ) {
	case 8:
		word_count--;
		if( word_count >= 0 ) {
			*( word + word_count ) = '\0';
			//sthw_call_once_key = 1;
			word_character_number = (char *) charater_number( word, word_count );
		} else {
			word_count = 0;
		}
		// Passed at 20190406
		printf("backspace: %s \r\n", word );
		// exit(-1);
		break;
	case 13:
		//sthw_call_once_key = 1;
		break;
	case 27:
		*mode = -1;
		//sthw_call_once_key = 1;
	case 32:
		key_code[0] = key;
		word_count++;
		word = m_concat( word, (char *) key_code );
		// usually, the below is not necessary..
		*( word + word_count ) = '\0';
		word_character_number = (char *) charater_number( word, word_count );
		break;
		/* commented out 20180923
	case 'v':
		succ = pastechar (hwnd, pastestr);
		// x succ = Paste( hwnd, pastestr );
		// modify later!
		word = m_concat( word, (char *) pastestr );
		word_count = array_count( word );
		break;
		*/
	}

// Passed at 20190406
//	printf("word: %s \r\n", word );
//	exit(-1);

}

char* charater_number ( char* cn, int number )
{
	char c;
	static char num_str[2048];
	static char str[2048];

	strcpy( str, "cn: ");
	for ( int i=0; i<number; i++ ) {
		c = *( cn + i );
		itoa( c, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );
	}

	return ( char* )str;
}

int something_word_initialize () {

	word = nullptr;

	return 0;
}

int something_word_proc() {


	return 0;
}

//
// creation: 20190403
//
int wmpaint_somtehing_word_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	// this is called at 20190406

	if ( word == nullptr ) {
		print_word = copyof( "type words:" );
	}

	RECT rect;

	// 20190423
	SetRect( &rect, 0, 0, 400, 400);
	DrawText( hDC, TEXT( "wmpaint_somtehing_word_proc: Could you please press ESC until it does work." ), -1, &rect, DT_NOCLIP);

	// 20190423
	SetRect( &rect, 200, 200, 400, 400);
	DrawText( hDC, TEXT( print_word ), -1, &rect, DT_NOCLIP);

	// 20190406
//	FillRect( hDC, &rect, (HBRUSH)(COLOR_WINDOW+1) );
//	DrawText( hDC, TEXT( word ), -1, &rect, DT_NOCLIP );

	return 0;
}

//
//
//
//
//
void paint_something_word_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	PAINTSTRUCT ps;
	RECT rect_2, rect;
	char* store_word;

	// this is not called at 20190406
	// exit(-1);

	HDC hdc = BeginPaint(hWnd, &ps);
//	HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);
	HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );

	SelectObject( hdc, hPen );

	SetRect( &rect_2, 300, 300, 400, 350);
	SetTextColor( hdc, RGB( 0, 0, 0));

	// development: 20190413
	// this line must be printed on the screen but wa not.
	DrawText( hdc, TEXT( "Could you push Escape until this works." ), -1, &rect_2, DT_NOCLIP);

	// store word
//	store_word = ( char* ) malloc( sizeof( char ) * ( word_count + 1 ) );
//	copy( store_word, word, word_count );

	SetRect( &rect, 300, 300, 600, 350);
	//Rectangle( hdc, rect.left, rect.top, rect.right, rect.bottom );
	FillRect(hdc, &rect, (HBRUSH)(COLOR_WINDOW+1) );
	DrawText( hdc, TEXT( word ), -1, &rect, DT_NOCLIP);

//	if ( is_all_alpha ( store_word ) == 0 ) {
		// Drop
//		exit( -1 );
//	}

//	word = store_word;
//	free( word );
}

void copy( char *a, char *b, int wc ) {

	for( int i=0; i < wc; i++ ) {
		*( a + i ) = *( b + i );
	}

}

//
//
//
//
//
void getchar_something_word_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	FileControler *fc = nullptr;
	char key_code[1];
	int number;

	// 20190424
	// does stop this.
	// exit(-1);

	// usually, keyup is still called.
	if ( sthw_call_once_key == 1 ) {
		sthw_call_once_key = 0;
		return;
	}

//	if ( is_alpha ( wParam ) == 0 ) return;
//	print_word = (char*) "aaa\r\nbbb\r\n";

	key_code[0] = wParam;

	word_count++;
	word = m_concat( word, (char *) key_code );

	// usually, the below is not necessary..
	*( word + word_count ) = '\0';

	word_character_number = (char *) charater_number( word, word_count );

	printf("word: %s \r\n", word );

	char** argv = (char**)malloc (sizeof(char*) * 2 );

	fc = new FileControler ();
//	char** file_list = fc->get_files_001 ( "C:\\Users\\soresore soreda\\Documents\\java004\\*.java", &number );
	char** file_list = fc->get_files_001 ( "C:\\java005\\*.java", &number );
	for( int i=0; i<number; i++ ) {
		print_word = m_concat( print_word, (char *) *(file_list + i ) );
		print_word = m_concat( print_word, (char *) copyof("\r\n") );
		*( argv + 1 ) = *(file_list + i );
		numbering_main( 2, (char**)argv );
	}

	// exit(-1);
}

int is_all_alpha ( char* bb ) {

	int b;
	int a = array_count( ( char* ) bb );

	for ( int i=0; i<a; i++ ) {
		b = is_alpha( a );
		if( b == 0 ) return 0;
	}

	return 1;
}

int is_alpha ( char a ) {

	if ( 'A' <= a && 'z' >= a )
		return 1;

	return 0;
}

int something_word_escape () {
//	static int turntomain = -1;
	int a;

	if ( is_empty ( word ) == 1 ) return 1;

	a = array_count( word );
	if ( a > 0 ) {
		free(word);
		word = nullptr;
		word_count = 0;
		return 0;
	} else {
		return 1;
	}
}

int is_empty ( char* a_word ) {
	char c;
	int a = array_count( a_word );

	for( int i=0; i<a; i++ ) {
		c = *(word + i );
		if ( 'A' <= c && c <= 'z' ) {
			return 0;
		}
	}

	return 1;
}

