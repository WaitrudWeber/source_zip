#ifndef _V3DCALCULATION_
#define _V3DCALCULATION_

class v3dCalculation {

	public:
		int calculation_threed () ;
		int calculation_threed_002 () ;
		int calculation_threed_003 () ;

};

#endif
