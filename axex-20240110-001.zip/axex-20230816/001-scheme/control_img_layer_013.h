#ifndef _CONTROL_IMG_LAYER_013_
#define _CONTROL_IMG_LAYER_013_
//...
extern int control_img_layer_013 ();
extern int set_control_img_layer_013 (int ii, int jj, char* word);
extern int initialize_control_img_layer_013 (int ii, int jj, char* word);
#endif
