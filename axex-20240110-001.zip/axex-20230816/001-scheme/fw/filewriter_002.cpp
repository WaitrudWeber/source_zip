int filewriter_002 ();

filewriter_002 () {
nreturn 1;

}


