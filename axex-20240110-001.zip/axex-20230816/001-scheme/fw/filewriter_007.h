#ifndef _FILEWRITER_007_
#define _FILEWRITER_007_
//...
extern int filewriter_007 ();
extern int set_filewriter_007 ();
extern int initialize_filewriter_007 ();
#endif
