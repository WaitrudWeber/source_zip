#ifndef _READ_CSV__006_
#define _READ_CSV__006_
//...
extern int read_csv_000a_006 ();
extern int set_read_csv_000a_006 (char** argv, int argc);
extern int initialize_read_csv_000a_006 (char** argv, int argc);
#endif
