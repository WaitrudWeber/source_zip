#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_005.h"

int csvgetcount_005 () ;
void csvsetcount_005 ( int mcount ) ;
void csvafree_005 (char* mafree) ;
char* csvcopyof_005 ( char* mstring ) ;

static Logging* log_001;
static LOG_001* dlog_001 = NULL;

int Set_Logging_read_csv_005 ( Logging* log ) ;

char logmessage[255];

//
int Set_Logging_read_csv_005 ( Logging* log ) {
	printf("int Set_Logging_read_csv_005 ( Logging* log ) starts.\r\n");
	log_001 = (Logging*)log;
	printf("int Set_Logging_read_csv_005 ( Logging* log ) ends.\r\n");
	return 0;
}

int csvgetcount_005 () {

	return 4;
}

void csvsetcount_005 ( int mcount ) {
}

void csvafree_005 (char* mafree) {
	int c;
	dlog_001 = log_001->update_log ( (char*)"void csvafree_005 (char* mafree) starts." );
	c = get_last_index_005() ;

	sprintf(logmessage, "last index %d\0\0", c );
	dlog_001 = log_001->update_log ( (char*) logmessage );

	aFree_005 ( mafree );
	c = get_last_index_005() ;

	sprintf(logmessage, "last index %d after aFree_005 \0\0", c );
	dlog_001 = log_001->update_log ( (char*) logmessage );

	dlog_001 = log_001->update_log ( (char*)"void csvafree_005 (char* mafree) ends." );
}

char* csvcopyof_005 ( char* mstring ) {
	char* result = NULL;
	dlog_001 = log_001->update_log ( (char*)"char* csvcopyof_005 ( char* mstring ) starts." );

	result = copyof_012( mstring);

	dlog_001 = log_001->update_log ( (char*)"char* csvcopyof_005 ( char* mstring ) ends." );
	return result;
}

