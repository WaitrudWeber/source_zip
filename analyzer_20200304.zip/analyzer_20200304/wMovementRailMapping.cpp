#include <stdio.h>
#include <windows.h>

#include "wEvent.h"
#include "wMovementRailMapping.h"

void wMovementRailMapping::setPid ( int id ) {
}


