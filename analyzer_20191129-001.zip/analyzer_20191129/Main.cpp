#include "vPoint.h"
#include "vLine.h"

#include "vCalculation.h"
#include "vCircle.h"

int main () {

	vPoint* Up = new vPoint ( 0.0f, 1.0f, 0.0f );
	vPoint* Right = new vPoint (1.0f, 0.0f, 0.0f );

	vCircle* circle = new vCircle ( );
	circle->calculation( *Up, *Right );

	return 0;
}


