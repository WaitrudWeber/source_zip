#include <stdio.h>
#include <stdlib.h>

#include "parse.h"

int m_count = 0;
int m_size = 0;
char* token;

char* string_allocation (int size) ;
char* put_token (char c);
int initialize_parse ();


/*
int main ( int argc, char *argv[] ) {

	FILE *fp;
	fp = fopen ( argv[1], "rb" );
	char dummy[1];

	m_size = 256;
	token = (char * )string_allocation ( m_size );


	for( int i=0; i<10; i++ ) {

		char c = fread ( dummy, 1, 1, fp);
		token = put_token ( dummy[0] );
//		printf( "%d %d\n", *token, token);
//		printf ("%s dummy=%s token[%d]=%d\n", dummy, token, i, token[i] );
	}

	return 0;
}
*/



int initialize_parse () {
	m_size = 256;
	token = (char * )string_allocation ( m_size );

	return 0;
}

char* put_token (char c) {
	m_count++;
	char *dummy;

	if ( m_size < m_count ) {
		m_size *= 2;
		dummy = (char * )string_allocation ( m_size );
		for ( int i=0; i< m_size/2; i++) {
			*( dummy + i ) = *( token + i );
		}
		free(token);
		token = dummy;
	}

	*( token + m_count - 1) = c;
	*( token + m_count ) = '\0';

/*
	for( int i=0; i<m_count; i++ ) {
		printf ( "c %d i %d token[%d]=%d token: %s\n", c, i, i, token[ i ], token );
	}
*/

//	printf ( "c %d m_count %d token[%d]=%d token: %s\n", c, m_count - 1, m_count - 1, token[ m_count - 1 ], token );
	return token;
}




/*
char* string_read ( FILE *fp, int size ) {

	if ( size > m_size ) {
		m_size = size;
	}

	token = (char * )string_allocation ( m_size );
	//result = fread ( buffer, 1, size, fp );
}
*/

char* string_allocation (int size) {
	char * buffer;

	buffer = (char*) malloc ( sizeof(char) * size );

	return buffer;
}



