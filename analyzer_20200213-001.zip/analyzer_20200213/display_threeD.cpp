#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "wTextarea.h"
#include "clipboard.h"
#include "Print.h"	//ADD: 20191228

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
//#include "vLine.h"
#include "vCircle.h"

#include "vPointStructure.h"
#include "vPointLinear.h"
#include "display_threeD.h"

int display_threeD_initialize () ;
int getchar_something_word_proc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int getchar_display_threeD_proc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int getchar_display_threeD_proc_002 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ; // drawing

int wmpaint_display_threeD_proc_org ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int wmpaint_display_threeD_proc_002 ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;

int wmpaint_display_patches ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;


void GamePaint_006(HDC hDC) ;
void GamePaint_007(HDC hDC) ;
void GamePaint_008(HDC hDC, POINT* points) ;

void GamePaint_009(HDC hDC, vLine* line ) ;
void GamePaint_010(HDC hDC, vPoint* point ) ;
void GamePaint_011(HDC hDC, vLine* line ) ;
void GamePaint_012( HDC hDC, POINT* points, int num ) ;

void GamePaint_013( HDC hDC, POINT* points, int num ) ;

int getchar_up () ;
void Print_Global_Vertexes ( vPoint* points, int** numbering, int num_patches, int base_num_patches) ;

vPoint* pointss = nullptr;
int** patches = nullptr;
vLine* patch_lines = nullptr;

int num_patches = 0;
int base_num_patches = 0;
int num_patch_lines = 0;

int Flag_Animation = 1;
int Flag_Animation_seconds = 2;

vTriangle atri;
vTriangle screen_tri;
// static vPoint eye;

vPoint ray;
vPoint point_intersection;
float g_x, g_y;
int display_3d = 0;
vLine** lines = nullptr;		// axes in the 3-D.
vLine** lines_2D = nullptr;  // axes on the screen.

vLine** lines_patches = nullptr;
vLine** lines_patches_2D = nullptr;

vScreen* screen = nullptr;
HWND hWindow;

static int call_once_display_threeD_initialize = 0;
vLine* to_screen( vLine** v3d_line, int num ) ;
int count_screen( char* pchar_vline ) ;

void put_vertex(  vPoint* be_set, vPoint* p1 );

vPoint* vertexes = nullptr;
int** patch_num = nullptr;

// Curve
static vPointLinear* CurveLines = new vPointLinear ();
static int memorized_CurveLines = 0;

// Curve_Support
static vPointLinear* CurveLines_Support = new vPointLinear ();
static int memorized_CurveLines_Support = 0;

int mode_rails = 1;

int CurveLines_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int NormalFaces_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int DisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int aDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int bDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int cDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int dDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int dDisplayControls_wmpaint_display_threeD_proc_002 ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int dDisplayControls_wmpaint_display_threeD_proc_OnRails ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;

int dDisplayControls_wmpaint_display_threeD_proc_Refrection ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;


vLine* to_screen_line( vLine* ll ) ;
void create_lines( vPointLinear* curveLines, vLine** sl_lines, int num ) ;
void create_lines_003( vPointLinear* curveLines, vLine** sl_lines, int num ) ;

int waitfor_wmpaint_display_threeD_proc () ;
int create_CurveLines( vLine** l_lines, int line_num ) ;
void Slide_Support_Line ( vPointLinear* pCurveLines_Support ) ;
void Slide_Support_Line_OnRails ( vPointLinear* pCurveLines_Support ) ;
void Slide_Support_Line_OnRails_Set_Slide ( vPointLinear* pCurveLines_Support , vPoint* point ) ;

int rails_initialization () ;
int display_threeD_screen_initialize_OnRails () ;


// scope : 20190217
//
//
//
//
void put_vertex(  vPoint* be_set, vPoint* p1 ) {
	be_set->setPoint( p1->x, p1->y, p1->z );
}

//
//
//
//
//
int rails_initialization () {
	printf("starts rails_initialization()\r\n");
	CurveLines->FirstCreation_OnRails();
	CurveLines->generateControls( );
	CurveLines->CurveRevisement( );

	// Copy vPointLinear: 20191229
	printf( "CurveLines_Suppor: STARTS\r\n" );
	CurveLines_Support->FirstCreation_OnRails();
	CurveLines_Support = CurveLines->copy_point_linear( CurveLines_Support );
//	Slide_Support_Line_OnRails ( CurveLines_Support );
	vPoint* point = memorizevPoint( 250.0f, 0.0f, 250.0f);
	Slide_Support_Line_OnRails_Set_Slide ( CurveLines_Support, point );
	CurveLines_Support->generateControls( );
	CurveLines_Support->CurveRevisement( );
	printf( "CurveLines_Support: ENDS\r\n" );

	printf("ends curve_initialization()\r\n");
	return 0;
}

//
//
//
//
//
int curve_initialization () {

	printf("starts curve_initialization()\r\n");

	printf("STARTS CurveLines->FirstCreation()\r\n");
	CurveLines->FirstCreation();
	printf("ENDS CurveLines->FirstCreation()\r\n");

	printf("STARTS CurveLines->PrintAnchors();\r\n");
	CurveLines->PrintAnchors();
	printf("ENDS CurveLines->PrintAnchors();\r\n");

	printf("CurveLines->print_lines_num= %d\r\n", CurveLines->print_lines_num);

	// Modify: 20191219
	printf("STARTS CurveLines->PrintControls();\r\n");
	CurveLines->PrintControls();
	printf("ENDS CurveLines->PrintControls();\r\n");
	// Modified: 20191219

	printf("CurveLines->print_lines_num= %d\r\n", CurveLines->print_lines_num);

	//vCalculation* calc = new vCalculation();
	//calc->Print_Point_Memories ();

	CurveLines->generateControls( );
	printf("CurveLines->print_lines_num= %d\r\n", CurveLines->print_lines_num);
	//exit(-1);

	// TEST CALL ONECE: We could call it here at 20191219.
	// CurveLines->CurveRevisement( CurveLines->aPS[1]->C2, CurveLines->aPS[1]->Anchor, CurveLines->aPS[1]->C1, CurveLines->aPS[1]->Anchor);
	CurveLines->CurveRevisement( );

	// Copy vPointLinear: 20191229
	printf( "CurveLines_Suppor: STARTS\r\n" );
	CurveLines_Support->FirstCreation();
	CurveLines_Support = CurveLines->copy_point_linear( CurveLines_Support );
	Slide_Support_Line ( CurveLines_Support );
	CurveLines_Support->generateControls( );
	CurveLines_Support->CurveRevisement( );
	printf( "CurveLines_Support: ENDS\r\n" );

	printf("ends curve_initialization()\r\n");
}

// 20191229: we put p( 10.0f, 10.0f, 10.0f ) to CurveLine primitive
//
//
//
//
void Slide_Support_Line ( vPointLinear* pCurveLines_Support ) {
	vCalculation* calc =new vCalculation();
	vPoint* point = memorizevPoint( -250.0f, -10.0f, -250.0f);
//	vPoint* point = memorizevPoint( -250.0f, -10.0f, -0.0f);

	int number = pCurveLines_Support->numPS;
	for( int i=0; i<number; i++ ) {
		calc->add( pCurveLines_Support->aPS[i]->C1, point, pCurveLines_Support->aPS[i]->C1 );
		calc->add( pCurveLines_Support->aPS[i]->C2, point, pCurveLines_Support->aPS[i]->C2 );
		calc->add( pCurveLines_Support->aPS[i]->Anchor, point, pCurveLines_Support->aPS[i]->Anchor );
	}

}

//
//
//
//
//
void Slide_Support_Line_OnRails_Set_Slide ( vPointLinear* pCurveLines_Support , vPoint* point ) {
	vCalculation* calc =new vCalculation();

	int number = pCurveLines_Support->numPS;
	for( int i=0; i<number; i++ ) {
		calc->add( pCurveLines_Support->aPS[i]->C1, point, pCurveLines_Support->aPS[i]->C1 );
		calc->add( pCurveLines_Support->aPS[i]->C2, point, pCurveLines_Support->aPS[i]->C2 );
		calc->add( pCurveLines_Support->aPS[i]->Anchor, point, pCurveLines_Support->aPS[i]->Anchor );
	}

}

void Slide_Support_Line_OnRails ( vPointLinear* pCurveLines_Support ) {
	vCalculation* calc =new vCalculation();
//	vPoint* point = memorizevPoint( -250.0f, -10.0f, -250.0f);
	vPoint* point = memorizevPoint( 250.0f, 0.0f, 250.0f);

	int number = pCurveLines_Support->numPS;
	for( int i=0; i<number; i++ ) {
		calc->add( pCurveLines_Support->aPS[i]->C1, point, pCurveLines_Support->aPS[i]->C1 );
		calc->add( pCurveLines_Support->aPS[i]->C2, point, pCurveLines_Support->aPS[i]->C2 );
		calc->add( pCurveLines_Support->aPS[i]->Anchor, point, pCurveLines_Support->aPS[i]->Anchor );
	}

}


int display_threeD_screen_initialize_Refrection () {

	printf("display_threeD_screen_initialize_Refrection STARTS:\r\n");


	printf("display_threeD_screen_initialize_Refrection ENDS:\r\n");

	return 0;
}

// All qualified at 20190627:
//
//
//
//
int display_threeD_screen_initialize_OnRails () {
	vPoint* eye = nullptr;

	if ( call_once_display_threeD_initialize == 0 ) {
		call_once_display_threeD_initialize = 1;
	} else {
		exit(-1);
	}

	eye = new vPoint();
	eye->setPoint( 300.0f, 300.0f, -300.0f);
	screen = new vScreen ();
//	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
//	vPoint* V= new vPoint ( 0, 90.0f, 0 );
//	screen->put_U ( *U );
//	screen->put_V ( *V );

	screen->put_Up ( *( new vPoint( 0.0f, 1.0f, 0.0f) ) );
//	screen->put_C ( *( new vPoint( 0.0f, 0.0f, -50.0f) ));
	screen->setWidth ( 640 );
	screen->setHeight ( 480 );
	screen->setEye ( *eye );
	screen->LookAt ( *(new vPoint( -0.0f, 0.0f, 0.0f )) );
	screen->HowFarFromEye = 320.0f;

	screen->calculation_up_UV();
	screen->OntheScreen( &g_x, &g_y );

	if ( memorized_CurveLines == 0 ) {
		rails_initialization ();
	}

	memorized_CurveLines = 1;
	printf("display_threeD_screen_initialize:memorized_CurveLines=%d\r\n", memorized_CurveLines );
}


// All qualified at 20190627:
//
//
//
//
int display_threeD_screen_initialize () {
	vPoint* eye = nullptr;

	if ( call_once_display_threeD_initialize == 0 ) {
		call_once_display_threeD_initialize = 1;
	} else {
		exit(-1);
	}

	eye = new vPoint();
	eye->setPoint( 500.0f, 500.0f, 500.0f);
	screen = new vScreen ();
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen->put_U ( *U );
	screen->put_V ( *V );

	screen->put_Up ( *( new vPoint(0.0f, 1.0f, 0.0f) ) );
	screen->put_C ( *( new vPoint( 0.0f, 0.0f, -50.0f) ));
	screen->setWidth ( 640 );
	screen->setHeight ( 480 );
	screen->setEye ( *eye );
	screen->LookAt ( *(new vPoint( -250.0f, 0.0f, 350.0f )) );
	screen->HowFarFromEye = 320.0f;

	screen->calculation_up_UV();
	screen->OntheScreen( &g_x, &g_y );

	if ( memorized_CurveLines == 0 ) {
		switch ( mode_rails ) {
		case 0:
			curve_initialization ();
		case 1:
			rails_initialization ();
			break;
		}
	}

	memorized_CurveLines = 1;
	printf("display_threeD_screen_initialize:memorized_CurveLines=%d\r\n", memorized_CurveLines );
}

// All qualified at 20190627:
//
//
//
//
int display_threeD_screen_initialize_002 () {
	vPoint* eye = nullptr;

	if ( call_once_display_threeD_initialize == 0 ) {
		call_once_display_threeD_initialize = 1;
	} else {
		exit(-1);
	}

	eye = new vPoint();
	eye->setPoint( 500.0f, 500.0f, -500.0f);
	screen = new vScreen ();
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen->put_U ( *U );
	screen->put_V ( *V );

	screen->put_Up ( *( new vPoint(0.0f, 1.0f, 0.0f) ) );
	screen->put_C ( *( new vPoint( 0.0f, 0.0f, -50.0f) ));
	screen->setWidth ( 640 );
	screen->setHeight ( 480 );
	screen->setEye ( *eye );
	screen->LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );
	screen->HowFarFromEye = 320.0f;

	screen->calculation_up_UV();
	screen->OntheScreen( &g_x, &g_y );

	if ( memorized_CurveLines == 0 )
		curve_initialization();

	memorized_CurveLines = 1;
	printf("display_threeD_screen_initialize:memorized_CurveLines=%d\r\n", memorized_CurveLines );
}


//
//
//
//
//
int display_threeD_initialize () {
	vPoint eye;
	char *p_cc;

	if ( call_once_display_threeD_initialize == 0 ) {
		call_once_display_threeD_initialize = 1;
	} else {
		exit(-1);
	}

	printf("display_threeD_initialize\r\n");

	eye.setPoint( 1500.0f, 1500.0f, -1500.0f);

	atri.p1.setPoint( 100.0f,   0.0f, 100.0f );
	atri.p2.setPoint( 200.0f, 200.0f, 200.0f );
	atri.p3.setPoint( 300.0f,   0.0f, 100.0f );

	screen = new vScreen ();
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen->put_U ( *U );
	screen->put_V ( *V );

	screen->put_Up ( *( new vPoint(0.0f, 1.0f, 0.0f) ) );
	screen->put_C ( *( new vPoint( 0.0f, 0.0f, -50.0f) ));
	screen->setWidth ( 640 );
	screen->setHeight ( 480 );
	screen->setEye ( eye );
	screen->LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );
	screen->HowFarFromEye = 320.0f;
	screen->calculation_up_UV();
	screen->OntheScreen( &g_x, &g_y );

	display_3d = 1;

	printf("display_threeD_initialize=000\r\n");

	lines = (vLine**) malloc ( sizeof(vLine*) * 3 );
	lines_2D = (vLine**) malloc ( sizeof(vLine*) * 3 );
	for( int i=0; i<3; i++ ) {
		printf("i:%d \r\n", i);
		lines[i] = new vLine();
		lines_2D[i] = new vLine();
	}
	//exit(-1);

	lines[0]->setLine( (new vPoint( -50.0f, 0.0f, 0.0f)), (new vPoint(300.0f,   0.0f, 0.0f)) );
	lines[1]->setLine( (new vPoint( 0.0f, -50.0f, 0.0f)), (new vPoint(  0.0f, 300.0f, 0.0f)) );
	lines[2]->setLine( (new vPoint( 0.0f, 0.0f, -50.0f)), (new vPoint(  0.0f, 0.0f, 300.0f)) );
	lines[0]->c1 = (char*) "x1";
	lines[0]->c2 = (char*) "x2";

	printf("display_threeD_initialize=001\r\n");

	lines_2D[0]->setLine( (new vPoint( 0.0f, 0.0f, 0.0f)), (new vPoint( 300.0f,   0.0f, 0.0f)) );
	lines_2D[1]->setLine( (new vPoint( 0.0f, 0.0f, 0.0f)), (new vPoint(   0.0f, 300.0f, 0.0f)) );
	lines_2D[2]->setLine( (new vPoint( 0.0f, 0.0f, 0.0f)), (new vPoint(   0.0f,   0.0f, 300.0f)) );

	printf("display_threeD_initialize=002\r\n");

	lines_patches = (vLine**) malloc ( sizeof(vLine*) * 3 );
	lines_patches_2D = (vLine**) malloc ( sizeof(vLine*) * 3 );

	printf("display_threeD_initialize=0021\r\n");

	for( int i=0; i<3; i++ ) {
		lines_patches[i] = new vLine();
		lines_patches_2D[i] = new vLine();
	}

	// commented out at 20190518
	lines_patches[0]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[0]->p2 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[1]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[1]->p2 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[2]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[2]->p2 = new vPoint( 0.0f, 0.0f, 0.0f); 

	printf("display_threeD_initialize=0022\r\n");

	// x lines_patches[0]->setLine( new vPoint( 0.0f, 0.0f, 0.0f), new vPoint( 0.0f, 0.0f, 0.0f) );
	// x lines_patches[0]->setLine( new vPoint( 0.0f, 0.0f, 0.0f), new vPoint( 0.0f, 0.0f, 0.0f) );
	printf("lines_patches[2]->p2->x %f\r\n", lines_patches[2]->p2->x );

	printf("display_threeD_initialize=0023\r\n");

	// commented out at 20190518
	lines_patches_2D[0]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[0]->p2 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[1]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[1]->p2 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[2]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[2]->p2 = new vPoint( 0.0f, 0.0f, 0.0f); 

	lines_patches_2D[0]->c1 = (char *) p_cc;
	lines_patches_2D[0]->c1 = (char *) copyof( "x1" );
	lines_patches_2D[0]->c2 = (char *) copyof( "x2" );
	lines_patches_2D[1]->c1 = (char *) copyof( "y1" );
	lines_patches_2D[1]->c2 = (char *) copyof( "y2" );
	lines_patches_2D[2]->c1 = (char *) copyof( "z1" );
	lines_patches_2D[2]->c2 = (char *) copyof( "z2" );

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	//point_intersection = intersection->Intersect( atri, eye, ray );

	printf("display_threeD_initialize=003\r\n");

	// Book a triangle patch
	num_patches = 1;
	patch_num = (int**) malloc( sizeof(int*) * 1 ) ;
	vertexes = (vPoint*) malloc( sizeof(vPoint) * 8 ) ;

	vertexes = new vPoint ( 0.0f, 0.0f, 0.0f );
	// scope put a vertex
	put_vertex( vertexes + 1, new vPoint ( 5.0f, 10.0f, 0.0f ));
	put_vertex( vertexes + 2, new vPoint ( 10.0f, 0.0f, 0.0f ));

	base_num_patches = 3;
	printf("display_threeD_initialize=001");
	Print_Global_Vertexes ( vertexes, patch_num, num_patches, base_num_patches );

	int* p_tri_patch = (int*) malloc( sizeof(int) * base_num_patches ) ;
	p_tri_patch[0] = 0;
	p_tri_patch[1] = 1;
	p_tri_patch[2] = 2;

	patch_num[0] = p_tri_patch;

	num_patch_lines = 0;
	num_patch_lines = base_num_patches*num_patches;


	if ( memorized_CurveLines == 0 )
		curve_initialization();

	memorized_CurveLines = 1;

	printf("display_threeD_initialize will return 0.\r\n");

	return 0;
}


int get_coordinate_on_screen ( vPoint lp, float* lx, float* ly ) {

	return screen->get_coordinate_on_screen( lp, lx, ly );
}
/*//
//
//
//
//
int get_coordinate_on_screen ( vPoint lp, float* lx, float* ly ) {
	vCalculation calc;
//	vTriangle screen_tri;

	ray = calc.subtract( lp, screen->eye);
	ray = calc.normal(ray);
	// if ( ray.x == 0 && ray.y == 0 && ray.z == 0 ) return -1;

	screen_tri.p1 = screen->C;
	screen_tri.p2 = calc.add( screen->C, screen->U );
	screen_tri.p3 = calc.add( screen->C, screen->V );

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	vPoint point_intersection = intersection->Intersect( screen_tri, screen->eye, ray );

	printf("intersection = ");
	point_intersection.print();
//
//	vPoint result;
//	screen->setPoint(lp);
//	screen->OntheScreen( lp, &result );

	int result = screen->OntheScreen( point_intersection, lx, ly );

	return 0;
}*/

// 002: drawing in 2D
//
//
//
//
int getchar_display_threeD_proc_002 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
//	int key_w = wParam;

	printf("getchar = %d\r\n", wParam );
	//exit(-1);
	switch ( wParam ) {
	case 'j': // UP
		getchar_up ();
		break;
	case 40: // DOWN
		break;
	}

	return 0;
}

//
//
//
//
//
int getchar_display_threeD_proc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
//	int key_w = wParam;

	printf("getchar = %d\r\n", wParam );
	//exit(-1);
	switch ( wParam ) {
	case 'j': // UP
		getchar_up ();
		break;
	case 40: // DOWN
		break;
	}

	return 0;
}

//
//
//
//
int getchar_up () {

	printf("getchar_up :\r\n");
	vCalculation this_calc;
	float depth = this_calc.length ( this_calc.subtract( screen->eye, screen->lookat ) );

	screen->eye = this_calc.add( screen->eye, screen->up );
	printf("screen->eye = ");
	screen->eye.print();

	vPoint ray = this_calc.subtract( screen->eye, screen->lookat );
	ray = this_calc.normal( ray );
	printf("ray = ");
	ray.print();
	ray = this_calc.scale( ray, depth );
	printf("ray = ");
	ray.print();
	screen->eye = this_calc.add( screen->lookat, ray );

	printf("screen->up = ");
	screen->up.print();
	printf("screen->eye = ");
	screen->eye.print();
	screen->calculation_up_UV();

	printf("screen->eye = ");
	screen->eye.print();
	printf("screen->lookat = ");
	screen->lookat.print();
//	exit(-1);
	return 0;
}

//
//
//
//
//
int wmpaint_display_threeD_proc_org ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	HDC     hDC;
	PAINTSTRUCT ps;

	// this is not called at 20190406
	// exit(-1);
	hDC = BeginPaint( hWnd, &ps);

	GamePaint_007( hDC );

	EndPaint(hWnd, &ps);
	return 0;
}

//
//
//
//
void Print_Global_Vertexes ( vPoint* points, int** numbering, int num_patches, int base_num_patches)
{
// 20190217
// p( 10.000000, 0.000000, 0.000000)
// p( 0.000000, 186447550218240.000000, -0.000000)
// p( 0.000000, 0.000000, 300.000000)

	int num = num_patches*base_num_patches;
	for(int i=0; i< num; i++ ) {
		( points + i )->print();
	}
}

//
//
//
//
//
int calculation_pathes () {

	vPointLinear mpl;

	float t = 0.0f;
	vPoint* c1 = new vPoint ( 0.0f, 0.0f, 0.0f );
	vPoint* c2 = new vPoint ( 0.0f, 0.0f, 0.0f );

	vPointLinear* pl = new vPointLinear();
	pl->calculation ();

	for ( int i=0; i< 100; i++ ) {
		double di = i;
		t = di/100.0 ;
//		vPoint result = (vPoint) pl->additional_positionP( c1, c2, t );
//		result = (vPoint) mpl.additional_positionP( c1, c2, t );

	}

	return 0;
}

//
//
//
//
//
int wmpaint_display_patches ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	calculation_pathes ();

	GamePaint_009( hDC, lines_patches_2D[0] );
}

// 002: drawing circles:
//
//
//
//
//
int  wmpaint_display_threeD_proc_002( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	printf("wmpaint_display_threeD_proc_002: \r\n");
	// exit(-21); // it doesn't work.

	int result = waitfor_wmpaint_display_threeD_proc ();
	if ( result == 1 ) {
		dDisplayControls_wmpaint_display_threeD_proc_002 ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
	}



	return result;
}

//
//
//
//
//
//
int wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	static int once = 0;

	int result = waitfor_wmpaint_display_threeD_proc ();
	if ( result == 1 && once == 0 ) {
		//int curve_result = CurveLines_wmpaint_display_threeD_proc ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
		// printf("curve_result=%d\r\n", curve_result );
		switch( mode_rails ){
		case 0:
			dDisplayControls_wmpaint_display_threeD_proc ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
			break;
		case 1:
			dDisplayControls_wmpaint_display_threeD_proc_OnRails ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
//			dDisplayControls_wmpaint_display_threeD_proc ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
			break;
		}
		once = 1;
		// NormalFaces_wmpaint_display_threeD_proc ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
		// exit(-1);
	}

	return result;
}

//
//
//
//
//
int waitfor_wmpaint_display_threeD_proc () {

	for( int i=0; i<2; i++ ) {
		printf("memorized_CurveLines=%d\r\n", memorized_CurveLines );
		if ( memorized_CurveLines == 1 ) return 1;
		Sleep (1000);
	}

	return 0;
}

// Qualified: 20190710
//
//
//
//
//
int aDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("Allocation of local lines: %d %d\r\n", line_num, CurveLines->numPS );
	// Allocation: 20190708
	if ( line_num == 0 ) {

		l_lines = (vLine**) malloc( sizeof(vLine*) * ( CurveLines->numPS + 1 )  );
		for( int i=0; i<CurveLines->numPS; i++ ) {
			// x vLine* allocation_line = (vLine*) malloc ( sizeof(vLine) * 1 );
			// x vLine* allocation_line = new vLine();
			l_lines[i] = (vLine*) new vLine();
		}
		line_num = CurveLines->numPS;

		printf( "Allocated: 0 \r\n" );
	} else if (  line_num <= CurveLines->numPS ) {

		l_lines = (vLine**) realloc( l_lines, sizeof(vLine*) * CurveLines->numPS );
		for( int i=line_num; i<CurveLines->numPS; i++ ) {
			l_lines[i] = new vLine();
		}
		line_num = CurveLines->numPS;
	}

	printf("local lines:\r\n");
	for( int i=0; i<line_num; i++ ) {
		printf("i: %d ", i );
		l_lines[i]->print();
		// l_lines[i]->p1->print();
		// l_lines[i]->p2->print();
	}

	printf("aDisplayControls_wmpaint_display_threeD_proc ends\r\n");
}

//
//
//
//
//
//
int bDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("bDisplayControls_wmpaint_display_threeD_proc: Loop starts.\r\n");
	for( int i=0; i<10; i++) {
		vLine* line = new vLine();
		line->print();
	}
	printf("bDisplayControls_wmpaint_display_threeD_proc: Loop ends.\r\n");
}

// Qualified: 
//
//
//
//
//
int dDisplayControls_wmpaint_display_threeD_proc_002 ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;

	printf("Allocation of local lines: %d %d\r\n", line_num, CurveLines->numPS );
	vPoint* Up = new vPoint( 1.0f, 1.0f, 1.3f );

	vCircle* vcircle = new vCircle ();
	vPoint* cneter = memorizevPoint( 5.0f, 5.0f, 5.0f);
	vcircle->set_center( cneter );
	vcircle->set_R( 10.0f );
	vcircle->calculation ( *Up, screen->U ); // U means right of screen.
	//U is not any pointer.

	l_lines = (vLine**) vcircle->getLines();
	line_num = vcircle->index_pixel;

	printf("line_num %d \r\n", line_num);

	for ( int i=0; i<line_num; i++ ) {
		l_lines[i] = (vLine*)to_screen_line(l_lines[i]);
		GamePaint_011( hDC, l_lines[i] );
		printf("i: %d is painted\r\n", i );
		l_lines[i]->print();
	}

	printf("dDisplayControls_wmpaint_display_threeD_proc_002 ends.\r\n");
	// 20200204
	//exit(-21);
}

// Qualified: 
//
//
//
//
//
int dDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int l_line_num = 0;
	//ADD: 20191229
	static vLine** l_lines_support = nullptr;
	static int l_line_num_support = 0;
	//ADD: 20191229
	vLine* line = nullptr;
	vLine* line_2 = nullptr;


	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("dDisplayControls_wmpaint_display_threeD_proc starts.\r\n");
	printf("Allocation of local lines: %d %d\r\n", l_line_num, CurveLines->numPS );

	//20191130
	//l_lines = (vLine**) CurveLines->generateControlsLines();
	//l_line_num = CurveLines->line_num;
	//20191219
	l_lines = (vLine**) CurveLines->print_lines;
	l_line_num = CurveLines->print_lines_num;


	printf("l_line_num %d\r\n", l_line_num);
	for ( int i=0; i<l_line_num; i++ ) {
		printf( "l_lines[%d]=%p\r\n", i, l_lines[i] );
		l_lines[i]->print();
		l_lines[i] = (vLine*)to_screen_line(l_lines[i]);
		GamePaint_011( hDC, l_lines[i] );  // changed 011 to 009
		printf("i: %d is painted\r\n", i );
	}

//	exit(-1);

	//ADD: 20191229
	l_lines_support = (vLine**) CurveLines_Support->print_lines;
	l_line_num_support = CurveLines_Support->print_lines_num;
	for ( int i=0; i<l_line_num_support; i++ ) {
		l_lines_support[i]->print();
		l_lines_support[i] = (vLine*)to_screen_line(l_lines_support[i]);
		GamePaint_011( hDC, l_lines_support[i] );  // changed 011 to 009
		printf("i: %d is supportedly painted\r\n", i );
	}
	//ADD: 20191229

	printf("set_level_error_msg=%d level_error_msg=%d CurveLines->curve_points_num=%d\r\n", set_level_error_msg, level_error_msg, CurveLines->curve_points_num);
	//ADD: 20191229
	for ( int i=0; i<CurveLines->curve_points_num; i++ ) {
		line = new vLine();
		line->setLine ( CurveLines->curve_points[i], CurveLines_Support->curve_points[i]);
		line = (vLine*)to_screen_line( line );
		line->print();
		CurveLines->curve_points[i]->print();
		CurveLines_Support->curve_points[i]->print();
		GamePaint_011( hDC, line );
		printf("patch i: %d is painted\r\n", i );
	}
	//ADD: 20191229
//	exit(-1);

	static POINT points[4];
	//ADD: 20191231
	for ( int i=0; i<CurveLines->curve_points_num - 2 ; i+=2 ) {
		line = new vLine();
		line->setLine ( CurveLines->curve_points[i], CurveLines_Support->curve_points[i]);
		line = (vLine*)to_screen_line( line );
		line->print();

		line_2 = new vLine();
		line_2->setLine ( CurveLines->curve_points[i +1], CurveLines_Support->curve_points[i + 1]);
		line_2 = (vLine*)to_screen_line( line_2 );
		line_2->print();

		points[0] = { (int)line->p1->x, (int)line->p1->y };
		points[1] = { (int)line->p2->x, (int)line->p2->y };
		points[2] = { (int)line_2->p2->x, (int)line_2->p2->y };
		points[3] = { (int)line_2->p1->x, (int)line_2->p1->y };

		GamePaint_013( hDC, (POINT*)points, 4 );
		printf("draw i: %d is painted\r\n", i );
	}
	//ADD: 20191231


	//CurveLines->PrintControls();
	printf("dDisplayControls_wmpaint_display_threeD_proc ends.\r\n");
	// exit(-1); //20191202
	// exit(-1); //20191219
	// exit(-1);
}

// Qualified: 
//
//
//
//
int dDisplayControls_wmpaint_display_threeD_proc_Refrection ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	printf( "dDisplayControls_wmpaint_display_threeD_proc_Refrection Starts: \r\n" );


	printf( "dDisplayControls_wmpaint_display_threeD_proc_Refrection Ends: \r\n" );

	return 0;
}



// Qualified: 
//
//
//
//
//
int dDisplayControls_wmpaint_display_threeD_proc_OnRails ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int l_line_num = 0;
	//ADD: 20191229
	static vLine** l_lines_support = nullptr;
	static int l_line_num_support = 0;
	//ADD: 20191229
	vLine* line = nullptr;
	vLine* line_2 = nullptr;


	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("dDisplayControls_wmpaint_display_threeD_proc starts.\r\n");
	printf("Allocation of local lines: %d %d\r\n", l_line_num, CurveLines->numPS );

	//20191130
	//l_lines = (vLine**) CurveLines->generateControlsLines();
	//l_line_num = CurveLines->line_num;
	//20191219
	l_lines = (vLine**) CurveLines->print_lines;
	l_line_num = CurveLines->print_lines_num;


	printf("l_line_num %d\r\n", l_line_num);
	for ( int i=0; i<l_line_num; i++ ) {
		printf( "l_lines[%d]=%p\r\n", i, l_lines[i] );
		l_lines[i]->print();
		l_lines[i] = (vLine*)to_screen_line(l_lines[i]);
		GamePaint_011( hDC, l_lines[i] );  // changed 011 to 009
		printf("i: %d is painted\r\n", i );
	}

//	exit(-1);

	//ADD: 20191229
	l_lines_support = (vLine**) CurveLines_Support->print_lines;
	l_line_num_support = CurveLines_Support->print_lines_num;
	for ( int i=0; i<l_line_num_support; i++ ) {
		l_lines_support[i]->print();
		l_lines_support[i] = (vLine*)to_screen_line(l_lines_support[i]);
		GamePaint_011( hDC, l_lines_support[i] );  // changed 011 to 009
		printf("i: %d is supportedly painted\r\n", i );
	}
	//ADD: 20191229

	printf("set_level_error_msg=%d level_error_msg=%d CurveLines->curve_points_num=%d\r\n", set_level_error_msg, level_error_msg, CurveLines->curve_points_num);
	//ADD: 20191229
	for ( int i=0; i<CurveLines->curve_points_num; i++ ) {
		line = new vLine();
		line->setLine ( CurveLines->curve_points[i], CurveLines_Support->curve_points[i]);
		line = (vLine*)to_screen_line( line );
		line->print();
		CurveLines->curve_points[i]->print();
		CurveLines_Support->curve_points[i]->print();
		GamePaint_011( hDC, line );
		printf("patch i: %d is painted\r\n", i );
	}
	//ADD: 20191229
//	exit(-1);

	static POINT points[4];
	//ADD: 20191231
	for ( int i=0; i<CurveLines->curve_points_num - 2 ; i+=2 ) {
		line = new vLine();
		line->setLine ( CurveLines->curve_points[i], CurveLines_Support->curve_points[i]);
		line = (vLine*)to_screen_line( line );
		line->print();

		line_2 = new vLine();
		line_2->setLine ( CurveLines->curve_points[i +1], CurveLines_Support->curve_points[i + 1]);
		line_2 = (vLine*)to_screen_line( line_2 );
		line_2->print();

		points[0] = { (int)line->p1->x, (int)line->p1->y };
		points[1] = { (int)line->p2->x, (int)line->p2->y };
		points[2] = { (int)line_2->p2->x, (int)line_2->p2->y };
		points[3] = { (int)line_2->p1->x, (int)line_2->p1->y };

		GamePaint_012( hDC, (POINT*)points, 4 );
		printf("draw i: %d is painted\r\n", i );
	}
	//ADD: 20191231


	//CurveLines->PrintControls();
	printf("dDisplayControls_wmpaint_display_threeD_proc ends.\r\n");
	// exit(-1); //20191202
	// exit(-1); //20191219
	// exit(-1);
}

// Qualified: 20190711
//
//
//
//
//
int cDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("Allocation of local lines: %d %d\r\n", line_num, CurveLines->numPS );
	// Allocation: 20190708
	if ( line_num == 0 ) {

		l_lines = (vLine**) malloc( sizeof(vLine*) * ( CurveLines->numPS + 1 )  );
		for( int i=0; i<CurveLines->numPS; i++ ) {
			// x vLine* allocation_line = (vLine*) malloc ( sizeof(vLine) * 1 );
			// x vLine* allocation_line = new vLine();
			l_lines[i] = (vLine*) new vLine();
		}
		line_num = CurveLines->numPS;

		printf( "Allocated: 0 \r\n" );
	} else if (  line_num <= CurveLines->numPS ) {

		l_lines = (vLine**) realloc( l_lines, sizeof(vLine*) * CurveLines->numPS );
		for( int i=line_num; i<CurveLines->numPS; i++ ) {
			l_lines[i] = new vLine();
		}
		line_num = CurveLines->numPS;
	}

	printf("local lines:\r\n");
	for( int i=0; i<line_num; i++ ) {
		printf("i: %d ", i );
		l_lines[i]->setLine( (vPoint*) CurveLines->aPS[i]->C1, (vPoint*) CurveLines->aPS[i]->C2 );
		l_lines[i]->print();
		// l_lines[i]->p1->print();
		// l_lines[i]->p2->print();
	}

	printf("cDisplayControls_wmpaint_display_threeD_proc ends.\r\n");
}

//
//
//
//
//
//
int DisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static char num_str[2048];
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("Allocation of local lines: %d %d\r\n", line_num, CurveLines->numPS );
	// Allocation: 20190708
	if ( line_num == 0 ) {

		l_lines = (vLine**) malloc( sizeof(vLine*) * ( CurveLines->numPS + 1 )  );
		for( int i=0; i<CurveLines->numPS; i++ ) {
			vLine* allocation_line = (vLine*) malloc ( sizeof(vLine) * 1 );
			// x vLine* allocation_line = new vLine();
			// x l_lines[i] = (vLine*) new vLine();
		}
		line_num = CurveLines->numPS;

		printf( "Allocated: 0 \r\n" );
	} else if (  line_num <= CurveLines->numPS ) {

		l_lines = (vLine**) realloc( l_lines, sizeof(vLine*) * CurveLines->numPS );
		for( int i=line_num; i<CurveLines->numPS; i++ ) {
			l_lines[i] = new vLine();
		}
		line_num = CurveLines->numPS;
	}

	// Modified: 20191218
	printf("create_lines_003:\r\n");
	create_lines_003 ( (vPointLinear*)CurveLines, l_lines, CurveLines->numPS );
	//create_lines ( (vPointLinear*)CurveLines, l_lines, CurveLines->numPS );

	printf("local lines:\r\n");
	for( int i=0; i<CurveLines->numPS; i++ ) {
		l_lines[i]->p1->print();
		l_lines[i]->p2->print();
		GamePaint_011( hDC, l_lines[i] );
	}

	exit(-1);
}

//
//
//
//
//
//
int NormalFaces_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static char num_str[2048];
	static vLine** l_lines = nullptr;

	if ( memorized_CurveLines == 0 ) return -1;
	if ( l_lines != nullptr ) return 2;

	l_lines = (vLine**) malloc( sizeof(vLine*) * CurveLines->numPS );
	for( int i=0; i<CurveLines->numPS; i++ ) {
		l_lines[i] = new vLine();
	}
	create_lines( (vPointLinear*)CurveLines, l_lines, CurveLines->numPS );
	//exit( -1 );

	for( int i=0; i<CurveLines->numPS; i++ ) {
		l_lines[i]->p1->print();
		l_lines[i]->p2->print();
		GamePaint_011( hDC, l_lines[i] );
	}

	//exit(-1);
}


// 20191218:
void create_lines_004 ( vPointLinear* curveLines, vLine** l_lines, int num ) {

	vPointLinear* prot_curveLines = new vPointLinear();

	//20191218 we could not call the below.
	//prot_curveLines->CurveRevisement();

}

// 20191218:
//
//
//
//
void create_lines_003 ( vPointLinear* curveLines, vLine** l_lines, int num ) {
	static int line_num = 0;
	line_num = num;

	printf( "create_lines_003: START:\r\n" );
	vCalculation* calc = new vCalculation ();
	vCurveCalculation* curve_calc = new vCurveCalculation ();

	//20191218 we could not call the below.
	//int curve_revisement = curveLines->CurveRevisement();

	for( int i=0; i<num; i++ ) {
		printf ( "normal_faces i %d / %d: ", i, num );
		if ( curveLines->aPS[i]->Anchor == nullptr ) exit(-1);
		if ( curveLines->normal_faces[i] == nullptr ) exit(-1);

		//curveLines->normal_faces[i]->print();
		vPoint* p3 = new vPoint();
		calc->add( curveLines->aPS[i]->Anchor, (vPoint*)curveLines->normal_faces[i], p3 );
		p3->print();
		curveLines->aPS[i]->Anchor->print();
		l_lines[i]->setLine( (vPoint*)curveLines->aPS[i]->Anchor, p3 );
	}
	printf( "create_lines_003: END:\r\n" );
}


//
//
//
//
//
void create_lines( vPointLinear* curveLines, vLine** l_lines, int num ) {
	static int line_num = 0;
	line_num = num;

	printf( "create_lines: START:\r\n" );
	vCalculation* calc = new vCalculation ();
	for( int i=0; i<num; i++ ) {
		printf ( "normal_faces i %d / %d: ", i, num );
		if ( curveLines->aPS[i]->Anchor == nullptr ) exit(-1);
		if ( curveLines->normal_faces[i] == nullptr ) exit(-1);

		//curveLines->normal_faces[i]->print();
		vPoint* p3 = new vPoint();
		calc->add( curveLines->aPS[i]->Anchor, (vPoint*)curveLines->normal_faces[i], p3 );
		p3->print();
		curveLines->aPS[i]->Anchor->print();
		l_lines[i]->setLine( (vPoint*)curveLines->aPS[i]->Anchor, p3 );
	}
	printf( "create_lines: END:\r\n" );
}


//
//
//
//
//
vLine* to_screen_line( vLine* ll ) {
	static float fx[3], fy[3];

	printf("to_screen_line starts: \r\n");

	get_coordinate_on_screen ( *(ll->p1), &fx[0], &fy[0] );
	ll->p1->x = fx[0];
	ll->p1->y = fy[0];
	get_coordinate_on_screen ( *(ll->p2), &fx[0], &fy[0] );
	ll->p2->x = fx[0];
	ll->p2->y = fy[0];

	printf("to_screen_line return %p: \r\n", ll );

	return ll;
}

//
//
//
//
//
//
int CurveLines_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static vLine* l = nullptr;

	if ( memorized_CurveLines == 0 ) return -1;

	printf("CurveLines->numPS=%d\r\n", CurveLines->numPS);

	l_lines = (vLine**) malloc( sizeof(vLine*) * CurveLines->numPS );
	for ( int i=0; i<CurveLines->numPS; i++ ) {
		printf("vLine:%d %d\r\n", i, l_lines[i] );
		l = new vLine(); // <- we can' do the left.
		Sleep(1000);
		printf("vLine allocation:%d %d\r\n", i, l );
		l_lines[i] = l;
	}
	printf("create_CurveLines: %d starts\r\n", CurveLines->numPS );
	create_CurveLines ( l_lines, CurveLines->numPS );
	printf("create_CurveLines: %d ends\r\n", CurveLines->numPS );
	//exit(-1);

	for( int i=0; i<CurveLines->numPS; i++ ) {
		GamePaint_011( hDC, l_lines[i] );
	}

}

//
//
//
//
//
//
int CurveLines_wmpaint_display_threeD_proc_org ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	float fx[3], fy[3];
	static vLine** l_lines = nullptr;
	static char num_str[2048];

	if ( memorized_CurveLines == 0 ) return -1;

	if ( l_lines != nullptr ) return 2; // return 2: means doesn't need to convert models.

	l_lines = (vLine**) malloc( sizeof(vLine*) * 6 );

	get_coordinate_on_screen ( *(CurveLines->aPS[0]->Anchor), &fx[0], &fy[0] );

	// Allocation vLine which has vPoint p1 and p2.
	l_lines[ 0 ]->p1->x = fx[0];
	l_lines[ 0 ]->p1->y = fy[0];
	l_lines[ 0 ]->c1 = copyof("A0");

	for( int i=1; i<6; i++ ) {
		get_coordinate_on_screen ( *(CurveLines->aPS[i]->Anchor), &fx[0], &fy[0] );
		l_lines[ i - 1 ]->p2->x = fx[0];
		l_lines[ i - 1 ]->p2->y = fy[0];
		l_lines[ i ]->p1->x = fx[0];
		l_lines[ i ]->p1->y = fy[0];
		l_lines[ i ]->c1 = copyof( m_concat( copyof("A"), itoa( i, num_str, 10 ) ) );
	}

	get_coordinate_on_screen ( *(CurveLines->aPS[ 5 ]->Anchor), &fx[0], &fy[0] );
	l_lines[ 5 ]->p2->x = fx[0];
	l_lines[ 5 ]->p2->y = fy[0];
	l_lines[ 5 ]->c1 = copyof("A6");

	for( int i=0; i<6; i++ ) {
		GamePaint_011( hDC, l_lines[i] );
	}

}

//
//
//
//
//
int create_CurveLines( vLine** l_lines, int line_num ) {
	static float fx[3], fy[3];
	static char num_str[2048];

	if ( line_num == 0 ) return 0;

	if ( l_lines == nullptr ) {
		l_lines = (vLine**) malloc( sizeof(vLine*) * line_num );
	}
	get_coordinate_on_screen ( *(CurveLines->aPS[0]->Anchor), &fx[0], &fy[0] );



	// Quallified here at 20190628.
	// Allocation vLine which has vPoint p1 and p2.
	l_lines[0] = new vLine();
	l_lines[ 0 ]->p1->x = fx[0];
	l_lines[ 0 ]->p1->y = fy[0];
	l_lines[ 0 ]->c1 = copyof("A0");

	printf("003\r\n");

	for( int i=1; i<line_num; i++ ) {
		get_coordinate_on_screen ( *(CurveLines->aPS[i]->Anchor), &fx[0], &fy[0] );
		l_lines[ i - 1 ]->p2->x = fx[0];
		l_lines[ i - 1 ]->p2->y = fy[0];
		l_lines[ i ] = new vLine();
		l_lines[ i ]->p1->x = fx[0];
		l_lines[ i ]->p1->y = fy[0];
		l_lines[ i ]->c1 = copyof( m_concat( copyof("A"), itoa( i, num_str, 10 ) ) );
	}

	get_coordinate_on_screen ( *(CurveLines->aPS[ line_num - 1 ]->Anchor), &fx[0], &fy[0] );
	l_lines[ line_num - 1 ]->p2->x = fx[0];
	l_lines[ line_num - 1 ]->p2->y = fy[0];
	l_lines[ line_num - 1 ]->c1 = copyof("A6");

	return 1;
}


//
// lines            :
// lines_2D         :
// lines_patches_2D :
// lines_patches    :
//
int F011_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	float lx, ly;
	float fx[3], fy[3];
	POINT points[3];
	vCalculation l_calc;

	if ( display_3d == 0 ) return -1;

//	vLine* v3d_line = l_calc.Lines_from_Mesh( vertexes, patch_num, num_patches, base_num_patches );
	// Print Global Vertexesx
	Print_Global_Vertexes ( vertexes, patch_num, num_patches, base_num_patches );

	printf("atri.p1=");
	atri.p1.print();
	printf("atri.p2=");
	atri.p2.print();
	printf("atri.p3=");
	atri.p3.print();

	printf("screen C=");
	screen->C.print();

	get_coordinate_on_screen ( atri.p1, &fx[0], &fy[0] );
	lines_patches_2D[0]->p1->x = fx[0];
	lines_patches_2D[0]->p1->y = fy[0];
	lines_patches_2D[2]->p2->x = fx[0];
	lines_patches_2D[2]->p2->y = fy[0];

	get_coordinate_on_screen ( atri.p2, &fx[1], &fy[1] );
	lines_patches_2D[0]->p2->x = fx[1];
	lines_patches_2D[0]->p2->y = fy[1];
	lines_patches_2D[1]->p1->x = fx[1];
	lines_patches_2D[1]->p1->y = fy[1];

	get_coordinate_on_screen ( atri.p3, &fx[2], &fy[2] );
	lines_patches_2D[1]->p2->x = fx[2];
	lines_patches_2D[1]->p2->y = fy[2];
	lines_patches_2D[2]->p1->x = fx[2];
	lines_patches_2D[2]->p1->y = fy[2];

	GamePaint_011( hDC, lines_patches_2D[0] );
	GamePaint_011( hDC, lines_patches_2D[1] );
	GamePaint_011( hDC, lines_patches_2D[2] );

	get_coordinate_on_screen ( atri.p3, &fx[0], &fy[0] );
	lines_2D[0]->p1->x = fx[0];
	lines_2D[0]->p1->y = fy[0];
	lines_2D[1]->p1->x = fx[1];
	lines_2D[1]->p1->y = fy[1];
	lines_2D[2]->p1->x = fx[2];
	lines_2D[2]->p1->y = fy[2];
	lines_2D[0]->p2->x = fx[0];
	lines_2D[0]->p2->y = fy[0];
	lines_2D[1]->p2->x = fx[1];
	lines_2D[1]->p2->y = fy[1];
	lines_2D[2]->p2->x = fx[2];
	lines_2D[2]->p2->y = fy[2];

	GamePaint_011( hDC, lines_2D[0] );
	GamePaint_011( hDC, lines_2D[1] );
	GamePaint_011( hDC, lines_2D[2] );

	GamePaint_011( hDC, lines[0] );
	GamePaint_011( hDC, lines[1] );
	GamePaint_011( hDC, lines[2] );

	// vLine** v3d_line = l_calc.Lines_from_Mesh( vertexes, patch_num, num_patches, base_num_patches );
	// vLine* v2d_line = (vLine*) to_screen( v3d_line,  num_patches*base_num_patches );
	// GamePaint_009( hDC, v2d_line );

	return 0;
}





//
//
//
//
//
vLine* to_screen( vLine** v3d_line, int num ) {
	vLine* v2d_line = nullptr;
	vLine a;
	int b[3];
	vLine l[3];
	float x, y;

//	int num = sizeof(v3d_line) / sizeof( vLine ) ;
	a.p1 = new vPoint( 0.0f, 0.0f, 0.0f );

	v2d_line = (vLine*) malloc( sizeof(vLine) * num );
	for( int i=0; i<num; i++ ) {
		vLine* line = ( v2d_line + i ) ;
		line->p1 = new vPoint();
		line->p2 = new vPoint();
	}


	//printf("b=%d int size = %d\r\n", sizeof(b), sizeof(int) );
	//printf("l=%d vLine size = %d\r\n", sizeof(l), sizeof(vLine) );
	//printf("v2d_line=%d vLine size = %d conunt array %d\r\n", sizeof(v2d_line), sizeof(vLine), count_screen((char*)(&l[0])) );

//	printf("num=%d %d %d / %d sizeof a vLine %d &vLine %d\r\n", num, sizeof( v3d_line ), sizeof( *v3d_line ), sizeof( vLine ), sizeof(a), sizeof(&a) );

	printf("set of to_screen.\r\n");

	for ( int i=0; i<num; i++ ) {
		vLine* l1 = *( v3d_line + i );
		vLine* l2 = ( v2d_line + i );

		printf(" %d / %d \r\n", i, num );

		vPoint* p1 = l1->p1;
		vPoint* p2 = l1->p2;

		vPoint* d2_p1 = l2->p1;
		vPoint* d2_p2 = l2->p2;

		get_coordinate_on_screen ( *(a.p1), &x, &y );

		// exit(-1);
		p1->print();

//		get_coordinate_on_screen ( *(p1), &x, &y );
//		get_coordinate_on_screen ( *p1, &( d2_p2->x ), &( d2_p2->y ) );
//		get_coordinate_on_screen ( *(l1->p2), &(l2->p2->x), &(l2->p2->y) );

		// the below parts are all error.
//		get_coordinate_on_screen ( *(l1->p1), &(l1->p1->x), &(l1->p1->y) );
//		get_coordinate_on_screen ( *(l1->p2), &(l1->p2->x), &(l1->p2->y) );
//		get_coordinate_on_screen ( *(l2->p1), &(l2->p1->x), &(l2->p1->y) );
//		get_coordinate_on_screen ( *(l2->p2), &(l2->p2->x), &(l2->p2->y) );
	}

	printf("end of to_screen.\r\n");
	// exit(-1);

	return v2d_line;
}

//
//
//
//
//
int count_screen( char* pchar_vline ) {

	int result = 0;
	for( int i=0; i=256*256; i++ ) {
		result++;
		char* c = pchar_vline++;
		if ( *c == '\0' ) break;
	}

	return result;
}

// Very Thanks to: http://www.informit.com/articles/article.aspx?p=328647&seqNum=3
// int FillRect(HDC hDC, CONST RECT *lprc, HBRUSH hbr);
// BOOL Rectangle(HDC hDC, int xLeft, int yTop, int xRight, int yBottom);
// BOOL MoveToEx(HDC hDC, int x, int y, LPPOINT pt);
// BOOL LineTo(HDC hDC, int x, int y);
// BOOL TextOut(HDC hDC, int x, int y, LPCTSTR szString, int iLength);
// HPEN CreatePen(int iPenStyle, int iWidth, COLORREF crColor);
// HPEN hBluePen = CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
// HBRUSH hPurpleBrush = CreateSolidBrush(RGB(255, 0, 255));
// HPEN hPen = SelectObject(hDC, hBluePen);
// SelectObject(hDC, hPen);
// DeleteObject(hBluePen);
// HBRUSH hBrush = SelectObject(hDC, hPurpleBrush);
//  // *** Do some drawing here! ***
//  SelectObject(hDC, hBrush);
//  DeleteObject(hPurpleBrush);

// case WM_PAINT:
//  HDC     hDC;
//  PAINTSTRUCT ps;
//  hDC = BeginPaint(hWindow, &ps);

//  // Paint the game
//  GamePaint(hDC);
//
// EndPaint(hWindow, &ps);
// return 0;
//
//
//
//

//
//
//
//
//
void GamePaint_000(HDC hDC)
{
	MoveToEx(hDC, 0, 0, NULL);
	LineTo(hDC, 50, 50);
}

void GamePaint_001(HDC hDC)
{
	TextOut(hDC, 10, 10, TEXT("Michael Morrison"), 16);
}

void GamePaint_002(HDC hDC)
{
	RECT rect;
	GetClientRect(hWindow, &rect);
	DrawText(hDC, TEXT("Michael Morrison"), -1, &rect,
	DT_SINGLELINE | DT_CENTER | DT_VCENTER);
}

void GamePaint_003(HDC hDC)
{
	MoveToEx(hDC, 10, 40, NULL);
	LineTo(hDC, 44, 10);
	LineTo(hDC, 78, 40);
}

void GamePaint_004(HDC hDC)
{
	Rectangle(hDC, 16, 36, 72, 70);
	Rectangle(hDC, 34, 50, 54, 70);
}

void GamePaint_005(HDC hDC)
{
	Ellipse(hDC, 40, 55, 48, 65);
}

void GamePaint_006(HDC hDC)
{
	POINT points[3];
	points[0] = { 305, 10 };
	points[1] = { 355, 50 };
	points[2] = { 325, 55 };
	Polygon( hDC, points, 3 );
}

void GamePaint_007(HDC hDC) {
	RECT msg_clip;

	SetRect ( &msg_clip, 300, 0, 400, 50);
//	DrawText( hdc, TEXT( m_pastestr ), -1, &msg_clip, DT_NOCLIP);
	DrawText( hDC, TEXT( "GamePaint_007" ), -1, &msg_clip, DT_NOCLIP);
}

// 3 points :triangle
void GamePaint_008(HDC hDC, POINT* points)
{
	POINT p = points[0];
	printf("point 1: %ld %ld\r\n", p.x, p.y );
	Polygon( hDC, points, 3 );
}

void GamePaint_009(HDC hDC, vLine* line )
{
	vPoint *p1, *p2;
	p1 = line->p1;
	p2 = line->p2;

	printf("GamePaint_009: line : %f %f - %f %f\r\n", p1->x, p1->y, p2->x, p2->y );
//	printf("GamePaint_009: line : %f %f - %f %f\r\n", line->p1->x, line->p1->y, line->p2->x, line->p2->y );
	MoveToEx(hDC, (int)line->p1->x, (int)line->p1->y, NULL);
	LineTo(hDC, (int)(line->p2)->x, (int)(line->p2)->y );
}

//
//
//
// vPoint
//
void GamePaint_010(HDC hDC, vPoint* point ) {

	MoveToEx(hDC, (int)point->x, (int)point->y, NULL);
	LineTo(hDC, (int)point->x, (int)point->y );
}



// customized from GamePaint_009
//
//
//
//
void GamePaint_011(HDC hDC, vLine* line ) {

	int scale_2 = 30;
	static RECT rect_2, rect;

	printf("GamePaint_011: 000\r\n");

	MoveToEx(hDC, (int)line->p1->x, (int)line->p1->y, NULL);
	LineTo(hDC, (int)(line->p2)->x, (int)(line->p2)->y );
	printf("GamePaint_011: 001\r\n");

	line->print();

	if ( line->c1 != nullptr ) {
		SetRect( &rect, (int)line->p1->x - scale_2, (int)line->p1->y - scale_2, (int)line->p1->x + scale_2, (int)line->p1->y + scale_2 );
		DrawText( hDC, TEXT( line->c1 ), -1, &rect, DT_NOCLIP );
	}
	printf("GamePaint_011: 002\r\n");

	if ( line->c2 != nullptr ) {
		SetRect( &rect_2, (int)line->p2->x - scale_2, (int)line->p2->y - scale_2, (int)line->p2->x + scale_2, (int)line->p2->y + scale_2 );
		DrawText( hDC, TEXT( line->c2 ), -1, &rect_2, DT_NOCLIP );
	}
	printf("GamePaint_011: 003\r\n");

	return;
}


// Very Thanks to: http://wisdom.sakura.ne.jp/system/winapi/win32/win29.html
//		SelectObject(hdc , CreateSolidBrush(0xFF));
//		SetPolyFillMode(hdc , imode);
//		Polygon(hdc , po , 8);
//		EndPaint(hwnd , &ps);
//		DeleteObject(SelectObject(hdc , GetStockObject(WHITE_BRUSH)));

// customized from GamePaint_009
//
//
//
//
void GamePaint_012( HDC hDC, POINT* points, int num ) {
	static RECT rect;
	int retval;

	SelectObject( hDC , CreateSolidBrush(0x88));
	retval = SetPolyFillMode( hDC, ALTERNATE);
	retval = Polygon( hDC, points, num);  
	DeleteObject(SelectObject(hDC , GetStockObject(0x88)));

//	Polygon( hDC, points, num );

//	SetRect( &rect, (int)x1, (int)y1, (int)x2, (int)y2 );
//	FillRect(hDC, &rect, (HBRUSH) (COLOR_WINDOW+1));

	return;
}

// customized from GamePaint_009
//
//
//
//
void GamePaint_013( HDC hDC, POINT* points, int num ) {
	static RECT rect;
	int retval;

	SelectObject( hDC , CreateSolidBrush(0x880000));
	retval = SetPolyFillMode( hDC, ALTERNATE);
	retval = Polygon( hDC, points, num);  
	DeleteObject(SelectObject(hDC , GetStockObject(0x880000)));

//	Polygon( hDC, points, num );

//	SetRect( &rect, (int)x1, (int)y1, (int)x2, (int)y2 );
//	FillRect(hDC, &rect, (HBRUSH) (COLOR_WINDOW+1));

	return;
}

