#ifndef _V_DISPLAY_cONTROLLER_H_
#define _V_DISPLAY_cONTROLLER_H_



class vDisplayController {

	private:
		vLine** lines = nullptr;
		vLine** lines_2D = nullptr;
		vAxex_2D AXEX_2D_002[30];
		vAxex_2D** AXEX_2D_001 = nullptr;
		vLine** Line_AXEX = nullptr;
		vCalculation Calc;
		vScreen* screen_001;

	public:
		void Set_Lines (vLine** l );
		void Set_Lines_2D (vLine** l );
		int Approach_vAxex_2D( vPoint* ap ) ;

} ;

#endif

