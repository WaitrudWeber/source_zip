#ifndef _CONTROL_IMG_LAYER_000_
#define _CONTROL_IMG_LAYER_000_
//...
extern int control_img_layer_000 ();
extern int set_control_img_layer_000 (int ii, int jj, char* word);
extern int initialize_control_img_layer_000 (int ii, int jj, char* word);
#endif
