#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "print_mouse_move_005.h"
// https://www.ibm.com/docs/ja/i/7.1?topic=ssw_ibm_i_71/rtref/strcat.html

int print_mouse_005() ;

int print_mouse_005() {
	FILE *fp;
	int screen_height = 480;
	int screen_width = 640;
	int border_pixel = 1;
	double width = (1.0 / 79.5 ) * 79.5 * 79.5;
	double height = ( 1.0 / 79.5 ) * 79.5 * 79.5;
	double x = 5.0;
	double y = 5.0;
	int i = 0;
	char* tab_index = "		";

	fp = (FILE*) fopen(".\\001-graph-006-001-01\.txt", "wb");
	while ( y < screen_height && i < 10 ) {
		printf("%sSetRect( &rect_xy_head[%d], %d,%d,%d,%d);\r\n", tab_index, i, (int)x, (int)y, (int)x + width, (int)y + height );
		if ( x > screen_width ) {
			y += height;
			x = 5.0;
		} else {
			x += ( width + border_pixel );
		}
		i++;
	}

	fclose(fp);

	return 0;
}

