#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// https://www.ibm.com/docs/ja/i/7.1?topic=ssw_ibm_i_71/rtref/strcat.html

int print_header_file_011 () ;
extern const char *byte_to_binary_011( int x );

char* filename;
char* define_block;
char* function_block;
char* function_block_01;
char* function_block_02;

char* logfilename;

char* includion_block;
char* includion_block_01;

char* makefile_block;
char* sourcefile_block;
char* code_block;
char* code_block_01;
char* code_block_02;

int set_logfilename_block_011 (char* lfunction) ;

int set_includion_block_011 (char* lfunction) ;
int set_includion_block_011_01 (char* lfunction) ;

int set_filename_move_011 (char* lfilename) ;
int set_define_block_011 (char* ldefine) ;
int set_function_block_011 (char* lfunction) ;
int set_function_block_011_01 (char* lfunction) ;
int set_function_block_011_02 (char* lfunction) ;

int set_code_block_011 (char* lcode) ;
int set_makefile_block_011 (char* lmakefile) ;
int set_source_file_011 (char* lsourcefile) ;

int print_makefile_011 ( char** function_name, int num ) ;
int print_makefile_011_a ( char** function_name, int num ) ;
int print_makefile_011_b ( char** function_name, int num ) ;
int print_makefile_011_c ( char* function_name ) ;
int print_source_file_011 () ;

int set_logfilename_block_011 (char* lfunction) {
	printf("int set_logfilename_block_011 (char* lfunction) starts.\r\n");
	logfilename = lfunction;
	printf("int set_logfilename_block_011 (char* lfunction) ends.\r\n");
	return 0;
}


int set_includion_block_011_01 (char* lfunction) {
	printf("int set_includion_block_011_01 (char* lfunction) starts.\r\n");
	includion_block_01 = (char*)lfunction;
	printf("int set_includion_block_011_01 (char* lfunction) ends.\r\n");
	return 0;
}

int set_includion_block_011 (char* lfunction) {
	printf("int set_includion_block_011 (char* lfunction) starts.\r\n");
	includion_block = (char*)lfunction;
	printf("int set_includion_block_011 (char* lfunction) ends.\r\n");
	return 0;
}


int set_source_file_011 (char* lsourcefile) {
	printf("int set_source_file_011 (char* lfilename) starts.\r\n");

	sourcefile_block = (char*)lsourcefile;
	printf("sourcefile_block %s\r\n", sourcefile_block);
	printf("int set_source_file_011 (char* lfilename) ends.\r\n");
	return 0;
}

int print_source_file_011 () {
	FILE *fp;

	printf("print_source_file_011 () starts.\r\n");
	printf("%s\r\n", function_block);
	printf("%s\r\n", sourcefile_block);

	fp = (FILE*) fopen( sourcefile_block, "wb");

	fprintf(fp, "%s\r\n", includion_block);
	fprintf(fp, "%s\r\n", includion_block_01);
	fprintf(fp, "%s\r\n", logfilename);
	fprintf(fp, "%s\r\n", function_block);
	fprintf(fp, "%s\r\n", function_block_01);
	fprintf(fp, "%s\r\n\r\n", function_block_02);
	fprintf(fp, "%s\r\n\r\n", code_block);
	fprintf(fp, "%s\r\n\r\n", code_block_01);
	fprintf(fp, "%s\r\n\r\n", code_block_02);

	fclose(fp);

	printf("print_source_file_011 () ends.\r\n");
	return 0;
}

int set_filename_move_011 (char* lfilename) {
	printf("int set_filename_move_011 (char* lfilename) starts.\r\n");

	filename = (char*)lfilename;

	printf("filename %s\r\n", filename);
	printf("int set_filename_move_011 (char* lfilename) ends.\r\n");
	return 0;
}

int set_define_block_011 (char* ldefine) {
	printf("int set_define_block_011 (char* ldefine) starts.\r\n");

	define_block = (char*)ldefine;

	printf("ldefine %s\r\n", ldefine);
	printf("int set_define_block_011 (char* ldefine) ends.\r\n");
	return 0;
}

int set_code_block_011 (char* lcode) {
	printf("int set_code_block_011 (char* lcode) starts.\r\n");

	code_block = (char*)lcode;

	printf("function_block %s\r\n", lcode);
	printf("int set_code_block_011 (char* lcode) ends.\r\n");
	return 0;
}

int set_code_block_011_01 (char* lcode) {
	printf("int set_code_block_011_01 (char* lcode) starts.\r\n");

	code_block_01 = (char*)lcode;

	printf("function_block %s\r\n", lcode);
	printf("int set_code_block_011_01 (char* lcode) ends.\r\n");
	return 0;
}

int set_code_block_011_02 (char* lcode) {
	printf("int set_code_block_011_02 (char* lcode) starts.\r\n");

	code_block_02 = (char*)lcode;

	printf("function_block %s\r\n", lcode);
	printf("int set_code_block_011_02 (char* lcode) ends.\r\n");
	return 0;
}


int set_function_block_011 (char* lfunction) {
	printf("int set_define_block_011 (char* lfunction) starts.\r\n");

	function_block = (char*)lfunction;

	printf("function_block %s\r\n", lfunction);
	printf("int set_define_block_011 (char* lfunction) ends.\r\n");
	return 0;
}

int set_function_block_011_01 (char* lfunction) {
	printf("int set_function_block_011_01 (char* lfunction) starts.\r\n");

	function_block_01 = (char*)lfunction;

	printf("function_block_01 %s\r\n", function_block_01);
	printf("int set_function_block_011_01 (char* lfunction) ends.\r\n");
	return 0;
}
int set_function_block_011_02 (char* lfunction) {
	printf("int set_function_block_011_02 (char* lfunction) starts.\r\n");

	function_block_02 = (char*)lfunction;

	printf("function_block_02 %s\r\n", function_block_02);
	printf("int set_function_block_011_02 (char* lfunction) ends.\r\n");
	return 0;
}

//
int set_makefile_block_011 (char* lmakefile) {
	printf("int set_makefile_block_011 (char* lmakefile) starts.\r\n");

	makefile_block = (char*)lmakefile;

	printf("lmakefile %s\r\n", lmakefile);
	printf("int set_makefile_block_011 (char* lmakefile) ends.\r\n");
	return 0;
}


//
// int print_makefile_011 ( char** function_name, int num ) ;
int print_makefile_011 ( char** function_name, int num ) {
	int i;
	FILE* fp;

	printf("int print_makefile_011 ( char** function_name, int num ) starts.\r\n");

	fp = (FILE*) fopen( filename, "wb");

	printf ( "#... |%p| num%d\r\n", function_name, num );
	fprintf ( fp, "#... |%p| num%d\r\n", function_name, num );
	for ( i = 0; i<num; i++ ) {
		printf(  "%d %s \r\n", i, function_name[i] );
		fprintf( fp, "%s ", function_name[i] );
	}

	fclose (fp);
	printf("int print_makefile_011 ( char** function_name, int num ) ends.\r\n");
	return 1;
}

int print_makefile_011_a ( char** function_name, int num ) {
	int i;
	printf("int print_makefile_011_a ( char** function_name, int num ) starts.\r\n");
	printf ( "#... |%p| num %d\r\n", (char**)function_name, num );
	for ( i = 0; i < num; i++ ) {
		printf("i %3d |%p| %s\r\n", i, function_name[i], function_name[i] );
	}

	printf("int print_makefile_011_a ( char** function_name, int num ) ends.\r\n");
	return 0;
}

int print_makefile_011_b ( char** function_name, int num ) {
	int i;
	printf("int print_makefile_011_b ( char** function_name, int num ) starts.\r\n");
	printf ( "#... |%p| num %d\r\n", (char**)function_name, num );
	for ( i = 0; i < num; i++ ) {
		printf("i %3d |%p| |%p| |%p| |%s|\r\n", i, function_name, &function_name[0], &function_name[i], &function_name[i] );
	}
	printf("int print_makefile_011_b ( char** function_name, int num ) ends.\r\n");
	return 0;
}

// int print_makefile_011_c ( char** function_name ) ;
int print_makefile_011_c ( char* function_name ) {
	static int start = 0;
	FILE *fp;

	printf("int print_makefile_011_c ( char* function_name ) starts.\r\n");

	if (start == 0) {
		fp = (FILE*) fopen( makefile_block, "wb");
		start++;
	} else {
		fp = (FILE*) fopen( makefile_block, "ab");
	}

	fprintf( fp, " %s", function_name );

	fclose(fp);
	printf("int print_makefile_011_c ( char* function_name ) ends.\r\n");
	return 0;
}


//
int print_header_file_011 () {
	int i, a;
	FILE* fp;

	printf("int print_header_file_011 () starts.\r\n");

	fp = (FILE*) fopen( filename, "wb");

	fprintf ( fp, "#ifndef %s\r\n", define_block );
	fprintf ( fp, "#define %s\r\n", define_block );

	fprintf ( fp, "//...\r\n" );

	printf ( "function_block %s\r\n", function_block );
	printf ( "function_block_01 %s\r\n", function_block_01 );
	printf ( "function_block_02 %s\r\n", function_block_02 );
	fprintf ( fp, "extern %s\r\n", function_block );
	fprintf ( fp, "extern %s\r\n", function_block_01 );
	fprintf ( fp, "extern %s\r\n", function_block_02 );

	fprintf ( fp, "#endif\r\n" );
	fclose (fp);

	printf("int print_header_file_011 () ends.\r\n");
//	exit(-1);

	return 0;
}

// https://stackoverflow.com/questions/111928/is-there-a-printf-converter-to-print-in-binary-format
const char *byte_to_binary_011
(
    int x
)
{
    static char b[33];
    b[0] = '\0';

    unsigned int z;
    unsigned long z_start;
    z_start = 256*256*256*128;

//    printf("z_start %d\r\n", z_start);

    for (z = 256*256*256*128; z > 0; z >>= 1)
    {
//   	printf("x %d z %d\r\n", x, z );
        strcat(b, ((x & z) == z) ? "1" : "0");
    }

	printf("b%s\r\n", b);
    return b;
}


