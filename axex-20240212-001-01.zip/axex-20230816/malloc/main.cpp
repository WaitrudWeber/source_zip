#include <stdio.h>
#include <stdlib.h>

#include "malloc_001.h"


int main (char** argv, int argc) {
	int a;
	char ***str_a = NULL;

	str_a = mallocation_001_02 ( 100, 100 ) ;

	return 0;
}

