#ifndef _CONTROL_IMAGE_LAYER_010_
#define _CONTROL_IMAGE_LAYER_010_
//...
extern int putthegray_010 ( int ii, int jj, char* word ) ;
extern int putthegray_010_01 ( int ii, int jj, char* word ) ;
extern int Set_lot_001_Control_Image_Layer_001 (Logging* logg) ;
extern int Caribration_Control_Image_Layer_001 () ;

#endif
