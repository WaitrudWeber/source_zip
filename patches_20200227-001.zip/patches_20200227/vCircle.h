#ifndef _VCIRCLE_
#define _VCIRCLE_

class vCircle {

public:
	vPoint** pixels = nullptr;
	int max_pixel = 5;
	int index_pixel = 0;

private:
	float R = 0.0;
	vPoint* Center = nullptr;

public:
	void calculation ( vPoint setup, vPoint right_x );
	void set_center( vPoint* set_c );
	void set_R( float r );
	vLine** getLines() ;
	void calculation_local_axis( vPoint set_up, vPoint right_x, vPoint *local_x_axis,  vPoint *local_y_axis, vPoint *local_z_axis) ;

private:

};

#endif

