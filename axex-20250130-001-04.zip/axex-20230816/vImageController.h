#ifndef _VIMANGECONTROLLER_
#define _VIMANGECONTROLLER_

typedef struct rgbt_val {
	unsigned char r;
	unsigned char g;
	unsigned char b;
	unsigned char t;
} RGBT_VAL;

//
typedef struct image_canvas {
	int width;
	int height;
	int layer_num;
	int width_index;
	int height_index;
	int layer_num_index;
	int width_max = 8;
	int height_max = 8;
	int layer_num_max = 8;
	RGBT_VAL*** img = NULL;
} IMG_CANVAS;


class vImangeController {

	public:

	private:
		IMG_CANVAS* img_canvas = NULL;

	public:
		int Initialize ();
		int Reallocation () ;
		int Reallocation_001 () ;
		int Reallocation_002 () ;
		int Reallocation_003 ( int layer_num ) ;

	private:

};

#endif
