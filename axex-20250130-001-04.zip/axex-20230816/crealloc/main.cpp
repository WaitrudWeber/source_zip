#include <stdio.h>
#include <stdlib.h>

#include "realloc_001.h"


int main (char** argv, int argc) {
	int a;
	char **str_a = NULL;

	a = reallocation_001_02_loop_1000 ( str_a, 14) ;


	return 0;
}

