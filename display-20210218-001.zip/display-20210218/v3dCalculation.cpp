#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
//#include "aToken.h"
//#include "wC_structure.h"
//#include "analyzer_C.h"

//#include "wTextarea.h"
//#include "clipboard.h"
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
//#include "vBox.h"

#include "vCalculation.h"
#include "vCurveCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
//#include "vLine.h"
//#include "vCircle.h"

#include "vPointStructure.h"
#include "vPointLinear.h"
//#include "vRailCurtain.h"

#include "display_threeD.h"

#include "v3dCalculation.h"

vCalculation calc;

// void vCalculation::Print_Point_Memories () {
//
int v3dCalculation::calculation_thread () {
	printf("v3dCalculation:: calculation_threed () starts.\r\n");
/*	calc.Print_Point_Memories ();

	display_threeD_screen_initialize_OnRails () ;

	calc.Print_Point_Memories (); */
	printf("v3dCalculation:: calculation_threed () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_002 () {
/*	printf("v3dCalculation:: calculation_thread_002 () starts.\r\n");
	calc.Print_Point_Memories ();

	rails_initialization () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_002 () ends.\r\n"); */
	return 1;
}

int v3dCalculation::calculation_thread_003 () {
	printf("v3dCalculation:: calculation_thread_003 () starts.\r\n");
/*	calc.Print_Point_Memories ();

	memorizevpoint_tests () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_003 () ends.\r\n");*/
	return 1;
}

int v3dCalculation::calculation_thread_004 () {
	printf("v3dCalculation:: calculation_thread_004 () starts.\r\n");
	calc.Print_Point_Memories ();

	curve_initialization () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_004 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_005 () {
	printf("v3dCalculation:: calculation_thread_005 () starts.\r\n");
/*	calc.Print_Point_Memories ();

	subtract_loop ();

	calc.Print_Point_Memories ();*/
	printf("v3dCalculation:: calculation_thread_005 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_006 () {
	printf("v3dCalculation:: calculation_thread_006 () starts.\r\n");
/*	calc.Print_Point_Memories ();

	memorize_print ();

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_006 () ends.\r\n");*/
	return 1;
}

int v3dCalculation::calculation_thread_007 () {
	printf("v3dCalculation:: calculation_thread_007 () starts.\r\n");
/*	calc.Print_Point_Memories ();

	add_loop ();

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_007 () ends.\r\n");*/
	return 1;
}

int v3dCalculation::calculation_thread_008() {
	printf("v3dCalculation:: calculation_thread_008 () starts.\r\n");
/*	calc.Print_Point_Memories();

	// Recognision: 20200508: inside display_threeD_screen_initialize_OnRails:
	//rails_initialization(); inside display_threeD_screen_initialize_OnRails:
	int a001 = display_threeD_screen_initialize_OnRails();

	calc.Print_Point_Memories();
	printf("v3dCalculation:: calculation_thread_008 () ends.\r\n");
	*/
	return 1;
}

int v3dCalculation::calculation_thread_009() {
	printf("v3dCalculation:: calculation_thread_009 () starts.\r\n");
	/*calc.Print_Point_Memories();

	// Recognision: 20200508: inside display_threeD_screen_initialize_OnRails:
	//rails_initialization(); inside display_threeD_screen_initialize_OnRails:
	int a001 = display_threeD_screen_initialize_OnRails();
	int a002 = getCreatedLines();

	calc.Print_Point_Memories();
	printf("v3dCalculation:: calculation_thread_009 () ends.\r\n");
	*/
	return 1;
}

int v3dCalculation::calculation_thread_010() {
	printf("v3dCalculation:: calculation_thread_010 () starts.\r\n");
/*	HWND hWnd;
	HDC hDC;
	PAINTSTRUCT* ps = nullptr;
	hWnd = 0;
	hDC = 0;

	calc.Print_Point_Memories();

	// Recognision: 20200508: inside display_threeD_screen_initialize_OnRails:
	//rails_initialization(); inside display_threeD_screen_initialize_OnRails:
	int a001 = display_threeD_screen_initialize_OnRails();
	int a002 = dDisplayControls_wmpaint_display_threeD_proc( hWnd, hDC, ps, 0, 0, 0 );
	//	int a002 = dDisplayControls_wmpaint_display_threeD_proc(HWND hWnd, HDC hDC, PAINTSTRUCT * ps, UINT uMsg, WPARAM wParam, LPARAM lParam);

	calc.Print_Point_Memories();
	printf("v3dCalculation:: calculation_thread_010 () ends.\r\n");
*/	return 1;
}

