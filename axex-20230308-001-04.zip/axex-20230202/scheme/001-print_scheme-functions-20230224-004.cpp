		button1.setButton( 10 , 10 , 100 , 80 );

		button2.setButton( 110 , 10 , 100 , 80 );

		button3.setButton( 210 , 10 , 100 , 80 );

		button4.setButton( 310 , 10 , 100 , 80 );

		button5.setButton( 410 , 10 , 100 , 80 );

		button6.setButton( 510 , 10 , 100 , 80 );

		button7.setButton( 610 , 10 , 100 , 80 );

		button8.setButton( 10 , 90 , 100 , 80 );

		button9.setButton( 110 , 90 , 100 , 80 );

		button10.setButton( 210 , 90 , 100 , 80 );

		button11.setButton( 310 , 90 , 100 , 80 );

		button12.setButton( 410 , 90 , 100 , 80 );

		button13.setButton( 510 , 90 , 100 , 80 );

		button14.setButton( 610 , 90 , 100 , 80 );

		button15.setButton( 10 , 170 , 100 , 80 );

		button16.setButton( 110 , 170 , 100 , 80 );

		button17.setButton( 210 , 170 , 100 , 80 );

		button18.setButton( 310 , 170 , 100 , 80 );

		button19.setButton( 410 , 170 , 100 , 80 );

		button20.setButton( 510 , 170 , 100 , 80 );

		button21.setButton( 610 , 170 , 100 , 80 );

		button22.setButton( 10 , 250 , 100 , 80 );

		button23.setButton( 110 , 250 , 100 , 80 );

		button24.setButton( 210 , 250 , 100 , 80 );

		button25.setButton( 310 , 250 , 100 , 80 );

		button26.setButton( 410 , 250 , 100 , 80 );

		button27.setButton( 510 , 250 , 100 , 80 );

		button28.setButton( 610 , 250 , 100 , 80 );

		button29.setButton( 10 , 330 , 100 , 80 );

		button30.setButton( 110 , 330 , 100 , 80 );

		button31.setButton( 210 , 330 , 100 , 80 );

		button32.setButton( 310 , 330 , 100 , 80 );

		button33.setButton( 410 , 330 , 100 , 80 );

		button34.setButton( 510 , 330 , 100 , 80 );

		button35.setButton( 610 , 330 , 100 , 80 );

		button36.setButton( 10 , 410 , 100 , 80 );

		button37.setButton( 110 , 410 , 100 , 80 );

		button38.setButton( 210 , 410 , 100 , 80 );

		button39.setButton( 310 , 410 , 100 , 80 );

		button40.setButton( 410 , 410 , 100 , 80 );

		button41.setButton( 510 , 410 , 100 , 80 );

		button42.setButton( 610 , 410 , 100 , 80 );

// 42, 6 

