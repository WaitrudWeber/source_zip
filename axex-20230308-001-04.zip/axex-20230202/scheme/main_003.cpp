#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Very thanks to:
// https://bytes.com/topic/c/answers/818961-frand#:~:text=There%20is%20no%20standard%20C%20function%20called%20%22frand%22.,a%20bug%20report.%20anyway.%20%22We%20must%20do%20something.
// https://bytes.com/topic/c/answers/818961-frand
// https://stackoverflow.com/questions/13408990/how-to-generate-random-float-number-in-c
// https://codingpointer.com/c-tutorial/generate-random-float-number
//
int main () {

	int i;

	i=1;
	while ( i <4 ) {

		printf("	vPoint* right_%03d = Calc.cross( depth_%03d, up_%03d );\r\n", i, i, i -1);
		printf("	vPoint* up_%03d = Calc.cross( right_%03d, depth_%03d );\r\n", i, i, i);
		printf("	Calc.normal( up_%03d );\r\n", i );
		printf("	Calc.normal( depth_%03d );\r\n", i );
		printf("	Calc.normal( right_%03d );\r\n", i );

		printf("	this->SetRight ( right_%03d->x, right_%03d->y, right_%03d->z );\r\n", i, i, i);
		printf("	this->SetUp ( up_%03d->x, up_%03d->y, up_%03d->z );\r\n", i, i, i);
		printf("	this->SetDepth ( depth_%03d->x, depth_%03d->y, depth_%03d->z );\r\n", i, i, i);

		i++;
		printf("\r\n");
	}

	i=1;
	printf("	free_point (up_%03d);\r\n", i - 1);
	while ( i <4 ) {
		printf("	free_point (up_%03d);\r\n", i );
		printf("	free_point (right_%03d);\r\n", i );
		printf("	free_point (depth_%03d);\r\n", i );
		i++;
		printf("\r\n");
	}


	i=1;
	while ( i <4 ) {
		printf("	x -=  whith/2.0f;\r\n");
		printf("	y -=  whith/2.0f;\r\n");

		printf("	vPoint* right_%03d = Calc.scalize ( right_%03d, (double)x ):\r\n", i, i -1);
		printf("	vPoint* up_%03d = Calc.scalize ( up_%03d, (double)y ):\r\n", i, i - 1 );


		i++;
		printf("\r\n");
	}

	i=1;
	while ( i <4 ) {
		printf("	free_point (up_%03d);\r\n", i );
		printf("	free_point (right_%03d);\r\n", i );
		printf("	free_point (depth_%03d);\r\n", i );
		i++;
		printf("\r\n");
	}

	return 0;
}

int main_001 () {

	int i;
	float x, y, r, r_min;

	srand(time(NULL));

	r_min = 10.0f;

	for ( i = 0; i <30; i++ ) {
		x = 640.0f;
		y = 480.0f;
		r = 20.0f;
		x = ((float)rand()/(float)(RAND_MAX)) * x;
		y= ((float)rand()/(float)(RAND_MAX)) * y;
		r= ((float)rand()/(float)(RAND_MAX)) * r;
		printf("	vCircle_2D_001[%d] = new vCircle_2D ( %f\f, %f\f, %f\f );\r\n", i, x, y, r);
	}

	return 0;
}

/*
// https://stackoverflow.com/questions/13408990/how-to-generate-random-float-number-in-c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
    srand((unsigned int)time(NULL));

    float a = 5.0;
    for (int i=0;i<20;i++)
        printf("%f\n", ((float)rand()/(float)(RAND_MAX)) * a);
    return 0;
}
*/
