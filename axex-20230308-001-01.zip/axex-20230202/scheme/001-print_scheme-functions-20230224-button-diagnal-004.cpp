		button1.setButton( 10 , 10 , 100 , 100 );

		button2.setButton( 110 , 110 , 100 , 100 );

		button3.setButton( 210 , 210 , 100 , 100 );

		button4.setButton( 310 , 310 , 100 , 100 );

		button5.setButton( 410 , 410 , 100 , 100 );

		button6.setButton( 510 , 510 , 100 , 100 );

		button7.setButton( 610 , 610 , 100 , 100 );

// diagnal 7 width &d

