	textarea[0]->setTextarea( 10 , 10 , 100 , 80 );

	textarea[1]->setTextarea( 110 , 10 , 100 , 80 );

	textarea[2]->setTextarea( 210 , 10 , 100 , 80 );

	textarea[3]->setTextarea( 310 , 10 , 100 , 80 );

	textarea[4]->setTextarea( 410 , 10 , 100 , 80 );

	textarea[5]->setTextarea( 510 , 10 , 100 , 80 );

	textarea[6]->setTextarea( 610 , 10 , 100 , 80 );

	textarea[7]->setTextarea( 10 , 90 , 100 , 80 );

	textarea[8]->setTextarea( 110 , 90 , 100 , 80 );

	textarea[9]->setTextarea( 210 , 90 , 100 , 80 );

	textarea[10]->setTextarea( 310 , 90 , 100 , 80 );

	textarea[11]->setTextarea( 410 , 90 , 100 , 80 );

	textarea[12]->setTextarea( 510 , 90 , 100 , 80 );

	textarea[13]->setTextarea( 610 , 90 , 100 , 80 );

	textarea[14]->setTextarea( 10 , 170 , 100 , 80 );

	textarea[15]->setTextarea( 110 , 170 , 100 , 80 );

	textarea[16]->setTextarea( 210 , 170 , 100 , 80 );

	textarea[17]->setTextarea( 310 , 170 , 100 , 80 );

	textarea[18]->setTextarea( 410 , 170 , 100 , 80 );

	textarea[19]->setTextarea( 510 , 170 , 100 , 80 );

	textarea[20]->setTextarea( 610 , 170 , 100 , 80 );

	textarea[21]->setTextarea( 10 , 250 , 100 , 80 );

	textarea[22]->setTextarea( 110 , 250 , 100 , 80 );

	textarea[23]->setTextarea( 210 , 250 , 100 , 80 );

	textarea[24]->setTextarea( 310 , 250 , 100 , 80 );

	textarea[25]->setTextarea( 410 , 250 , 100 , 80 );

	textarea[26]->setTextarea( 510 , 250 , 100 , 80 );

	textarea[27]->setTextarea( 610 , 250 , 100 , 80 );

	textarea[28]->setTextarea( 10 , 330 , 100 , 80 );

	textarea[29]->setTextarea( 110 , 330 , 100 , 80 );

	textarea[30]->setTextarea( 210 , 330 , 100 , 80 );

	textarea[31]->setTextarea( 310 , 330 , 100 , 80 );

	textarea[32]->setTextarea( 410 , 330 , 100 , 80 );

	textarea[33]->setTextarea( 510 , 330 , 100 , 80 );

	textarea[34]->setTextarea( 610 , 330 , 100 , 80 );

	textarea[35]->setTextarea( 10 , 410 , 100 , 80 );

	textarea[36]->setTextarea( 110 , 410 , 100 , 80 );

	textarea[37]->setTextarea( 210 , 410 , 100 , 80 );

	textarea[38]->setTextarea( 310 , 410 , 100 , 80 );

	textarea[39]->setTextarea( 410 , 410 , 100 , 80 );

	textarea[40]->setTextarea( 510 , 410 , 100 , 80 );

	textarea[41]->setTextarea( 610 , 410 , 100 , 80 );

// 42, 0 

	textarea[0] = new wTextarea ();
	textarea[1] = new wTextarea ();
	textarea[2] = new wTextarea ();
	textarea[3] = new wTextarea ();
	textarea[4] = new wTextarea ();
	textarea[5] = new wTextarea ();
	textarea[6] = new wTextarea ();
	textarea[7] = new wTextarea ();
	textarea[8] = new wTextarea ();
	textarea[9] = new wTextarea ();
	textarea[10] = new wTextarea ();
	textarea[11] = new wTextarea ();
	textarea[12] = new wTextarea ();
	textarea[13] = new wTextarea ();
	textarea[14] = new wTextarea ();
	textarea[15] = new wTextarea ();
	textarea[16] = new wTextarea ();
	textarea[17] = new wTextarea ();
	textarea[18] = new wTextarea ();
	textarea[19] = new wTextarea ();
	textarea[20] = new wTextarea ();
	textarea[21] = new wTextarea ();
	textarea[22] = new wTextarea ();
	textarea[23] = new wTextarea ();
	textarea[24] = new wTextarea ();
	textarea[25] = new wTextarea ();
	textarea[26] = new wTextarea ();
	textarea[27] = new wTextarea ();
	textarea[28] = new wTextarea ();
	textarea[29] = new wTextarea ();
	textarea[30] = new wTextarea ();
	textarea[31] = new wTextarea ();
	textarea[32] = new wTextarea ();
	textarea[33] = new wTextarea ();
	textarea[34] = new wTextarea ();
	textarea[35] = new wTextarea ();
	textarea[36] = new wTextarea ();
	textarea[37] = new wTextarea ();
	textarea[38] = new wTextarea ();
	textarea[39] = new wTextarea ();
	textarea[40] = new wTextarea ();
	textarea[41] = new wTextarea ();
// 42, 0 

