		textarea1.setTextarea( 10 , 10 , 100 , 80 );

		textarea2.setTextarea( 110 , 10 , 100 , 80 );

		textarea3.setTextarea( 210 , 10 , 100 , 80 );

		textarea4.setTextarea( 310 , 10 , 100 , 80 );

		textarea5.setTextarea( 410 , 10 , 100 , 80 );

		textarea6.setTextarea( 510 , 10 , 100 , 80 );

		textarea7.setTextarea( 610 , 10 , 100 , 80 );

		textarea8.setTextarea( 10 , 90 , 100 , 80 );

		textarea9.setTextarea( 110 , 90 , 100 , 80 );

		textarea10.setTextarea( 210 , 90 , 100 , 80 );

		textarea11.setTextarea( 310 , 90 , 100 , 80 );

		textarea12.setTextarea( 410 , 90 , 100 , 80 );

		textarea13.setTextarea( 510 , 90 , 100 , 80 );

		textarea14.setTextarea( 610 , 90 , 100 , 80 );

		textarea15.setTextarea( 10 , 170 , 100 , 80 );

		textarea16.setTextarea( 110 , 170 , 100 , 80 );

		textarea17.setTextarea( 210 , 170 , 100 , 80 );

		textarea18.setTextarea( 310 , 170 , 100 , 80 );

		textarea19.setTextarea( 410 , 170 , 100 , 80 );

		textarea20.setTextarea( 510 , 170 , 100 , 80 );

		textarea21.setTextarea( 610 , 170 , 100 , 80 );

		textarea22.setTextarea( 10 , 250 , 100 , 80 );

		textarea23.setTextarea( 110 , 250 , 100 , 80 );

		textarea24.setTextarea( 210 , 250 , 100 , 80 );

		textarea25.setTextarea( 310 , 250 , 100 , 80 );

		textarea26.setTextarea( 410 , 250 , 100 , 80 );

		textarea27.setTextarea( 510 , 250 , 100 , 80 );

		textarea28.setTextarea( 610 , 250 , 100 , 80 );

		textarea29.setTextarea( 10 , 330 , 100 , 80 );

		textarea30.setTextarea( 110 , 330 , 100 , 80 );

		textarea31.setTextarea( 210 , 330 , 100 , 80 );

		textarea32.setTextarea( 310 , 330 , 100 , 80 );

		textarea33.setTextarea( 410 , 330 , 100 , 80 );

		textarea34.setTextarea( 510 , 330 , 100 , 80 );

		textarea35.setTextarea( 610 , 330 , 100 , 80 );

		textarea36.setTextarea( 10 , 410 , 100 , 80 );

		textarea37.setTextarea( 110 , 410 , 100 , 80 );

		textarea38.setTextarea( 210 , 410 , 100 , 80 );

		textarea39.setTextarea( 310 , 410 , 100 , 80 );

		textarea40.setTextarea( 410 , 410 , 100 , 80 );

		textarea41.setTextarea( 510 , 410 , 100 , 80 );

		textarea42.setTextarea( 610 , 410 , 100 , 80 );

// 42, 0 

		wTextarea	textarea1;
		wTextarea	textarea2;
		wTextarea	textarea3;
		wTextarea	textarea4;
		wTextarea	textarea5;
		wTextarea	textarea6;
		wTextarea	textarea7;
		wTextarea	textarea8;
		wTextarea	textarea9;
		wTextarea	textarea10;
		wTextarea	textarea11;
		wTextarea	textarea12;
		wTextarea	textarea13;
		wTextarea	textarea14;
		wTextarea	textarea15;
		wTextarea	textarea16;
		wTextarea	textarea17;
		wTextarea	textarea18;
		wTextarea	textarea19;
		wTextarea	textarea20;
		wTextarea	textarea21;
		wTextarea	textarea22;
		wTextarea	textarea23;
		wTextarea	textarea24;
		wTextarea	textarea25;
		wTextarea	textarea26;
		wTextarea	textarea27;
		wTextarea	textarea28;
		wTextarea	textarea29;
		wTextarea	textarea30;
		wTextarea	textarea31;
		wTextarea	textarea32;
		wTextarea	textarea33;
		wTextarea	textarea34;
		wTextarea	textarea35;
		wTextarea	textarea36;
		wTextarea	textarea37;
		wTextarea	textarea38;
		wTextarea	textarea39;
		wTextarea	textarea40;
		wTextarea	textarea41;
		wTextarea	textarea42;
// 42, 0 

