#ifndef _WPARAM_SYNSE_001_H_
#define _WPARAM_SYNSE_001_H_

class wParamSynse_001 {

	public:
		wParamSynse_001();

	private:

} ;

#endif
