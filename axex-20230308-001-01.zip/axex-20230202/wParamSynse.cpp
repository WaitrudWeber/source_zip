#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

//


#include "wTextarea.h"
#include "wTextareaController.h"

#include "wParamSynse.h"



wParamSynse::wParamSynse () {
	int a = Initialization ();
	a = Initialization_001 ();
	a = Initialization_002 ();
}

//
int wParamSynse::Initialization () {

	box_param = (wTextarea**)malloc (sizeof(wTextarea*) * box_param_num );
	if ( box_param == NULL ) {
		printf("We cannot allocate box_param and it exits.\r\n");
		exit(-1);
	}

	return 0;
}


int wParamSynse::Initialization_002 () {

	box_param[0]->setTextarea( 10 , 10 , 100 , 80 );

	box_param[1]->setTextarea( 110 , 10 , 100 , 80 );

	box_param[2]->setTextarea( 210 , 10 , 100 , 80 );

	box_param[3]->setTextarea( 310 , 10 , 100 , 80 );

	box_param[4]->setTextarea( 410 , 10 , 100 , 80 );

	box_param[5]->setTextarea( 510 , 10 , 100 , 80 );

	box_param[6]->setTextarea( 610 , 10 , 100 , 80 );

	box_param[7]->setTextarea( 10 , 90 , 100 , 80 );

	box_param[8]->setTextarea( 110 , 90 , 100 , 80 );

	box_param[9]->setTextarea( 210 , 90 , 100 , 80 );

	box_param[10]->setTextarea( 310 , 90 , 100 , 80 );

	box_param[11]->setTextarea( 410 , 90 , 100 , 80 );

	box_param[12]->setTextarea( 510 , 90 , 100 , 80 );

	box_param[13]->setTextarea( 610 , 90 , 100 , 80 );

	box_param[14]->setTextarea( 10 , 170 , 100 , 80 );

	box_param[15]->setTextarea( 110 , 170 , 100 , 80 );

	box_param[16]->setTextarea( 210 , 170 , 100 , 80 );

	box_param[17]->setTextarea( 310 , 170 , 100 , 80 );

	box_param[18]->setTextarea( 410 , 170 , 100 , 80 );

	box_param[19]->setTextarea( 510 , 170 , 100 , 80 );

	box_param[20]->setTextarea( 610 , 170 , 100 , 80 );

	box_param[21]->setTextarea( 10 , 250 , 100 , 80 );

	box_param[22]->setTextarea( 110 , 250 , 100 , 80 );

	box_param[23]->setTextarea( 210 , 250 , 100 , 80 );

	box_param[24]->setTextarea( 310 , 250 , 100 , 80 );

	box_param[25]->setTextarea( 410 , 250 , 100 , 80 );

	box_param[26]->setTextarea( 510 , 250 , 100 , 80 );

	box_param[27]->setTextarea( 610 , 250 , 100 , 80 );

	box_param[28]->setTextarea( 10 , 330 , 100 , 80 );

	box_param[29]->setTextarea( 110 , 330 , 100 , 80 );

	box_param[30]->setTextarea( 210 , 330 , 100 , 80 );

	box_param[31]->setTextarea( 310 , 330 , 100 , 80 );

	box_param[32]->setTextarea( 410 , 330 , 100 , 80 );

	box_param[33]->setTextarea( 510 , 330 , 100 , 80 );

	box_param[34]->setTextarea( 610 , 330 , 100 , 80 );

	box_param[35]->setTextarea( 10 , 410 , 100 , 80 );

	box_param[36]->setTextarea( 110 , 410 , 100 , 80 );

	box_param[37]->setTextarea( 210 , 410 , 100 , 80 );

	box_param[38]->setTextarea( 310 , 410 , 100 , 80 );

	box_param[39]->setTextarea( 410 , 410 , 100 , 80 );

	box_param[40]->setTextarea( 510 , 410 , 100 , 80 );

	box_param[41]->setTextarea( 610 , 410 , 100 , 80 );

	return 0;
}

//
int wParamSynse::Initialization_001 () {

	box_param[0] = new wTextarea ();
	box_param[1] = new wTextarea ();
	box_param[2] = new wTextarea ();
	box_param[3] = new wTextarea ();
	box_param[4] = new wTextarea ();
	box_param[5] = new wTextarea ();
	box_param[6] = new wTextarea ();
	box_param[7] = new wTextarea ();
	box_param[8] = new wTextarea ();
	box_param[9] = new wTextarea ();
	box_param[10] = new wTextarea ();
	box_param[11] = new wTextarea ();
	box_param[12] = new wTextarea ();
	box_param[13] = new wTextarea ();
	box_param[14] = new wTextarea ();
	box_param[15] = new wTextarea ();
	box_param[16] = new wTextarea ();
	box_param[17] = new wTextarea ();
	box_param[18] = new wTextarea ();
	box_param[19] = new wTextarea ();
	box_param[20] = new wTextarea ();
	box_param[21] = new wTextarea ();
	box_param[22] = new wTextarea ();
	box_param[23] = new wTextarea ();
	box_param[24] = new wTextarea ();
	box_param[25] = new wTextarea ();
	box_param[26] = new wTextarea ();
	box_param[27] = new wTextarea ();
	box_param[28] = new wTextarea ();
	box_param[29] = new wTextarea ();
	box_param[30] = new wTextarea ();
	box_param[31] = new wTextarea ();
	box_param[32] = new wTextarea ();
	box_param[33] = new wTextarea ();
	box_param[34] = new wTextarea ();
	box_param[35] = new wTextarea ();
	box_param[36] = new wTextarea ();
	box_param[37] = new wTextarea ();
	box_param[38] = new wTextarea ();
	box_param[39] = new wTextarea ();
	box_param[40] = new wTextarea ();
	box_param[41] = new wTextarea ();

	return 0;
}

