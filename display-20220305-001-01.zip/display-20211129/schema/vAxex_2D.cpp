#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"	// ADD: 20200125
#include "sender.h"			// ADD: 20200125
#include "Print.h"			// ADD: 20200125

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vAxex_2D.h"

Axex_2D::Axex_2D ( float xx, float yy, float rr, float d_distance) {
	this->x = xx;
	this->y = yy;
	this->r = rr;
	this->distance = d_distance;
}


int Axex_2D::SetUp ( float xx, float yy, float zz ) {

	if ( up == nullptr ) {
		up = new vPoint ( xx, yy, zz );
	} else {
		up->setPoint ( xx, yy, zz );
	}

	up = new vPoint ( xx, yy, zz );
	Calc.normal(up);

	return 0;
}


int Axex_2D::SetDepth ( float xx, float yy, float zz ) {
	if ( depth == nullptr ) {
		depth = new vPoint ( xx, yy, zz );
	} else {
		depth->setPoint ( xx, yy, zz );
	}
	Calc.normal(depth);

	return 0;
}

int Axex_2D::SetEye ( float xx, float yy, float zz ) {

	// postion
	if (eye_001 == nullptr ) { 
		eye_001 = new vPoint ( xx, yy, zz );
	} else {
		eye_001->setPoint ( xx, yy, zz );
	}

	return 0;
}

int Axex_2D::SetCenter ( float xx, float yy, float zz ) {

	// postion
	if (center == nullptr ) { 
		center = new vPoint ( xx, yy, zz );
	} else {
		center->setPoint ( xx, yy, zz );
	}

	return 0;
}

// Use SetCenter amd SetDepth for memorization.
int Axex_2D::Calculation_Axex ( ) {
	vPoint* arrow = nullptr;
	vPoint* depth_002 = nullptr;

	// 001
	arrow = (vPoint*)Calc.scalize( (vPoint*)depth, (float)distance); // multiple
	vPoint* c_001 = Calc.add( this->eye_001, arrow );
	this->SetCenter ( c_001->x, c_001->y, c_001->z );

	//002 depth
	depth_002 = Calc.subtract ( center, eye_001);
	Calc.normal ( depth_002 );
	this->SetDepth ( depth_002->x, depth_002->y, depth_002->z );

	// 003
	vPoint* pp = Calc.cross ( up, depth );	
	Calc.normal(pp);
	right = Calc.cross ( up, depth );	
	Calc.normal(right);


	free_point(pp);
	free_point(c_001);
	free_point(arrow);
	free_point(depth_002);
	return 0;
}
