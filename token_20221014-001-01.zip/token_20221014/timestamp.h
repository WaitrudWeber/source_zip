#ifndef TIMESTAMP_H
#define TIMESTAMP_H

extern char* get_datetime_info () ;

#endif
