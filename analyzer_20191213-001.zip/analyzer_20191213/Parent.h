#ifndef _PARENT_H_
#define _PARENT_H_

// Child -> wKickDisplayEventThreeD
// Parent -> wKickEventExe

//Base class 
class wKickEventExe 
{ 
    public: 
      int id_p; 

	public:
		void setId ( int id );

}; 

#endif

