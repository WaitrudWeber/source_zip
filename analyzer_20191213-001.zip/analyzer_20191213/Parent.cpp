#include "Parent.h"

// Child -> wKickDisplayEventThreeD
// Parent -> wKickEventExe

void wKickEventExe::setId (int id ) {
	this->id_p = id;
}
