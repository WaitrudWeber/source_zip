#ifndef _CHILD_H_
#define _CHILD_H_

// Child -> wKickDisplayEventThreeD
// Parent -> wKickEventExe

// Sub class inheriting from Base Class(Parent) 
class wKickEventDisplayThreeD : public wKickEventDisplayExe 
{ 
    public: 
      int id_c; 

	private:
		int pid;

	public:
		void setPid ( int id ) ;
};

#endif
