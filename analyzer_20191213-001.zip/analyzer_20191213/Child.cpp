#include "Parent.h"
#include "Child.h"

// Child -> // Child -> wKickEventDisplayThreeD
// Parent -> wKickEventExe

void wKickEventDisplayThreeD::setPid ( int id ) {
	this->pid =id;
}