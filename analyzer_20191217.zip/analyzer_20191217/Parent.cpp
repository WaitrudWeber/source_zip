#include "Parent.h"

void Parent::setId (int id ) {
	this->id_p = id;
}