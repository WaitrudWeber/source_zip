#ifndef _VMODEL_
#define _VMODEL_

class vModel {

	public :
		vTriangle* m_triangle = nullptr;
		int triangleMumber = 0;

	public :
		getTriangleNumber();

};

vModel* model = nullptr;

#endif


