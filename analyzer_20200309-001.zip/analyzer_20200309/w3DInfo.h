#ifndef _W3DINFO_H_
#define _W3DINFO_H_

class w3DInfo {

	public:
		vPoint* Ray = nullptr;

	private:
		vLine** stack_lines = nullptr;
		int num_stack_lines = 0;
		int max_stack_lines = 8;

	public:
		void SetRay( vPoint* ray ) ;
		void PutLine( vLine* line ) ;
		vLine* GetLine( vLine* line ) ;

	private:

};

#endif

