#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "array_counter.h"
#include "wTextarea.h"
#include "clipboard.h"
#include "Print.h"	//ADD: 20191228

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
//#include "vLine.h"
#include "vCircle.h"

#include "vPointStructure.h"
#include "vPointLinear.h"
#include "display_threeD.h"

#include "wKickEvent.h"
#include "wKickEventDisplayThreeD.h"
//#include "wKickEventDisplayThreeD.h"

#include "wKickEvent.h"


void wKickEvent::Processor_001 ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	printf("wKickEvent::Processor_001 starts\r\n");

	printf("wKickEvent::Processor_001 ends\r\n");
}

void wKickEvent::setId (int id ) {
	this->id_p = id;
}


void wKickEvent::Execute () {
	printf("wKickEvent::Execute starts\r\n");

	printf("wKickEvent::Execute ends\r\n");
}


//
//
//
//
//
void wKickEvent::Prefectured () {
	printf("wKickEvent::Prefectured starts\r\n");
	printf("wKickEvent::Prefectured ends\r\n");
}

//
//
//
//
//
void wKickEvent::PreProcessor () {
	printf("wKickEvent::PreProcessor starts\r\n");
	printf("wKickEvent::PreProcessor ends\r\n");
}

void wKickEvent::Processor () {
	printf("wKickEvent::Processor starts\r\n");
	printf("wKickEvent::Processor ends\r\n");
}


