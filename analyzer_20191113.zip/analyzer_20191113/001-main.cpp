#include "array_counter.h"


int main () {

	return 0;
}

