// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "wButton.h"
#include "wButtonControler.h"

wButtonController::wButtonController () {

	this->mode = 0;
	this->number_button = 0;
	AryButton = nullptr;
}

void wButtonController::addButton ( wButton* b ) {
	if ( this->number_button ==0 || AryButton == nullptr ) {
		AryButton = ( wButton** ) malloc ( sizeof( wButton* ) * 1 );
		this->number_button = 1;
		AryButton[ this->number_button ] = b;
		return;
	}

	this->number_button++;
	AryButton = (wButton **) realloc( AryButton, this->number_button * sizeof(wButton *) );
	AryButton[ this->number_button ] = b;


}

void wButtonController::drawButtons ( HDC hdc ) {

	for ( int i=0; i<this->number_button; i++ ) {
		AryButton[ i ]->drawButton( hdc );
	}

}


// void
