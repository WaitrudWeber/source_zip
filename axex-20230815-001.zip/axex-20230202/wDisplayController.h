#ifndef _W_DISPLAY_cONTROLLER_H_
#define _W_DISPLAY_cONTROLLER_H_



class wDisplayController {

	private:
		vLine** lines = nullptr;
		vLine** lines_2D = nullptr;
		wEvent* p_evt = nullptr;
//		wEvent* event = nullptr;

	public:
		void Set_Lines (vLine** l );
		void Set_Lines_2D (vLine** l );
		int nDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
//		void Set_wEvent (wEvent* ev );

} ;

#endif

