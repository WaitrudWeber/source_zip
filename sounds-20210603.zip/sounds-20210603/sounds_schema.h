#ifndef _SOUNDS_SCHEMA_
#define _SOUNDS_SCHEMA_

extern void sounds_schema ();
extern int itnitialize_sounds() ;

extern int m_mode;
#endif
