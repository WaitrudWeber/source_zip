#ifndef _WORK_004_H_
#define _WORK_004_H_
class WORK_004 { 
	public:
		WORK_005 *iWORK_004=nullptr;

	public:
		SetWORK_005( WORK005 *lWORK005 ); 

};
#endif
