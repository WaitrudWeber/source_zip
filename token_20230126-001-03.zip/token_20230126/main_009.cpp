#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"
#include "replace_main.h"

int replace_main (int argc, char** argv ) ;

/*
	aaa: aaa: b: cc:
*/

int main (int argc, char** argv ) {

	int a = replace_main ( argc, argv);
	return 0;
}

int replace_main (int argc, char** argv ) {
	printf("main starts.\r\n");

//	char* a_001 = (char*)"a$00<><></>$00bbb\r\ncc$01c";
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$00", (char*)"ee" );
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$01", (char*)"ffff" );
//	printf("a_001 |%s|\r\n", a_001);

	if ( argc != 4 ) {
		printf("csv_replace {input-csv-file} {form-html-file} {output-html-file}\r\n");
	}

//	int a = read_csv(".\\001-csv-20210317-001\.txt");
//	int b = replace_csv ( ".\\001-form-20210317-001\.html", ".\\001-html-20210317-001\.txt");

	printf("input-csv: %s form-html-file: %s output-html-file: %s\r\n", argv[1], argv[2], argv[3]);
	sleep(2);

	int a = read_csv( argv[1] );
	int b = replace_csv ( argv[2], argv[3] );

//	char* string_all = read_all ( ".\\001-form-20210317-001\.html" );
//	printf("string_all:%s\r\n", string_all);

	printf("main ends.\r\n");

	return 0;
}
