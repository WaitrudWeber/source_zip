#ifndef _VCALCULATION_
#define _VCALCULATION_


extern void Put_Memories_vPoint ( vPoint* p_006 );
extern void Put_Memories_vLine ( vLine* l_003 );


extern void put_memories( vPoint* dummy_vPoint );
//extern void put_memories_vLine( vLine* dummy_vLine );

extern vPoint* memorizevPoint( float a, float b, float c );
extern void put_points( vPoint* p );
extern void garbage_memories () ;
extern void free_point( vPoint* p);
extern vLine* memorizevLine( vPoint* a, vPoint* b );

extern void print_memories_vLine ( ) ;
extern void print_point_memories ( ) ;



// x the below: 001
//extern static vPoint** dummy_vPoint;
//extern static vPoint* dummy_p;
//extern static vPoint* dummy_pp;
static vPoint** dummy_vPoint = nullptr;
static vPoint* dummy_p = nullptr;
static vPoint* dummy_pp = nullptr;

static vLine** dummy_vLine = nullptr;
static vLine* dummy_vLine_p = nullptr;


class vCalculation {

public:
	vPoint* cross ( vPoint p1, vPoint p2);
	vPoint* cross ( vPoint* p1, vPoint* p2);
	void cross ( vPoint* p1, vPoint* p2, vPoint* p3) ;
	vPoint* normal ( vPoint p1 );
	void normal ( vPoint* p1 );
	void normal ( vPoint* p1, vPoint *p2 );
	vPoint* add ( vPoint p1, vPoint p2);
	vPoint* subtract ( vPoint p1, vPoint p2);
	vPoint* subtract ( vPoint* p1, vPoint* p2) ;
	vPoint* subtract_001 ( vPoint* p1, vPoint* p2);
	int subtract ( vPoint* p1, vPoint* p2, vPoint *p3);
	// 20191114 start
	vPoint* scale ( vPoint* p1, float w_scale, vPoint* result );
	void scale ( vPoint* p1, float w_scale ) ;
	vPoint* scale ( vPoint p1, float w_scale ) ;
	// 20191114 end
	// 20191120 start
	vPoint* scalize ( vPoint* p1, float w_scale);
	// 20191120 end
	double length ( vPoint lp );
	double length ( float x1, float y1, float z1);
	float dot ( vPoint p1, vPoint p2) ;
	vLine** Lines_from_Mesh ( vPoint* points, int** numbering, int num_patches, int base_num_patches) ;
	void add ( vPoint p1, vPoint p2, vPoint* p3 ) ;
	void add ( vPoint* p1, vPoint* p2, vPoint* p3) ;
	double length ( vPoint* lp );
	vPoint* add ( vPoint* p1, vPoint* p2) ;
	void Print_Point_Memories () ;
	void subtract ( vPoint p1, vPoint p2, vPoint *result) ;

private:
	void cross ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	double normal ( float x1, float y1, float z1, float* x2, float* y2, float* z2 );
	void subtract ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	void add ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	void scale ( float x1, float y1, float z1, float scale, float* x3, float* y3, float* z3);
	void dot ( float x1, float y1, float z1, float x2, float y2, float z2, float* dot ) ;
	vLine* put_line( vLine* be_set, vLine* l1) ;
	void Print_Lines ( vLine** array, int num ) ;
	void put_point( vPoint* lp1, vPoint* points_number ) ;




};

#endif
