#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <stdio.h>

#include "array_counter.h"
#include "wEvent.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"



#include "vCalculation.h"
#include "vIntersection.h"




#include "vScreen.h"
#include "vScreenCG.h"
#include "something_word.h"

#include "vPointStructure.h"
#include "vPointLinear.h"

#include "vAxex_2D.h"
#include "creation_of_axex.h"

#include "display_threeD.h"

#include "vDisplayController.h"
#include "wDisplayController.h"

#include "wJavaStructure.h"
#include "wCanvasController.h"

//
//
//
//
wCanvasController::wCanvasController() {
	// 20220321
	Initialize_Axex();
}

//
//
//
//
//void wCanvasController::Print_struct(wJavaStructure top ) {
//
//
//}

//
//
//
//
void wCanvasController::setEvent( wEvent* evt ) {

	this->event = evt;

}

//
//
//
//
void wCanvasController::kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

}

//
//
//
//
void wCanvasController::Process () {

	Processed = 0;
//	switch ( *( this->event->uMsg ) ) {
	switch ( this->event->Type ) {
	case WM_PAINT:
		ProcessWmPaint ();
		Processed = 1;
		break;
	case WM_CHAR:
//		ProcessWmChar ();
		Processed = 1;
	case WM_KEYUP:
		printf("wCanvasController::WM_KEYUP: %d\r\n", WM_KEYUP);
		// Passed at 20190406
		ProcessWmKeyup ();
		Processed = 1;
		ProcessedKeyup = 1;
		break;
	}

}

//
void wCanvasController::Set_Axex_Line( int x1, int y1, int x2, int y2 ) {
	printf("void wCanvasController::Set_Axex_Line( int x1, int y1, int x2, int y2 ) starts.");
	axline[this->AXEX_2D_LINE_Index]->p1->x = x1;
	axline[this->AXEX_2D_LINE_Index]->p1->y = y1;
	axline[this->AXEX_2D_LINE_Index]->p2->x = x2;
	axline[this->AXEX_2D_LINE_Index]->p2->y = y2;
	this->AXEX_2D_LINE_Index++; 
	printf("void wCanvasController::Set_Axex_Line( int x1, int y1, int x2, int y2 ) ends.");
}


void wCanvasController::ProcessWmKeyup () {
	printf("void wCanvasController::ProcessWmKeyup () starts.\r\n");

	if ( this->event->wParam < 999 && this->event->wParam >= 0 )
		this->key_wParam_Keyup = this->event->wParam;
	else {
		printf("void wButtonController::ProcessWmKeyup () ends as skipping.\r\n");
		return;
	}

	int m_mode = this->event->main_mode;
	this->event->wParam_Keyup = this->key_wParam_Keyup;

	//  8 Backspace
	// 17 Ctl
	// 13 Enter
	// 27 ESC
	// 37 LEFT
	// 38 UP
	// 38 RIGHT
	// 40 DOWN
	switch ( this->key_wParam_Keyup ) {
	case 13:
		call_once_key = 1;
		break;
	case 17:
		break;
	case 27:
		//escape_action( m_mode );
		//m_mode = -1; // means f
		// screen.
		call_once_key = 1;
		break;
	case 37:
		printf("case 37\r\n");
		exit(-1);
		break;
	case 38:
//		this->CursolNumber--;
//		this->selectButton( );
		call_once_key = 1;
		break;
	case 39:
		break;
	case 40:
//		this->CursolNumber++;
//		this->selectButton( );
		call_once_key = 1;
		break;
	}

	if ( m_mode == 8 &&  this->key_wParam_Keyup == 65 ) {
		AXEX_2D_002_Index_Selected++;
		if ( AXEX_2D_002_Index_Selected >= AXEX_2D_002_Index ) {  //a
			AXEX_2D_002_Index_Selected = 0;
		}
		printf("AXEX_2D_002_Index_Selected %d / AXEX_2D_002_Index %d %f %f - %f %f\r\n", AXEX_2D_002_Index_Selected, AXEX_2D_002_Index, lines_2D_001[AXEX_2D_002_Index_Selected].p1->x, lines_2D_001[AXEX_2D_002_Index_Selected].p1->y, lines_2D_001[AXEX_2D_002_Index_Selected].p2->x, lines_2D_001[AXEX_2D_002_Index_Selected].p2->y );
		call_once_key == 1;
	} else if ( m_mode == 8 &&  this->key_wParam_Keyup == 66 ) { //b
		int a = convert_AXEX_2D();
		this->AXEX_2D_002_Index = 0;
		for ( int i = 3; i<line_index; i++ ) {
			this->Set_vAxex_2D( lines_2D_001[i].p1->x, lines_2D_001[i].p1->y ); 
			this->Set_vAxex_2D( lines_2D_001[i].p2->x, lines_2D_001[i].p2->y ); 
		}
		call_once_key == 1;
	}

	this->event->main_mode = m_mode;

	printf("wCanvasController:: this->key_wParam_Keyup=%d\r\n", this->key_wParam_Keyup );
	printf("void wCanvasController::ProcessWmKeyup () ends.\r\n");
}

//
//
//
//
void wCanvasController::ProcessWmChar () {
	switch ( this->event->main_mode ) {
	case 2:
		//something_word
		//getchar_display_threeD_proc ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		//exit(-1);
		break;
	case 8:
		//getchar_display_threeD_proc ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		break;
	}
}

//
//
//
//
void wCanvasController::ProcessWmPaint () {

	static 	RECT rect;
	int	R = 20;
	int a = 0;

	printf("void wCanvasController::ProcessWmPaint () starts.\r\n");

    SetRect(&rect, 300, 460, 600, 480 );
	SetTextColor( event->hDc, RGB( 0 , 0,  0 ) );

	Rectangle( event->hDc, 300, 460, 600, 480  );
	DrawText( event->hDc, TEXT( "Cavas 20210901" ), -1, &rect, DT_NOCLIP);

	SelectObject(event->hDc, GetStockObject(DC_PEN));
	SelectObject(event->hDc, GetStockObject(DC_BRUSH));

	SetDCBrushColor(event->hDc, RGB( 255, 0, 0));
	SetDCPenColor(event->hDc, RGB( 0, 0, 255));
	Ellipse( event->hDc, 50 - R,  50 - R, 50 + R, 50 + R );

	//
	//if ( vAxex_2D_002[0].x == 0) exit(-1);

	switch ( this->event->main_mode ) {
	case 2:
		//something_word
//		wmpaint_somtehing_word_proc ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
		break;
	case 7:
		break;
	case 8:
		// OK: ROOT
		for ( int i=0; i<AXEX_2D_002_Index; i++ ) {
			if ( AXEX_2D_002_Index_Selected == i ) {
	    	    //    Set the DC Brush to Red
				//    The RGB macro is declared in "Windowsx.h"
				SetDCBrushColor(event->hDc, RGB( 255, 0, 0));
				//    Set the event->hDc to Blue
				SetDCPenColor(event->hDc, RGB( 0, 0, 255));
				printf("Selected %d/ %d\r\n", AXEX_2D_002_Index_Selected, AXEX_2D_002_Index);
//				exit(-1);
			} else {
				SetDCBrushColor(event->hDc, RGB( 255, 255, 255));
				SetDCPenColor(event->hDc, RGB( 0, 0, 0));
			}
			a = Ellipse( event->hDc, vAxex_2D_002[i].x - R, vAxex_2D_002[i].y - R, vAxex_2D_002[i].x + R, vAxex_2D_002[i].y + R );
			// exit(-1); OK: ROOT
		}
		// 20220321
		// Draw axex
		if ( axline != nullptr )
			for ( int i=0; i<3; i++ ) {
				if ( axline[i] != nullptr ) {
					MoveToEx( event->hDc, (int)axline[i]->p1->x, (int)axline[i]->p1->y, NULL);
					LineTo  ( event->hDc, (int)axline[i]->p2->x, (int)axline[i]->p2->y );
					printf("line to: ax;ine\r\n");
				}
			}

		break;
	}

	printf("void wCanvasController::ProcessWmPaint () ends.\r\n");
//	exit(-1);
}

// 20220321
void wCanvasController::Initialize_Axex ( ) {
		if ( axline == nullptr )
			axline = (vLine**)malloc(sizeof(vLine*)*3);

		// On the 2D
		if ( axline != nullptr ) {
			axline[0] = memorizevLine( memorizevPoint( width/2.0f + 0.0f, height/2.0f + 0.0f, 0.0f), memorizevPoint( width/2.0f + 200.0f, height/2.0f + 0.0f, 0.0f) );
			axline[1] = memorizevLine( memorizevPoint( width/2.0f + 0.0f, height/2.0f + 0.0f, 0.0f), memorizevPoint( width/2.0f +   0.0f, height/2.0f + 200.0f, 0.0f) );
			axline[2] = memorizevLine( memorizevPoint( width/2.0f + 0.0f, height/2.0f + 0.0f, 0.0f), memorizevPoint( width/2.0f + 100.0f, height/2.0f + 100.0f, 0.0f) );
		}
}


void wCanvasController::Set_vAxex_2D ( float x, float y ) {
	vAxex_2D_002[AXEX_2D_002_Index].x = x;
	vAxex_2D_002[AXEX_2D_002_Index].y = y;
	AXEX_2D_002_Index++;
	if ( AXEX_2D_002_Max <= AXEX_2D_002_Index ) AXEX_2D_002_Index = 0;
}

//
int wCanvasController::Get_vAxex_2D ( int num, float *x, float *y ) {
	*x = vAxex_2D_002[num].x;
	*y = vAxex_2D_002[num].y;

	return 0;
}

int wCanvasController::GetSelected ( ) {

	return AXEX_2D_002_Index_Selected;
}
