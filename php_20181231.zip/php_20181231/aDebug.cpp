#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <cstdio>

//#include "stdafx.h"

//#include <tchar.h>
//#include <wchar.h>
#include <windows.h>


#include "Print.h"

#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NON_CONFORMING_SWPRINTFS

#include "aDebug.h"

#define PRINTBUFFER	1024


char str_print[PRINTBUFFER];
char dummy_str_print[PRINTBUFFER];

// int DEBUG ( char* f_name, const char* mem, const char* fmt, ...) ;
int DEBUG ( char* f_name, const char* fmt, ...) ;

//
// 1st: f_name : Function name
// 2nd: p_ind  : Parameter indicator
//
int DEBUG ( char* f_name, const char* fmt, ...) {
	va_list ap;
	va_start(ap, fmt);
	char* result;

	wsprintf( (LPSTR) dummy_str_print, (LPCSTR)"%s", vformat(fmt, ap));
	va_end(ap);

	result = NULL;
	result = (char *) dummy_str_print;

	printf("DEBUG: %s", result);

	return 0;
}




