#include <stdio.h>
#include "array_counter.h"

int main () {

	char a_dummy[] = {'a', 'b', '\0'};
	char* p_dummy = (char*)"aaa";
	char dummy[2];
	const char* msg = "printf:\r\n";
	char* msg_2 = "printf:";

	char* conv_ary = "\0";

	dummy[0] = '\r';
	dummy[1] = '\n';

//	p_dummy[0] = '\r';
//	p_dummy[1] = '\n';
//	p_dummy[2] = '\0';

// x	*( p_dummy + 0 ) = '\r';
// x	*( p_dummy + 1 ) = '\n';
// x	*( p_dummy + 2 ) = '\0';

//	*( p_dummy + 0 ) = (char *) "\r";
//	*( p_dummy + 1 ) = (char *) "\n";
//	*( p_dummy + 2 ) = (char *) "\0";

	printf("m_compare: |%s|%s| %d %s", (char *)dummy, "\r\n", m_compare(dummy, "\r\n") );

	printf("\r\n\r\ndummy: %.*s\r\n", 2, dummy);

	printf( "\r\n\r\ndummy: %.*s\r\n", dummy );

	printf( "\r\n\r\ndummy: %.*s\r\n", msg );
	printf( "\r\n\r\ndummy: %.*s\r\n", msg_2 );

	printf( "\r\n\r\ndummy: %s\r\n", msg );
	printf( "\r\n\r\ndummy: %s\r\n", msg_2 );

	printf("m_compare: %d %s", m_compare( dummy, "\r\n" ), "\r\n" );

	printf("m_compare: %d %s", m_compare( (char *)dummy, "\r\n" ), "\r\n" );

	// o
	printf("m_compare: %d %s", m_compare( (char *)dummy, (char *)"\r\n" ), "\r\n" );


	printf ( "m_concat: %s\r\n", m_concat( (char *)msg, (char *)msg_2) );
	printf ( "m_concat: %s\r\n", m_concat( (char *)dummy, (char *)msg_2) );

	conv_ary = (char* )dummy;
	printf ( "m_concat: %s\r\n", m_concat( (char *)conv_ary, (char *)msg_2) );

	printf ( "m_concat: %s\r\n", m_concat( (char *)a_dummy, (char *)msg_2) );

	return 0;

}


