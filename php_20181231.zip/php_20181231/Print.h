#pragma once


//#include "Print.h"

extern void PrintErrorMsg(const char* fmt, ...);
extern wchar_t* vformat(const char* fmt, va_list args);
extern wchar_t* _toChars(char * m_string);
extern char* toChars(LPSTR str);

extern char* PrintError(const char* mem, const char* fmt, ...);

