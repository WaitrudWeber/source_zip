#ifndef _V3DCALCULATION_
#define _V3DCALCULATION_

class v3dCalculation {

	public:
		int calculation_thread () ;
		int calculation_thread_002 () ;
		int calculation_thread_003 () ;
		int calculation_thread_004 () ;
		int calculation_thread_005 () ;
		int calculation_thread_006 () ;
		int calculation_thread_007 () ;

};

#endif
