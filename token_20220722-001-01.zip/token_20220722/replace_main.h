#ifndef _SENDER_H_
#define _SENDER_H_
extern int replace_main (int argc, char** argv ) ;
#endif
