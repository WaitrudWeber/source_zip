#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"

int main (int argc, char** argv ) {
	printf("start of main:\r\n");

	char* token = (char*) "\"He is a briliant person. \" ";

	char* result = m_trim ( token );

	printf("result: |%s|\r\n", result );

	print_memories ();
	printf("end of main:\r\n");
	return 0;
}

