#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"

#include "read_csv_004.h"
#include "read_csv_005.h"


#include "control_img_layer_010.h"

extern char* filename_control_img_layer_010_ = (char*)"control_img_layer_010.txt";

int control_img_layer_010 ();
int set_control_img_layer_010 (int ii, int jj, char* word);
int initialize_control_img_layer_010 (int ii, int jj, char* word);

int control_img_layer_010 () {
	return 0;
}


int control_img_layer_set_010 (int ii, int jj, char* word) {
 	return 0; 
}

int control_img_layer_initialize_010 (int ii, int jj, char* word) {
 	return 0; 
}

