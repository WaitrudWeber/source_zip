#ifndef _CONTROL_IMG_LAYER_005_
#define _CONTROL_IMG_LAYER_005_
//...
extern int control_img_layer_005 ();
extern int set_control_img_layer_005 (int ii, int jj, char* word);
extern int initialize_control_img_layer_005 (int ii, int jj, char* word);
#endif
