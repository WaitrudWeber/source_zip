#ifndef ADEBUG_H
#define ADEBUG_H

extern int debug_allow_print_console ;

// extern int DEBUG ( char* f_name, const char* mem, const char* fmt, ...) ;
extern int DEBUG ( char* f_name, const char* fmt, ...) ;

#endif
