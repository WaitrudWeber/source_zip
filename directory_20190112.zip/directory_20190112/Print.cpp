//#include "SDL.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//#include <iostream>
#include <cstdio>

//#include "stdafx.h"
//#include <tchar.h>

#include <windows.h>
// LPSTR

#include "array_counter.h"
#include "parse.h"
#include "Print.h"

//#define __cdecl	1
#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NON_CONFORMING_SWPRINTFS

#define VFMT_PRINTBUFFER	2048



//int __cdecl system(const char *);

//extern "C" {
	char* PrintError(const char* mem, const char* fmt, ...);

	wchar_t* vformat(const char* fmt, va_list ap);
	wchar_t* vformat(const char* fmt, va_list *pap);
//	wchar_t* vformat(const char* fmt, va_list ap);
	wchar_t* _toChars(char * m_string);

	char* toChars(LPSTR str);

	const wchar_t *GetWC(const char *c);
	int count_perceent( const char* fmt, char** ctype );
	char tochar(char* str );

//}

void error(const char* fmt, ...) {
	//	using namespace N;
	va_list ap;
	va_start(ap, fmt);
//	LPSTR ps;

	// printf("%s", vformat(fmt, ap) );
	// printf("%s", vformat(fmt, ap));
	// _tprintf( _toChars("aaa") );
	// _tprintf(L"aaaa");
	// _tprintf( _toChars( (char *)"aaaa" ) );
	// _tprintf(_toChars( fmt));
	// int a = ppp( L"aaa" );
	// toChars( L"aaa" );
	// printf("aaa");
	// std::printf("aaa");
	// printf_s("aaa");

	// write memories
	// x printf("%s", vformat(fmt, ap) );
	char strx[VFMT_PRINTBUFFER];

	// 20181127
//	wsprintf( (LPWSTR)strx, (LPCWSTR)"%s", vformat(fmt, ap));




	wsprintf( (LPSTR) &strx[0], (LPCSTR)"%s", vformat(fmt, ap));

	//printf("error: %s", strx);

	va_end(ap);
	//	exit(1);
}

/*
#include <windows.h>
#include <string>
#include <vector>

static string utf16ToUTF8( const wstring &s )
{
    const int size = ::WideCharToMultiByte( CP_UTF8, 0, s.c_str(), -1, NULL, 0, 0, NULL );

    vector<char> buf( size );
    ::WideCharToMultiByte( CP_UTF8, 0, s.c_str(), -1, &buf[0], size, 0, NULL );

    return string( &buf[0] );
}
*/


int ppp (LPSTR a) {
	return 0;
}

/*
namespace N {
	class C {
		friend void FriendFunc() {
		}
		friend void AnotherFriendFunc(C* c) {}
	};
}
*/

char* PrintError(const char* mem, const char* fmt, ...) {

	va_list ap;
//	va_start(ap, fmt);
//	va_start(ap, num_args);

//	char strx[VFMT_PRINTBUFFER];
	char* result;

	wsprintf( (LPSTR) mem, (LPCSTR)"%s", vformat(fmt, &ap));
//	va_end(ap);


	result = NULL;
	result = (char *) mem;

	return	result;
}

//char* toChars(wchar_t* str)
char* toChars( LPSTR str )
{
//	char* cptc = (LPSTR )str;
//	char* ptc = const_cast<(char*)>( str );
	char* ptc = (char*)str;

	return ptc;
//	return cptc;
}

const wchar_t *GetWC(const char *c)
{
	const size_t cSize = strlen(c) + 1;
	wchar_t* wc = new wchar_t[cSize];
	mbstowcs(wc, c, cSize);

	return wc;
}

wchar_t* _toChars(char* l_string )
{
	// LPSTR lpstr = const_cast<LPSTR>(m_string);
	// x LPCWSTR lpcwstr = const_cast<LPCWSTR>(m_string);
	// LPCWSTR lpcwstr = (LPCWSTR)lpstr;
	// T2A(L"aaa");
	// char *pc = (char*) TEXT( "aaa" );

	return (wchar_t*)GetWC( l_string );

	//wchar_t* wp = (wchar_t*)m_string;

	//return wp;
}

wchar_t* vformat(const char* fmt, va_list ap) {
}

wchar_t* vformat(const char* fmt, va_list *p_ap) {
//	char buf[2000];
	wchar_t* abuf;
	abuf = (wchar_t*) L"aaa";

	// x vswprintf(buf, _toChars((char*)fmt), args);
	// o vswprintf( abuf, L"aaa", args);
	// vswprintf( abuf, _toChars( (char*)fmt ), args);
	// o vswprintf(abuf, _toChars((char*)fmt), args);

	// char *str_org = (char *)"left=%d top=%d right=%d bottom=%d";
	char strx[2000];
	char** ctype;
	char** param;

	double	vf;
	int 	vi;
	char* 	vs;
	char	vc;
	char*	vsc = "\0\0";
	va_list	ap;
	// o wsprintf( (LPWSTR)strx, (LPCWSTR)str_org, 10, 10, 10, 10);
	// o wsprintf( (LPWSTR)strx, (LPCWSTR)str_org, args);

	// 20181127
	// x wsprintf((LPWSTR)strx, (LPCWSTR)fmt, args);

	printf("wchar_t* vformat:start\r\n");

	ctype = (char**) malloc ( sizeof(char*)*256 );
	for( int i=0; i< 256; i++ ) {
		ctype[i] = (char*) malloc ( sizeof(char)* 10 );
	}

	param = (char**) malloc ( sizeof(char*)*256 );
	for( int i=0; i< 256; i++ ) {
		param[i] = (char*) malloc ( sizeof(char)* 30 );
	}

	int c_percent = count_perceent(fmt, (char**)ctype);
//	va_start( ap, c_percent);

	int c_param = 0;
	for ( int i=0; i<c_percent; i++ ) {
		printf("loop i: %d/%d\r\n", i, c_percent );
		if ( m_compare ( ctype[i], "int" ) == 1 ) {
			vi = va_arg( *p_ap, int );
			itoa( vi, param[c_param], 10);
			param[c_param] = m_concat(param[c_param], ":");
			c_param++;
		} else if ( m_compare ( ctype[i], "char" ) == 1 ) {
			printf("char:start\r\n");
			vs = va_arg( *p_ap, char* );
			for ( int j=0; j<2; j++) {
				//printf("vs:%d %d", j, vs[j]);
				printf("vs:%d\r\ns", j);
			}
			printf("char:va_arg\r\n");
			//vc = tochar(vs);
			printf("char:tochar\r\n");
			// x vc = va_arg( *p_ap, char* );
			// x vc = vs;
			// x vc = *vs;
			// x vc = va_arg( *p_ap, char );
			// x vs[1] = '\0'; // o
			// o vc = 1;
			// x vsc[0] = vc;

			//printf("char:vs:%d %c char:vc:%d\r\n", vs, vs, vc);

			// x *(vsc) = vc;
			sprintf( param[c_param], "%c", vs);
			// x param[c_param][0] = vc;
			// x param[c_param][1] = '\0';
			printf("char:param:\r\n");
//			param[c_param] = m_concat(param[c_param], ":");
			printf("char:m_concat\r\n");
			c_param++;
			printf("char:end\r\n");
		} else if ( m_compare ( ctype[i], "float" ) == 1 ) {
			vf = va_arg( *p_ap, double );
			sprintf(param[c_param], "%f", vf);
			param[c_param] = m_concat(param[c_param], ":");
			c_param++;
		} else if ( m_compare ( ctype[i], "string" ) == 1 ) {
			vs = va_arg( (va_list)*p_ap, char* );
			param[c_param] = vs;
			param[c_param] = m_concat(param[c_param], ":");
			c_param++;
		}
	}

	for ( int i=0; i< c_param; i++) {
		printf("param:%d %s\r\n", i, param[i]);
	}


	//wsprintf( (LPSTR)strx, (LPCSTR)fmt, args);

	// vsprintf(buf, 2000, _toChars((char*)fmt, args);
	// vswprintf(buf, fmt, args);
	// char* result = toChars( abuf );
	//va_end( ap );

	//free
	for( int i=0; i< 256; i++ ) {
		free(ctype[i]);
	}
	free(ctype);

	for( int i=0; i< 256; i++ ) {
		free(param[i]);
	}
	free(param);

	printf("wchar_t* vformat:end\r\n");

	return abuf;
}

char tochar(char* str ) {
	char c = *( str) ;
	return c;
}

int count_perceent( const char* fmt, char** ctype ) {
	int result = 0;
	int flag = 0;
	for ( int i=0; 1; i++ ) {
		if ( fmt[i] == '\0' ) break;
		if ( fmt[i] == '%' ) {
			result++;
			flag = 1;
		}
		if ( flag && alphabet (fmt[i]) == 1 ) {
			switch (fmt[i]) {
			case 'c':
				ctype[result -1] = "char";
				break;
			case 'd':
				ctype[result -1] = "int";
				break;
			case 'f':
				ctype[result -1] = "float";
				break;
			case 's':
				ctype[result -1] = "string";
				break;
			}
			flag = 0;
		}
	}

	return result;
}


/*
std::string vformat(std::string fmt, va_list args) {
	char buf[2000];
	vsprintf(buf, fmt.c_str(), args);
	return std::string(buf);
}
*/

/*
void PrintErrorMsg(const char* fmt, ...);

void PrintErrorMsg(const char* fmt, ...) {

}*/
