#ifndef _PARSE_H_
#define _PARSE_H_


//#include "Print.h"

extern void PrintErrorMsg(const char* fmt, ...);
extern wchar_t* vformat(const char* fmt, va_list *pap);
extern wchar_t* vformat(const char* fmt, va_list ap);
extern wchar_t* _toChars(char * m_string);
extern char* toChars(LPSTR str);

extern char* PrintError(const char* mem, const char* fmt, ...);

#endif