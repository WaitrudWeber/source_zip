#include <windows.h>
#include <iostream>

#include "array_counter.h"
#include "parse.h"

#include "list_directory.h"
#include "php_analyzer.h"
#include "Print.h"
#include "aDebug.h"

using namespace std;

void stack_lootin( int depth, char* char_string ) ;
void concat_tests () ;
void check_lootin () ;

char* print_mem = NULL;
//
//
//
//
//
int main ( int argc, char** argv ) {

	debug_allow_print_console = 1;

	check_lootin ();
	exit(-1);

//	concat_tests();
//
//	char* char_string = m_concat ("a", "b" );
//	printf("char_string:%s\r\n", char_string );
//	stack_lootin( 1, char_string );

	char* c_a = (char*)"c:\\aaa\\*";
	int n = 0;

	print_mem = (char*)malloc (sizeof(char) * 1024 ) ;

	debug_allow_print_console = 1;
	// DEBUG ( "main", "%s \r\n", c_a ) ;
	//char* a_print_error = PrintError ( print_mem, "%s %d \r\n", c_a, 1 ) ;
	printf("print_mem: %s", print_mem);
	exit(-1);

//	int a = m_last_with("ClassLoader.php-php", ".php" );
//	printf( "return m_last_with : %d \r\n", a );
//	exit(-1);
//
//	char** split_a = split("*.php", '*', &n );
//	for ( int i=0; i<n; i++ ) {
//		printf("i: %d %s\r\n", i, split_a[i] );
//	}

	int start_index = m_start_with( c_a, (char*)"\\" );
	printf("start_index: %d\r\n", start_index );

	FileControler fc;
	//fc.List_Files( ".\\*" );
	//fc.List_Files( (char *)"C:\\laravel_src\\blog\\*" );
	//fc.print_strings ();

	int file_num = 0;
	char** files = (char**) fc.get_files ( ".\\*\.php", &file_num );
//	char** files = (char**) fc.get_files ( "C:\\laravel_src\\*", &file_num );
//	fc.print_strings ();

	for ( int i=0; i<file_num; i++ ) {
		printf ( "file: %d %s\r\n", i, files[i] );
	}

//	for ( int i=0; i<file_num; i++ ) {
//		php_parse ( files[i] );
//	}

	// fc.List_Files( "C:\\laravel_src\\blog\\*" );
	// fc.List_Files( "c:\\aaa\\*" );
	exit( -1 );

	int index = m_last_with( c_a, (char*)"\\" );
	printf("index: %d\r\n", index );

	// substring ( start, length ) ;
	char* string_directory = substring( c_a, 0, index );
	printf("string_directory: %s\r\n", string_directory );

	// filename
	printf ( "%d\r\n", file_type( "filename.php", "*.php" ) );		// 1
	printf ( "%d\r\n", file_type( "filename.php-", "*.php" ) );  	// -1
	printf ( "%d\r\n", file_type( "filename.php-", "*.php*" ) ); 	// 1

//
//	int a_index = m_aaa();
//	m_aaa();
//

	// 
	// copy by windows api
	// https://docs.microsoft.com/en-us/windows/desktop/api/winbase/nf-winbase-copyfile
	CopyFile( "specification.txt", "tmp-specification.txt", TRUE );
	return 0;
}

void check_lootin () {

	const char* char_string = "char_string";
	char c = 'A';
	int num = 10;
	float f_num = 10.054f;

	DEBUG ("check_lootin", "%f %3d %c %s\r\n", f_num, num, c, char_string );

}

void concat_tests () {
	char* m_a;
	m_a = m_concat ( "C:\\laravel_src\\blog\\app\\", "Console" );
	printf("m_a:%s\r\n", m_a  );
}

void stack_lootin( int depth, char* char_string ) {

	if ( depth >= 1000 ) {
		return;
	}
	printf( "depth: %d char_string: %s\r\n", depth, char_string );

	depth++;
	char* char_concat = m_concat ( char_string, "g" );
	stack_lootin ( depth, char_concat );
}




