#ifndef WTEXTAREAE_H
#define WTEXTAREAE_H

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

class wTextarea {
	public:
		int x, y, width, height;
		char* textarea;

	private:
		int mode;

	public:
		wTextarea(char* txt);
		void setTextarea( int xx, int yy, int h, int w);
		void setMode ( int m );
		int paintTextarea(  HDC hdc, char* aname );

};

#endif
