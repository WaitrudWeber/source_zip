#ifndef _PRINT_MOUSE_006_
#define _PRINT_MOUSE_006_
extern int worl_006 () ;
extern int print_mouse_move_006 () ;
#endif

