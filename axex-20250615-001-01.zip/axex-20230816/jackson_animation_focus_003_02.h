#ifndef _JACSON_ANIMATION_FOCUS_003_02_H_
#define _JACSON_ANIMATION_FOCUS_003_02_H_

extern int Draw_Circle_Line_005 (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;
extern int Draw_Line_and_Focus ();
extern int Draw_Line_and_Focus_thin ();
extern int Set_Debug_Sleep_003_02 (int value );
extern int Draw_Line_and_Focus_thin_axex ();

// 20250528
extern int Organize_Axex (int type);
extern int Print_Organize_Axex (vLine** lines, int num);
extern int Draw_Organize_Axex (vLine** lines, int num);

// 20250530
extern int Draw_Line_and_Focus_thin_axex_bones ();
extern int Draw_Organize_Bones_Line_005 (vPoint** points, int num);
// 20250611
extern int Change_Eye_thin_axex_bones () ;


#endif
