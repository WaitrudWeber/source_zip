int filewriter_008 ();

filewriter_008 () {
nreturn 1;

}


