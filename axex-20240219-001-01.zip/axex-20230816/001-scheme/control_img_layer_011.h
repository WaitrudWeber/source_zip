#ifndef _CONTROL_IMG_LAYER_011_
#define _CONTROL_IMG_LAYER_011_
//...
extern int control_img_layer_011 ();
extern int set_control_img_layer_011 (int ii, int jj, char* word);
extern int initialize_control_img_layer_011 (int ii, int jj, char* word);
#endif
