#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "allocation.h"


extern static vPoint** allocation;

vPoint** getPoints () ;

vPoint** getPoints () {
	return allocation;
}

