extern vPoint** getPoints () ;
// x extern static vPoint** allocation;
static vPoint** allocation = nullptr;
