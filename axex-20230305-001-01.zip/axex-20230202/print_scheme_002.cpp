#include <stdio.h>
#include <stdlib.h>

int create_funtion_print_scheme_001 ();

//�X�L�[�}�𐶐�����t�@���N�V����
int create_funtion_print_scheme_001 ()
{
	FILE *fp;
	int i;
	char* func_key = (char*)"wButton button_o";


	fp = fopen( "001-filename-001\.txt","wb");
//	fprintf("	%s_%0d () {\r\n//($code_block)}\r\n", func_key, i );

//	for ( i=0; i<10; i++ )
//		fprintf("	%s_%0d () {\r\n//($code_block)}\r\n", "wButton button_o", i );
//		fprintf("	%s_%0d () {\r\n//($code_block)}\r\n", func_key, i );

	fclose(fp);
	return 0;
}

