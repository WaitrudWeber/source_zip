#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "list_directory.h"
#include "parse.h"
#include "numbering.h"

#include "file_numbering.h"

int find_numbering (char* filename);
int find_numbering_011 (char* filename, int debug_num);

int find_numbering_011 (char* filename, int debug_num)
{
	FileControler *fc = nullptr;
	char key_code[1];
	int number;
	int success;
	static char* print_word = NULL;

	printf("int find_numbering_011 (char* filename, int debug_num) starts.\r\n");

	printf("001: filename: %s debug_num %d\r\n", filename, debug_num);
	if ( debug_num == 1 ) exit(-1);

	char** argv = (char**)malloc (sizeof(char*) * 5 );
	if ( argv == NULL ) {
		printf("argv can not be allocated\r\n");
		exit(-1);
	}

	char** file_info = (char**) malloc ( sizeof(char*) * 3 );
	if ( file_info == NULL ) {
		printf("file_info can not be allocated.\r\n");
		exit(-1);
	}

	printf("002: filename: %s\r\n", filename);
	if ( debug_num == 2 ) exit(-1);

	fc = new FileControler ();
//	char** file_list = fc->get_files_001 ( "C:\\Users\\soresore soreda\\Documents\\java004\\*.java", &number );
//	char** file_list = fc->get_files_001 ( "C:\\java005\\*.java", &number );
	char** file_list = fc->get_files_012 ( filename, &number, debug_num );

	printf("debug_num = %d\r\n", debug_num );
	printf("find_numbering_011: filename: %s number %d\r\n", filename, number);
	if ( debug_num == 6 ) exit(-1);

	for( int i=0; i<number; i++ ) {
		print_word = m_concat( print_word, (char *) *(file_list + i ) );
		print_word = m_concat( print_word, (char *) copyof("\r\n") );
		*( argv + 1 ) = *(file_list + i );

		success = fc->get_file_info ( (char*)( file_list + i ), (char**)file_info );
		if ( debug_num == 7 ) exit(-1);

		*( argv + 2 ) = *(file_info + 0 );
		*( argv + 3 ) = *(file_info + 1 );
		*( argv + 4 ) = *(file_info + 2 );

		for ( int j=0; j<5; j++ )
			printf("j %d %s\r\n", j, *( argv + 4 ) );

		if ( debug_num == 8 ) exit(-1);

		numbering_main_011( 5, (char**)argv );

		if ( debug_num == 9 ) exit(-1);
}

	printf("int find_numbering_011 (char* filename, int debug_num) ends.\r\n");
	return 0;
}

int find_numbering (char* filename)
{
	FileControler *fc = nullptr;
	char key_code[1];
	int number;
	int success;
	static char* print_word = NULL;

	char** argv = (char**)malloc (sizeof(char*) * 5 );
	if ( argv == NULL ) {
		printf("argv can not be allocated\r\n");
		exit(-1);
	}

	char** file_info = (char**) malloc ( sizeof(char*) * 3 );
	if ( file_info == NULL ) {
		printf("file_info can not be allocated.\r\n");
		exit(-1);
	}

	fc = new FileControler ();
//	char** file_list = fc->get_files_001 ( "C:\\Users\\soresore soreda\\Documents\\java004\\*.java", &number );
//	char** file_list = fc->get_files_001 ( "C:\\java005\\*.java", &number );
	char** file_list = fc->get_files_001 ( filename, &number );
	for( int i=0; i<number; i++ ) {
		print_word = m_concat( print_word, (char *) *(file_list + i ) );
		print_word = m_concat( print_word, (char *) copyof("\r\n") );
		*( argv + 1 ) = *(file_list + i );

		success = fc->get_file_info ( (char*)( file_list + i ), (char**)file_info );
		*( argv + 2 ) = *(file_info + 0 );
		*( argv + 3 ) = *(file_info + 1 );
		*( argv + 4 ) = *(file_info + 2 );

		numbering_main_011( 5, (char**)argv );
	}

	return 0;
}

//	char** file_info = (char**) malloc ( sizeof(char*) * 3 );
//	int success = this->get_file_info ( lpcstr_path, file_info );
// lpcstr_path
// int FileControler::get_file_info ( char *lpcstr_path, char **result ) 
