class sHtml {

	public:
		int isHead = 0;
		char* tag_name = nullptr;
		aHashMap values;
		aHashMap sheets_values;
		sHtml *children;	// should be array scaned
		sHtml *parent;		// should be list scaned

	public:
		void set_tag_name (char* tname);
		void print ();

};


