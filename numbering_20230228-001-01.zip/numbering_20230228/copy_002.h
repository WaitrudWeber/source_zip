//
typedef struct filetimeinfo {
	char* creationtime = NULL;
	char* updatetime = NULL;
	char* accesstime = NULL;
	char* filename = NULL;
/*	BOOL b_success = 0;
	HANDLE hTime = INVALID_HANDLE_VALUE;
	LPFILETIME lp_creationtime;
	LPFILETIME lp_updatetime;
	LPFILETIME lp_accesstime;
	WIN32_FIND_DATA ffd;*/
} FILEDATETIMEINFO;


extern int get_filetimeinfo(FILEDATETIMEINFO* fti) ;
extern int filetime_main(int argc, char **argv) ;
extern int filetime_main_001(int argc, char **argv) ;

extern char* get_file_time_info_001 (char* filename) ;

