#include<stdio.h>

//#include "Parent.h"
//#include "Child.h"

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"

int main () {

	vCurveCalculation* calc_curve = new vCurveCalculation ();

	vPoint* p1 = memorizevPoint (  10.0f,  10.0f,  10.0f);
	vPoint* p2 = memorizevPoint (  30.0f,  30.0f,  30.0f);
	vPoint* p3 = memorizevPoint ( 110.0f, 110.0f, 110.0f);
	vPoint* p4 = memorizevPoint (  80.0f,  80.0f,  80.0f);

	vPoint* results = calc_curve->BattleField ( p1, p2, p3, p4, 0.5f );
	printf("results : |%p| \r\n", results);

	return 0;
}

