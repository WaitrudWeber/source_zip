#include<stdio.h>
#include<stdlib.h>

//#include "Parent.h"
//#include "Child.h"

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"


int index = 0;
int index_max = 0;
vPoint** dummy_arry = nullptr;

void put_points( vPoint* p ) ;

// p1: Anchor
// p2: setting controls
//
// p3: Anchor(next)
// p4: setting controls
//
int main () {

	vCurveCalculation* calc_curve = new vCurveCalculation ();
	vCalculation* calc = new vCalculation();

	vPoint* p1 = memorizevPoint (  10.0f,  10.0f,  10.0f);
	vPoint* p2 = memorizevPoint (  30.0f,  30.0f,  30.0f);
	vPoint* p3 = memorizevPoint ( 110.0f, 110.0f, 110.0f);
	vPoint* p4 = memorizevPoint (  80.0f,  80.0f,  80.0f);

	int devide = 5;
	for( int i=0; i<devide; i++ ) {
		float t = (float)i / (float) devide;
		vPoint* curve_p = (vPoint*) calc_curve->BattleField ( p1, p2, p3, p4, t );
		// put_points( curve_p );
		printf("curve_p : |%p| \r\n", curve_p );
	}


	calc->Print_Point_Memories ();

	return 0;
}

