#include <stdio.h>
#include <stdlib.h>
#include <iostream>


#include "aHashMap.h"
#include "aMemoryAnalyzer.h"

#include "sHtml.h"
#include "anHtml.h"

/***

the below does not be compiled.

	hmap = new aHashMap();
	hmap->put_value( (char*) "abc", (char*) "abcd");

> C:\aaa\bin\make.exe all
gcc -Wall -O3 -o sourcevisualizer-check-lootin.o -c sourcevisualizer-check-lootin.cpp
sourcevisualizer-check-lootin.cpp: In function 'int main(int, char**)':
sourcevisualizer-check-lootin.cpp:7:12: warning: variable 'hmap' set but not used [-Wunused-but-set-variable]
  aHashMap* hmap = nullptr;
            ^~~~
gcc array_counter.o java_struct.o parse.o aHtml.o aHashMap.o sourcevisualizer-check-lootin.o  -o sourcevisualizer.exe
sourcevisualizer-check-lootin.o:sourcevisualizer-check-lootin.cpp:(.text.startup+0x16): undefined reference to `operator new(unsigned int)'
collect2.exe: error: ld returned 1 exit status
make: *** [Makefile:19: sourcevisualizer.exe] Error 1

*****/


int main_argc_argv_html ( int argc, char *argv[] );
int main_argc_argv_memory_analyzer ( int argc, char *argv[] );
int main_argc_argv ( int argc, char *argv[] );

// gcc g++ ming++

int main ( int argc, char *argv[] ) {


//	main_argc_argv ( argc, argv );
	main_argc_argv_html ( argc, argv );
//	main_argc_argv_memory_analyzer ( argc, argv );

	return 0;
}

int main_argc_argv_html ( int argc, char *argv[] ) {

	anHtml anl;

	anl.token = (char *) "html";
	anl.current_letter = (char *)" ";
	anl.analyze();

	if ( anl.current_tag != nullptr ) anl.current_tag->print();
	else printf( "current_tag is nullptr\n" );

	anl.token = (char *) "script";
	anl.current_letter = (char *)" ";
	anl.analyze();

	if ( anl.current_tag != nullptr ) anl.current_tag->print();
	else printf( "current_tag is nullptr\n" );

	return 0;
}

int main_argc_argv_memory_analyzer ( int argc, char *argv[] ) {

	aMemoryAnalyzer anl;
	aMemoryAnalyzer *p_anl=nullptr;

	p_anl = new aMemoryAnalyzer ();


	return 0;
}


int main_argc_argv ( int argc, char *argv[] ) {

	aHashMap aaa;

	aHashMap* hmap = nullptr;
//	hmap = new aHashMap();
//	hmap->put_value( (char*) "abc", (char*) "abcd");

	aaa.put_value( (char*) "aba", (char*) "abca");
	aaa.put_value( (char*) "abb", (char*) "abcb");
	aaa.put_value( (char*) "abc", (char*) "abcc");
	aaa.put_value( (char*) "abd", (char*) "abcd");
	aaa.put_value( (char*) "abe", (char*) "abce");
	aaa.put_value( (char*) "abf", (char*) "abcf");
	aaa.put_value( (char*) "abg", (char*) "abcg");
	aaa.put_value( (char*) "abh", (char*) "abch");
	aaa.put_value( (char*) "abi", (char*) "abci");
	aaa.put_value( (char*) "abj", (char*) "abcj");
	aaa.put_value( (char*) "abk", (char*) "abck");
	aaa.put_value( (char*) "abl", (char*) "abcl");
	aaa.put_value( (char*) "abm", (char*) "abcm");
	aaa.put_value( (char*) "abn", (char*) "abcn");
	aaa.put_value( (char*) "abo", (char*) "abco");
	aaa.put_value( (char*) "abp", (char*) "abcp");
	aaa.put_value( (char*) "abq", (char*) "abcq");
	aaa.put_value( (char*) "abr", (char*) "abcr");
	aaa.put_value( (char*) "abs", (char*) "abcs");
	aaa.put_value( (char*) "abt", (char*) "abct");


	printf("%s\n", (char *)aaa.get_value( (char *)"abb" ) );

	return 0;
}

