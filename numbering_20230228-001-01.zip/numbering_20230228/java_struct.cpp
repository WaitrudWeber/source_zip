#include <stdio.h>
#include <stdlib.h>

#include "java_struct.h"

int put_package( char* name_package );
int initialize_java_keywords () ;
JAVA_KEYWORDS java_keywords;
JAVA_CLASS java_class;
int check_structor ();

int set_main_class ( char* name_class ) ;
int set_main_class_modifier ( char* modifier ) ;
int print_main_class ( JAVA_CLASS j );

int l_print_main_class ( JAVA_CLASS j ) ;


// memory check
int check_structor () {

	for( int i = 0; i<100; i++ ) {
		put_package ( (char *) "aaa.aaa.aaa" );
	}

	for( int i = 0; i<100; i++ ) {
		printf ( "java_keywords.package[ %d ] = %s\n", i, java_keywords.package[i] );
	}

	return 1;
}

int print_main_class () {
	return l_print_main_class ( java_class );
}

int l_print_main_class ( JAVA_CLASS j ) {

	printf ( "main_class: %s\n", j.main_class );
	printf ( "modifier: %s\n", j.modifier );

	for ( int i=0; i<j.attributes_num; i++ ) {
		printf ( "attr[%d]=%s\n", i, j.attributes[i] );
	}

	return 1;
}

int set_main_class ( char* name_class ) {

	java_class.main_class = (char *) name_class;

	//java_class->main_class = "aaaa";

	return 1;
}

//
//
//
//
//
int set_main_class_modifier ( char* modifier ) {

//	java_class.main_class = (char *) name_class;
	java_class.modifier = (char *) modifier;

	return 1;
}

//
//
//
//
//
int put_import ( char* name_import ) {
	java_keywords.import_num++;

	if ( java_keywords.import_num >= java_keywords.import_num_size ) {
		java_keywords.import_num_size = java_keywords.import_num_size * 2;
		printf("%d / %d\n", java_keywords.import_num, java_keywords.import_num_size);
		java_keywords.import = (char **) realloc( java_keywords.import, sizeof ( char** ) * java_keywords.import_num_size );
	}
	java_keywords.import[ java_keywords.import_num - 1 ] = (char*)name_import;

	return 1;
}

int put_package ( char* name_package ) {
	java_keywords.package_num++;

	if ( java_keywords.package_num >= java_keywords.package_num_size ) {
		java_keywords.package_num_size = java_keywords.package_num_size * 2;
		printf("%d / %d\n", java_keywords.package_num, java_keywords.package_num_size);
		java_keywords.package = (char **) realloc( java_keywords.package, sizeof ( char** ) * java_keywords.package_num_size );
	}

	java_keywords.package[ java_keywords.package_num - 1 ] = (char*)name_package;

	return 1;
}

int initialize_java_keywords () {

	java_keywords.package_num = 0;
	java_keywords.package_num_size = 8;
	java_keywords.package = (char**) malloc ( sizeof(char**) * java_keywords.package_num_size );

	java_keywords.import_num = 0;
	java_keywords.import_num_size = 8;
	java_keywords.import = (char**) malloc ( sizeof(char**) * java_keywords.import_num_size );

	return 1;
}

