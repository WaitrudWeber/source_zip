
extern int DEBUG ( char* f_name, char* p_ind, ...);
