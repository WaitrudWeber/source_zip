#undef UNICODE

#define	_WIN32_WINNT  0x501
//#define WIN32_LEAN_AND_MEAN

#define	MESSAGE_NUMBER 100

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>

#include "array_counter.h"
#include "timestamp.h"
#include "server.h"

// comment outed at	20190619
//#pragma comment (lib,	"Ws2_32.lib")

char* server_debug_log = (char *) copyof( (char	*) "debug.log" );

//char*	server_buffer_recv;
char* server_buffer_recv = (char *)	copyof(	(char *)"\0");
int	update_thread =	0;
int	server_console_line	=0;

char* buffer_debug_log = (char *) copyof( (char	*)"\0");


char recvbuf[DEFAULT_BUFLEN];
int	recvbuflen = DEFAULT_BUFLEN;

int	set_receive_buffer ();

int	__cdecl	server_main(void);
int	__cdecl	boot_console_server(void);
char* server_concat	( char*	a, char* b );

void PrintBuffer(char* dummy_buffer);

int	__cdecl	boot_console_server(void)
{
	int error;
	int count = 0;
	while ( count < MESSAGE_NUMBER	) {
		error	= server_main (	) ;
		if ( error !=	0 )	{
			printf ("server error: %d\n", error );
			exit( -1	);
		}
		count++;
		//added at 20190412
		if ( count <=	MESSAGE_NUMBER - 1)	{
			// sleep( 1000 );
			count = 0;
		}
	}

	return	0;
}

//
//
//
//
//
int	set_receive_buffer () {

	char* str_datetime;
	char* dummy_buffer;
	//	comented out at	20190619
	//	char* temp;

	update_thread = 1;
	str_datetime =	get_datetime_info () ;

	printf("recvbuf: %s\r\n", recvbuf );
	printf("str_datetime: %s\r\n",	str_datetime );
	int cnt = array_count ( str_datetime );

	dummy_buffer =	m_substring	( (char	*) str_datetime, 0,	cnt	- 1	);
	dummy_buffer =	server_concat (	dummy_buffer, copyof( (char	*)"	") );
	dummy_buffer =	server_concat (	dummy_buffer, recvbuf);
	dummy_buffer =	server_concat (	dummy_buffer, copyof( (char	*)"	 :a:  ") );
	dummy_buffer =	server_concat (	dummy_buffer, copyof( (char	*)"\r\n" ) );

	//	PrintBuffer( dummy_buffer );
	//	comented out at	20190619
	//temp	= server_buffer_recv;
	buffer_debug_log =	dummy_buffer;

	server_buffer_recv	= server_concat	( server_buffer_recv, dummy_buffer);
	printf("server_buffer_recv: %s\r\n", server_buffer_recv );

	return	1;
}

//
//
//
//
//
void PrintBuffer(char* dummy_buffer)
{
	FILE *fp;

	dummy_buffer =	m_print_buffer(dummy_buffer);

	fp	= fopen	( server_debug_log,	"a"	);
	fprintf(fp, "%s", dummy_buffer	);
	fclose(fp);

}

//
//
//
//
//
char* server_concat	( char*	a, char* b ) {
	return	m_concat ( a, b	);
}

//
//
//
//
//
int	__cdecl	server_main( void )
{
	WSADATA	wsaData;
	int	iResult;

	SOCKET ListenSocket	= INVALID_SOCKET;
	SOCKET ClientSocket	= INVALID_SOCKET;

	struct addrinfo	*result	= NULL;
	struct addrinfo	hints;

	int	iSendResult;
//	  char recvbuf[DEFAULT_BUFLEN];
//	  int recvbuflen = DEFAULT_BUFLEN;

	iResult	= WSAStartup(MAKEWORD(2,2),	&wsaData);
	if (iResult	!= 0) {
		printf("WSAStartup failed with error: %d\n", iResult);
		return 1;
	}

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family	= AF_INET;
	hints.ai_socktype =	SOCK_STREAM;
	hints.ai_protocol =	IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;

	iResult	= getaddrinfo(NULL,	DEFAULT_PORT, &hints, &result);
	if ( iResult !=	0 )	{
		printf("getaddrinfo	failed with	error: %d\n", iResult);
		WSACleanup();
		return 1;
	}

	ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
	if (ListenSocket ==	INVALID_SOCKET)	{
		printf("socket failed with error: %i\n", WSAGetLastError());
		freeaddrinfo(result);
		WSACleanup();
		return 1;
	}

	iResult	= bind(	ListenSocket, result->ai_addr, (int)result->ai_addrlen);
	if (iResult	== SOCKET_ERROR) {
		printf("bind failed	with error:	%d\n", WSAGetLastError());
		freeaddrinfo(result);
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}

	freeaddrinfo(result);

	iResult	= listen(ListenSocket, SOMAXCONN);
	if (iResult	== SOCKET_ERROR) {
		printf("listen failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}

	ClientSocket = accept(ListenSocket,	NULL, NULL);
	if (ClientSocket ==	INVALID_SOCKET)	{
		printf("accept failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		return 1;
	}

	closesocket(ListenSocket);

	do {

		iResult	= recv(	ClientSocket, recvbuf, recvbuflen, 0 );

		if (iResult	> 0) {
			printf("Bytes received:	%d\n", iResult);
			// Add 2018/11/03
			// printf("recvbuf 000: %s\r\n",	recvbuf	);
			set_receive_buffer ();

			iSendResult	= send(	ClientSocket, recvbuf, iResult,	0 );
			if (iSendResult	== SOCKET_ERROR) {
				printf("send failed	with error:	%d\n", WSAGetLastError());
				closesocket(ClientSocket);
				WSACleanup();
				return 1;
			}
			printf("Bytes sent:	%d\n", iSendResult);

			// increment
			server_console_line++;
		}
		else if	(iResult ==	0)
			printf("Connection closing...\n");
		else  {
			printf("recv failed	with error:	%d\n", WSAGetLastError());
			closesocket(ClientSocket);
			WSACleanup();
			return 1;
		}

	} while	(iResult > 0);

	iResult	= shutdown(	ClientSocket, SD_SEND );
	if (iResult	== SOCKET_ERROR) {
		printf("shutdown failed	with error:	%d\n", WSAGetLastError());
		closesocket(ClientSocket);
		WSACleanup();
		return 1;
	}

	closesocket(ClientSocket);
	WSACleanup();

	return 0;
}

