#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <cstdio>

//#include "stdafx.h"

//#include <tchar.h>
//#include <wchar.h>
#include <windows.h>


#include "Print.h"

#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NON_CONFORMING_SWPRINTFS

#include "aDebug.h"

#define PRINTBUFFER	1024


char str_print[PRINTBUFFER];

int DEBUG ( char* f_name, char* p_ind, ...);

//
// 1st: f_name : Function name
// 2nd: p_ind  : Parameter indicator
//
int DEBUG ( char* f_name, char* p_ind, ...) {

	sprintf( str_print, "%s\n", f_name );

	return 0;
}




