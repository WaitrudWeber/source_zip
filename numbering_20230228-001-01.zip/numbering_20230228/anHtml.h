
class anHtml {

	public:
		int mode = 0; // 0:tag name 1:normal properties 2:style sheets
		sHtml *current_tag = nullptr;
		char* token = nullptr;
		char* current_letter = nullptr;

	public:
		int analyze();
		int the_end_of_letter();
		int exist_tag();

	private:
//		char* usual_tags = { "html", "script", "body", "input" };

};


