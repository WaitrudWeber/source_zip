#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

//#include <ctime>

#include "array_counter.h"
#include "parse.h"
#include "aToken.h"

aToken::aToken () {
	initialize_parse();
}

int aToken::getRaw()
{
	return m_raw - 1;
}

int aToken::getLine()
{
	return m_line;
}


// 20190227
// When we use tokenizer, we just call getToken.
//
//
//
char* aToken::getToken( FILE *fp, int *index, int *file_end )
{
	char *c_dummy;
	char dummy[256];
	int previous_index = 0;
	int mode_token = 0; // skip
	// 0: skip
	// 1: 
	// 2: 
	int breakable = 0;
	dummy[0] = '\0';

	for ( int i=( *index ); i< (*file_end) && breakable == 0; i++ ) {
		previous_index = i;
		m_fread ( dummy, 1, fp);
		printf("i=%d mode_token=%d\r\n", i, mode_token );
		switch(mode_token) {
		case 0:
			switch ( dummy[0] ) {
			case ' ':
				break;
			default:
				if ( is_alphabet( dummy ) == 1 ) {
					mode_token = 1;
				} else {
					mode_token = 2;
				}
				token = put_token ( dummy[0] );
				printf("token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				break;
			}
			break;
		case 1:
			if ( line_or_space ( dummy ) == 1 ) {
				breakable = 1;
				*index = i;
			} else {
				token = put_token ( dummy[0] );
				printf("token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
			}
			/* switch ( dummy[0] ) {
			case ' ':
				breakable = 1;
				*index = i;
				break;
			default:
				token = put_token ( dummy[0] );
				printf("token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				break;
			} */
			break;
		case 2:
			printf("case 2:token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
			if ( line_or_space ( dummy ) == 1 ) {
				breakable = 1;
				*index = i;
			} else {
				token = put_token ( dummy[0] );
				printf("case 2-2:token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				// judge comment out
				if ( m_compare( token, "/*" ) == 1 ) {
					breakable = 1; 
					*index = i;
				}
			}
			break;
		}

		// DEBUG
		if ( previous_index > i ) {
			printf("getToken: previous_index > i\r\n");
			printf("getToken: i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		}

	}

	backward( dummy );
	c_dummy = copyof( dummy );
	c_dummy = m_trim ( c_dummy );

	printf("aToken::getToken token=%s\r\n", token);
	printf("aToken::getToken c_dummy=%s\r\n", c_dummy);
	// return token;

	// DEBUG check
	if ( m_contains ( c_dummy, (char*)"\r\n" ) == 1 || m_contains ( c_dummy, (char*)"\n" ) == 1 ) {
		exit(-1);
	}

	return token;
}

//
//
//
//
//
//
int aToken::skip_to( char* skip_to, int *index , int file_end, FILE *fp) {
	char dummy[256];
	aToken *iToken = nullptr;
	char *parse_token;
	iToken = new aToken();
	int ii = *index;
	char *a_token;
	char *b_token;

	int counter = 0;

	printf("skip to: %s\r\n", skip_to);
	for( ii=*index; ii<file_end && ii<100; ii++ ) {
		printf("loop1:\r\n");
		m_fread ( dummy, 1, fp);
		printf("loop2:\r\n");
		a_token = m_concat( a_token, &dummy[0] );
		printf("loop3:\r\n");
		b_token = substring(a_token, counter - 2, 2);
		printf("loop4:\r\n");
		sleep (1);

		// b_token = copyof("*/");
		printf("ii: %d file_end: %d counter: %d a_token: %s b_token: %s \r\n", ii, file_end, counter, a_token, b_token );

		if ( m_compare( b_token, (char *) "*/" ) == 1 ) {
			// donot use token just use merge
			printf("comment out ends: ii %d raw %d line %d\r\n", ii, iToken->getRaw(), iToken->getLine() );
			exit(-1);
		}

		counter++;
	}

	*index = ii;
}


//
//
//
//
//
int aToken::line_or_space ( char* dummy ) {
	// space
	// "\r\n"

	if ( m_start_with ( dummy, "\n\r" ) == 1 ) {
		//exit( -1 );
		return 1;
	} else if ( m_start_with ( dummy, "\n" ) == 1 ) {
		//exit( -1 );
		return 1;
	} else if ( m_start_with ( dummy, " " ) == 1 ) {
		//exit( -1 );
		return 1;
	} else {

		return 0;
	}
}

//
//
//
// scope
//
void aToken::free_main_token () {
	m_cnt_tkn = 0;
}

void aToken::backward( char *dummy) {
	// int i = 0;
	char c1, c2;
	int cnt_dummy = array_count ( dummy ) ;

	for ( int i=0; i<cnt_dummy/2 && i<256*256; i++ ) {
		c1 = *( dummy + cnt_dummy - 1 - i );
		c2 = *( dummy + i );
		*( dummy + cnt_dummy -1 - i ) = c2;
		*( dummy + i ) = c1;
		printf("i %d %c %c\r\n",i,  c1, c2);
	}

	printf("backward dummy %s\r\n", dummy);
//	exit(-1);
}

//
//
//
//
//
//
int aToken::is_alphabet( char* char_dummy )
{
	return alphabet( char_dummy[0] );
}


