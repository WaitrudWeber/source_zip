#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "vLine.h"


int main ( int argc, char** argv ) {
	vLine** lines = nullptr;
	vLine* p_lines = nullptr;

	printf("lines is going to be memorized.\r\n");

	lines = (vLine**) malloc( sizeof(vLine*) * 10 );

	for( int i=0; i<10; i++ ) {
		p_lines = (vLine*) lines[i];
		p_lines = (vLine*) *(lines + i );
		lines[i] = new vLine();
		lines[i]->setLine( new vPoint( (float)i, 0.0f, 0.0f ), new vPoint( i + 1.0f , 0.0f, 0.0f ) );
	}

	printf("lines is shown on the following.\r\n");

	for( int i=0; i<10; i++ ) {
		p_lines = (vLine*) lines[i];
		p_lines = (vLine*) *(lines + i );

		printf( "%f \r\n", p_lines->p1->x );
	}

	return 0;

}