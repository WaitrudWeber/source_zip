#include <sys/stat.h>
#include <time.h>

#include<stdarg.h>
#include<stdio.h>
//#include<iostream>
#include <windows.h>
// x #include <fileapi.h>

#include "array_counter.h"
#include "sender.h"
#include "Print.h"
#include "aDebug.h"
#include "list_directory.h"
#include "parse.h"

#include "copy_002.h"


int sum(int, ...);
int file_open( char* char_filename ) ;
char* file_all_open( char* char_filename ) ;
int filesize_003( FILE *fp ) ;
int file_list_main(int argc, char **argv) ;

void print_chars( char* char_string) ;
int filetime_main(int argc, char **argv) ;
int base_main(int argc, char **argv) ;
int get_filetimeinfo(FILEDATETIMEINFO* fti) ;

void print_chars_001( char* char_string, int num) ;

char* get_file_time_info_001 (char* filename) ;


//
//
//
//
//
int base_main(int argc, char **argv) {
	HANDLE hTime = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA ffd;
	int *number = 0;

	number = (int*) char_string(4);

	char* path_filename = copyof("C:\\Users\\soresore soreda\\source-002\\aDebug.cpp");
/*	char* spliter = copyof("\\");
	char** layers = split ( path_filename, spliter[0], number );
	char* concat_filename = nullptr;

	printf ("number: %d\r\n", *number);
	for( int i=0; i<*number; i++ ) {
		printf("i:%3d :%s \r\n", i, (char*)layers[i]);
		concat_filename = m_concat( concat_filename, layers[i] );
		concat_filename = m_concat( concat_filename, spliter );
	}
*/
//	printf ("concat_filename: %s \r\n", concat_filename );

	return 0;
}


int get_filetimeinfo(FILEDATETIMEINFO* fti) {

	FILE *wfp;
	char* w_filename;

	char** creationtime = nullptr;
	char* updatetime = nullptr;
	char* accesstime = nullptr;

	BOOL b_success = 0;
	HANDLE hTime = INVALID_HANDLE_VALUE;
	LPFILETIME lp_creationtime;
	LPFILETIME lp_updatetime;
	LPFILETIME lp_accesstime;
	WIN32_FIND_DATA ffd;

	char* print = NULL;

	w_filename = m_concat( fti->filename, "-creationtime.txt");
	wfp = fopen( w_filename, "ab");

	
	creationtime =(char**) char_string( 256 );
	updatetime = char_string( 256 );
	accesstime = char_string( 256 );

	hTime = FindFirstFile( copyof(fti->filename), &ffd );

	b_success = GetFileTime(  hTime, (LPFILETIME)creationtime, (LPFILETIME)accesstime, (LPFILETIME)updatetime );
	b_success = GetFileTime(  hTime, lp_creationtime, lp_accesstime, lp_updatetime );

	print = (char*)lp_creationtime;
	printf( "creationtime: %s\r\n", creationtime[0]);
	printf( "lp_creationtime: %s\r\n", print);
//	printf( "lp_creationtime: %s\r\n", lp_creationtime);

	print_chars(creationtime[0]);
//	print_chars((char *)lp_creationtime);

	fwrite( copyof((char*)creationtime[0]), sizeof(char), array_count(creationtime[0]), wfp);
	fwrite( copyof((char*)"\r\n"), sizeof(char), 2, wfp);
	fwrite( copyof((char*)accesstime), sizeof(char), array_count(accesstime), wfp);


//	fti->lp_creationtime = lp_creationtime;
//	fti->creationtime = creationtime;
/*	fti->updatetime = updatetime;
	fti->lp_updatetime = lp_updatetime;
	fti->accesstime = accesstime;
	fti->lp_accesstime = lp_accesstime;
*/
	fclose(wfp);
	exit(-1);
	return 0;
}

//
char* get_file_time_info_001 (char* filename) {
    struct stat filestat;
	char* result;
	char* result_001;
	printf("int get_file_time_info_001 (char* filename) starts.\r\n");

    stat( filename,&filestat);

	result_001 = char_string ( 256 ); 

	sprintf( result_001, "File modified time %s",
            ctime(&filestat.st_mtime)
          );


	result = (char*) &filestat.st_mtime;

    printf("File modified time %s",
            ctime(&filestat.st_mtime)
          );

    printf("000 File modified time %s\r\n",
            result );

    printf("001 File modified time %s\r\n",
            result_001 );


	printf("int get_file_time_info_001 (char* filename) ends.\r\n");
	return result_001;
}

// get_file_time_info_001

int filetime_main(int argc, char **argv) {
    struct stat filestat;
	char* str_time_info;

	str_time_info = (char*)get_file_time_info_001 ( ".\\001-test-date-001.txt" );
	printf("str_time_info %s \r\n", str_time_info);

	return 0;
}


// input
// char* filename
// ;	creationtime
// ;	updatetime
// :	accesstime
// : HANDLE hTime = INVALID_HANDLE_VALUE;
// : WIN32_FIND_DATA ffd;
// : LPFILETIME lp_creationtime;
// : LPFILETIME lp_updatetime;
// : LPFILETIME lp_accesstime;
//
//
int filetime_main_001(int argc, char **argv) {
	SYSTEMTIME st;

	int success = 0;
	char* creationtime = nullptr;
	char* updatetime = nullptr;
	char* accesstime = nullptr;

	BOOL b_success = 0;
	HANDLE hTime = INVALID_HANDLE_VALUE;
	FILETIME creationtime_003;
	FILETIME accesstime_003;
	FILETIME updatetime_003;
	FILETIME creationtime_002;
	FILETIME accesstime_002;
	FILETIME updatetime_002;
	FILETIME creationtime_001;
	FILETIME accesstime_001;
	FILETIME updatetime_001;
	LPFILETIME lp_creationtime;
	LPFILETIME lp_updatetime;
	LPFILETIME lp_accesstime;
	WIN32_FIND_DATA ffd;
	LPFILETIME lp_updatetime_256;
	LPFILETIME lp_accesstime_256;
	LPFILETIME lp_creationtime_256;

    struct stat filestat;


	char* print = NULL;

    stat(".\\001-test-date-001.txt",&filestat);
    /* newline included in ctime() output */
  /*  printf(" File access time %s",
            ctime(&filestat.st_atime)
          );
    printf(" File modify time %s",
            ctime(&filestat.st_mtime)
          );*/
    printf("File changed time %s",
            ctime(&filestat.st_ctime)
          );
/*    printf("  File birth time %s",
            ctime(&filestat.st_birthtime)
          );
*/

	creationtime = char_string( 256 );
	updatetime = char_string( 256 );
	accesstime = char_string( 256 );

	lp_creationtime_256 = (LPFILETIME)char_string( 256 );
	lp_updatetime_256   = (LPFILETIME)char_string( 256 );
	lp_accesstime_256   = (LPFILETIME)char_string( 256 );

//	hTime = FindFirstFile( copyof("C:\\Users\\soresore soreda\\source-002\\aDebug.cpp"), &ffd );
//	hTime = FindFirstFile( copyof(".\\005-Main.cpp.txt"), &ffd );
	hTime = FindFirstFile( copyof(".\\001-test-date-001.txt"), &ffd );

	printf("(char*)ffd.cFileName %s\r\n", (char*)ffd.cFileName);

	b_success = GetFileTime(  hTime, (LPFILETIME)creationtime, (LPFILETIME)accesstime, (LPFILETIME)updatetime );
	b_success = GetFileTime(  hTime, lp_creationtime, lp_accesstime, lp_updatetime );
	b_success = GetFileTime(  hTime, &creationtime_001, &accesstime_001, &updatetime_001 );

	b_success = FileTimeToLocalFileTime((LPFILETIME) &creationtime_001, (LPFILETIME) &creationtime_002);

	b_success = FileTimeToSystemTime((LPFILETIME)&creationtime_001, &st);
	printf("creattiontime:%d-%d-%d %d:%d:%d:%d\n", st.wYear,
		st.wMonth,
		st.wDay,
		st.wHour,
		st.wMinute,
		st.wSecond,
		st.wMilliseconds);

	b_success = FileTimeToSystemTime((LPFILETIME)&creationtime_002, &st);
	printf("creattiontime local:%d-%d-%d %d:%d:%d:%d\n", st.wYear,
		st.wMonth,
		st.wDay,
		st.wHour,
		st.wMinute,
		st.wSecond,
		st.wMilliseconds);


	b_success = FileTimeToSystemTime((LPFILETIME)&updatetime_002, &st);
	printf("updatetime local:%d-%d-%d %d:%d:%d:%d\n", st.wYear,
		st.wMonth,
		st.wDay,
		st.wHour,
		st.wMinute,
		st.wSecond,
		st.wMilliseconds);

	creationtime_003.dwLowDateTime  = creationtime_001.dwHighDateTime;
	creationtime_003.dwHighDateTime = creationtime_001.dwLowDateTime;

	b_success = FileTimeToSystemTime( (LPFILETIME)&creationtime_003, &st );
	printf("frip work:%d-%d-%d %d:%d:%d:%d\n", st.wYear,
		st.wMonth,
		st.wDay,
		st.wHour,
		st.wMinute,
		st.wSecond,
		st.wMilliseconds);


	// x printf( "lp_creationtime: %d: %d\r\n", lp_creationtime, *lp_creationtime);
	// x printf( "lp_creationtime: %d: %d\r\n", creationtime, *creationtime);
	printf( "creationtime: %d\r\n", creationtime);
	printf( "lp_creationtime: %d\r\n", lp_creationtime);
	printf( "lp_creationtime_256: %d\r\n", lp_creationtime_256);

	print = (char*)lp_creationtime;
	printf( "print lp_creationtime: %s\r\n", print);

	print_chars_001 ( (char*) &creationtime_003, 8);

	return 0;
}

//
//
//
//
//
void print_chars_001( char* char_string, int num) {
	FILE* wfp;
	FILEDATETIMEINFO fti;
	long print;
	time_t timestamp_sec; /* timestamp in second */
	char* filename = (char*) "001-print_file_time-001\.txt";

	printf("void print_chars_001( char* char_string, int num) starts.\r\n");

	fti.filename = (char*) filename;
	int ab = get_filetimeinfo(&fti);

	wfp = fopen ( "001-print_file_time-001\.txt", "ab");

	fprintf( wfp, "FILEDATETIMEINFO 001-print_file_time-001\.txt %ld\r\n");
	fprintf( wfp, "param size: timestamp %d FILEDATETIMEINFO %d / filename %d remain %d\r\n", 
		sizeof(timestamp_sec), sizeof(fti), sizeof(fti.filename), sizeof(fti) - sizeof(fti.filename) );

	print = (long) char_string;
	fprintf( wfp, "print char_string long %ld %d bytes.\r\n", print, num);

	for( int i=0; i<num; i++ ) {
		fprintf( wfp, "n %3d: cn: %3d \r\n", i, char_string[i]);
	}

	fclose(wfp);

	printf("void print_chars_001( char* char_string, int num) ends.\r\n");
}


//
//
//
//
//
void print_chars( char* char_string) {
	printf("void print_chars( char* char_string) starts.\r\n");
	for( int i=0; 1; i++ ) {
		if ( char_string[i] == '\0' ) break;
		printf("n %3d: cn: %3d \r\n", i, char_string[i]);
	}
	printf("void print_chars( char* char_string) ends.\r\n");

}

//
//
//
//
//
int file_list_main(int argc, char **argv) {

	char* filename;
	char **file_list;
	int number;
/*	FileControler *fc = nullptr;

	if ( argc < 2 ) {
		printf( "argc == %d \r\n", argc );
		exit(-1);
	}

//	debug_allow_print_console = 1;
	//err_msg_001 ( "main: %d", argc);

	fc = new FileControler ();
	fc->print_char((char*)".\\*.cpp");
	printf("get_files: start: %s : %s\r\n", argv[1], copyof(".\\*.cpp"));
	// x file_list = (char**) fc->get_files (  (char*)argv[1] , number );
	file_list = (char**) fc->get_files (  copyof(".\\*.cpp") , &number );
	printf("get_files: end\r\n");

	fc->print_strings();

	printf("numnrt: %5d\r\n", number);
	for ( int i=0; i<(number); i++ ) {
		printf( "|%5d|%s|\r\n", i, *(file_list + i) );
	}
*/
	return 0;
}

//
//
//
//
//
//
int filesize_003( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

//
// 
//
//
//
char* file_all_open( char* char_filename ) {
	FILE *fp;

//	printf("file_all_open\r\n");
	char* dummy = char_string ( 256 * 256 );
	fp = fopen( char_filename, "rb");
	int file_end = filesize_003 ( fp );

	for ( int i=0; i< file_end; i++ ) {
//		printf("i: %4d/%4d ", i, file_end);
		m_fread( dummy, 1, fp );
		token = put_token( dummy[0] );
//		printf("dummy: %c|%3d|\r\n", dummy[0], dummy[0] );
	}

	fclose (fp);
	return token;
}

//
//
//
//
//
int file_open( char* char_filename ) {
	FILE *fp;
	char* dummy = char_string ( 256 * 256 );

	fp = fopen( char_filename, "rb");
	int file_end = filesize_003 ( fp );
	for ( int i=0; i< file_end; i++ ) {
		m_fread( dummy, 1, fp );
	}

	fclose (fp);
}

int sum(int num_args, ...) {
   int val = 0;
   va_list ap;
   int i;

   va_start(ap, num_args);
   for(i = 0; i < num_args; i++) {
      val += va_arg(ap, int);
   }
   va_end(ap);
 
   return val;
}
