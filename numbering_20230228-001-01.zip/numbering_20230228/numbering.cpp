#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "array_counter.h"
#include "parse.h"
#include "aToken.h"
#include "timestamp.h"

#include "copy_002.h"

int numbering_parse ( char* filename ) ;
int filesize( FILE *fp ) ;
void backward( char *dummy, char *token ) ;
void put_letter_to_file( char char_dummy, char* filename ) ;
void put_int_to_file( int int_dummy, char* filename ) ;

void fput_int_to_file( int int_dummy, FILE *wfp ) ;
void fput_letter_to_file( char char_dummy, FILE *wfp ) ;
void takeout_line_end_after_colon ( char* filename ) ;

int is_number( char char_dummy ) ;
void output_to_stripe ( char* filename ) ;
void write_tag( char* char_string, FILE *wfp ) ;
int numbering_main ( int argc, char *argv[] ) ;

int main ( int argc, char *argv[] ) {

	numbering_main( 2, argv );
//	filetime_main( argc, argv );

	return 0;
}

int numbering_main ( int argc, char *argv[] ) {

	initialize_parse();

	numbering_parse ( argv[1] );

	printf("line feed yen_r %d\r\n", '\r');
	printf("tab 0x0A 0x09 %c %c\r\n", 0x0A, 0x09 );

	return 0;
}



//
//
//
//
//
int parse_org ( char* filename ) {
	FILE *fp;
	char dummy[256*256];
	char* w_filename;

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	dummy[0] = '\0';
	w_filename = m_concat( filename, ".txt");

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		if ( m_raw == 1 )  {
			put_int_to_file( m_line, w_filename ) ;
		}
		put_letter_to_file( dummy[0], w_filename );
//		printf("line %d raw %d filename %s\r\n", m_line, m_raw, w_filename );
	}

	fclose(fp);
}

//
//
//
//
//
int numbering_parse ( char* filename ) {
	FILE *fp, *wfp;
	char dummy[256*256];
	char* w_filename;
	// Add: 20191218
	printf("numbering_parse: filename %s \r\n", filename); 
	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	dummy[0] = '\0';
	w_filename = m_concat( filename, ".txt");
	wfp = fopen( w_filename, "ab");

	// put file name
	int ac =  array_count ( filename );
	fwrite( filename, sizeof(char), ac, wfp);
	// Add: 20191218

	char* char_timestamp = get_file_time_info_001 ( filename );
	int ac_timestamp = array_count ( char_timestamp );
	fwrite( copyof((char*)" "), sizeof(char), 2, wfp);
	fwrite( char_timestamp, sizeof(char), ac_timestamp , wfp);
	fwrite( copyof((char*)"\r\n"), sizeof(char), 2, wfp);
	printf("char_timestamp: %s \r\n", char_timestamp);

	/*char* char_timestamp = get_datetime_info ();
	int ac_timestamp = array_count ( get_datetime_info () );
	fwrite( copyof((char*)" "), sizeof(char), 2, wfp);
	fwrite( char_timestamp, sizeof(char), ac_timestamp , wfp);
	fwrite( copyof((char*)"\r\n"), sizeof(char), 2, wfp);
	printf("char_timestamp: %s \r\n", char_timestamp);*/

	// first line
	fput_int_to_file( m_line, wfp ) ;

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		fput_letter_to_file( dummy[0], wfp );
		if ( m_raw == 1 ) {
			fput_int_to_file( m_line, wfp ) ;
		}
		printf("line %d raw %d filename %s\r\n", m_line, m_raw, w_filename );
	}

	fclose(wfp);
	fclose(fp);

	// takeout the line end after colon if it has it.
	// takeout_line_end_after_colon ( w_filename ) ;

	output_to_stripe ( w_filename ) ;
}

//
//
//
//
//
void output_to_stripe ( char* filename ) {
	FILE *fp, *wfp;
	char dummy[ 256 * 256 ];
	char* w_filename;
	int letter_mode = 0;
	int dark = 0;

	// skip       : 0
	// \r         : 1
	// \n         : 2
	// <td/><td>  : 3
	initialize_parse();

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	dummy[0] = '\0';
	w_filename = m_concat( filename, ".txt");
	wfp = fopen( w_filename, "ab");

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		switch( letter_mode ) {
		case 0:
			if ( dummy[0] == '\r' ) {
				letter_mode = 1;
			} else if ( dummy[0] == '\n' ) {
				letter_mode = 2;
			} else if ( dummy[0] == 0x09 ) {
				letter_mode = 3;
			} else {
				fput_letter_to_file( dummy[0], wfp );
			}
			break;
		case 1:
			switch( dummy[0] ) {
			case '\n':
				letter_mode = 2;
				break;
			default:
				fput_letter_to_file( '\r', wfp );
				fput_letter_to_file( dummy[0], wfp );
				letter_mode = 0;
				break;
			}
			break;
		case 2:
			// fput_letter_to_file( '\r', wfp );
			// fput_letter_to_file( '\n', wfp );
			switch( dark ) {
			case 0:
				write_tag ( "</font></td></tr>\r\n<tr><td bgcolor=\"#AAAAAA\"><font color=\"#000000\">" , wfp);
				dark = 1;
				break;
			case 1:
				write_tag ( "</font></td></tr>\r\n<tr><td bgcolor=\"#AAAAFF\"><font color=\"#000000\">" , wfp);
				dark = 0;
				break;
			}
			//exit(-1);
			letter_mode = 0;
			break;
		case 3: // Tab next 0x09
			write_tag ( "&#8195;" , wfp);
			fput_letter_to_file( dummy[0], wfp );
			letter_mode = 0;
			break;
		}
		printf( "output_to_stripe: line %d raw %d filename %s\r\n", m_line, m_raw, w_filename );
	}

	fclose(wfp);
	fclose(fp);
}

//
//
//
//
//
void write_tag( char* char_string, FILE *wfp ) {

	fwrite( char_string, sizeof(char), array_count(char_string), wfp);
}

//
//
//
//
//
void takeout_line_end_after_colon ( char* filename ) {
	FILE *fp, *wfp;
	char dummy[ 256 * 256 ];
	char* w_filename;
	int letter_mode = 0;

	// skip       : 0
	// number     : 1
	// colon : 2
	initialize_parse();

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	dummy[0] = '\0';
	w_filename = m_concat( filename, ".txt");
	wfp = fopen( w_filename, "ab");

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		switch( letter_mode ) {
		case 0:
			if ( is_number ( dummy[0] ) == 1 ) {
				letter_mode = 1;
			}
			fput_letter_to_file( dummy[0], wfp );
			break;
		case 1:
			switch( dummy[0] ) {
			case ' ':
				letter_mode = 1; // still 1.
				break;
			case ':':
				letter_mode = 2; 
				break;
			}
			fput_letter_to_file( dummy[0], wfp );
			break;
		case 2:
			switch( dummy[0] ) {
//			case ' ':
//				fput_letter_to_file( dummy[0], wfp );
//				break;
			case '\r':
				break;
			case '\n':
				letter_mode = 0; 
				break;
			default:
				fput_letter_to_file( dummy[0], wfp );
				break;
			}
			break;
		}
		printf( "line %d raw %d filename %s\r\n", m_line, m_raw, w_filename );
	}

	fclose(wfp);
	fclose(fp);


	output_to_stripe ( w_filename ) ;
}

//
//
//
//
//
int is_number( char char_dummy ) {

	if ( '0' <= char_dummy && '9' >= char_dummy ) return 1;

	return 0;
}

//
//
//
//
//
void fput_int_to_file( int int_dummy, FILE *wfp ) {
	char dummy[256];

	sprintf( dummy, "%3d :", int_dummy );
	// line end is put when put use "a+" and fprintf.
	fwrite( dummy, sizeof(char), 5, wfp);
}

//
//
//
//
//
void put_int_to_file( int int_dummy, char* filename ) {
	FILE *fp;
	char dummy[256];

	sprintf( dummy, "%3d :", int_dummy );

	// line end is put when put use "a+" and fprintf.
	fp = fopen( filename, "ab");
	fwrite( dummy, sizeof(char), 3, fp);

	fclose(fp);
}

//
//
//
//
//
void fput_letter_to_file( char char_dummy, FILE *wfp ) {
	fwrite( &char_dummy, sizeof(char), 1, wfp);
}

//
//
//
//
//
void put_letter_to_file( char char_dummy, char* filename ) {
	FILE *fp;

//	FILE *fp = fopen( filename, "a+");
	fp = fopen( filename, "ab");
	fwrite( &char_dummy, sizeof(char), 1, fp);
	fclose(fp);
}

int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

