#include <stdio.h>
#include <stdlib.h>

#include "aHashMap.h"

// X
//aHashMap::aHashMap() {
//}

// X
//aHashMap () {
//}

// X
//aHashMap::aHashMap() {
//
//	return 1;
//}

// X
//aHashMap() {
//	return 1;
//}

/*
int aHashMap::aHashMap() {
	h_name = (char**) malloc ( sizeof(char**) * size );
	if( h_name == nullptr ) return -1;

	h_value = (char**) malloc ( sizeof(char**) * size );
	if( h_value == nullptr ) return -1;

	return 1;
}
*/

void aHashMap::print () {

	for( int i=0; i<num; i++ ) {
		printf( "%04d:%s=%s\n", i, this->h_name[i], this->h_value[i]);
	}
}


int aHashMap::put_value (char* n, char* v) {

	this->num++;
//	printf("%d / %d\n", num, size);

	if ( num >= size ) {
		size = size * 2;
		printf("%d / %d\n", num, size);
		h_name = (char **) realloc( h_name, sizeof ( char** ) * size );
		h_value = (char **) realloc( h_value, sizeof ( char** ) * size );
	}

	// x h_name[ num - 1 ] = (char*)n;
	// x *(h_name + num - 1 ) = (char*)n;
	// x *(h_name + num - 1 ) = (char*)"aaa";
	// x h_name[ num - 1 ] = (char*)"aaa";

// xx	printf("%s %s\n", n, h_name[0] );
// x	printf("%s %s\n", n, *h_name );
// o	printf("%s %s\n", n, h_name );

	// Do not use constructor.
	if ( h_name == nullptr || h_value == nullptr ) {
// o		printf("allocation from now.\n");
		this->size = 10;
		h_name = (char**) malloc ( sizeof(char**) * size );
		h_value = (char**) malloc ( sizeof(char**) * size );
//		printf("end allocation.\n");
	}

	h_name[ num - 1 ] = (char*)n;
	h_value[ num - 1 ] = (char*)v;
//	printf("%d / %d %s %s has finished!\n", num, size, h_name[ num - 1 ], h_value[ num - 1 ]);

	return 1;

}

char* aHashMap::get_value (char* n) {

	for( int i=0; i<num; i++) {
		if ( compare( n, h_name[i] ) == 1 ) {

			return h_value[i];

		}
	}

	return nullptr;

}

int aHashMap::compare ( char* tkn, char* m ) {

	int count_t = array_count( m );
	int count_m = array_count( m );

	if ( count_t != count_m ) return -1;

	// does not match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) return -1;
	}

	return 1;
}

int aHashMap::array_count( char *ary )
{
	char c;
	int count = 0;
	for ( ;; ) {
		c = *ary;
		if ( c == '\0' ) {
			break;
		}
		ary++;
		count++;
	}

	return count;
}



