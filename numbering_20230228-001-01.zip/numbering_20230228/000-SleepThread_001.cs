﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Diagnostics;
using System.Threading;


namespace WindowsFormsApp3
{
    // https://www.dotnetperls.com/sleep
    class SeepThread_001
    {
        public void aMain()
        {
            //
            // Demonstrates 3 different ways of calling Sleep.
            //
            var stopwatch = Stopwatch.StartNew();
            Thread.Sleep(0);
            stopwatch.Stop();
            Console.WriteLine(stopwatch.ElapsedMilliseconds);
            Console.WriteLine(DateTime.Now.ToLongTimeString());

            stopwatch = Stopwatch.StartNew();
            Thread.Sleep(5000);
            stopwatch.Stop();
            Console.WriteLine(stopwatch.ElapsedMilliseconds);
            Console.WriteLine(DateTime.Now.ToLongTimeString());

            stopwatch = Stopwatch.StartNew();
            System.Threading.Thread.Sleep(1000);
            stopwatch.Stop();
            Console.WriteLine(stopwatch.ElapsedMilliseconds);

            //
            // Bonus: shows SpinWait method.
            //
            stopwatch = Stopwatch.StartNew();
            Thread.SpinWait(100000 * 10000);
            stopwatch.Stop();
            Console.WriteLine(stopwatch.ElapsedMilliseconds);
        }

    }


}
