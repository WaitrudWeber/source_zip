#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>

#include <windows.h>

#include "array_counter.h"
#include "Print.h"
#include "parse.h"

#include "sender.h"
#include "aDebug.h"
#include "debug_msg.h"

#include "aToken.h"


char msg[2048];

int parse ( char* filename ) ;
int filesize( FILE *fp ) ;
void backward( char *dummy, char *token ) ;
void slide_to_back ( char *msg, int i, int count ) ;
char* change_line_end (char* msg) ;

void place_char ( char *p_char, char c ) ;
void print_memories ( char *msg );

int main ( int argc, char *argv[] ) {
	int success;
	char* err_msg_3 = (char *) copyof ( "\r\nerr_msg 3\n\n\n\n" );

	// initialize_parse();
	// success = parse ( argv[1] );

	char* msg = copyof ( "err_msg" );
	char* msg_2 = copyof ( "err_msg 2" );
	char* result_001;


	// To ensure place char.
	place_char ( msg, 'a' ) ;
	place_char ( msg + 1 , 'b' ) ;
	result_001 = err_msg_001 ( "mainloop: msg: %s ", msg );
	// exit(-1);
	// the result is the below
	// Thu Mar 07 14:26:29 201 start of place_char   :a:  
	// Thu Mar 07 14:26:29 201 13767520 10 13 97ar   :a:  
	// Thu Mar 07 14:26:29 201 end of place_char r   :a:  
	// Thu Mar 07 14:26:29 201 start of place_char   :a:  
	// Thu Mar 07 14:26:29 201 13767521 10 13 98ar   :a:  
	// Thu Mar 07 14:26:29 201 end of place_char r   :a:  
	// Thu Mar 07 14:26:29 201 mainloop: msg: abr_msg   :a:  
	// Good at 20190307

	result_001 = err_msg_001 ( "check of slide_to_back: |%s| ", msg_2 );
	int cnt = array_count( msg_2 );
	cnt++;
	msg_2 = (char *) realloc ( msg_2, sizeof(char*) * cnt ); // Do not forget to place cast (char *)
	// slide_to_back ( msg_2, 3, cnt );
	result_001 = err_msg_001 ( "check of slide_to_back: |%s| ", msg_2 );
	// exit(-1);
	// tests-001-002.txt at 20190307
	// Thu Mar 07 16:19:15 201 check of slide_to_back: |err_msg 2| 10 c=  0 c=  :a:  
	// Thu Mar 07 16:19:15 201 check of slide_to_back: |err_msg 2| 10 c=  0 c=  :a:  
	// Good at 20190307

	result_001 = err_msg_001 ( "mainlootin: |%s| ", err_msg_3 );
	result_001 = change_line_end ( err_msg_3 );
	result_001 = err_msg_001 ( "mainlootin: |%s| ", err_msg_3 );

	return 0;
}

//
//
//
//
//
char* change_line_end (char* msg) {
	int previous_c;
	char* result_001;

	result_001 = err_msg_001 ( "change_line_end: msg: %s ", msg );
	// exit(-1);

	previous_c = 0;
	int count = array_count( msg );
	for( int i=0; i<count; i++ ) {
		result_001 = err_msg_001 ( "change_line_end: loop i %d count %d ", i, count );
		result_001 = err_msg_001 ( "change_line_end: msg: %s ", msg );
		// exit(-1);

		char c = *( msg + i ) ;
		switch ( c ) {
		case '\r':
			break;
		case '\n':
			if ( previous_c == '\r' ) {
				break;
			} else {
				result_001 = err_msg_001 ( "start ");
				count++;
				i++;
				realloc ( msg, sizeof(char*) * count );
				result_001 = err_msg_001 ( "realloced ");
				slide_to_back ( msg, i - 1, count);
				//input = msg + i - 2;
				//msg[ i - 2 ] = '\r';

				place_char( &msg[ i - 2 ], '\r' );
				// x place_char( msg + i - 2, '\r' );
				// x *( msg + i -2 ) = '\r' ;
				result_001 = err_msg_001 ( "end ");
				//exit(-1);
			}
			break;
		}

		previous_c = c;
	}

	result_001 = err_msg_001 ( "end of change_line_end ");
	return msg;
}

//
//
//
// '\r': 13
// '\n': 10
void place_char ( char *p_char, char c ) {
	char* result_001;
	result_001 = err_msg_001 ( "start of place_char ");
	// o result_001 = err_msg_001 ( "%d %d %d", p_char, 0, c );
	// x result_001 = err_msg_001 ( "%d %c %d", p_char, *p_char, c );
	//   4249052 3 13
	// x result_001 = err_msg_001 ( "%d %c %d", p_char, *p_char, c );
	// print_memories( p_char ) ;
	result_001 = err_msg_001 ( "%d %d %d %d", p_char, '\n', '\r', c );
	*p_char = (char) c;
	// o *result_001 = (char) c;
	//*p_char = *result_001;
	result_001 = err_msg_001 ( "end of place_char ");
}

//
//
//
//
//
void print_memories ( char *msg ) {
	int count = array_count(msg);

	printf("msg:|%s|\r\n", msg); // the left works well.
	for( int i=0; i<count; i++ ) {
		// x printf("|%s|%s||\r\n", msg[i], msg ); // the left doesn't work.
		printf("|%s|%s||\r\n", *(msg +i ), msg ); // the left doesn't work.
	}
}

//
//
//
//
//
void slide_to_back ( char *msg, int start_i, int count ) {
	char *result_001;
	char c;

	result_001 = err_msg_001 ( "slide_to_back: start ");

	for( int i = start_i; i<count - 1; i++ ) {
		result_001 = err_msg_001 ( "slide_to_back: loop satrt i=%d count %d ", i , count);
		c = *( msg + i );
		place_char ( msg + i + 1, c ); // slide 1 to back and ensured to place.
		result_001 = err_msg_001 ( "slide_to_back: loop end   i=%d count %d c=%3d c=%c", i , count, c, c );
	}

	result_001 = err_msg_001 ( "slide_to_back: end ");

}

//
//
//
//
//
int parse ( char* filename ) {
	FILE *fp;
	aToken *iToken = nullptr;
	char *parse_token;
	int previous_index = 0;

	iToken = new aToken();
	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end && i<100; i++ ) {
		// DEBUG
		previous_index = i;
		printf("parse: i=%d\r\n", i);

		parse_token = iToken->getToken( fp, &i, &file_end );
		printf("parse_token: |%s|\r\n", parse_token );
		// this cannot scope the below function, but sucope it in aDebug.cpp at 20190303
		// DEBUG_SUB( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// DEBUG ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// o debug_msg_001 ();
		DEBUG_002 ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		printf("msg: |%s|\r\n", msg );

		if ( m_compare( parse_token, (char *) "void" ) == 1 ) {
			printf("void\r\n");
			exit( -1);
		} else {
//			m_free_token( parse_token );
//			free_main_token (); //scope
			iToken->free_main_token ();
//			free( parse_token );
//			token = (char*)"\0";
		}

		// DEBUG
		if ( previous_index > i ) {
			printf("previous_index > i\r\n");
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		} else if ( previous_index == i ) {
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		}

	}

	fclose(fp);

	return 1;
}

//
//
//
//
//
int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

