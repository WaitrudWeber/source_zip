#include "aHashMap.h"
#include "sHtml.h"

#include <stdio.h>

void sHtml::set_tag_name(char* tname) {

	this->tag_name = tname;


}

void sHtml::print() {

	printf( "isHead=%d\n", this->isHead );
	printf( "tag_name=%s\n", this->tag_name );
	this->values.print();
	this->sheets_values.print();
}

