#ifndef _AHASHMAP_
#define _AHASHMAP_

class aHashMap {

	public:


	private:
		int num = 0;
		int size = 10;
		char** h_name = nullptr;
		char** h_value = nullptr;

	public:
		//HashMap (){ return 1; };
		HashMap () {
			/*this->size = 10;
			h_name = (char**) malloc ( sizeof(char**) * size );
			if( h_name == nullptr ) return -1;

			h_value = (char**) malloc ( sizeof(char**) * size );
			if( h_value == nullptr ) return -1;

			return 1; */
		}; 
		int put_value (char* n, char* v);
		char* get_value (char* n);
		void print ();

	private:
		int compare ( char* tkn, char* m );
		int array_count( char *ary );


};

#endif

