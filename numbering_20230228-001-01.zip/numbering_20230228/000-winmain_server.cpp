//#include <iostream>	  // std::cout
//#include <algorithm>	  // std::max

// Special Thanks to the below
// http://gurigumi.s349.xrea.com/programming/visualcpp/sdk_scroll1.html

#include <windows.h>
#include "resource.h"

#include "array_counter.h"
#include "server.h"
#include "mythreadfunction.h"

HINSTANCE hInst;

ATOM MyRegisterClass(HINSTANCE hInstance);
BOOL InitInstance(HINSTANCE, int);
LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

int	start_thread = 0;

void SetText ( HWND	hWnd ) ;
void WriteText ();

int	min	( int x, int y );
int	max	( int x, int y );

int	min	( int x, int y ) {
	if	( x	<= y ) return x;
	else return y;
}

int	max	( int x, int y ) {
	if	( x	>= y ) return x;
	else return y;
}

//
//
//
//
//
int	APIENTRY WinMain(HINSTANCE hInstance,
					 HINSTANCE hPrevInstance,
					 LPSTR lpCmdLine,
					 int nCmdShow)
{
	MSG	msg;
	MyRegisterClass(hInstance);

	// Application Initialization 
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	// Message Process
	while (GetMessage(&msg,	NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return (int) msg.wParam;

}

//
//
//
//
// hWnd	<- hEdit
void SetText ( HWND	hWnd) {
	BOOL SetWindowTextA_return	= false;
//	HWND	  hWnd,
	LPCSTR	lpString;

	//	substance of server_buffer_recv	in server.cpp
	lpString =	( LPCSTR ) server_buffer_recv;
	SetWindowTextA_return = SetWindowTextA( hWnd, lpString	) ;

//	SetWindowTextA_return = SetWindowTextA( hWnd, "TEST"	);
}

//
//	Function: MyRegisterClass()
//
//	Purpose: Booking window.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize	= sizeof(WNDCLASSEX);

	wcex.style = CS_HREDRAW	| CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra	= 0;
	wcex.cbWndExtra	= 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(NULL , IDI_APPLICATION);
	wcex.hCursor = LoadCursor(NULL,	IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName =	MAKEINTRESOURCE(IDC_HP);
	wcex.lpszClassName = TEXT("HP");
	wcex.hIconSm = LoadIcon(NULL , IDI_APPLICATION);

	return RegisterClassEx(&wcex);
}

//
//	 Function: InitInstance(HINSTANCE, int)
//
//	 Purpose: Creating main	window
//
BOOL InitInstance(HINSTANCE	hInstance, int nCmdShow)
{
   HWND	hWnd;

   hWnd	= CreateWindow(TEXT("HP"), TEXT("HP"), WS_OVERLAPPEDWINDOW,
	  CW_USEDEFAULT, 0,	CW_USEDEFAULT, 0, NULL,	NULL, hInstance, NULL);

   if (!hWnd)
   {
	  return FALSE;
   }

   ShowWindow(hWnd,	nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//	Function: WndProc(HWND,	UINT, WPARAM, LPARAM)
//
//	Porpuse: Controlling window	messages.
//
//	WM_CREATE  - The Process when it creates window.
//	WM_SIZE	   - The Process when it changes its size of window.
//	WM_VSCROLL - The Process when it scrolls window.
//	WM_COMMAND - The Process of	Application	menu.
//	WM_DESTROY - The Process when it destroyes window for its end.
//
LRESULT	CALLBACK WndProc(HWND hWnd,	UINT message, WPARAM wParam, LPARAM	lParam)
{
	int	wmId, wmEvent;
	HWND static	hEdit;
	static int wx;		// Width of	Screen
	static int wy;		// Height of Screen
	static int y;		// Vertical	Position of	Scroll
	static int dy;		// Acceleration	of Scroll
	static int range;	// Length of Scroll
	static int yclient;	// Height of Client	Area which has surely screen.

	switch (message)
	{
		case WM_CREATE:
			hEdit =	CreateWindowEx(WS_EX_CLIENTEDGE, //	Window Style
				TEXT("EDIT"),
				TEXT("Special Thanks to	http://gurigumi.s349.xrea.com/programming/visualcpp/sdk_scroll1.html"),
				WS_CHILD | WS_VISIBLE |	ES_MULTILINE | WS_VSCROLL,
				0, 0,
				0, 0,
				hWnd,
				(HMENU)IDC_EDIT1,
				hInst,
				NULL);
			wx = GetSystemMetrics(SM_CXSCREEN);
			wy = GetSystemMetrics(SM_CYSCREEN);
			break;

		case WM_SIZE:
			yclient	= HIWORD(lParam);
			range =	wy - yclient;
			y =	min(y, range);
			SetScrollRange(hEdit, SB_VERT, 0, range, FALSE);
			SetScrollPos(hEdit,	SB_VERT, y,	TRUE);
			MoveWindow(hEdit, 0, 0,	LOWORD(lParam),	HIWORD(lParam),	TRUE);

			// x	SetText( hEdit );
			break;

		case WM_VSCROLL:
			switch (LOWORD(wParam))
			{
				case SB_LINEUP:
					dy = -1;
					break;
				case SB_LINEDOWN:
					dy = 1;
					break;
				case SB_THUMBPOSITION:
					dy = HIWORD(wParam)	- y;
					break;
				case SB_PAGEDOWN:
					dy = 10;
					break;
				case SB_PAGEUP:
					dy = -10;
					break;
				default:
					dy = 0;
					break;
			}
			dy = max( -y, min(dy, range	- y) );
			if (dy != 0)
			{
				y += dy;
				ScrollWindow( hEdit, 0,	-dy, NULL, NULL);
				SetScrollPos( hEdit, SB_VERT, y, TRUE);
				UpdateWindow( hEdit	);
			}
			break;

		case WM_COMMAND:
			wmId = LOWORD(wParam);
			wmEvent	= HIWORD(wParam);
			// wmid	means messages when	user selects menu.
			switch (wmId)
			{
				case IDM_EXIT:
					DestroyWindow(hWnd);
					break;
				default:
					return DefWindowProc(hWnd, message,	wParam,	lParam);
			}
			break;
		case WM_DESTROY:
			thread_dispose =	1;
			PostQuitMessage(0);
			break;
		default:
			if (	start_thread ==	0 )	{
				start_thread = 1;
				//server_main();
				multithread	() ;
			}
			//20181222
			switch (	update_thread )	{
			case	0:
				break;
			case	1:
				SetText( hEdit );
				update_thread =	2;
				break;
			case	2:
				WriteText();
				update_thread =	0;
				break;
			}
			return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}

void WriteText ()
{
	//	write shared memory
	writetext();
}


// https://stackoverflow.com/questions/5690333/get-text-from-an-edit-control
//
// GetWindowText(hWndCtrl, buff, 1024);
// BOOL	SetWindowTextA(
//	  HWND	 hWnd,
//	  LPCSTR lpString
//	);

