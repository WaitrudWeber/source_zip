#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "parse.h"
#include "aToken.h"

// 20190227
// When we use tokenizer, we just call getToken.
//
//
//
char* aToken::getToken( FILE *fp, int *index, int *file_end )
{
	char dummy[256];
	int mode_token = 0; // skip
	// 0: skip
	// 1: 
	// 2: 
	int breakable = 0;
	dummy[0] = '\0';

	for ( int i=*index; i<*file_end && breakable == 0; i++ ) {
		m_fread ( dummy, 1, fp);
		printf("dummy=%s\r\n", dummy );
		switch(mode_token) {
		case 0:
			switch ( dummy[0] ) {
			case ' ':
				break;
			default:
				if ( is_alphabet( dummy ) == 1 ) {
					mode_token = 1;
				} else {
					mode_token = 2;
				}
				token = put_token ( dummy[0] );
				printf("token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				break;
			}
			break;
		case 1:
			switch ( dummy[0] ) {
			case ' ':
				break;
			default:
				token = put_token ( dummy[0] );
				printf("token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				break;
			}
			break;
		case 2:
			switch ( dummy[0] ) {
			case ' ':
				breakable = 1;
				break;
			default:
				token = put_token ( dummy[0] );
				printf("token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				break;
			}
			break;
		}
	}

	backward( dummy );
	printf("token=%s\r\n", token);
	exit(-1);

	return token;
}

void aToken::backward( char *dummy) {
	int i = 0;
	char c1, c2;
	int cnt_dummy = array_count ( dummy ) ;

	for ( int i=0; i<cnt_dummy/2 && i<256*256; i++ ) {
		c1 = *( dummy + cnt_dummy - 1 - i );
		c2 = *( dummy + i );
		*( dummy + cnt_dummy -1 - i ) = c2;
		*( dummy + i ) = c1;
		printf("i %d %c %c\r\n",i,  c1, c2);
	}

	printf("backward dummy %s\r\n", dummy);
//	exit(-1);
}

//
//
//
//
//
//
int aToken::is_alphabet( char* char_dummy )
{
	return alphabet( char_dummy[0] );
}


