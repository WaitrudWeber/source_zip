#include<stdarg.h>
#include<stdio.h>
//#include<iostream>
#include <windows.h>

#include "array_counter.h"
#include "sender.h"
#include "Print.h"
#include "aDebug.h"
#include "list_directory.h"
#include "parse.h"

int sum(int, ...);
int file_open( char* char_filename ) ;
char* file_all_open( char* char_filename ) ;
int filesize( FILE *fp ) ;

int main(int argc, char **argv) {

	char* filename;
	char **file_list;
	int number;
	FileControler *fc = nullptr;

	if ( argc < 2 ) {
		printf( "argc == %d \r\n", argc );
		exit(-1);
	}

	debug_allow_print_console = 1;

	fc = new FileControler ();
	fc->print_char((char*)".\\*.cpp");
	printf("get_files: start: %s : %s\r\n", argv[1], copyof(".\\*.cpp"));
	file_list = (char**) fc->get_files (  copyof(".\\*.cpp") , &number );
	printf("get_files: end\r\n");

	fc->print_strings();

	printf("numnrt: %5d\r\n", number);
	for ( int i=0; i<(number); i++ ) {
		printf( "|%5d|%s|\r\n", i, *(file_list + i) );
	}

   return 0;
}

//
//
//
//
//
//
int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

//
// 
//
//
//
char* file_all_open( char* char_filename ) {
	FILE *fp;

//	printf("file_all_open\r\n");
	char* dummy = char_string ( 256 * 256 );
	fp = fopen( char_filename, "rb");
	int file_end = filesize ( fp );

	for ( int i=0; i< file_end; i++ ) {
//		printf("i: %4d/%4d ", i, file_end);
		m_fread( dummy, 1, fp );
		token = put_token( dummy[0] );
//		printf("dummy: %c|%3d|\r\n", dummy[0], dummy[0] );
	}

	fclose (fp);
	return token;
}

//
//
//
//
//
int file_open( char* char_filename ) {
	FILE *fp;
	char* dummy = char_string ( 256 * 256 );

	fp = fopen( char_filename, "rb");
	int file_end = filesize ( fp );
	for ( int i=0; i< file_end; i++ ) {
		m_fread( dummy, 1, fp );
	}

	fclose (fp);
}

int sum(int num_args, ...) {
   int val = 0;
   va_list ap;
   int i;

   va_start(ap, num_args);
   for(i = 0; i < num_args; i++) {
      val += va_arg(ap, int);
   }
   va_end(ap);
 
   return val;
}
