
#ifndef _VTRIANGLE_
#define _VTRIANGLE_

class vTriangle {

	public:
		vPoint	p1, p2, p3;
		vPoint *normal = nullptr;

	public:
		vTriangle ( );
		vPoint getNormal();

	private:

};

#endif

