#ifndef WBUTTONCONTROLLER_H
#define WBUTTONCONTROLLER_H

// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.
//
class wButtonController {
	public:
		int CursolNumber;
		int Processed = 0;

	private:
		int number_button;
		int mode;
		wButton **AryButton;
		int hTriger = 0;
		wEvent* event = nullptr;
		char* main_pastestr;
		char* main_replace_selection;
		//filename
		TCHAR m_szDir[MAX_PATH];
		int succ_paste = 0;
		int call_once_key = 0;
		int key_state = 0;

	public:
		wButtonController ();
		void addButton ( wButton* b );
		void drawButtons ( HDC hdc );
		void selectButton ( char* btn_nm );
		void selectButton ( );
		void kickEveentButtons ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
		void setTriger ( int h_triger ) ;
		void setEvent ( wEvent* evt ) ;
		void setEvent ( int number, wEvent* evt ) ;
		void Process ( ) ;
		void ProcessWmChar () ;
		void ProcessWmChar_ () ;
		void ProcessWmPaint () ;
		void ProcessWmKeyup () ;
		wButton* getButton ( int num ) ;
		void setKickEvent_001 ( int num, wKickEvent* kick_event) { }
		void kickEvent_001 () {}

	private:
		void escape_action( int mode );
		void initialize( int m );
		//void setButton( int xx, int yy, int h, int w);
		//int wdrawButton( HDC hdc, char *button_name, RECT rect );
		//int aaa();
		//int drawButton( HDC hdc );
		//void setMode ( int m );

};

#endif

