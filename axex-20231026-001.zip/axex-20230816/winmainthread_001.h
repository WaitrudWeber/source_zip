#ifndef _WINMAINTHREAD_001_H_
#define _WINMAINTHREAD_001_H_

//extern static LRESULT CALLBACK mainWindowProc_021 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern LRESULT CALLBACK mainWindowProc_021 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

#endif
