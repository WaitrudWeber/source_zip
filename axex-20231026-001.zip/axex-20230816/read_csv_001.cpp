#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_005.h"
#include "read_csv_001.h"

int csv_once (int *index, int *end_index ) ;
char get_char_001 () ;
int endline ( char bc, char c) ;
int puttheword ( int ii, int jj, char* word ) ;
char* m_concat_c_001 ( char* word , int c ) ;


char* word  = NULL;
char* word_c = NULL;

// Add; mode and quotes
// example
int csv_once (int *index, int *end_index ) {
	int i;
	int ii, jj;
	int mode;
	int count = 0;
	char c, bc;
	int word_cnt;
	int continued_flg = 0;

	mode = 0;
	ii=0; jj=0;

	for ( i = *index; i< 10 + *index && i < *end_index; i++ ) {
		count++;
		c = get_char_001 ();

		if ( mode == 0 && c == '\,' ) {
			ii++;
			continued_flg = 1;
		} if ( mode == 0 && endline ( bc, c) ) {
			word_cnt = array_count (word);
			word[ word_cnt - 1 ] = '\0';
			ii++;
			jj++;
			continued_flg = 1;
		}

		bc = c;

		if ( continued_flg == 1 ) {
			puttheword ( ii, jj, (char*) word );
			word = NULL;
			continued_flg = 0;
			continue;
		}


		word_c = (char*) m_concat_c_001 ( (char*) word , (int) c );
		csvafree_005(word);
		word = word_c;
	}

	*index += count;
}

char get_char_001 () {
	return 0;
}

int endline ( char bc, char c) {
	return 0;
}


int puttheword ( int ii, int jj, char* word ) {
	return 0;
}

char* m_concat_c_001 ( char* word , int c ) {
	static char* dummy = NULL;
	char cc;

	cc = (char)c;

	if ( dummy == NULL ) {
		dummy = (char*) malloc ( sizeof(char) * 4 );
		if ( dummy == NULL ) return NULL;
	}
	dummy[0] = c;
	dummy[1] = '\0';

	return m_concat( word, dummy );
}

