// https://github.com/WaitrudWeber/source_zip/blob/master/winmain-20190109.zip
// https://docs.microsoft.com/en-us/windows/desktop/dataxchg/using-the-clipboard


//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-hProcess-in-mingw-what-to-use-instead
// #include <strsafe.h>

//#include <mmdeviceapi.h>

#include "resource.h"

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"

#include "clipboard.h"

#include "button.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "display_threeD.h"
#include "vPointStructure.h"


#include "vSoundBuffer_001.h"

#include "image_layer_001.h"

#include "wEvent.h"
#include "wEventListener.h"

#include "wJavaStructure.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

#include "wTextarea.h"
#include "wTextareaController.h"

#include "something_word.h"
#include "thread_print.h"


#include "wDisplayController.h"
//#include "wParamSynse_003.h"
#include "wCanvasController.h"

#include "cg_schema.h"


#include "ReturnableParam.h"

#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "log_001.h"

#include "csv_text_001.h"
#include "settle_grid_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"

#include "function_name.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_003.h"
#include "winmainthread_005a_002.h"
#include "winmainthread_005a_001.h"
#include "winmainthread_005a_000.h"
#include "winmainthread_005a_007.h"
#include "winmainthread_005a_008.h"
#include "winmainthread_005a_006.h"

#include "winmainthread_001.h"
#include "winmainthread_002.h"
#include "winmainthread_005.h"

#define _DRAW_PARAM_00000000000000000000000000000001_ 1
#define _DRAW_PARAM_00000000000000000000000000000010_ 2
#define _DRAW_PARAM_00000000000000000000000000000100_ 4
#define _DRAW_PARAM_00000000000000000000000000001000_ 8
#define _DRAW_PARAM_00000000000000000000000000010000_ 16
#define _DRAW_PARAM_00000000000000000000000000100000_ 32
#define _DRAW_PARAM_00000000000000000000000001000000_ 64
#define _DRAW_PARAM_00000000000000000000000010000000_ 128
#define _DRAW_PARAM_00000000000000000000000100000000_ 256
#define _DRAW_PARAM_00000000000000000000001000000000_ 512
#define _DRAW_PARAM_00000000000000000000010000000000_ 1024
#define _DRAW_PARAM_00000000000000000000100000000000_ 2048
#define _DRAW_PARAM_00000000000000000001000000000000_ 4096
#define _DRAW_PARAM_00000000000000000010000000000000_ 8192
#define _DRAW_PARAM_00000000000000000100000000000000_ 16384
#define _DRAW_PARAM_00000000000000001000000000000000_ 32768
#define _DRAW_PARAM_00000000000000010000000000000000_ 65536
#define _DRAW_PARAM_00000000000000100000000000000000_ 131072
#define _DRAW_PARAM_00000000000001000000000000000000_ 262144
#define _DRAW_PARAM_00000000000010000000000000000000_ 524288


//char param_csv[5][255];
//int file_end;
//int file_index;
//CSVTEXT_001 csvtext;

extern void Initialize_firstset_015 ();
extern void Initialize_firstset_016 ();

extern int Set_Param_005 ( int i, int j, char* param  ) ;


extern void Initialize_firstset_012 ();
extern void Initialize_firstset_013 ();
extern void Initialize_firstset_014 ();
extern void Initialize_firstset_017 ();
extern void Initialize_firstset_018 () ;
extern void Initialize_firstset_019 () ;


DWORD WINAPI Animation_5times_thread_validate_025 ( LPVOID hdc ) ;

//static LRESULT CALLBACK mainWindowProc_021 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
LRESULT CALLBACK mainWindowProc_022 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );




// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
 LRESULT CALLBACK mainWindowProc_025 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{

	if ( p_evt == nullptr ) {
		p_evt = new wEvent ();
	}

	p_evt->hWnd = hWnd;
	p_evt->uMsg = &uMsg;
	p_evt->wParam = wParam;
	p_evt->lParam = lParam;
	p_evt->main_mode = m_mode;
//	wtextareacontroller.setEvent ( p_evt );

	// Code Block 1 - 01:
	p_evt->Type = uMsg;

	switch (uMsg) {
	case WM_CREATE:

		initialize_read_csv_000a_013 (NULL, 0);
		Initialize_firstset_winmainthread_005a_01 () ;

		Initialize_firstset_019 ();
		Initialize_firstset_012 ();
		Initialize_firstset_013 ();
		Initialize_firstset_014 ();


//		param_int[20] = (int) ( (double) 1000.0/27.0 );

//		for ( i=0; i<255; i++ )
//			soundwave[i] = 127;

		for ( i=0; i<255; i++ )
			soundwave[i] = sin( i * 0.1 ) * 127.0;

		SetRect( &rect_xy[0], 10, 25, 60, 60 );//04
		SetRect( &rect_xy[1], 60, 25, 110, 60 );//04
		SetRect( &rect_xy[2], 110, 25, 160, 60 );//04
		SetRect( &rect_xy[3], 160, 25, 210, 60 );//04
		SetRect( &rect_xy[4], 210, 25, 260, 60 );//04
		SetRect( &rect_xy[5], 260, 25, 310, 60 );//04
		SetRect( &rect_xy[6], 310, 25, 360, 60 );//04
		SetRect( &rect_xy[7], 360, 25, 410, 60 );//04
		SetRect( &rect_xy[8], 410, 25, 460, 60 );//04
		SetRect( &rect_xy[9], 460, 25, 510, 60 );//04
		SetRect( &rect_xy[10], 510, 25, 560, 60 );//04
		SetRect( &rect_xy[11], 560, 25, 610, 60 );//04
		SetRect( &rect_xy[12], 10, 75, 60, 110 );//04
		SetRect( &rect_xy[13], 60, 75, 110, 110 );//04
		SetRect( &rect_xy[14], 110, 75, 160, 110 );//04
		SetRect( &rect_xy[15], 160, 75, 210, 110 );//04
		SetRect( &rect_xy[16], 210, 75, 260, 110 );//04
		SetRect( &rect_xy[17], 260, 75, 310, 110 );//04
		SetRect( &rect_xy[18], 310, 75, 360, 110 );//04
		SetRect( &rect_xy[19], 360, 75, 410, 110 );//04

/*		SetRect( &rect_xy_head[0], 10, 10, 60, 25 );//04
		SetRect( &rect_xy_head[1], 60, 10, 110, 25 );//04
		SetRect( &rect_xy_head[2], 110, 10, 160, 25 );//04
		SetRect( &rect_xy_head[3], 160, 10, 210, 25 );//04
		SetRect( &rect_xy_head[4], 210, 10, 260, 25 );//04
		SetRect( &rect_xy_head[5], 260, 10, 310, 25 );//04
		SetRect( &rect_xy_head[6], 310, 10, 360, 25 );//04
		SetRect( &rect_xy_head[7], 360, 10, 410, 25 );//04
		SetRect( &rect_xy_head[8], 410, 10, 460, 25 );//04
		SetRect( &rect_xy_head[9], 460, 10, 510, 25 );//04
		SetRect( &rect_xy_head[10], 510, 10, 560, 25 );//04
		SetRect( &rect_xy_head[11], 560, 10, 610, 25 );//04
		SetRect( &rect_xy_head[12], 10, 60, 60, 75 );//04
		SetRect( &rect_xy_head[13], 60, 60, 110, 75 );//04
		SetRect( &rect_xy_head[14], 110, 60, 160, 75 );//04
		SetRect( &rect_xy_head[15], 160, 60, 210, 75 );//04
		SetRect( &rect_xy_head[16], 210, 60, 260, 75 );//04
		SetRect( &rect_xy_head[17], 260, 60, 310, 75 );//04
		SetRect( &rect_xy_head[18], 310, 60, 360, 75 );//04
		SetRect( &rect_xy_head[19], 360, 60, 410, 75 );//04 
*/
		SetRect( &rect_log_cursol[0], 10, 320, 25, 335 );//04
		SetRect( &rect_log[0], 25, 320, 345, 335 );//04
		SetRect( &rect_log_cursol[1], 10, 335, 25, 350 );//04
		SetRect( &rect_log[1], 25, 335, 345, 350 );//04
		SetRect( &rect_log_cursol[2], 10, 350, 25, 365 );//04
		SetRect( &rect_log[2], 25, 350, 345, 365 );//04
		SetRect( &rect_log_cursol[3], 10, 365, 25, 380 );//04
		SetRect( &rect_log[3], 25, 365, 345, 380 );//04
		SetRect( &rect_log_cursol[4], 10, 380, 25, 395 );//04
		SetRect( &rect_log[4], 25, 380, 345, 395 );//04

/*		SetRect( &l_rect_xy_head[0], 10, 10, 60, 25 );//04
		SetRect( &l_rect_xy_head[1], 60, 10, 110, 25 );//04
		SetRect( &l_rect_xy_head[2], 110, 10, 160, 25 );//04
		SetRect( &l_rect_xy_head[3], 160, 10, 210, 25 );//04
		SetRect( &l_rect_xy_head[4], 210, 10, 260, 25 );//04
		SetRect( &l_rect_xy_head[5], 260, 10, 310, 25 );//04
		SetRect( &l_rect_xy_head[6], 310, 10, 360, 25 );//04
		SetRect( &l_rect_xy_head[7], 360, 10, 410, 25 );//04
		SetRect( &l_rect_xy_head[8], 410, 10, 460, 25 );//04
		SetRect( &l_rect_xy_head[9], 460, 10, 510, 25 );//04
		SetRect( &l_rect_xy_head[10], 510, 10, 560, 25 );//04
		SetRect( &l_rect_xy_head[11], 560, 10, 610, 25 );//04*/

		SetRect( &l_rect_xy[0], 10, 25, 60, 60 );//04
		SetRect( &l_rect_xy[1], 60, 25, 110, 60 );//04
		SetRect( &l_rect_xy[2], 110, 25, 160, 60 );//04
		SetRect( &l_rect_xy[3], 160, 25, 210, 60 );//04
		SetRect( &l_rect_xy[4], 210, 25, 260, 60 );//04
		SetRect( &l_rect_xy[5], 260, 25, 310, 60 );//04
		SetRect( &l_rect_xy[6], 310, 25, 360, 60 );//04
		SetRect( &l_rect_xy[7], 360, 25, 410, 60 );//04
		SetRect( &l_rect_xy[8], 410, 25, 460, 60 );//04
		SetRect( &l_rect_xy[9], 460, 25, 510, 60 );//04
		SetRect( &l_rect_xy[10], 510, 25, 560, 60 );//04
		SetRect( &l_rect_xy[11], 560, 25, 610, 60 );//04
		SetRect( &l_rect_xy[12], 10, 60, 60, 110 );//04
		SetRect( &l_rect_xy[13], 60, 60, 110, 110 );//04
		SetRect( &l_rect_xy[14], 110, 60, 160, 110 );//04
		SetRect( &l_rect_xy[15], 160, 60, 210, 110 );//04
		SetRect( &l_rect_xy[16], 210, 60, 260, 110 );//04
		SetRect( &l_rect_xy[17], 260, 60, 310, 110 );//04
		SetRect( &l_rect_xy[18], 310, 60, 360, 110 );//04
		SetRect( &l_rect_xy[19], 360, 60, 410, 110 );//04
		SetRect( &l_rect_xy[20], 410, 60, 460, 110 );//04
		SetRect( &l_rect_xy[21], 460, 60, 510, 110 );//04
		SetRect( &l_rect_xy[22], 510, 60, 560, 110 );//04
		SetRect( &l_rect_xy[23], 560, 60, 610, 110 );//04
		SetRect( &l_rect_xy[24], 10, 110, 60, 160 );//04
		SetRect( &l_rect_xy[25], 60, 110, 110, 160 );//04
		SetRect( &l_rect_xy[26], 110, 110, 160, 160 );//04
		SetRect( &l_rect_xy[27], 160, 110, 210, 160 );//04
		SetRect( &l_rect_xy[28], 210, 110, 260, 160 );//04
		SetRect( &l_rect_xy[29], 260, 110, 310, 160 );//04
		SetRect( &l_rect_xy[30], 310, 110, 360, 160 );//04
		SetRect( &l_rect_xy[31], 360, 110, 410, 160 );//04
		SetRect( &l_rect_xy[32], 410, 110, 460, 160 );//04
		SetRect( &l_rect_xy[33], 460, 110, 510, 160 );//04
		SetRect( &l_rect_xy[34], 510, 110, 560, 160 );//04
		SetRect( &l_rect_xy[35], 560, 110, 610, 160 );//04
		SetRect( &l_rect_xy[36], 10, 160, 60, 210 );//04
		SetRect( &l_rect_xy[37], 60, 160, 110, 210 );//04
		SetRect( &l_rect_xy[38], 110, 160, 160, 210 );//04
		SetRect( &l_rect_xy[39], 160, 160, 210, 210 );//04
		SetRect( &l_rect_xy[40], 210, 160, 260, 210 );//04
		SetRect( &l_rect_xy[41], 260, 160, 310, 210 );//04
		SetRect( &l_rect_xy[42], 310, 160, 360, 210 );//04
		SetRect( &l_rect_xy[43], 360, 160, 410, 210 );//04
		SetRect( &l_rect_xy[44], 410, 160, 460, 210 );//04
		SetRect( &l_rect_xy[45], 460, 160, 510, 210 );//04
		SetRect( &l_rect_xy[46], 510, 160, 560, 210 );//04
		SetRect( &l_rect_xy[47], 560, 160, 610, 210 );//04
		SetRect( &l_rect_xy[48], 10, 210, 60, 260 );//04
		SetRect( &l_rect_xy[49], 60, 210, 110, 260 );//04
		SetRect( &l_rect_xy[50], 110, 210, 160, 260 );//04
		SetRect( &l_rect_xy[51], 160, 210, 210, 260 );//04
		SetRect( &l_rect_xy[52], 210, 210, 260, 260 );//04
		SetRect( &l_rect_xy[53], 260, 210, 310, 260 );//04
		SetRect( &l_rect_xy[54], 310, 210, 360, 260 );//04
		SetRect( &l_rect_xy[55], 360, 210, 410, 260 );//04
		SetRect( &l_rect_xy[56], 410, 210, 460, 260 );//04
		SetRect( &l_rect_xy[57], 460, 210, 510, 260 );//04
		SetRect( &l_rect_xy[58], 510, 210, 560, 260 );//04
		SetRect( &l_rect_xy[59], 560, 210, 610, 260 );//04
		SetRect( &l_rect_xy[60], 10, 260, 60, 310 );//04
		SetRect( &l_rect_xy[61], 60, 260, 110, 310 );//04
		SetRect( &l_rect_xy[62], 110, 260, 160, 310 );//04
		SetRect( &l_rect_xy[63], 160, 260, 210, 310 );//04
		SetRect( &l_rect_xy[64], 210, 260, 260, 310 );//04
		SetRect( &l_rect_xy[65], 260, 260, 310, 310 );//04
		SetRect( &l_rect_xy[66], 310, 260, 360, 310 );//04
		SetRect( &l_rect_xy[67], 360, 260, 410, 310 );//04
		SetRect( &l_rect_xy[68], 410, 260, 460, 310 );//04
		SetRect( &l_rect_xy[69], 460, 260, 510, 310 );//04
		SetRect( &l_rect_xy[70], 510, 260, 560, 310 );//04
		SetRect( &l_rect_xy[71], 560, 260, 610, 310 );//04
		SetRect( &l_rect_xy[72], 10, 310, 60, 360 );//04
		SetRect( &l_rect_xy[73], 60, 310, 110, 360 );//04
		SetRect( &l_rect_xy[74], 110, 310, 160, 360 );//04
		SetRect( &l_rect_xy[75], 160, 310, 210, 360 );//04
		SetRect( &l_rect_xy[76], 210, 310, 260, 360 );//04
		SetRect( &l_rect_xy[77], 260, 310, 310, 360 );//04
		SetRect( &l_rect_xy[78], 310, 310, 360, 360 );//04
		SetRect( &l_rect_xy[79], 360, 310, 410, 360 );//04
		SetRect( &l_rect_xy[80], 410, 310, 460, 360 );//04
		SetRect( &l_rect_xy[81], 460, 310, 510, 360 );//04
		SetRect( &l_rect_xy[82], 510, 310, 560, 360 );//04
		SetRect( &l_rect_xy[83], 560, 310, 610, 360 );//04
		SetRect( &l_rect_xy[84], 10, 360, 60, 410 );//04
		SetRect( &l_rect_xy[85], 60, 360, 110, 410 );//04
		SetRect( &l_rect_xy[86], 110, 360, 160, 410 );//04
		SetRect( &l_rect_xy[87], 160, 360, 210, 410 );//04
		SetRect( &l_rect_xy[88], 210, 360, 260, 410 );//04
		SetRect( &l_rect_xy[89], 260, 360, 310, 410 );//04
		SetRect( &l_rect_xy[90], 310, 360, 360, 410 );//04
		SetRect( &l_rect_xy[91], 360, 360, 410, 410 );//04
		SetRect( &l_rect_xy[92], 410, 360, 460, 410 );//04
		SetRect( &l_rect_xy[93], 460, 360, 510, 410 );//04
		SetRect( &l_rect_xy[94], 510, 360, 560, 410 );//04
		SetRect( &l_rect_xy[95], 560, 360, 610, 410 );//04

		SetRect( &RefreshRect, 0, 0, 640, 480 );//04
		DRAW_PARAM = 0;

//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000000001_;

// BLANK
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000000010_;

//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000000100_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000001000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000010000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000100000_;

		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000010000000000000_;
		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000100000000000000_;

//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000001000000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000010000000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000100000000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000001000000000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000010000000000000000000_;


		hFont = CreateFont (20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);
		SetTextColor( hDC, RGB(0 ,0, 255) );

		//
		Caribration_winmainthread_005a_01 () ;
		break;
	case WM_MOUSEMOVE: //512
		param_int[1] = GET_Y_LPARAM ( lParam );
		param_int[3] = param_int[2] - param_int[1]; // diff in a step
		if (param_int[3] < 0) param_int[3] = - param_int[3];

		sprintf( value_text[0], "%04d", GET_X_LPARAM ( lParam ) );
		sprintf( value_text[1], "%04d", param_int[1] );
		sprintf( value_text[3], "%04d", param_int[3] );
		sprintf( value_text[4], "%04d", param_int[4] - param_int[1] );

		param_int[0] = GET_X_LPARAM ( lParam );
		param_int[1] = GET_Y_LPARAM ( lParam );
		param_int[2] = param_int[1];
		param_int[4] += 1;

		SetRect( &rect_xy[11], param_int[3], 400, param_int[3] + 10, 450 );//04

		b_Processed = 1;

//		for ( i =0; i<20; i++ )
//			InvalidateRect( hWnd, &rect_xy[i], FALSE);

//		InvalidateRect( hWnd, &RefreshRect, FALSE);

//		InvalidateRect( hWnd, &rect_xy[0], FALSE);
//		InvalidateRect( hWnd, &rect_xy[1], FALSE);
//		InvalidateRect( hWnd, &rect_xy[2], FALSE);
//		InvalidateRect( hWnd, &rect_xy[3], FALSE);
//		InvalidateRect( hWnd, &rect_xy[4], FALSE);
//		InvalidateRect( hWnd, &rect_xy[5], FALSE);
//		InvalidateRect( hWnd, &rect_xy[6], FALSE);

		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d DRAW_PARAM=%d\r\n", WM_MOUSEMOVE, flg_paint, DRAW_PARAM );
		break;
	case WM_PAINT: //15
		paint_wm_006 ( &b_Processed );
		b_Processed = 2;
		flg_paint = 1;
		printf("WM_PAINT=uMsg=%d flg_paint=%d hDC %d DRAW_PARAM %d\r\n", WM_PAINT, flg_paint, hDC, DRAW_PARAM );
		break;
	case WM_KEYUP:
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000010000_;
		InvalidateRect( hWnd, &RefreshRect, FALSE);
//		InvalidateRect( hWnd, &RefreshRect, TRUE);
//		InvalidateRect( p_evt->hWnd, &rect_xy[15], FALSE);
//		InvalidateRect( p_evt->hWnd, &rect_xy[17], FALSE);
		switch (wParam) {
		case 65:
			dlog_001 = log_001.update_log ( (char*)"print_log :" );
			dlog_001 = log_001.print_log ();
			exit(-1);
			break;
		case 66:
			// char** param_csv;
			// int file_end;
			// int file_index;
			// CSVTEXT_001 csvtext;
//			csvtext.csv_text_once_006( &file_index, &file_end, (char**)param_csv, 5 ) ;
			Set_Param_005( 1, 1, (char*) "dell_0101"  ) ;
			break;
		case 67: // c
			index = 0;
			Set_Logging_read_csv_004 (&log_001);
			Set_Logging_read_csv_002 (&log_001);
			file_all_size ( "001-filename-20231002-01-b\.txt", &end_index ) ;
			Set_Filename_002 ( "001-filename-20231002-01-b\.txt" );
			puttheword_004 ( 1, 1, (char*) "aaa" ) ;
			puttheword_004 ( 8, 8, (char*) "bbb" ) ;
			Set_Read_Bar () ;
			break;
		case 68: // d
			csv_once_002 ( &index, &end_index);
			param_percent = (double) index / (double) end_index ;
			sprintf( log_message, "index %d end_index %d param_percent %f", index, end_index, param_percent);
			dlog_001 = log_001.update_log ( (char*) log_message );
			sprintf( log_message, "Per %f \0\0", param_percent);
			Set_Param_005a( 0, 3, (char*) log_message ) ;
			// gettheword_004
			/*Set_Param_005( 2, 3, (char*) gettheword_004( 8, 8 ) ) ;
			Set_Param_005( 0, 0, (char*) gettheword_004( 0, 0 ) ) ;
			Set_Param_005( 1, 0, (char*) gettheword_004( 1, 0 ) ) ;
			Set_Param_005( 2, 0, (char*) gettheword_004( 1, 0 ) ) ;
			Set_Param_005( 0, 1, (char*) gettheword_004( 0, 1 ) ) ;
			Set_Param_005( 2, 5, (char*) gettheword_002_c () ) ;
			Initialize_firstset_017 ();
			Set_Read_Bar();*/
			break;
		case 69: // e
			Initialize_firstset_015();
			break;
		case 70: // f
			Initialize_firstset_016();
			break;
		case 71: // g
			halt_invalidate = 0;
			ThreadHandle_001 = CreateThread( NULL, /* default security attributes */ 0, /* default stack size */    
			Animation_5times_thread_validate_025, /* thread function */ (LPVOID)&(p_evt->hDc), /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId_001);
			break;
		case 72: // h
			halt_invalidate = 1;
			ThreadHandle_001 = CreateThread( NULL, /* default security attributes */ 0, /* default stack size */    
			Animation_5times_thread_validate_025, /* thread function */ (LPVOID)&(p_evt->hDc), /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId_001);
			break;
		case 73: // i
			Set_Param_005( 1, 1, (char*) "ani-includion"  ) ;
			Set_Param_005( 1, 2, (char*) "ani-file-extern"  ) ;
			sprintf( log_message, "param_d|%p|", &param_d[0][0][0] );
			Set_Param_005( 2, 2, (char*) log_message ) ;
			break;
		case 74: // j
			Set_Param_005a_base( (char***)&param_d[0][0][0] ) ;
			break;
		case 75: // k
			Set_Param_005a( 1, 3, (char*) "ani-includion-01"  ) ;
			Set_Param_005a( 1, 4, (char*) "ani-file-extern-01"  ) ;
			break;
		case 76: // l
			Set_Param_005a_base( (char***)&param_d[0][0][0] ) ;
			break;
		case 77: // m
			Set_All_Params ();
			break;
		case 78: // n
			l_settle_grid.set_log_001(&log_001);
			l_settle_grid.set_write_file_name("001-filename-20231002-01\.txt");
			l_settle_grid.csv_save("001-filename-20231002\.txt", (char**)param_d, 12, 8 );
//			csvtext_001.set_log_001	( &log_001 );
//			csvtext_001.csv_save("001-filename-20231002\.txt", (char**)param_d, 12, 8 );
			break;
		case 79: // o
			Set_Param_005a( 1, 3, (char*) "a-ani-includion-01"  ) ;
			Get_Param_005a( 1, 3, (char**) &param_ecv[0]  ) ;
			Set_Param_005a( 1, 4, (char*) &param_ecv[0][0] ) ;
			break;
		case 80: // p
			Return_Read_Bar();
			break;
		case 81: // q
			halt_invalidate = 0;
			ThreadHandle_001 = CreateThread( NULL, /* default security attributes */ 0, /* default stack size */    
			Animation_5times_thread_validate_025_002, /* thread function */ (LPVOID)&(p_evt->hDc), /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId_001);
			break;
		case 82: // r
			Create_base_funcs_winmainthread_005a_01 () ;
			Create_base_cls_winmainthread_005a_01 ( (char*) "winmainthread_005a_01" )  ;
			break;
		case 83: // s
			winmainthread_005a_007_001_01 () ;
			break;
		case 84: // t
			l_settle_grid.set_log_001(&log_001);
			l_settle_grid.set_write_file_name ("001-filename-20231002\.txt");
			l_settle_grid.csv_save("001-filename-20230710\.txt", (char**)param_d, 12, 8 );
			winmainthread_005a_007_001 ();
			break;
		case 85: // u
			l_settle_grid.set_log_001(&log_001);
			winmainthread_005a_007_001_03_fnc ( ".\\fnc\\001-filename-20231023\.txt", "fnc_name", 1000 );
			break;
		case 86: // v
			l_settle_grid.set_log_001(&log_001);
			winmainthread_005a_007_001_04_fnc ( ".\\fnc\\001-filename-20231023-01\.txt", "fnc_name", 1000 );
			break;
		case 87: // w
			l_settle_grid.set_log_001(&log_001);
			process_setting ();
			break;
		}
		b_Processed = 1;
		printf("WM_KEYUP=uMsg=%d flg_paint=%d wParam %d lParam %d\r\n", WM_KEYUP, flg_paint, wParam, lParam );
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		printf("WM_KEYDOWN=uMsg=%d flg_paint=%d\r\n", WM_KEYDOWN, flg_paint );
		break;
	}

	switch (uMsg) {
	case WM_PAINT: //15
		SelectObject((HDC)(hDC), hFont2);
		DeleteObject(hFont);
		EndPaint( hWnd, &ps_001 );	
//		wtextareacontroller.stack_number_free ();
		break;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

// invalidate:
// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-invalidaterect
//
//
DWORD WINAPI Animation_5times_thread_validate_025 ( LPVOID hdc ) {
	printf("Animation_5times_thread_validate_025 starts.\r\n");

	DWORD hdc_011 = *(DWORD*)hdc;
	for ( param_int[19] = 0; param_int[19]<255 * 100; param_int[19]++ ) {
		InvalidateRect( p_evt->hWnd, &RefreshRect, FALSE);

		csv_once_002 ( &index, &end_index);
		param_percent = (double) index / (double) end_index ;
		sprintf( log_message, "index %d end_index %d param_percent %f", index, end_index, param_percent);
		dlog_001 = log_001.update_log ( (char*) log_message );

		Set_Read_Bar () ;

		if ( index >= end_index ) break;

		Sleep(param_int[20]);
	}

	Initialize_firstset_017 ();
	Return_Read_Bar () ;
	printf("Animation_5times_thread_validate_025 ends.\r\n");
	return 0;
}



//
int Set_Param_005( int i, int j, char* param  ) {
	char buf_a[255];
	int ac;
	dlog_001 = log_001.update_log ( "int Set_Param_005( int i, int j, char* param  ) starts." );

	ac = array_count( param );

	dlog_001 = log_001.update_log ( (char*)log_message );

	csvafree_005(param_d [0][ j * table_width + i ]);
	param_d [0][ j * table_width + i ] = (char*) csvcopyof_005 ( param);
	sprintf( log_message, "i %d j %d ac %d |%p|", i, j, ac, param_d [0][ j * table_width + i ] );

	dlog_001 = log_001.update_log ( "int Set_Param_005( int i, int j, char* param  ) ends." );
	return 0;
}


//
void Initialize_firstset_018 () {
	printf("void Initialize_firstset_018 () starts.\r\n");
	log_001.init_log ();
	log_001.start_log ();
	log_001.Set_Filename( (char*)".\\001-filename-20230710-001\.txt");

	Set_Logging_read_csv_004 (&log_001);
	Set_Logging_read_csv_002 (&log_001);
	Set_Logging_read_csv_005 (&log_001);
	Set_Param_005a_log (&log_001);
	Set_Param_005a_base( (char***)&param_d[0][0][0] );
	printf("void Initialize_firstset_018 () ends.\r\n");
}


void Initialize_firstset_016 ()
{
	int i, j;

	for ( i = 0; i<3; i++ ) {
		for ( j = 0; j<3; j++ ) {
			Set_Param_005( i, j, "DEL"  );
		}
	}
}


void Initialize_firstset_017 ()
{
	int i, j;

	dlog_001 = log_001.update_log ( "void Initialize_firstset_017 () starts." );

	for ( i = 0; i<table_width; i++ ) {
		for ( j = 0; j<table_height; j++ ) {
			Set_Param_005a( i, j, (char*) gettheword_004( i, j ) ) ;
		}
	}

	dlog_001 = log_001.update_log ( "void Initialize_firstset_017 () ends." );
}


void Initialize_firstset_015 ()
{
	int i, j;

	for ( i = 0; i<table_width; i++ ) {
		for ( j = 0; j<table_height; j++ ) {
			Set_Param_005( i, j, "--"  );
		}
	}
}

void Initialize_firstset_014 ()
{
	printf("void Initialize_firstset_014 () starts.\r\n");
	dlog_001 = log_001.update_log ( (char*)"void Initialize_firstset_014 () starts." );

	dlog_001 = log_001.update_log ( (char*)"1" );
	dlog_001 = log_001.update_log ( (char*)"2" );
	dlog_001 = log_001.update_log ( (char*)"3" );
	dlog_001 = log_001.update_log ( (char*)"4" );

//	csvtext_001.set_read_file_name("001-filename-20230621\.txt" );
//	csvtext_001.csv_index = 3;
//	csvtext_001.csv_read();

	dlog_001 = log_001.update_log ( (char*)"void Initialize_firstset_014 () ends." );
	printf("void Initialize_firstset_014 () ends.\r\n");
}

void Initialize_firstset_013 ()
{
	printf("void Initialize_firstset_013 () starts.\r\n");
		param_c[0] = csvcopyof_005 ("0");
		param_c[1] = csvcopyof_005 ("-");
		param_c[2] = csvcopyof_005 ("-");
		param_c[3] = csvcopyof_005 ("-");
		param_c[4] = csvcopyof_005 ("-");
		param_c[5] = csvcopyof_005 ("-");
		param_c[6] = csvcopyof_005 ("-");
		param_c[7] = csvcopyof_005 ("Very");
		param_c[8] = csvcopyof_005 ("thanks");
		param_c[9] = csvcopyof_005 ("to");
		param_c[10] = csvcopyof_005 ("lotus");
		param_c[11] = csvcopyof_005 ("11");

		param_d [0][0] = csvcopyof_005 ("-");
		param_d [0][1] = csvcopyof_005 ("-");
		param_d [0][2] = csvcopyof_005 ("-");
		param_d [0][3] = csvcopyof_005 ("-");
		param_d [0][4] = csvcopyof_005 ("-");
		param_d [0][5] = csvcopyof_005 ("-");
		param_d [0][6] = csvcopyof_005 ("-");
		param_d [0][7] = csvcopyof_005 ("-");
		param_d [0][8] = csvcopyof_005 ("-");
		param_d [0][9] = csvcopyof_005 ("-");
		param_d [0][10] = csvcopyof_005 ("-");
		param_d [0][11] = csvcopyof_005 ("-");
		param_d [0][12] = csvcopyof_005 ("-");
		param_d [0][13] = csvcopyof_005 ("-");
		param_d [0][14] = csvcopyof_005 ("-");
		param_d [0][15] = csvcopyof_005 ("-");
		param_d [0][16] = csvcopyof_005 ("-");
		param_d [0][17] = csvcopyof_005 ("-");
		param_d [0][18] = csvcopyof_005 ("-");
		param_d [0][19] = csvcopyof_005 ("-");
		param_d [0][20] = csvcopyof_005 ("-");
		param_d [0][21] = csvcopyof_005 ("-");
		param_d [0][22] = csvcopyof_005 ("-");
		param_d [0][23] = csvcopyof_005 ("-");
		param_d [0][24] = csvcopyof_005 ("-");
		param_d [0][25] = csvcopyof_005 ("-");
		param_d [0][26] = csvcopyof_005 ("-");
		param_d [0][27] = csvcopyof_005 ("-");
		param_d [0][28] = csvcopyof_005 ("-");
		param_d [0][29] = csvcopyof_005 ("-");
		param_d [0][30] = csvcopyof_005 ("-");
		param_d [0][31] = csvcopyof_005 ("-");
		param_d [0][32] = csvcopyof_005 ("-");
		param_d [0][33] = csvcopyof_005 ("-");
		param_d [0][34] = csvcopyof_005 ("-");
		param_d [0][35] = csvcopyof_005 ("-");
		param_d [0][36] = csvcopyof_005 ("-");
		param_d [0][37] = csvcopyof_005 ("-");
		param_d [0][38] = csvcopyof_005 ("-");
		param_d [0][39] = csvcopyof_005 ("-");
		param_d [0][40] = csvcopyof_005 ("-");
		param_d [0][41] = csvcopyof_005 ("-");
		param_d [0][42] = csvcopyof_005 ("-");
		param_d [0][43] = csvcopyof_005 ("-");
		param_d [0][44] = csvcopyof_005 ("-");
		param_d [0][45] = csvcopyof_005 ("-");
		param_d [0][46] = csvcopyof_005 ("-");
		param_d [0][47] = csvcopyof_005 ("-");
		param_d [0][48] = csvcopyof_005 ("-");
		param_d [0][49] = csvcopyof_005 ("-");
		param_d [0][50] = csvcopyof_005 ("-");
		param_d [0][51] = csvcopyof_005 ("-");
		param_d [0][52] = csvcopyof_005 ("-");
		param_d [0][53] = csvcopyof_005 ("-");
		param_d [0][54] = csvcopyof_005 ("-");
		param_d [0][55] = csvcopyof_005 ("-");
		param_d [0][56] = csvcopyof_005 ("-");
		param_d [0][57] = csvcopyof_005 ("-");
		param_d [0][58] = csvcopyof_005 ("-");
		param_d [0][59] = csvcopyof_005 ("-");
		param_d [0][60] = csvcopyof_005 ("-");
		param_d [0][61] = csvcopyof_005 ("-");
		param_d [0][62] = csvcopyof_005 ("-");
		param_d [0][63] = csvcopyof_005 ("-");
		param_d [0][64] = csvcopyof_005 ("-");
		param_d [0][65] = csvcopyof_005 ("-");
		param_d [0][66] = csvcopyof_005 ("-");
		param_d [0][67] = csvcopyof_005 ("-");
		param_d [0][68] = csvcopyof_005 ("-");
		param_d [0][69] = csvcopyof_005 ("-");
		param_d [0][70] = csvcopyof_005 ("-");
		param_d [0][71] = csvcopyof_005 ("-");
		param_d [0][72] = csvcopyof_005 ("-");
		param_d [0][73] = csvcopyof_005 ("-");
		param_d [0][74] = csvcopyof_005 ("-");
		param_d [0][75] = csvcopyof_005 ("-");
		param_d [0][76] = csvcopyof_005 ("-");
		param_d [0][77] = csvcopyof_005 ("-");
		param_d [0][78] = csvcopyof_005 ("-");
		param_d [0][79] = csvcopyof_005 ("-");
		param_d [0][80] = csvcopyof_005 ("-");
		param_d [0][81] = csvcopyof_005 ("-");
		param_d [0][82] = csvcopyof_005 ("-");
		param_d [0][83] = csvcopyof_005 ("-");
		param_d [0][84] = csvcopyof_005 ("-");
		param_d [0][85] = csvcopyof_005 ("-");
		param_d [0][86] = csvcopyof_005 ("-");
		param_d [0][87] = csvcopyof_005 ("-");
		param_d [0][88] = csvcopyof_005 ("-");
		param_d [0][89] = csvcopyof_005 ("-");
		param_d [0][90] = csvcopyof_005 ("-");
		param_d [0][91] = csvcopyof_005 ("-");
		param_d [0][92] = csvcopyof_005 ("-");
		param_d [0][93] = csvcopyof_005 ("-");
		param_d [0][94] = csvcopyof_005 ("-");
		param_d [0][95] = csvcopyof_005 ("MinGW");

//	csvtext_001.set_log_001	( &log_001 );
//	csvtext_001.csv_save("001-filename-20230621\.txt", (char**)param_d, 12, 8 );

	dlog_001 = log_001.update_log ( (char*)"void Initialize_firstset_013 () ends." );
	printf("void Initialize_firstset_013 () ends.\r\n");
}

// void Initialize_firstset_019 () ;
//
void Initialize_firstset_019 () {
	printf("void Initialize_firstset_019 () starts.\r\n");
	set_a_sleep_thread_time ( 10 );
	printf("void Initialize_firstset_019 () endss.\r\n");
}


// -> invalid
// -> move
// -> invalid
// -> 
void Initialize_firstset_012 ()
{
	printf("void Initialize_firstset_012 () starts.\r\n");
		param_a[0] = (char*)"0";
		param_a[1] = "0";
		param_a[2] = "9";
		param_a[3] = "27";
		param_a[4] = "3";
		param_a[5] = "true";
		param_a[6] = "true";
		param_a[7] = "0";
		param_a[8] = "242";
		param_a[9] = "37.037037037"; // 37.037037
		param_a[10] = "a";
		param_a[11] = "a";
		param_a[12] = "a";
		param_a[13] = "a";
		param_a[14] = "a";
		param_a[15] = "a";
		param_a[16] = "a";
		param_a[17] = "a";
		param_a[18] = "a";
		param_a[19] = "a";
		param_b[0] = "mouse x";
		param_b[1] = "mouse y";
		param_b[2] = "frequent";
		param_b[3] = "frequent * 3";
		param_b[4] = "frequent / 3";
		param_b[5] = "invalidate1"; //true or not
		param_b[6] = "invalidate2"; //true or not
		param_b[7] = "cursol";
		param_b[8] = "buffer size";
		param_b[9] = "base sleep";
		param_b[10] = "b";
		param_b[11] = "b";
		param_b[12] = "b";
		param_b[13] = "b";
		param_b[14] = "b";
		param_b[15] = "b";
		param_b[16] = "b";
		param_b[17] = "b";
		param_b[18] = "b";
		param_b[19] = "b";

//		il_001.initialize_image_layer();
//		il_001.set_default_image_layer();

		dlog_001 = log_001.update_log ( (char*)"one" );
		dlog_001 = log_001.update_log ( (char*)"two" );
		dlog_001 = log_001.update_log ( (char*)"three" );
		dlog_001 = log_001.update_log ( (char*)"four" );
		dlog_001 = log_001.update_log ( (char*)"five" );
		dlog_001 = log_001.update_log ( (char*)"six" );
		dlog_001 = log_001.update_log ( (char*)"seven" );
		dlog_001 = log_001.update_log ( (char*)"eight" );

	printf("void Initialize_firstset_012 () ends.\r\n");
}

//
