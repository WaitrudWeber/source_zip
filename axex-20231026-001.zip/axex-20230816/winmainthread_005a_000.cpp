#include <tchar.h>
#include <windows.h>
#include <windowsx.h>


#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "csv_text_001.h"
#include "settle_grid_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_000.h"

static char*** param_d_005 ;

static Logging* l_log_001 = NULL;
static LOG_001* dl_log_001 = NULL;
static char a_log_message[255];



extern char* filename_winmainthread_005a_000_ = (char*)"winmainthread_005a_000.txt";

int winmainthread_005a_000 ();
int set_winmainthread_005a_000 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_000 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

int Get_Param_005a( int i, int j, char** param  ) ;
int Set_Param_005a( int i, int j, char* param  ) ;
int Set_Param_005a_base( char**** lp ) ;
int Set_Param_005a_log( Logging* llog ) ;

int Inc_param_a ();
int Dec_param_a ();


int winmainthread_005a_000 () {
	return 1;

}

int winmainthread_005a_set_000 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_000 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int Iinc_param_a () {
	param_d_index++;
	if ( param_d_index >= param_d_index_max ) param_d_index = param_d_index_max -1;
	return 0;
}

int Dec_param_a () {
	param_d_index--;
	if ( param_d_index <= 0 ) param_d_index = 0;
	return 0;
}

//
int Get_Param_005a( int i, int j, char** param  ) {
	dl_log_001 = l_log_001->update_log ( (char*)"Get_Param_005a( int i, int j, char** param  ) starts.\0" ); 
	param[0] = (char*) param_d [param_d_index][ j * table_width + i ];
	param_dcv[param_d_index] = &param[0][0]; //current value

	sprintf(a_log_message, "param[0] |%s|\0", param[0]);
	dl_log_001 = l_log_001->update_log ( (char*)a_log_message ); 
	dl_log_001 = l_log_001->update_log ( (char*)"Get_Param_005a( int i, int j, char** param  ) ends.\0" ); 
	return 0;
}

//
int Set_Param_005a( int i, int j, char* param  ) {
	char buf_a[255];
	int ac;

	if ( l_log_001 == NULL ) return -1;
//	if ( param_d == NULL ) return -1;

	printf("int Set_Param_005a( int i, int j, char* param  ) starts.\r\n");

	dl_log_001 = l_log_001->update_log ( "int Set_Param_005( int i, int j, char* param  ) starts." );

	ac = array_count( param );

	printf( "msg i %d j %d param ac %d |%s| table|%p|", i, j, ac, param, param_d [param_d_index][ j * table_width + i ] );
	sprintf( a_log_message, "msg i %d j %d param ac %d |%s| table|%p|", i, j, ac, param, param_d [param_d_index][ j * table_width + i ] );
	dl_log_001 = l_log_001->update_log ( (char*)a_log_message );

	csvafree_005(param_d [param_d_index][ j * table_width + i ]);
	param_d [param_d_index][ j * table_width + i ] = (char*) csvcopyof_005( param);
	dl_log_001 = l_log_001->update_log ( (char*)a_log_message ); 

	dl_log_001 = l_log_001->update_log ( "int Set_Param_005( int i, int j, char* param  ) ends." ); 
	printf("int Set_Param_005a( int i, int j, char* param  ) ends.\r\n");

	return 0;
}

//
int Set_Param_005a_base( char*** lp ) {
	printf("int Set_Param_005a_base( char*** lp ) starts.\r\n");
	printf("l_log_001|%p|\r\n", l_log_001);
	param_d_005 = lp;
	sprintf( a_log_message, "param_d_005|%p|", param_d_005 );
	dl_log_001 = l_log_001->update_log ( (char*)a_log_message ); 
	printf("int Set_Param_005a_base( char*** lp ) ends.\r\n");
	return 0;
}

//
int Set_Param_005a_log( Logging* llog ) {
	printf("int Set_Param_005a_log( Logging* llog ) starts.\r\n");
	l_log_001 = llog;
	printf("l_log_001|%p|\r\n", l_log_001);
	printf("int Set_Param_005a_log( Logging* llog ) ends.\r\n");
	return 0;
}
