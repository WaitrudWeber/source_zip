#ifndef _PRINT_MOUSE_008_
#define _PRINT_MOUSE_008_
int print_mouse_move_008 () ;
#endif
