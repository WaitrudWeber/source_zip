#ifndef _READ_CSV__013_
#define _READ_CSV__013_
//...
extern int read_csv_000a_013 ();
extern int set_read_csv_000a_013 (char** argv, int argc);
extern int initialize_read_csv_000a_013 (char** argv, int argc);
#endif
