#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "print_mouse_move_012.h"
#include "print_mouse_move_011.h"
#include "print_mouse_move_010.h"

// https://www.ibm.com/docs/ja/i/7.1?topic=ssw_ibm_i_71/rtref/strcat.html

typedef struct build_class_struct {
	char* class_unit_name;
	char* bing_unit_name;
	build_class_struct* sibling = NULL;
	build_class_struct* children = NULL;
} BUILD_CLASS;

char* print_mouse_move_010_upper (char* word, char* uppername) ;
int print_mouse_move_010_op_01 (char* opt) ;
int print_mouse_move_010_a (int argc, char** argv ) ;
int print_mouse_move_010 () ;
int print_mouse_move_010_01 () ;
extern const char *byte_to_binary_010( int x );

int create_build_class_010 (BUILD_CLASS* bc ) ;
int create_build_class_010 (BUILD_CLASS* bc, char* grp_name ) ;
BUILD_CLASS* recreate_build_class_010 (BUILD_CLASS* bc ) ;

char* clsname = NULL;
char* clsname_upper = NULL;
char* file_return = (char*)"001-return-001\.txt";
char* file_param = (char*)"001-function-param-001\.txt";
char* file_includion = (char*)"001-includion-file-001\.txt";

char CLSNAME_UPPER[255];

char filename_define_numbered[16][64];
char filename_header_numbered[16][64];
char filename_cpp_numbered[16][64];
char filename_func_proto_numbered[16][64];
char filename_func_proto_set_numbered[16][128];
char filename_func_proto_initialize_numbered[16][128];
char filename_func_code_numbered[16][64];
char filename_func_code_set_numbered[16][128];
char filename_func_code_initialize_numbered[16][128];
char filename_func_includion_numbered[16][64];
char filename_func_logfilename_numbered[16][128];

char file_return_buffer [64];
char file_param_buffer [128];
char file_includion_buffer [128];

int number = 16;

int print_mouse_move_010_op_02 (char* opt) ;
int print_mouse_move_010_file_name_numbered ( char* filename, int num ) ;
int print_mouse_move_010_initialize () ;
int print_function_010 ( int num ) ;
int print_makefie_010 ( int num ) ;
int print_sourcefile_010 ( int num ) ;

int filesize( FILE *fp ) ;
int read_function_block () ;
int read_param_block () ;
int read_includion_block () ;


int print_mouse_move_010_a (int argc, char** argv ) {
	int a;
	int i;
	int b_flg[16];
	printf("int print_mouse_move_010_a (int argc, char** argv ) starts.\r\n");
	printf("argc %d\r\n", argc);

	a = print_mouse_move_010_initialize () ;

	b_flg[0] = 0;

	for ( i = 0; i<argc; i++ ) {
		printf("argv[%d] %s\r\n", i, argv[i]);
	}

	for ( i = 0; i<argc; i++ ) {
		printf("b_flg[0] = %d\r\n", b_flg[0]);
		if ( b_flg[0] ) {
			if ( argv[i][0] == '-' ) {
				printf("argv[%d][0] includes Hi\r\n", i);
				exit(-1);
			}
			b_flg[0] = 0;
			clsname = argv[i];
			clsname_upper = print_mouse_move_010_upper(clsname, (char*) CLSNAME_UPPER);
			printf("CL = %s set clsname %s\r\n", argv[i], clsname );
			printf("set clsname_upper %s\r\n", clsname_upper );
		}
		if ( b_flg[1] ) {
			b_flg[1] = 0;
			number = atoi(argv[i]);
			printf("number=%d\r\n", number );
		}

		switch(argv[i][0]) {
		case '-':
			if ( print_mouse_move_010_op_01(argv[i]) ) {
				b_flg[0] = 1;
			} else if ( print_mouse_move_010_op_02(argv[i]) ) {
				b_flg[1] = 1;
			}
			break;
		}
	}

	for ( i=0; i<16; i++ ) {
		printf("b_flg [%d] = %d\r\n", i, b_flg[i]);
		if ( b_flg[i] == 1 ) exit(-1);
	}

	a = print_mouse_move_010_file_name_numbered ( clsname, number );
	a = print_function_010 ( number );
	a = print_makefie_010( number );
	a = print_sourcefile_010( number );

	printf("int print_mouse_move_010_a (int argc, char** argv ) ends.\r\n");
	return 0;
}

//
int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

int read_code_return_010 () {
	FILE *fp;
	fp = fopen ( file_return, "rb");

	fclose(fp);
	return 0;
}

//
int print_function_010 ( int num ) {
	int a, i;
	printf("int print_function_010 ( int num ) starts.\r\n");

	for ( i = 0; i<num; i++ ) {
		set_filename_move_011 ( filename_header_numbered[i] );
		set_function_block_011 ( filename_func_proto_numbered[i] );
		set_function_block_011_01 ( filename_func_proto_set_numbered[i] );
		set_function_block_011_02 ( filename_func_proto_initialize_numbered[i] );
		set_define_block_011 ( filename_define_numbered[i] );
		a = print_header_file_011 ();
	}

	for ( i = 0; i<num; i++ ) {
		set_source_file_011 ( filename_cpp_numbered[i] );
		set_function_block_011 ( filename_func_proto_numbered[i] );
		set_function_block_011_01 ( filename_func_proto_set_numbered[i] );
		set_function_block_011_02 ( filename_func_proto_initialize_numbered[i] );
		set_code_block_011 ( filename_func_code_numbered[i] );	// d
		set_code_block_011_01 ( filename_func_code_set_numbered[i] ); // d
		set_code_block_011_02 ( filename_func_code_initialize_numbered[i] ); // d
		// file_includion
		set_includion_block_011 ( (char*)file_includion_buffer );
		set_includion_block_011_01 ( (char*)filename_func_includion_numbered[i] );

		set_logfilename_block_011 ( (char*)filename_func_logfilename_numbered[i] );
		a = print_source_file_011 ();
	}

	printf("int print_function_010 ( int num ) ends.\r\n");
	return 0;
}

int print_sourcefile_010 ( int num ) {
	int i;
	printf("int print_sourcefile_010 ( int num ) starts.\r\n");
	for ( i = 0; i<num; i++ ) {
		set_source_file_011 (filename_cpp_numbered[i]);
		set_function_block_011 (filename_func_proto_numbered[i]);
	}
	printf("int print_sourcefile_010 ( int num ) ends.\r\n");
	return 0;
}

int print_makefie_010 ( int num ) {
	int i;
	printf("int print_makefie_010 ( int num ) stars.\r\n");

	set_makefile_block_011 ( (char*)"makefile-001\.txt" );

	printf ( "#... |%p| num %d\r\n", (char**)filename_cpp_numbered, num );

	for ( i = 0; i < num; i++ ) {
		printf("i %3d |%p| %s\r\n", i, filename_cpp_numbered[i], filename_cpp_numbered[i] );
	}

	for ( i = 0; i < num; i++ ) {
		print_makefile_011_c ( filename_cpp_numbered[i] );
	}


//	print_makefile_011_b ( (char**)filename_cpp_numbered, num );
//	print_makefile_011_a ( (char**)filename_cpp_numbered, num );
//	print_makefile_011 ( (char**)filename_cpp_numbered, num );

	printf("int print_makefie_010 ( int num ) ends.\r\n");
	return 0;
}

//
int print_mouse_move_010_initialize () {
	printf("int print_mouse_move_010_initialize () starts.\r\n");

	set_filename_move_011 ("001-filename-20230906-001\.txt");

	printf("int print_mouse_move_010_initialize () ends.\r\n");
	return 0;
}

// int read_includion_block () ;
int read_includion_block () {
	FILE *fp;
	int file_size;

	fp = fopen ( file_includion, "r");
	file_size = filesize (fp);
	printf("file_size: %d\r\n", file_size);

	fread( file_includion_buffer, 1, file_size, fp );

	printf("file_includion_buffer: %s\r\n", file_includion_buffer);

	fclose(fp);
	return 0;
}

int read_param_block () {
	FILE *fp;
	int file_size;
	fp = fopen ( file_param, "r");
	file_size = filesize (fp);
	printf("file_size: %d\r\n", file_size);

	fread( file_param_buffer, 1, file_size, fp );

	printf("file_param_buffer: %s\r\n", file_param_buffer);

	fclose(fp);
	return 0;
}

int read_function_block () {
	FILE *fp;
	int file_size;
	fp = fopen ( file_return, "r");
	file_size = filesize (fp);
	printf("file_size: %d\r\n", file_size);

	fread( file_return_buffer, 1, file_size, fp );

	printf("file_return_buffer: %s\r\n", file_return_buffer);

	fclose(fp);
	return 0;
}

//
int print_mouse_move_010_file_name_numbered ( char* filename, int num ) {
	int i, a;
	char* stab = (char*)"	";
	char* le = (char*)"\r\n";
	printf("int print_mouse_move_010_file_name_numbered ( char* filename, int num ) starts.\r\n");

	printf("filename %s num %d\r\n", filename, num );
	if (num > 16 ) exit(-1);

	a = read_function_block ();
	a = read_param_block ();
	a = read_includion_block ();

	for ( i=0; i<num; i++ ) {
		printf("header |%p|%s|\r\n", filename_header_numbered[i], filename_header_numbered[i] );
	}

	// base block 001
	for ( i=0; i<num; i++ ) {
		sprintf( filename_header_numbered[i], "%s_%03d\.h", filename, i );
		sprintf( filename_cpp_numbered[i], "%s_%03d\.cpp", filename, i );
		sprintf( filename_define_numbered[i], "_%s_%03d\_", CLSNAME_UPPER, i );
		sprintf( filename_func_proto_numbered[i], "int %s_%03d\ ()\;", filename, i );
// o		sprintf( filename_func_code_numbered[i], "int %s_%03d\ { return 0 }\0\0", filename, i );
		printf( "|%p|%s|\r\n", &filename_func_code_numbered[i][0], &filename_func_code_numbered[i][0] );
		print_return_zero ( &filename_func_code_numbered[i][0], filename, i, file_return_buffer);

		sprintf( filename_func_proto_set_numbered[i], "int set_%s_%03d\ (%s)\;", filename, i, file_param_buffer);
		sprintf( filename_func_proto_initialize_numbered[i], "int initialize_%s_%03d\ (%s)\;", filename, i,  file_param_buffer);

		sprintf( filename_func_code_set_numbered[i], "int %s_set_%03d\ (%s)\ {\r\n %s \r\n}\0\0", filename, i, file_param_buffer, file_return_buffer );
		sprintf( filename_func_code_initialize_numbered[i], "int %s_initialize_%03d\ (%s)\ {\r\n %s \r\n}\0\0", filename, i, file_param_buffer, file_return_buffer );

		sprintf( filename_func_includion_numbered[i], "#include \"%s_%03d\.h\"\r\n", filename, i );
		sprintf( filename_func_logfilename_numbered[i], "extern char* filename_%s_%03d_ = (char*)\"%s_%03d\.txt\"\;\r\n", filename, i, filename, i );
		printf("%s\r\n", filename_func_logfilename_numbered[i] );
//		exit(-1);
	}

//	exit(-1);
	for ( i=0; i<num; i++ ) {
		printf("header %s\r\n", filename_header_numbered[i] );
	}

	for ( i=0; i<num; i++ ) {
		printf("source |%p|%s|\r\n", filename_cpp_numbered[i], filename_cpp_numbered[i] );
	}

	for ( i=0; i<num; i++ ) {
		printf("define %s\r\n", filename_define_numbered[i] );
	}

	for ( i=0; i<num; i++ ) {
		printf("function proto |%p|%s|\r\n", &filename_func_proto_numbered[i][0], &filename_func_proto_numbered[i][0] );
	}

	for ( i=0; i<num; i++ ) {
		printf("function proto |%p|%s|\r\n", &filename_func_proto_set_numbered[i][0], &filename_func_proto_set_numbered[i][0] );
	}

	for ( i=0; i<num; i++ ) {
		printf("function proto |%p|%s|\r\n", &filename_func_proto_initialize_numbered[i][0], &filename_func_proto_initialize_numbered[i][0] );
	}

	for ( i=0; i<num; i++ ) {
		printf("function code |%p|%s|\r\n", &filename_func_code_numbered[i][0], &filename_func_code_numbered[i][0] );
	}

//	exit(-1);
	printf("int print_mouse_move_010_file_name_numbered ( char* filename, int num ) ends.\r\n");
}

// char* print_mouse_move_010_upper (char* word, char* uppername) ;
char* print_mouse_move_010_upper (char* word, char* uppername) {
	int i;
	int up;
	char c;
	up = 'a' -'A';
	printf("up %d a %d A %d\r\n", up, 'a', 'A');

	for ( i=0; 1; i++ ) {
		if ( word[i] == '\0' ) {
			uppername[i] = '\0';
			printf("break i = %d uppername %s\r\n", i, uppername);
			break;
		}
		if ( word[i] <= 'z' && word[i] >= 'A') {
			c = word[i];
			if ( word[i] >= 'a') {
				c -=  up;
			}
			uppername[i] = c;
			printf("c |%c|%3d| word[%3d]|%3d|%c|\r\n", c, c, i, word[i], word[i] );
		}
	}

	return uppername;
}

//
int print_mouse_move_010_op_02 (char* opt) {
	int i;
	int result = 1;
	char opt_cl[4] = { '-', 'n', 'u', 'm' };

	for ( i=0; i<4; i++ ){
		if ( opt_cl[i] != opt[i] ) {
			result = 0;
			break;
		}
		if ( opt[i] == '\0' ) {
			result = 0;
			break;
		}
	}

	return result;
}

//
int print_mouse_move_010_op_01 (char* opt) {
	int i;
	int result = 1;
	char opt_cl[3] = { '-', 'C', 'L' };

	for ( i=0; i<3; i++ ){
		if ( opt_cl[i] != opt[i] ) {
			result = 0;
			break;
		}
		if ( opt[i] == '\0' ) {
			result = 0;
			break;
		}
	}

	return result;
}

int print_mouse_move_010 () {

	return 0;
}

//
int print_mouse_move_010_01 () {
	int i, a;
	FILE* fp;
	BUILD_CLASS bc;
	BUILD_CLASS* bc_001 = NULL;

	fp = fopen ( "w", "001-filename-001\.txt");

	bc_001 = recreate_build_class_010(bc_001);

	a = create_build_class_010 ( &bc, (char*) "SettleGrid");
	a = create_build_class_010 ( bc_001, (char*) "SettleGrid");

	for ( i = 0; i< 9; i++ ) {
		fprintf ( fp, "%d\r\n", i );
	}

	fclose (fp);
	return 0;
}

//
int create_build_class_010 (BUILD_CLASS* bc, char* grp_name ) {
	int i;
	int c;
	for ( i=0; i<100; i++ ) {
		c = *(grp_name + i );
		printf("c|%4d|%c|%4d|\r\n", c, c, i );
		if ( c == '\0' ) break;
	}

	bc->class_unit_name = (char*) grp_name ;

	return 0;
}

//
BUILD_CLASS* recreate_build_class_010 (BUILD_CLASS* bc ) {

	bc = (BUILD_CLASS*) realloc ( bc, sizeof(BUILD_CLASS) );
	return bc;
}


// https://stackoverflow.com/questions/111928/is-there-a-printf-converter-to-print-in-binary-format
const char *byte_to_binary_010
(
    int x
)
{
    static char b[33];
    b[0] = '\0';

    unsigned int z;
    unsigned long z_start;
    z_start = 256*256*256*128;

//    printf("z_start %d\r\n", z_start);

    for (z = 256*256*256*128; z > 0; z >>= 1)
    {
//   	printf("x %d z %d\r\n", x, z );
        strcat(b, ((x & z) == z) ? "1" : "0");
    }

	printf("b%s\r\n", b);
    return b;
}


