#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_014.h"

extern char* filename_read_csv_000a_014_ = (char*)"read_csv_000a_014.txt";

int read_csv_000a_014 ();
int set_read_csv_000a_014 (char** argv, int argc);
int initialize_read_csv_000a_014 (char** argv, int argc);

int read_csv_000a_014 () {
	return 1;

}


int read_csv_000a_set_014 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_014 (char** argv, int argc) {
 	return 1;
 
}

