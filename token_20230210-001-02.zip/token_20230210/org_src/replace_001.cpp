#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include <stdlib.h>
#include <time.h>
#include "timestamp.h"


#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"
#include "replace_001.h"
#include "replace_main.h"
// #include "sounds-work-001.h"
// #include "sounds-011.h"
int key_print(char* string_key1, char* string_key2, char** string_keys3, int num ) ; 
int key_print_fp(FILE* fp, char* string_key1, char* string_key2, char** string_keys3, int num ) ; 
int match_001( FILE *fp, int *index, char* string_key1) ;

int test_match_001 () ;


int test_match_001 () {
	FILE* fp;
	int index, i, a, flg_minus;
	char* string_key = NULL;
	char* string_key_001 = (char*)"aab";
	char* string_key_002 = (char*)"smld";

	fp = fopen("001-20230207-001.txt", "rb");
	if ( fp == NULL ) {
		printf("fp is null and so it exits.\r\n");
		exit(-1);
	}

	string_key = string_key_001;
	flg_minus = 0;
	index = 0;
	for ( i =0; i< 10; i++ ) {
		a = match_001( fp, &index, string_key ) ;
		printf("i %d index %d fp|%d| string_key|%s|\r\n", i, index, fp, string_key );
		if ( a == 1 ) flg_minus++;

		if ( flg_minus == 1 ) {
			index -= 2;
			i -= 2;
			string_key = string_key_002 ;
		} else if ( flg_minus == 2 ) {
			break;
		}

		if ( i < -1 ) break;		
	}

	printf("i %d flg_minus %d a %d string_key |%s| fp|%d|\r\n", i, flg_minus, a, string_key, fp );
	fclose(fp);
	printf("fp |%d|\r\n", fp);

	return 0;
}

int test_match_002 () {
	FILE* fp;
	int index, i, a, flg_minus;
	char* string_key = NULL;
	char* string_key_001 = (char*)"aab";
	char* string_key_002 = (char*)"smld";
	char* string_key_003 = (char*)"5";
	int exits = 0;

	printf("int test_match_002 () starts.\r\n");

	fp = fopen("001-20230207-001.txt", "rb");
	if ( fp == NULL ) {
		printf("fp is null and so it exits.\r\n");
		exit(-1);
	}

	printf("exits=%d\r\n", exits);
	string_key = string_key_001;
	flg_minus = 0;
	index = 0;
	for ( i =0; i<100; i++ ) {
		printf("001 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );
		a = match_001( fp, &index, string_key ) ;

		printf("002 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );

		if ( a == 1 ) flg_minus++;
		else {
			printf("a|%d| and does not match.\r\n", a);
		}
		switch(flg_minus) {
		case 0:
			break;
		case 1:
			index -= 2;
			i -= 2;
			string_key = string_key_002 ;
			break;
		case 2:
			string_key = string_key_003 ;
			break;
		case 3:
			exits = 1;
			break;
		}

		printf("003 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );

		if ( i < -1 || exits ) break;
	}

	printf("004 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );
	fclose(fp);
	printf("fp |%d|\r\n", fp);

	printf("int test_match_002 () ends.\r\n");
	return 0;
}
//
int key_print_fp(FILE* fp, char* string_key1, char* string_key2, char** string_keys3, int num ) {
	printf("int key_print(FILE* fp, char* string_key1, char* string_key2, char** string_keys3, int num ) ends.\r\n");
	printf("00 fp|%p| 01|%p|%d| 02|%p|%d| 03|%p|%d|\r\n", fp, string_key1, array_count(string_key1), string_key2, array_count(string_key2), string_keys3, num );
	for ( int i=0; i<num; i++ ) {
		printf("|%04d|%s|\r\n", i, string_keys3[i] );
	}
	printf("int key_print(FILE* fp, char* string_key1, char* string_key2, char** string_keys3, int num ) starts.\r\n");
	return 0;
}

//
int key_print(char* string_key1, char* string_key2, char** string_keys3, int num ) {
	printf("int key_print(char* string_key1, char* string_key2 char** string_key, int num ) ends.\r\n");
	printf("01|%p|%d| 02|%p|%d| 03|%p|%d|\r\n", string_key1, array_count(string_key1), string_key2, array_count(string_key2), string_keys3, num );
	for ( int i=0; i<num; i++ ) {
		printf("|%04d|%s|\r\n", i, string_keys3[i] );
	}
	printf("int key_print(char* string_key1, char* string_key2 char** string_key, int num ) starts.\r\n");
	return 0;
}

int match_001( FILE *fp, int *index, char* string_key1) {
	char dummy_001[2];
	FILE* ffp;
	int flg_fault = 0;

	// fp, ffp
	// dummy_001, dummy, string_key1
	// dummy, string_key[1]
	// fp, ffp

	printf("int match_001( FILE *fp, int *index, char* string_key1) starts.\r\n");

	fread( dummy_001, 1, 1, fp );
	ffp = fp;
	(*index)++;
	dummy_001[1] = '\0';

	printf("dummy_001 |%s| string_key1 |%s| ffp|%d| \r\n", dummy_001, string_key1, ffp );

	if ( dummy_001[0] != string_key1[0] ) {
		printf("dummy_001 |%s| string_key1 |%s| ffp|%d| fp|%d|\r\n", dummy_001, string_key1, ffp, fp );
		printf ("int match_001( FILE *fp, int *index, char* string_key1) return -1.");
		return -1;
	}

	int cmp_size = (int) array_count (string_key1);
	printf("cmp_size |%d|\r\n", cmp_size );

	if ( cmp_size == 1 ) {
		printf ("int match_001( FILE *fp, int *index, char* string_key1) return 1.\r\n");
		return 1;
	}

	char* dummy = (char*) malloc ( sizeof(char) * ( cmp_size ) );
	if ( dummy == NULL ) {
		printf("dummyis NULL.\r\n");
		exit(-1);
	}

	fread( dummy, cmp_size - 1, 1, fp );
	dummy[ cmp_size - 1 ] = '\0';

	printf("dummy |%s| fp |%d|\r\n", dummy, fp );

	for( int i=1; i<cmp_size; i++ ) {
		if ( string_key1[i] != (char)dummy[ i -1 ] ) {
			flg_fault = 1;
		}
	}

	printf("flg_fault = %d\r\n", flg_fault );

	if (flg_fault == 1 ) {
		//fp = (FILE*)ffp;
		fseek( fp, (*index), SEEK_SET);
	} else (*index) += (cmp_size - 1);

	free(dummy);

	printf("dummy_001 |%s| string_key1 |%s| ffp|%d| fp|%d| (*index)=%d\r\n", dummy_001, string_key1, ffp, fp, (*index) );
	printf("int match_001( FILE *fp, int *index, char* string_key1) ends.\r\n");
	return 1;
}
