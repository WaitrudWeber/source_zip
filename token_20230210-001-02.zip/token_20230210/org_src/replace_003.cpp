#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include <stdlib.h>
#include <time.h>
#include "timestamp.h"

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"
#include "replace_001.h"
#include "replace_002.h"
#include "replace_003.h"
#include "replace_main.h"
// #include "sounds-work-001.h"
// #include "sounds-011.h"

int test_match_003_a () ;

// for the C-Languages:
int test_match_c_003 () ;
int test_match_c_003_01 () ;

int test_match_c_003_01 () {
	STRUCT_FILE structure_fp;
	FILE* fp;
	char* p_dummy = NULL;

	printf("int test_match_c_003_01 () starts.\r\n");

//	fp = fopen( "001-mode_001-001.txt", "rb");
	fp = fopen("001-20230207-001.txt", "rb");

	int file_size = (int) filesize(fp);
	printf("file_eize %d\r\n", file_size );

	structure_fp.file_start = fp;
	structure_fp.fp = fp;
	structure_fp.file_end_index = file_size;

	fp = fopen( "001-mode_001-001.txt", "rb");
	if ( fp == NULL ) {
		printf("fp is null and so it exits.\r\n");
		exit(-1);
	}

	structure_fp.index = 3;
	p_dummy = get_string_001( structure_fp , 3 );
	p_dummy[3] = '\0';

	printf("p_dummy |%s|\r\n", p_dummy );

	fclose(fp);

	printf("int test_match_c_003_01 () ends.\r\n");
	return 0;
}

// for the C-Languages:
int test_match_c_003 () {
	STRUCT_FILE structure_fp;
	FILE* fp;
	char* line_end = "\r\n";
	int file_end = 0;
	int i, index, b_index, a;
	char* p_dummy = NULL;

	printf("int test_match_c_003 () starts.\r\n");
	fp = fopen( "001-mode_001-001.txt", "rb");
	if ( fp == NULL ) {
		printf("fp is null and so it exits.\r\n");
		exit(-1);
	}

	int file_size = (int) filesize(fp);
	printf("file_eize %d\r\n", file_size );

	structure_fp.file_start = fp;
	structure_fp.fp = fp;
	structure_fp.file_end_index = file_size;

	a = 0;
	index = 0;
	b_index = 0;
	for ( i =0; i<file_size; i++ ) {
		a = match_001( fp, &index, line_end ) ;
		printf("xx: %d %d %s", b_index, index, line_end );

		if ( a == 1 )
			b_index = index;

		structure_fp.index = b_index;
		p_dummy = get_string_001( structure_fp , index - b_index );
		printf("answer %d %d p_dummy |%s|\r\n", p_dummy, b_index, index );

	}

	printf("int test_match_c_003 () ends.\r\n");
	return 0;
}

int test_match_003_a () {
	FILE* fp;
	int index, i, a, flg_minus;
	char* string_key = NULL;
	char* string_key_001 = (char*)"aab";
	char* string_key_002 = (char*)"smld";
	char* string_key_003 = (char*)"5";
	int exits = 0;

	printf("int test_match_002_a () starts.\r\n");

	fp = fopen("001-20230207-001.txt", "rb");
	if ( fp == NULL ) {
		printf("fp is null and so it exits.\r\n");
		exit(-1);
	}

	printf("exits=%d\r\n", exits);
	string_key = string_key_001;
	flg_minus = 0;
	index = 0;
	for ( i =0; i<100; i++ ) {
		printf("001 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );
		a = match_001( fp, &index, string_key ) ;

		printf("002 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );

		if ( a == 1 ) flg_minus++;
		else {
			printf("a|%d| and does not match.\r\n", a);
		}
		switch(flg_minus) {
		case 0:
			break;
		case 1:
			index -= 2;
			i -= 2;
			string_key = string_key_002 ;
			break;
		case 2:
			string_key = string_key_003 ;
			break;
		case 3:
			exits = 1;
			break;
		}

		printf("003 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );

		if ( i < -1 || exits ) break;
	}

	printf("004 i %d index %d fp|%d| string_key|%s| exits=%d a=%d\r\n", i, index, fp, string_key, exits, a );
	fclose(fp);
	printf("fp |%d|\r\n", fp);

	printf("int test_match_002_a () starts.\r\n");
	return 0;
}
