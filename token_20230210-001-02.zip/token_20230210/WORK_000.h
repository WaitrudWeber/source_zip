#ifndef _WORK_000_H_
#define _WORK_000_H_
class WORK_000 { 
	public:
		WORK_001 *iWORK_000=nullptr;

	public:
		SetWORK_001( WORK001 *lWORK001 ); 

};
#endif
