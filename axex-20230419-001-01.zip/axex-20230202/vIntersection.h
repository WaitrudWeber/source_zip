#ifndef _VINTERSECTION_H_
#define _VINTERSECTION_H_

class vIntersection {

	public:
		int OtherSide = 0;

	private:

	public:
		vIntersection ( );
		vPoint* Intersect( vTriangle tri, vPoint eye, vPoint ray );
		// 20210609
		double Depth ( vTriangle tri, vPoint eye, vPoint ray ) ;

	private:

};

#endif

