#ifndef _WTEXT_AREA_CONTROLLER_H_
#define _WTEXT_AREA_CONTROLLER_H_

// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.


class wTextareaController {
	public:
		int CursolNumber;

	private:
		int stack_index_textarea = 0;
		int number_textarea = 42;
		int mode;
		int *ArrayTextareaNumber = NULL;
		wTextarea **AryTextarea;
		wEvent* event = nullptr;

	public:
		wTextareaController();
		void addTextarea ( wTextarea* t );
		void drawTextareas ( HDC hdc );
		void selectTextarea ( char* btn_nm );
		void selectTextarea ( );
		void setTextarea ( int i, int num ) ;
		void setEvent ( wEvent* evt ) ;
		void ProcessWmPaint () ;
		void Process () ;
		void Process_001 () ;
		void stack_number ( int num ) ;
		void stack_number_free () ;

	private:
		int Initialization ();
		int Initialization_001 ();
		int Initialization_002 ();

		//void setButton( int xx, int yy, int h, int w);
		//int wdrawButton( HDC hdc, char *button_name, RECT rect );
		//int aaa();
		//int drawButton( HDC hdc );
		//void setMode ( int m );

};

#endif


