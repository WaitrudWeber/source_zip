//------------------------------------------------------------------------------
// ��1�́@WinMain�֐�
//------------------------------------------------------------------------------
#include <tchar.h>
#include <Windows.h>

//------------------------------------------------
// �L���萔(OK)
//------------------------------------------------
#define ERRMSG_TITLE        TEXT("WinMain�֐�")
#define ERRMSG_WINREG       TEXT("�E�C���h�E�E�N���X���o�^�ł��܂���B")
#define ERRMSG_CREATE       TEXT("�E�C���h�E���쐬�ł��܂���B")

//------------------------------------------------
// �E�C���h�E�E�N���X�̓o�^
//------------------------------------------------
static ATOM funcWindowClass( HINSTANCE hInstance, LPCTSTR lpClassName )
{
    UNREFERENCED_PARAMETER( hInstance );
    UNREFERENCED_PARAMETER( lpClassName );
    return 0;
}

//------------------------------------------------
// �E�C���h�E�̍쐬
//------------------------------------------------
static HWND funcCreateWindow( HINSTANCE hInstance, LPCTSTR lpClassName, LPCTSTR lpTitleName, int nCmdShow )
{
    UNREFERENCED_PARAMETER( hInstance );
    UNREFERENCED_PARAMETER( lpClassName );
    UNREFERENCED_PARAMETER( lpTitleName );
    UNREFERENCED_PARAMETER( nCmdShow );
    return NULL;
}

//------------------------------------------------
// ���C���֐�(OK)
//------------------------------------------------
extern int WINAPI _tWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow )
{
    LPCTSTR lpClassName = TEXT("Lesson1WndClass");
    LPCTSTR lpTitleName = TEXT("��1�́@WinMain�֐�");
    MSG Msg;
    
    // �E�C���h�E�E�N���X�̓o�^
    if ( funcWindowClass(hInstance,lpClassName) == 0 ){
        MessageBox( NULL, ERRMSG_WINREG, ERRMSG_TITLE, (MB_OK|MB_ICONERROR) );
        return -1;
    }
    // �E�C���h�E�̍쐬
    if ( funcCreateWindow(hInstance,lpClassName,lpTitleName,nCmdShow) == NULL ){
        MessageBox( NULL, ERRMSG_CREATE, ERRMSG_TITLE, (MB_OK|MB_ICONWARNING) );
        return -2;
    }
    // ���b�Z�[�W�E���[�v
    while ( GetMessage(&Msg,NULL,0,0) > 0 ){
        TranslateMessage( &Msg );
        DispatchMessage( &Msg );
    }
    UNREFERENCED_PARAMETER( hPrevInstance );
    UNREFERENCED_PARAMETER( lpCmdLine );
    return Msg.wParam;
}

//------------------------------------------------------------------------------
// End of Lesson1.cpp
//------------------------------------------------------------------------------


