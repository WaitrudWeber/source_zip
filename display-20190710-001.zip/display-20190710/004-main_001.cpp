//#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "debug_curve_lines.h"

int main () {
	int a;

	a = curve_initialization () ;
	a = first_revisement ();
	a = print_curves ();

	return 0;
}
