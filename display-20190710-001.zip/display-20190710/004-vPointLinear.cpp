#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vPointStructure.h"
#include "vPointLinear.h"

//
//
//
//
//
void vPointLinear::PrintAnchors( ) {

	for ( int i=0; i<this->numPS; i++) {
		aPS[i]->Anchor->print ();
	}

}

//
//
//
//
//
//
void vPointLinear::FirstCreatation( ) {
	aPS = (vPointStructure**)malloc( sizeof(vPointStructure*) * 6 );
	this->numPS = 6;
	for ( int i=0; i<this->numPS; i++)
		aPS[i] = (vPointStructure*) new vPointStructure();

	// vPoint* p = (vPoint*)new vPoint( 1.0f, 1.0f, 1.0f );
	// aPS[0]->Anchor = p;
	// aPS[0]->Set_Anchor( p );

	aPS[0]->Anchor = (vPoint*)new vPoint( 1.0f, 0.0f, 0.0f );
	aPS[1]->Anchor = (vPoint*)new vPoint( 1.1f, 50.0f, 200.0f );
	aPS[2]->Anchor = (vPoint*)new vPoint( 1.2f, 100.0f, 400.0f );
	aPS[3]->Anchor = (vPoint*)new vPoint( 1.3f, 150.0f, 600.0f );
	aPS[4]->Anchor = (vPoint*)new vPoint( 1.4f, 120.0f, 800.0f );
	aPS[5]->Anchor = (vPoint*)new vPoint( 1.5f, 20.0f, 1000.0f );

	this->FirstRevisement( );
}

//
//
//
//
//
//
void vPointLinear::FirstRevisement( ) {

	// can not revise.
	if ( this->numPS <=2 ) return;

	vCalculation* calc = nullptr;
	calc = new vCalculation();

	for ( int i=0; i<this->numPS; i++ ) {
		aPS[i]->C1 = (vPoint*)new vPoint();
		aPS[i]->C2 = (vPoint*)new vPoint();
	}

	// calculate the middle of Anchors
	for ( int i=1; i<this->numPS; i++ ) {
		calc->add(  *(aPS[ i - 1 ]->Anchor), *(aPS[ i ]->Anchor), aPS[ i ]->C1 );
		calc->add(  *(aPS[ i - 1 ]->Anchor), *(aPS[ i ]->Anchor), aPS[ i - 1 ]->C2 );
	}

	// vPoint** normal_faces = (vPoint**) malloc ( sizeof(vPoint*) * this->numPS ) ;
	this->normal_faces = (vPoint**) malloc ( sizeof(vPoint*) * this->numPS ) ;

	// turn left, which needs 3 anchors for creation of a face.
	for ( int i=1; i<this->numPS - 1; i++ ) {
		vPoint* normal = new vPoint();
		GetNormal ( (vPoint*)aPS[ i - 1 ]->Anchor, (vPoint*)aPS[ i ]->Anchor, (vPoint*)aPS[ i + 1 ]->Anchor, normal );
		this->normal_faces[i] = (vPoint*) normal;
	}
	this->normal_faces[ 0 ] = normal_faces[ 1 ];
	this->normal_faces[ this->numPS - 1 ] = normal_faces[ this->numPS - 2 ];

}

//
//
//
//
//
void vPointLinear::GetNormal ( vPoint* p1, vPoint* p2, vPoint* p3, vPoint* normal ) {

	vCalculation* calc = nullptr;
	calc = new vCalculation();

	calc->cross( p1, p2, normal );

}

//
//
//
//
//
vLine** vPointLinear::FirstCreateLines( vPointStructure** ps, int num_devide ) {


	this->FirstCreatation();

}

//
//
//
//
//
vLine** vPointLinear::generateLines( vPointStructure** ps, int num_devide ) {




}

void vPointLinear::calculation_array () {

	// aPS = new vPointStructure[ 10 ];
}

//
//
//
//
//
void vPointLinear::calculation () {
	vPoint	*p1, *p2, *p3, *p4;
	vCalculation* calc = nullptr;

	printf("start: void vPointLinear::calculation () \r\n");

	calc = new vCalculation();
	p1 = new vPoint ( 1.0f, 2.0f, 3.0f );
	p2 = new vPoint ( 1.5f, 2.5f, 3.5f );

	p3 = calc->scale( p1, 5.0f );
	p4 = calc->scale( p2, 5.0f );

	p1->print();
	p2->print();
	p3->print();
	p4->print();

	printf("end: void vPointLinear::calculation () \r\n");
	// exit(-1);
}

//
// 0<= t <= 1
//
vPoint vPointLinear::position( vPoint* c1, vPoint* c2, float t ) {

	//20190505
	double c = 3.0; // 1/length
	vPoint* start = new vPoint();
	vPoint* end = new vPoint();
	vCalculation* calc = nullptr;

//	vPoint a = calc->scale( start, t*t  );
//	vPoint b = calc->scale( end, 1 - t*t  );
//	vPoint c1 = calc->add ( a, b ) ;

	vPoint result;

	return result;
}

//
//
//
//
//
vPoint vPointLinear::additional_positionP( vPoint* c1, vPoint* c2, float t ) {

	//20190505
	double c = 3.0; // 1/length
	vPoint* start = new vPoint();
	vPoint* end = new vPoint();
	vCalculation* calc = nullptr;
	calc = new vCalculation();

	vPoint a = calc->scale( *start, t*t  );
//	vPoint b = calc->scale( end, 1.0 - t*t  );
//	vPoint c1 = calc->add ( a, b );

	vPoint result;

	return result;
}

//
//
//
//
//
vPoint vPointLinear::additional_position (vPointStructure* ps1, vPointStructure* ps2, float t ) {

	vPoint p;

	return p;
}
