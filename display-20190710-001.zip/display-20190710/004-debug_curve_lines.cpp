#include <tchar.h>
#include <windows.h>
#include <windowsx.h>


#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
#include "vPointStructure.h"
#include "vPointLinear.h"

#include "debug_curve_lines.h"

int display_threeD_initialize () ;
int getchar_up () ;
void Print_Global_Vertexes ( vPoint* points, int** numbering, int num_patches, int base_num_patches) ;

vPoint* pointss = nullptr;
int** patches = nullptr;
vLine* patch_lines = nullptr;

int num_patches = 0;
int base_num_patches = 0;
int num_patch_lines = 0;

vTriangle atri;
vTriangle screen_tri;
// static vPoint eye;

vPoint ray;
vPoint point_intersection;
float g_x, g_y;
int display_3d = 0;
vLine** lines = nullptr;		// axes in the 3-D.
vLine** lines_2D = nullptr;  // axes on the screen.

vLine** lines_patches = nullptr;
vLine** lines_patches_2D = nullptr;

vScreen* screen = nullptr;

static int call_once_display_threeD_initialize = 0;
vLine* to_screen( vLine** v3d_line, int num ) ;
int count_screen( char* pchar_vline ) ;

void put_vertex(  vPoint* be_set, vPoint* p1 );

vPoint* vertexes = nullptr;
int** patch_num = nullptr;

// Curve
static vPointLinear* CurveLines = new vPointLinear ();
static int memorized_CurveLines = 0;

vLine* to_screen_line( vLine* ll ) ;
void create_lines( vPointLinear* curveLines, vLine** sl_lines, int num ) ;

int waitfor_wmpaint_display_threeD_proc () ;
int create_CurveLines( vLine** l_lines, int line_num ) ;
void test_inclusion () ;
int first_revisement () ;
int curve_initialization () ;
int print_curves () ;


//
//
//
//
//
void test_inclusion () {
}

//
//
//
//
//
int print_curves () {

	printf("print_curves()\r\n");
	CurveLines->PrintAnchors();
	printf("print_curves\r\n");

	return 1;
}

//
//
//
//
//
int first_revisement () {

	printf("first_revisement()\r\n");
	CurveLines->FirstRevisement();
	printf("first_revisement\r\n");

	return 1;
}


// scope : 20190217
//
//
//
//
void put_vertex(  vPoint* be_set, vPoint* p1 ) {
	be_set->setPoint( p1->x, p1->y, p1->z );
}

//
//
//
//
//
int curve_initialization () {

	printf("curve_initialization()\r\n");
	CurveLines->FirstCreatation();
	printf("CurveLines->FirstCreatation()\r\n");
}

// All qualified at 20190627:
//
//
//
//
int display_threeD_screen_initialize () {
	vPoint* eye = nullptr;

	if ( call_once_display_threeD_initialize == 0 ) {
		call_once_display_threeD_initialize = 1;
	} else {
		exit(-1);
	}

	eye = new vPoint();
	eye->setPoint( 500.0f, 500.0f, -500.0f);
	screen = new vScreen ();
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen->put_U ( *U );
	screen->put_V ( *V );

	screen->put_Up ( *( new vPoint(0.0f, 1.0f, 0.0f) ) );
	screen->put_C ( *( new vPoint( 0.0f, 0.0f, -50.0f) ));
	screen->setWidth ( 640 );
	screen->setHeight ( 480 );
	screen->setEye ( *eye );
	screen->LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );
	screen->HowFarFromEve = 320.0f;

	screen->calculation_up_UV();
	screen->OntheScreen( &g_x, &g_y );

	if ( memorized_CurveLines == 0 )
		curve_initialization();

	memorized_CurveLines = 1;
	printf("display_threeD_screen_initialize:memorized_CurveLines=%d\r\n", memorized_CurveLines );
}

//
//
//
//
//
int display_threeD_initialize () {
	vPoint eye;
	char *p_cc;

	if ( call_once_display_threeD_initialize == 0 ) {
		call_once_display_threeD_initialize = 1;
	} else {
		exit(-1);
	}

	printf("display_threeD_initialize\r\n");

	eye.setPoint( 500.0f, 500.0f, -500.0f);

	atri.p1.setPoint( 100.0f,   0.0f, 100.0f );
	atri.p2.setPoint( 200.0f, 200.0f, 200.0f );
	atri.p3.setPoint( 300.0f,   0.0f, 100.0f );

	screen = new vScreen ();
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen->put_U ( *U );
	screen->put_V ( *V );

	screen->put_Up ( *( new vPoint(0.0f, 1.0f, 0.0f) ) );
	screen->put_C ( *( new vPoint( 0.0f, 0.0f, -50.0f) ));
	screen->setWidth ( 640 );
	screen->setHeight ( 480 );
	screen->setEye ( eye );
	screen->LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );
	screen->HowFarFromEve = 320.0f;
	screen->calculation_up_UV();
	screen->OntheScreen( &g_x, &g_y );

	display_3d = 1;

	printf("display_threeD_initialize=000\r\n");

	lines = (vLine**) malloc ( sizeof(vLine*) * 3 );
	lines_2D = (vLine**) malloc ( sizeof(vLine*) * 3 );
	for( int i=0; i<3; i++ ) {
		printf("i:%d \r\n", i);
		lines[i] = new vLine();
		lines_2D[i] = new vLine();
	}
	//exit(-1);

	lines[0]->setLine( (new vPoint( -50.0f, 0.0f, 0.0f)), (new vPoint(300.0f,   0.0f, 0.0f)) );
	lines[1]->setLine( (new vPoint( 0.0f, -50.0f, 0.0f)), (new vPoint(  0.0f, 300.0f, 0.0f)) );
	lines[2]->setLine( (new vPoint( 0.0f, 0.0f, -50.0f)), (new vPoint(  0.0f, 0.0f, 300.0f)) );
	lines[0]->c1 = (char*) "x1";
	lines[0]->c2 = (char*) "x2";

	printf("display_threeD_initialize=001\r\n");

	lines_2D[0]->setLine( (new vPoint( 0.0f, 0.0f, 0.0f)), (new vPoint( 300.0f,   0.0f, 0.0f)) );
	lines_2D[1]->setLine( (new vPoint( 0.0f, 0.0f, 0.0f)), (new vPoint(   0.0f, 300.0f, 0.0f)) );
	lines_2D[2]->setLine( (new vPoint( 0.0f, 0.0f, 0.0f)), (new vPoint(   0.0f,   0.0f, 300.0f)) );

	printf("display_threeD_initialize=002\r\n");

	lines_patches = (vLine**) malloc ( sizeof(vLine*) * 3 );
	lines_patches_2D = (vLine**) malloc ( sizeof(vLine*) * 3 );

	printf("display_threeD_initialize=0021\r\n");

	for( int i=0; i<3; i++ ) {
		lines_patches[i] = new vLine();
		lines_patches_2D[i] = new vLine();
	}

	// commented out at 20190518
	lines_patches[0]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[0]->p2 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[1]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[1]->p2 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[2]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[2]->p2 = new vPoint( 0.0f, 0.0f, 0.0f); 

	printf("display_threeD_initialize=0022\r\n");

	// x lines_patches[0]->setLine( new vPoint( 0.0f, 0.0f, 0.0f), new vPoint( 0.0f, 0.0f, 0.0f) );
	// x lines_patches[0]->setLine( new vPoint( 0.0f, 0.0f, 0.0f), new vPoint( 0.0f, 0.0f, 0.0f) );
	printf("lines_patches[2]->p2->x %f\r\n", lines_patches[2]->p2->x );

    printf("display_threeD_initialize=0023\r\n");

	// commented out at 20190518
	lines_patches_2D[0]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[0]->p2 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[1]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[1]->p2 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[2]->p1 = new vPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[2]->p2 = new vPoint( 0.0f, 0.0f, 0.0f); 

	lines_patches_2D[0]->c1 = (char *) p_cc;
	lines_patches_2D[0]->c1 = (char *) copyof( "x1" );
	lines_patches_2D[0]->c2 = (char *) copyof( "x2" );
	lines_patches_2D[1]->c1 = (char *) copyof( "y1" );
	lines_patches_2D[1]->c2 = (char *) copyof( "y2" );
	lines_patches_2D[2]->c1 = (char *) copyof( "z1" );
	lines_patches_2D[2]->c2 = (char *) copyof( "z2" );

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	//point_intersection = intersection->Intersect( atri, eye, ray );

	printf("display_threeD_initialize=003\r\n");

	// Book a triangle patch
	num_patches = 1;
	patch_num = (int**) malloc( sizeof(int*) * 1 ) ;
	vertexes = (vPoint*) malloc( sizeof(vPoint) * 8 ) ;

	vertexes = new vPoint ( 0.0f, 0.0f, 0.0f );
	// scope put a vertex
	put_vertex( vertexes + 1, new vPoint ( 5.0f, 10.0f, 0.0f ));
	put_vertex( vertexes + 2, new vPoint ( 10.0f, 0.0f, 0.0f ));

	base_num_patches = 3;
	printf("display_threeD_initialize=001");
	Print_Global_Vertexes ( vertexes, patch_num, num_patches, base_num_patches );

	int* p_tri_patch = (int*) malloc( sizeof(int) * base_num_patches ) ;
	p_tri_patch[0] = 0;
	p_tri_patch[1] = 1;
	p_tri_patch[2] = 2;

	patch_num[0] = p_tri_patch;

	num_patch_lines = 0;
	num_patch_lines = base_num_patches*num_patches;


	if ( memorized_CurveLines == 0 )
		curve_initialization();

	memorized_CurveLines = 1;

	printf("display_threeD_initialize will return 0.\r\n");

	return 0;
}

//
//
//
int get_cooordinate_on_screen ( vPoint lp, float* lx, float* ly ) {
	vCalculation calc;
//	vTriangle screen_tri;

	ray = calc.subtract( lp, screen->eye);
	ray = calc.normal(ray);
	// if ( ray.x == 0 && ray.y == 0 && ray.z == 0 ) return -1;

	screen_tri.p1 = screen->C;
	screen_tri.p2 = calc.add( screen->C, screen->U );
	screen_tri.p3 = calc.add( screen->C, screen->V );

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	vPoint point_intersection = intersection->Intersect( screen_tri, screen->eye, ray );

	printf("intersection = ");
	point_intersection.print();
//
//	vPoint result;
//	screen->setPoint(lp);
//	screen->OntheScreen( lp, &result );

	int result = screen->OntheScreen( point_intersection, lx, ly );

	return 0;
}

//
//
//
//
void Print_Global_Vertexes ( vPoint* points, int** numbering, int num_patches, int base_num_patches)
{
// 20190217
// p( 10.000000, 0.000000, 0.000000)
// p( 0.000000, 186447550218240.000000, -0.000000)
// p( 0.000000, 0.000000, 300.000000)

	int num = num_patches*base_num_patches;
	for(int i=0; i< num; i++ ) {
		( points + i )->print();
	}
}

//
//
//
//
//
int calculation_pathes () {

	vPointLinear mpl;

	float t = 0.0f;
	vPoint* c1 = new vPoint ( 0.0f, 0.0f, 0.0f );
	vPoint* c2 = new vPoint ( 0.0f, 0.0f, 0.0f );

	vPointLinear* pl = new vPointLinear();
	pl->calculation ();

	for ( int i=0; i< 100; i++ ) {
		double di = i;
		t = di/100.0 ;
//		vPoint result = (vPoint) pl->additional_positionP( c1, c2, t );
//		result = (vPoint) mpl.additional_positionP( c1, c2, t );

	}

	return 0;
}

//
//
//
//
//
int waitfor_wmpaint_display_threeD_proc () {

	for( int i=0; i<2; i++ ) {
		printf("memorized_CurveLines=%d\r\n", memorized_CurveLines );
		if ( memorized_CurveLines == 1 ) return 1;
		Sleep (1000);
	}

}

//
//
//
//
//
//
int NormalFaces_wmpaint_display_threeD_proc () {
	static char num_str[2048];
	static vLine** l_lines = nullptr;

	if ( memorized_CurveLines == 0 ) return -1;
	if ( l_lines != nullptr ) return 2;

	l_lines = (vLine**) malloc( sizeof(vLine*) * CurveLines->numPS );
	for( int i=0; i<CurveLines->numPS; i++ ) {
		l_lines[i] = new vLine();
	}
	create_lines( (vPointLinear*)CurveLines, l_lines, CurveLines->numPS );
	//exit( -1 );

	for( int i=0; i<CurveLines->numPS; i++ ) {
		l_lines[i]->p1->print();
		l_lines[i]->p2->print();
		// GamePaint_011( hDC, l_lines[i] );
	}

	//exit(-1);
}

//
//
//
//
//
void create_lines( vPointLinear* curveLines, vLine** l_lines, int num ) {
	printf( "create_lines: START:\r\n" );
	vCalculation* calc = new vCalculation ();
	for( int i=0; i<num; i++ ) {
		printf ( "normal_faces i %d / %d: ", i, num );
		if ( curveLines->aPS[i]->Anchor == nullptr ) exit(-1);
		if ( curveLines->normal_faces[i] == nullptr ) exit(-1);

		//curveLines->normal_faces[i]->print();
		vPoint* p3 = new vPoint();
		calc->add( curveLines->aPS[i]->Anchor, (vPoint*)curveLines->normal_faces[i], p3 );
		p3->print();
		curveLines->aPS[i]->Anchor->print();
		l_lines[i]->setLine( (vPoint*)curveLines->aPS[i]->Anchor, p3 );
	}
	printf( "create_lines: END:\r\n" );
}


//
//
//
//
//
vLine* to_screen_line( vLine* ll ) {
	float fx[3], fy[3];

	get_cooordinate_on_screen ( *(ll->p1), &fx[0], &fy[0] );
	ll->p1->x = fx[0];
	ll->p1->y = fy[0];
	get_cooordinate_on_screen ( *(ll->p2), &fx[0], &fy[0] );
	ll->p2->x = fx[0];
	ll->p2->y = fy[0];

	return ll;
}

//
//
//
//
//
int create_CurveLines( vLine** l_lines, int line_num ) {
	static float fx[3], fy[3];
	static char num_str[2048];

	if ( line_num == 0 ) return 0;

	if ( l_lines == nullptr ) {
		l_lines = (vLine**) malloc( sizeof(vLine*) * line_num );
	}
	get_cooordinate_on_screen ( *(CurveLines->aPS[0]->Anchor), &fx[0], &fy[0] );



	// Quallified here at 20190628.
	// Allocation vLine which has vPoint p1 and p2.
	l_lines[0] = new vLine();
	l_lines[ 0 ]->p1->x = fx[0];
	l_lines[ 0 ]->p1->y = fy[0];
	l_lines[ 0 ]->c1 = copyof("A0");

	printf("003\r\n");

	for( int i=1; i<line_num; i++ ) {
		get_cooordinate_on_screen ( *(CurveLines->aPS[i]->Anchor), &fx[0], &fy[0] );
		l_lines[ i - 1 ]->p2->x = fx[0];
		l_lines[ i - 1 ]->p2->y = fy[0];
		l_lines[ i ] = new vLine();
		l_lines[ i ]->p1->x = fx[0];
		l_lines[ i ]->p1->y = fy[0];
		l_lines[ i ]->c1 = copyof( m_concat( copyof("A"), itoa( i, num_str, 10 ) ) );
	}

	get_cooordinate_on_screen ( *(CurveLines->aPS[ line_num - 1 ]->Anchor), &fx[0], &fy[0] );
	l_lines[ line_num - 1 ]->p2->x = fx[0];
	l_lines[ line_num - 1 ]->p2->y = fy[0];
	l_lines[ line_num - 1 ]->c1 = copyof("A6");

	return 1;
}

//
//
//
//
//
vLine* to_screen( vLine** v3d_line, int num ) {
	vLine* v2d_line = nullptr;
	vLine a;
	int b[3];
	vLine l[3];
	float x, y;

//	int num = sizeof(v3d_line) / sizeof( vLine ) ;
	a.p1 = new vPoint( 0.0f, 0.0f, 0.0f );

	v2d_line = (vLine*) malloc( sizeof(vLine) * num );
	for( int i=0; i<num; i++ ) {
		vLine* line = ( v2d_line + i ) ;
		line->p1 = new vPoint();
		line->p2 = new vPoint();
	}


	//printf("b=%d int size = %d\r\n", sizeof(b), sizeof(int) );
	//printf("l=%d vLine size = %d\r\n", sizeof(l), sizeof(vLine) );
	//printf("v2d_line=%d vLine size = %d conunt array %d\r\n", sizeof(v2d_line), sizeof(vLine), count_screen((char*)(&l[0])) );

//	printf("num=%d %d %d / %d sizeof a vLine %d &vLine %d\r\n", num, sizeof( v3d_line ), sizeof( *v3d_line ), sizeof( vLine ), sizeof(a), sizeof(&a) );

	printf("set of to_screen.\r\n");

	for ( int i=0; i<num; i++ ) {
		vLine* l1 = *( v3d_line + i );
		vLine* l2 = ( v2d_line + i );

		printf(" %d / %d \r\n", i, num );

		vPoint* p1 = l1->p1;
		vPoint* p2 = l1->p2;

		vPoint* d2_p1 = l2->p1;
		vPoint* d2_p2 = l2->p2;

		get_cooordinate_on_screen ( *(a.p1), &x, &y );

		// exit(-1);
		p1->print();

//		get_cooordinate_on_screen ( *(p1), &x, &y );
//		get_cooordinate_on_screen ( *p1, &( d2_p2->x ), &( d2_p2->y ) );
//		get_cooordinate_on_screen ( *(l1->p2), &(l2->p2->x), &(l2->p2->y) );

		// the below parts are all error.
//		get_cooordinate_on_screen ( *(l1->p1), &(l1->p1->x), &(l1->p1->y) );
//		get_cooordinate_on_screen ( *(l1->p2), &(l1->p2->x), &(l1->p2->y) );
//		get_cooordinate_on_screen ( *(l2->p1), &(l2->p1->x), &(l2->p1->y) );
//		get_cooordinate_on_screen ( *(l2->p2), &(l2->p2->x), &(l2->p2->y) );
	}

	printf("end of to_screen.\r\n");
	// exit(-1);

	return v2d_line;
}

//
//
//
//
//
int count_screen( char* pchar_vline ) {

	int result = 0;
	for( int i=0; i=256*256; i++ ) {
		result++;
		char* c = pchar_vline++;
		if ( *c == '\0' ) break;
	}

	return result;
}

// Very Thanks to: http://www.informit.com/articles/article.aspx?p=328647&seqNum=3
// int FillRect(HDC hDC, CONST RECT *lprc, HBRUSH hbr);
// BOOL Rectangle(HDC hDC, int xLeft, int yTop, int xRight, int yBottom);
// BOOL MoveToEx(HDC hDC, int x, int y, LPPOINT pt);
// BOOL LineTo(HDC hDC, int x, int y);
// BOOL TextOut(HDC hDC, int x, int y, LPCTSTR szString, int iLength);
// HPEN CreatePen(int iPenStyle, int iWidth, COLORREF crColor);
// HPEN hBluePen = CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
// HBRUSH hPurpleBrush = CreateSolidBrush(RGB(255, 0, 255));
// HPEN hPen = SelectObject(hDC, hBluePen);
// SelectObject(hDC, hPen);
// DeleteObject(hBluePen);
// HBRUSH hBrush = SelectObject(hDC, hPurpleBrush);
//  // *** Do some drawing here! ***
//  SelectObject(hDC, hBrush);
//  DeleteObject(hPurpleBrush);

// case WM_PAINT:
//  HDC     hDC;
//  PAINTSTRUCT ps;
//  hDC = BeginPaint(hWindow, &ps);

//  // Paint the game
//  GamePaint(hDC);
//
// EndPaint(hWindow, &ps);
// return 0;
//
//
//
//

