#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "vLine.h"
#include "debug_curve_lines.h"

int memorize_lines_001_main () ;
int create_curve_main () ;


int main () {


	printf("main:\r\n");

	memorize_lines_001_main ();

	return 0;
}

//
//
//
//
//
int memorize_lines_001_main () {
	int num_lines = 10;
	vLine** lines = nullptr;
	vLine* aline = nullptr;
	vLine* bline = nullptr;
	vLine sline;

	printf("memorize_lines_001_main () starts\r\n");

/*	lines = (vLine**)malloc( sizeof(vLine*) * num_lines);
	for ( int i=0; i< num_lines; i++ ) {
		// x lines[i] = new vLine();
		// x aline = new vLine();
	}

	for ( int i=0; i< num_lines; i++ ) {
		printf("lines %d: p1 ", i );
		// x lines[i]->p1->print();
		// x sline.p1->print();
		printf("lines %d: p2 ", i );
		// x lines[i]->p2->print();
	}
*/
	printf("memorize_lines_001_main () will return 0\r\n");

	return 0;
}

//
//
//
//
//
int create_curve_main () {
	int a;

	a = curve_initialization () ;
	a = first_revisement ();
	a = print_curves ();

	return 0;
}
