#include "vPoint.h"
#include "vLine.h"

vLine::vLine ( ) {

	this->setLine( new vPoint(), new vPoint() );
}

//
//
//
//
//
void vLine::setLine ( vPoint* ap1, vPoint* ap2 ) {
	p1->x = ap1->x;
	p2->x = ap2->x;
	p1->y = ap1->y;
	p2->y = ap2->y;
	p1->z = ap1->z;
	p2->z = ap2->z;
}

//
//
//
//
//
void vLine::print () {
	//this->p1->print();
}

