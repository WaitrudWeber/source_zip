#ifndef _DEBUG_CURVE_LINES_H_
#define _DEBUG_CURVE_LINES_H_

extern int create_CurveLines( vLine** l_lines, int line_num ) ;
//extern void test_inclusion_a () ;
extern void test_inclusion () ;
extern int first_revisement () ;
extern int curve_initialization () ;
extern int print_curves () ;

#endif
