#ifndef MULTITHREAD_H
#define MULTITHREAD_H

// #ifndef SERVER_H
// #define SERVER_H

extern int thread_dispose;
extern int multithread () ;

#endif
