#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"

#include "vScreen.h"


vScreen::vScreen ( ) {

	//Point U = new Point();
	//Point V = new Point();

	this_calc = new vCalculation ();
}

int vScreen::getWidth() {
	return this->width;
}
int vScreen::getHeight() {
	return this->height;
}

int vScreen::OntheScreen ( vPoint lp, vPoint* result ) {

	// Screen( x, y );

	return 0;
}

// All qualified at 20190627:
//
//
//
//
int vScreen::OntheScreen ( vPoint lp, float* x, float* y ) {
	vCalculation calc;
	vPoint result;

	//printf("lp= ");
	//lp.print ();

	// Screen( x, y )
	// lp is surely on the screen.
	calc.subtract( &(lp) , &(this->C), &result );

	printf("lp = ");
	lp.print();

	printf("C = ");
	this->C.print();


	printf("result_001 = ");
	result.print();

//	*x = calc.dot( result, this->U ); // right
//	*y = calc.dot( result, this->V ); // up
	*x = calc.dot( result, this->u ); // right
	*y = calc.dot( result, this->up ); // up

	printf("up= ");
	this->up.print();
	printf("right= ");
	this->u.print();


	printf("001 x, y = %f , %f\r\n", *x, *y);

//	*x /= (double)this->width;
//	*y /= (double)this->height;

/*	printf("002 x, y = %f , %f\r\n", *x, *y);

	*y = -*y + this->height;

	printf("003 x, y = %f , %f height %f\r\n", *x, *y, this->height);*/

/*	result_x = calc.cross ( result, this->u ) ;
	result_y = calc.cross ( result, this->up ) ;

	// double -> float
	*x = (float) this_calc->length( result_x );
	*y = this->height - (float) this_calc->length( result_y );

	*x = *x + this->width / 2.0f;
	*y = ( -*y + this->height )  + this->height/2.0f; */

	return 0;
}

void vScreen::OntheScreen ( float* x, float* y ) {
	vPoint px;
	vPoint py;

	OntheScreen( &px, &py );
	*x = px.x;
	*y = px.y;
}

void vScreen::OntheScreen ( vPoint* x, vPoint* y) {
	vPoint px, py;
	subtract ( X, C, &px );
	subtract ( Y, C, &py );
}

void vScreen::LookAt ( vPoint lookat ) {
	this->lookat = lookat;
}

void vScreen::put_U ( vPoint a ) {
	U = a;
}

void vScreen::put_Up ( vPoint up ) {
	vCalculation calc;
	
	calc.normal( &(up), &(this->up) );
}

void vScreen::put_V ( vPoint b) {
	V = b;
}

void vScreen::put_C ( vPoint c) {
	C = c;
}

void vScreen::calculation () {
	calculation_uv_up();
}

void vScreen::calculation_uv_up () {

	vCalculation calc;

	calc.normal ( &(this->U), &(this->u) ) ;
	calc.normal ( &(this->V), &(this->v)  ) ;
	calc.cross ( &(this->u), &(this->v), &(this->up) ) ;

}

void vScreen::calculation_up_UV () {
	vCalculation calc_this;
	vPoint howfar, harfU, harfV;

	printf("this->eye= ");
	this->eye.print();
	printf("lookat= ");
	this->lookat.print();

	calc_this.subtract ( &(this->lookat), &(this->eye), &howfar );
	calc_this.normal( &howfar );
	printf("normal howfar= ");
	howfar.print();

	calc_this.scale( howfar, this->HowFarFromEve );

	printf("this->HowFarFromEve=%d\r\n", this->HowFarFromEve);

	printf("howfar= ");
	howfar.print();

	calc_this.add( &(this->eye), &howfar, &(this->C) );

	normal ( &(this->up) ) ;
	printf("up= ");
	up.print();

	u = cross( howfar, up );		//right , -left
	calc_this.normal ( u ) ;				
	up = cross( u, howfar );		//up
	v = cross( up, u );				// depth

	calc_this.scale( &u, this->width, &U );
	calc_this.scale( &(this->up), this->height, &V ); // V means UP, v means depth direction

	printf("u= ");
	u.print();
	printf("U= ");
	U.print();
	printf("V= ");
	V.print();

	calc_this.scale( &(u), -this->width/2.0f, &harfU );
	calc_this.scale( &(this->up), -this->height/2.0f, &harfV );

	calc_this.add( &(this->C), &(harfU), &(this->C) );
	calc_this.add( &(this->C), &(harfV), &(this->C) );

	printf("this->C= ");
	this->C.print();

	calc_this.add( &(this->C), &(this->U), &(this->LeftTop) );
	calc_this.add( &(this->C), &(this->V), &(this->RightBottom) );

	printf("this->LeftTop= ");
	this->LeftTop.print();
	printf("this->RightBottom= ");
	this->RightBottom.print();

}

vPoint vScreen::getRight() {
	//right also -left is this->u.
	return this->u;
}


void vScreen::normal( vPoint *a) {
	this_calc->normal ( a ) ;
}

void vScreen::subtract( vPoint a, vPoint b, vPoint *result) {

	result = this_calc->subtract ( a, b ) ;
}

vPoint vScreen::cross( vPoint a, vPoint b) {
	vPoint result;

	this_calc->cross ( &a, &b, &result ) ;
	return result;
}

//
//
//
void vScreen::setWidth( int w ) {
	this->width = w;
}

//
//
//
void vScreen::setHeight( int h ) {
	this->height = h;
}

//
//
//
void  vScreen::setEye ( vPoint leye ) {
	this->eye.x = leye.x;
	this->eye.y = leye.y;
	this->eye.z = leye.z;
}

