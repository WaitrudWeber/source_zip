

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "wEvent.h"
#include "wButton.h"
#include "wButtonController.h"
#include "wCanvasController.h"

#include "vDisplayController_002.h"



int vDisplayController_002::SetCanvas ( wCanvasController *l_canvas ) {
	this->canvas = l_canvas;
}

int vDisplayController_002::DisplayBones_002 () {
	//vPoint bones_001[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;

	printf("vDisplayController_002:: DisplayBones_002 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}


	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones_001[0].setPoint (  0.0f,  0.0f,    0.0f );
	bones_001[1].setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones_001[1], bones_001[0], &w1 );
	for ( int j=2; j<10; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones_001[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones_001[j-1].print();
			bones_001[j].print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones_001[ j ].setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("vDisplayController_002:: DisplayBones_002 () ends.\r\n");
//	exit(-1);
	return 0;
}

// 1. copy this function as _003.
// 2. use aFree in vCaculation.
// 3. set a moved point as selected.
int vDisplayController_002::MoveSelectedPoint_002 () {
	float x, y;
	vCalculation calc;
	const float c = 5.0f;
	vPoint* range_001;

	printf("int vDisplayController::MoveSelectedPoint_002 () starts.\r\n");

	vPoint* up_001 = &(screen_006.up);
	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones_001[selected] );

	//scalize * = *, *
	range_001 = calc.scalize ( up_001, c );

	// ADD calculation * = * , *
	vPoint* moved_point = calc.add ( selected_point, range_001 );

	printf("selected_point=");
	selected_point->print();

	printf("up_001=");
	up_001->print();


	printf("moved_point=");
	moved_point->print();

	// convert value, p, p
	int a = screen_006.get_cooordinate_on_screen ( *moved_point, &x, &y );
	int stored = this->canvas->AXEX_2D_002_Index;
	this->canvas->AXEX_2D_002_Index = selected;
	this->canvas->Set_vAxex_2D( x, y );
	this->canvas->AXEX_2D_002_Index = stored;

	printf("1002 x, y = %f, %f\r\n", x, y);

	printf("int vDisplayController::MoveSelectedPoint_002 () ends.\r\n");
	return 0;
}
// From u to x
// 1. copy this function as _003.
// 2. use aFree or free_point in vCaculation.
// 3. set a moved point as selected.
//
int vDisplayController_002::MoveSelectedPoint_003 () {
	float x, y;
	vCalculation calc;
	const float c = 50.0f;
	vPoint* range_001;

	printf("int vDisplayController::MoveSelectedPoint_002 () starts.\r\n");

	vPoint* up_001 = &(screen_006.up);
	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones_001[selected] );

	//scalize * = *, *
	range_001 = calc.scalize ( up_001, c );

	// ADD calculation * = * , *
	vPoint* moved_point_003 = calc.add ( selected_point, range_001 );
	this->bones_001[ selected ].setPoint( moved_point_003->x, moved_point_003->y, moved_point_003->z );

	printf("selected_point=");
	selected_point->print();

	printf("up_001=");
	up_001->print();

	printf("range_001=");
	range_001->print();

	printf("moved_point_003=");
	moved_point_003->print();

	printf("bones_001=");
	this->bones_001[ selected ].print();

	// convert value, p, p
	int a = screen_006.get_cooordinate_on_screen ( this->bones_001[ selected ], &x, &y );
	int stored = this->canvas->AXEX_2D_002_Index;
	this->canvas->AXEX_2D_002_Index = selected;
	this->canvas->Set_vAxex_2D( x, y );
	this->canvas->AXEX_2D_002_Index = stored;

	printf("1002 x, y = %f, %f\r\n", x, y);

	free_point ( up_001 );
	free_point ( selected_point );
	free_point ( moved_point_003 );
	//free_point ( range_001 );
	free ( range_001 );

	printf("range_001_a=");
	range_001->print();

	printf("int vDisplayController::MoveSelectedPoint_002 () ends.\r\n");
	return 0;
}


int vDisplayController_002::PrintBones ( ) {
	float x, y;
	vCalculation calc;
	printf("int vDisplayController_002::PrintBones () starts.\r\n");

	printf("bones_001 bones_max_index %d: \r\n", this->bones_max_index );
	for ( int i =0; i<this->bones_max_index; i++ ) {
		this->bones_001[i].print();
	}

	printf("int vDisplayController_002::PrintBones () ends.\r\n");
	exit(-1);
	return 0;
}

int vDisplayController_002::PrintBones_001 ( ) {
	float x, y;
	vCalculation calc;
	printf("int vDisplayController_002::PrintBones () starts.\r\n");

	printf("bones_001 bones_max_index %d: \r\n", this->bones_max_index );
	for ( int i =0; i<this->bones_max_index; i++ ) {
		this->bones_001[i].print();
	}

	printf("int vDisplayController_002::PrintBones () ends.\r\n");
	return 0;
}
