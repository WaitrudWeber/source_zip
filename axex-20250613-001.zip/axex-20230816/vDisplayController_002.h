#ifndef _V_DISPLAY_cONTROLLER_002_H_
#define _V_DISPLAY_cONTROLLER_002_H_

#include "vBox.h"
#include "vDisplayController_001.h"
#include "wCanvasController.h"

// 1. copy vDisplayController_001.h vDisplayController_001.cpp.
// 2. renumber by use of replace vDisplayController_001 to vDisplayController_002 in them above.
// 3. add Makefile vDisplayController_001.cpp.

class vDisplayController_002 {

	private:
		vPoint bones_001[10];
		int bones_max = 10;
		int bones_max_index = 0;
		//20250216
		vPoint** bones_006_01 = NULL;
		int bones_index_006_01 = 0;
		int bones_max_006_01 = 0;
		//20250216
		wCanvasController* canvas = nullptr;
		vCalculation Calc;
		vScreenCG screen_006;
		vLine** axex_line_3d_002 = nullptr;
		int axex_line_max = 3;
		char* ppm_filename = NULL;
		float*** ppm_img = NULL;
		int ppm_width, ppm_height;
		vDisplayController_001 display_001;
		char sound_buffer[255];

//		vBox box( 0.0f, 0.0f, 100.0f, 100.0f );

	public:
		int param_print = 0; // 1 is very slow abd exut.
		int debug = 2; // 0: 1: 2:

	private:
		int Set_Canvas_Bones () ;
		vPoint** reallocation_set_point_2d (int num); // 20250216
//		int SetCanvasBones_002 () :
//		int SetCanvasBones () :


	public:
		vLine** GetAxex(int* num);
		//20250216
		vPoint** GetPoints();
		vPoint** GetPoints(int* num);
		int CreateBones () ;
		//20250216
		int SetCanvas ( wCanvasController *l_canvas ) ;
		int SetPoint2D( float x, float y ) ;
		int PrintBones () ;
		int PrintBones_001 () ;
		int DisplayBones_002 () ;
		int DisplayBones_005_01 () ;
		int DisplayPillar () ;
		int DisplayAxex () ;
		int DisplayLightHouse () ;
		int DisplayBonesGear () ;
		int MoveSelectedPoint_002 () ;
		int MoveSelectedPoint_003 () ;
		int MoveSelectedPoint_004 (int number) ; // 1:up 2:right: depth
		int SetBaseAxex () ;
		int DisplayBaseAxex () ;
		int DisplayBaseAxexFixed () ;
		int SetEye (float x, float y, float z) ;
		int write_ppm_002 (char* filename, float*** img, int width, int height, int flag) ;
		int read_ppm_002 (char* filename, float*** img, int* width, int* height, int flag) ;
		int init_buffer (char* buffer, int size, int flag) ;
		int draw_line_002 (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) ;
		int create_img_buffer (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) ;
		int create_img_buffer_002 (char* filename, int width, int height, int flag) ;
		int create_img_buffer_print_its_adress (char* filename, int width, int height, int flag) ;
		int draw_canvas_buffer () ;
		int DisplaySolid (vPoint center ) ;
		int param_int (char* head, int* width, int* height);
		int param_int ( char* head, int* density );
		char* rechar_string (char* string_002, int num);
		char* mchar_string (char* string_002, int num);
		int mchar_string_001 (char* string_002, int num);
		int mchar_string_002 (char* string_002, int num);
		int realloc_main ();
		int malloc_main ();
		int malloc_main_001 ();
		int malloc_main_002 ();
		int Reflection_Figure (vTriangle *tri, vPoint eye, vPoint direction, vPoint **points, vLine **lines);
		int Reflection_Figure_with_Screen ( ) ;
		int Reflection_Figure_Setting (vTriangle *tri ) ;
		int Reflection_Figure (vTriangle *tri, vReturnableParam *result) ;
		vLine** CreateTriangleLine( vPoint p1, vPoint p2, vPoint p3, vPoint p4, vPoint p5, vPoint p6, vReturnableParam *result );
		int Reflection_Figure_Check_Triangle (vTriangle *tri, vReturnableParam *result) ;
		int Reflection_Figure_Play ();
		int Reflection_Figure_Play_001 ();
		int Draw_Line_001 () ;
		int create_candidate_corss_step ( int x, int y,  vReturnableParam *result ) ;
		int spread_from_middlepoint (vTriangle* tri) ;
		int spread_from_middlepoint_001 (vTriangle* tri) ;
		int spread_from_middlepoint_002 (vTriangle* tri) ;
		int spread_seed ( int x, int y ) ;
		int merge_returnable_param ( vReturnableParam result1, vReturnableParam *result2 ) ;
		int merge_returnable_param_001  ( vReturnableParam *result1, vReturnableParam *result2 ) ;
		int Create_Paint_Triangle () ;
		int print_condition (vPoint** p_array, int num ) ;
		int set_condition (double x, double y, double thick ) ;
		int check_print_condition () ;
		int check_print_condition_001 () ;
		int check_print_condition_002 () ;
		int merge_test () ;
		int merge_test_000 () ;
		int merge_test_001 () ;
		int merge_test_002 () ;
		int merge_test_003 () ;
		int merge_test_004 () ;
		int merge_test_005 () ;
		int merge_test_006 () ;
		int merge_test_007 () ;
		int merge_test_008 () ;
		int merge_test_009 () ;
		int merge_test_010 () ;
		int merge_test_011 () ;
		int merge_test_012 () ;
		int merge_test_013 () ;
		int merge_test_014 () ;
		int merge_test_015 () ;
		int merge_test_016 () ;
		int merge_test_017 () ;
		int merge_test_018 () ;
		int merge_test_019 () ;
		int merge_test_020 () ;
		int merge_test_021 () ;
		int merge_test_022 () ;
		int merge_test_023 () ;
		int merge_test_024 () ;
		int merge_test_025 () ;
		int merge_test_026 () ;
		int merge_test_027 () ;
		int merge_test_028 () ;
		int merge_test_029 () ;
		int merge_test_030 () ;
		int merge_test_031 () ;
		int merge_test_032 () ;
		int merge_test_033 () ;
		int merge_test_034 () ;
		int merge_test_035 () ;
		int merge_test_036 () ;
		int merge_test_037 () ;
		int merge_test_038 () ;
		int merge_test_039 () ;
		int merge_test_040 () ;
		int merge_test_041 () ;
		int merge_test_042 () ;
		int merge_test_043 () ;
		int merge_test_044 () ;
		int merge_test_045 () ;
		int merge_test_046 () ;
		int merge_test_047 () ;
		int merge_test_048 () ;
		int merge_test_049 () ;
		int merge_test_050 () ;
		int merge_test_051 () ;
		int merge_test_052 () ;
		int merge_test_053 () ;
		int merge_test_054 () ;
		int merge_test_055 () ;
		int merge_test_056 () ;
		int merge_test_057 () ;
		int merge_test_058 () ;
		int merge_test_059 () ;
		int merge_test_060 () ;
		int merge_test_061 () ;
		int merge_test_062 () ;
		int merge_test_063 () ;
		int merge_test_064 () ;
		int merge_test_065 () ;
		int merge_test_066 () ;
		int merge_test_067 () ;
		int merge_test_068 () ;
		int merge_test_069 () ;
		int merge_test_070 () ;
		int merge_test_071 () ;
		int merge_test_072 () ;
		int merge_test_073 () ;
		int merge_test_074 () ;
		int merge_test_075 () ;
		int merge_test_076 () ;
		int merge_test_077 () ;
		int merge_test_078 () ;
		int merge_test_079 () ;
		int merge_test_080 () ;
		int merge_test_081 () ;
		int merge_test_082 () ;
		int merge_test_083 () ;
		int merge_test_084 () ;
		int merge_test_085 () ;
		int merge_test_086 () ;
		int merge_test_087 () ;
		int merge_test_088 () ;
		int merge_test_089 () ;
		int merge_test_090 () ;
		int merge_test_091 () ;
		int merge_test_092 () ;
		int merge_test_093 () ;
		int merge_test_094 () ;
		int merge_test_095 () ;
		int merge_test_096 () ;
		int merge_test_097 () ;
		int merge_test_098 () ;
		int merge_test_099 () ;
		int get_sound_buffer (int index) ;
		int put_normal_sound_wave();
		int put_normal_sound_wave_001();
		int put_normal_sound_wave_002();
		int put_normal_sound_wave_003();

} ;

#endif

