#ifndef _CONTROL_IMAGE_LAYER_009_
#define _CONTROL_IMAGE_LAYER_009_
//...
extern int putthegray_009 ( int ii, int jj, char* word ) ;
extern int putthegray_009_01 ( int ii, int jj, char* word ) ;
extern int putthegray_009_02 ( int ii, int jj, char* word ) ;
extern int putthegray_009_03 ( int ii, int jj, char* word ) ;
extern int putthegray_009_04 ( int ii, int jj, char* word ) ;
extern int Set_Logging_Control_Image_Layer_009 (Logging* logg) ;
extern int Caribration_Control_Image_Layer_009 () ;
extern GRID_MATRIX_004* get_im_grid_matrix_009 () ;

extern int Set_Img_Width_Height (char*** img, int width, int height ) ;
extern int Free_Img_Width_Height () ;


#endif
