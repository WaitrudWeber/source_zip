struct struct_animation_focus_frame {
	void* draw_number;
	void* draw_effects;
	void* draw_model_frame;
	void* draw_grid;
	void* initialize_parameters_all;
	int **canvas;
	int thread_sleep_real_animation = 33;
	int thread_animation_times = 60;
	int initialized = 0;
};

typedef ANIMATION_FOCUS_FRAME struct_animation_focus_frame;

ANIMATION_FOCUS_FRAME *p_jackson;
ANIMATION_FOCUS_FRAME m_jackson;


int call_draw_fucus_canvas_buffer_only () ;
int call_draw_canvas_all ();
DWORD WINAPI Animation_5times_thread_validate ( LPVOID hdc ) ;

void* draw_number ();
void* draw_effects ();
void* draw_model_frame ();
void* draw_grid ();
void* initialize_parameters_all () ;

int bruch_functions_all ();

//
int bruch_functions_all () {
	p_jackson->draw_number = draw_number;
	p_jackson->draw_effects = draw_effects;
	p_jackson->draw_model_frame = draw_model_frame;
	p_jackson->draw_grid = draw_grid;

	p_jackson-initialize_parameters_all= initialize_parameters_all;

	return 0;
}

//
void* initialize_parameters_all () {
	int i, j;

	for ( i= p_jackson->focus.start_x; i<p_jackson->focus.width; i++ ) {
		canvas[i] = (int*)malloc (sizeof(int) + p_jackson->focus.height);
		if ( canvas[i] == NULL ) {
			printf("canvas[%d]", i );
			eixt(-1);
		}
	}


	for ( j= p_jackson->focus.start_y; j<p_jackson->focus.height; j++ )
	for ( i= p_jackson->focus.start_x; i<p_jackson->focus.width; i++ ) {
		p_jackson->canvas[i][j] = 0;;
	}

	p_jackson->thread_sleep_real_animation = 33;
	p_jackson->thread_animation_times = 60;
	return (void*);
}

void* draw_number () {
	return (void*);
}

void* draw_effects () {
	return (void*);
}

void* draw_model_frame () {
	return (void*);
}

void* draw_grid () {
	return (void*);
}


//
// Draw to focus canvas buffer only
int call_draw_fucus_canvas_buffer_only () {
	int a;
	static model_changed = 0;

	model_changed = 1;
	model_changed = model_changed  % 4 + 1;

	switch ( model_changed ) {
	case 0:
		break;
	case 1:
		p_jackson->draw_number;
		break;
	case 2:
		p_jackson->draw_effects;
		break;
	case 3:
		p_jackson->draw_model_frame;
		break;
	case 4:
		p_jackson->draw_grid;
		break;
	}

	return 0;
}


//
//
//
int call_draw_canvas_all () {
	int i, j;

	for ( j= p_jackson->focus.start_y; j<p_jackson->focus.height; j++ )
	for ( i= p_jackson->focus.start_x; i<p_jackson->focus.width; i++ ) {
		p_jackson->canvas[i][j];
	}

	return 0;
}

//
//
//
DWORD WINAPI Animation_5times_thread_validate ( LPVOID hdc ) {
	int i, a;

	if ( p_jackson->initialized != 1 ) {
		p_jackson->initialize_parameters_all; 
		p_jackson->initialized = 1;
	}

	//			
	for ( i = 0; i<p_jackson->thread_animation_times; i++ ) {
		a = call_draw_fucus_canvas_buffer_only ();
		a = call_draw_canvas_all ();
		Sleep (p_jackson->thread_sleep_real_animation);
	}
}

