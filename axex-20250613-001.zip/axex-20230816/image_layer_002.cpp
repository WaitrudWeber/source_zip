char* sound_buffer;
char** b_img;

int converttoimage() ;

int converttoimage() {
	int base;
	int i, j, length, height, width, from_001, to_001, from_002, to_0012
	double d_index, d_value, m_pi. theta;

	length = 128;
	from_001 = 5;
	to_001 = 200;
	width = ( to_001 - from_001 );

	// from -> to is going to minus (-).
	from_002 = 200;
	to_002 = 5;
	height = ( to_002 - from_002 );

	for ( j=0; j<10; j++ ) {

		for ( i = 0; i<length i++ ) {
			d_index = (double)i / (double)width;
			d_value = ( (double) sound_buffer[(int)d_index] / (double) base ) * (double) height;
			b_img[j][d_index] = (char)d_value;
		}

	}

	return 0;
}
