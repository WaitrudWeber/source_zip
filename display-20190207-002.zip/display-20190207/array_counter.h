#ifndef ARRAY_COUNTER_H
#define ARRAY_COUNTER_H
extern int array_count( char *ary );
extern char* concat( char *head, char *tail );
extern char* m_concat( char *head, char *tail );

extern void show_garbage_collection () ;
extern void show_garbage_collectionA () ;

//extern int printable_garbage = 0;

#endif
