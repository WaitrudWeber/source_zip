#ifndef _VCALCULATION_
#define _VCALCULATION_

extern void put_memories( vPoint* dummy_vPoint );
extern vPoint* memorizevPoint( float a, float b, float c );
extern void put_points( vPoint* p );

class vCalculation {

public:
	vPoint cross ( vPoint p1, vPoint p2);
	vPoint normal ( vPoint p1 );
	void normal ( vPoint* p1 );
	vPoint add ( vPoint p1, vPoint p2);
	vPoint subtract ( vPoint p1, vPoint p2);
	// 20191114 start
	vPoint* scale ( vPoint* p1, float w_scale, vPoint* result );
	void scale ( vPoint* p1, float w_scale ) ;
	vPoint scale ( vPoint p1, float w_scale ) ;
	// 20191114 end
	// 20191120 start
	vPoint* scalize ( vPoint* p1, float w_scale);
	// 20191120 end
	double length ( vPoint lp );
	double length ( float x1, float y1, float z1);
	float dot ( vPoint p1, vPoint p2) ;
	vLine** Lines_from_Mesh ( vPoint* points, int** numbering, int num_patches, int base_num_patches) ;
	void add ( vPoint p1, vPoint p2, vPoint* p3 ) ;
	void add ( vPoint* p1, vPoint* p2, vPoint* p3) ;
	void cross ( vPoint* p1, vPoint* p2, vPoint* p3) ;
	vPoint* subtract ( vPoint* p1, vPoint* p2) ;
	double length ( vPoint* lp );
	vPoint* add ( vPoint* p1, vPoint* p2) ;
	void Print_Point_Memories () ;

private:
	void cross ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	double normal ( float x1, float y1, float z1, float* x2, float* y2, float* z2 );
	void subtract ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	void add ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	void scale ( float x1, float y1, float z1, float scale, float* x3, float* y3, float* z3);
	void dot ( float x1, float y1, float z1, float x2, float y2, float z2, float* dot ) ;
	vLine* put_line( vLine* be_set, vLine* l1) ;
	void Print_Lines ( vLine** array, int num ) ;
	void put_point( vPoint* lp1, vPoint* points_number ) ;




};

#endif
