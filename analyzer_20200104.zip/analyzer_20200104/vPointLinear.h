#ifndef _WPOINTLINEAR_H_
#define _WPOINTLINEAR_H_

class vPointLinear {

	public:
		vPointStructure PS1, PS2;
		float T; // 0 <= T <= 1
		vPointStructure** aPS = nullptr;
		int numPS = 0;
		vPoint** normal_faces = nullptr;
		vLine** print_lines = nullptr;
		vPoint** curve_points = nullptr;
		int curve_points_num = 0;
		int curve_points_max = 32;
		int print_lines_num = 0;
		int print_lines_num_max = 32;

	private:


	public:
		vLine** generateLines( vPointStructure** ps, int num_devide );
		vLine** generateControlsLines( );
		vLine** generateControls( );
		vPoint position( vPoint* c1, vPoint* c2, float t ) ;
		vPoint additional_positionP( vPoint* c1, vPoint* c2, float t ) ;
		vPoint additional_position ( vPointStructure* ps1, vPointStructure* ps2, float t ) ;
		void calculation () ;
		void calculation_array () ;
		vLine** FirstCreateLines( vPointStructure** ps, int num_devide ) ;
		void FirstCreation();
		void GetNormal ( vPoint* p1, vPoint* p2, vPoint* p3, vPoint* normal ) ;
		int CurveRevisement ( vPoint* p1, vPoint* p2, vPoint* p3, vPoint* p4) ;
		void CurveRevisement () ;
		void FirstRevisement( ) ;
		void PrintAnchors ( );
		void PrintControls( );
		void put_line( vLine* l_line );

	private:


};

#endif
