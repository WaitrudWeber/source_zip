#include <stdio.h>
#include <stdlib.h>


#include "winmainthread_005a_004.h"

extern char* filename_winmainthread_005a_004_ = (char*)"winmainthread_005a_004.txt";

int winmainthread_005a_004 ();
int set_winmainthread_005a_004 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_004 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

int winmainthread_005a_004 () {
	return 1;

}


int winmainthread_005a_set_004 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_004 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

