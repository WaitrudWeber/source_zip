#include <stdio.h>
#include <stdlib.h>

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-hProcess-in-mingw-what-to-use-instead
// #include <strsafe.h>

//#include <mmdeviceapi.h>

#include "resource.h"

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"

#include "clipboard.h"

#include "button.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "display_threeD.h"
#include "vPointStructure.h"


#include "vSoundBuffer_001.h"

#include "image_layer_001.h"

#include "wEvent.h"
#include "wEventListener.h"

#include "wJavaStructure.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

#include "wTextarea.h"
#include "wTextareaController.h"

#include "something_word.h"
#include "thread_print.h"


#include "wDisplayController.h"
//#include "wParamSynse_003.h"
#include "wCanvasController.h"

#include "cg_schema.h"


#include "ReturnableParam.h"

#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "log_001.h"

#include "csv_text_001.h"
#include "settle_grid_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_002.h"
#include "winmainthread_005a_001.h"
#include "winmainthread_005a_000.h"


extern char* filename_winmainthread_005a_002_ = (char*)"winmainthread_005a_002.txt";

int winmainthread_005a_002 ();
int set_winmainthread_005a_002 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_002 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

int Putthewordstoggrid_002 () ;
DWORD WINAPI Animation_5times_thread_validate_025_002 ( LPVOID hdc ) ;



int winmainthread_005a_002 () {
	return 1;

}


int winmainthread_005a_set_002 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_002 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

// invalidate:
// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-invalidaterect
//
//
DWORD WINAPI Animation_5times_thread_validate_025_002 ( LPVOID hdc ) {
	printf("Animation_5times_thread_validate_025_002 starts.\r\n");

	DWORD hdc_011 = *(DWORD*)hdc;
	for ( param_int[19] = 0; param_int[19]<255 * 100; param_int[19]++ ) {
		InvalidateRect( p_evt->hWnd, &RefreshRect, FALSE);

		csv_once_002 ( &index, &end_index);
		param_percent = (double) index / (double) end_index ;
		sprintf( log_message, "index %d end_index %d param_percent %f", index, end_index, param_percent);
		dlog_001 = log_001.update_log ( (char*) log_message );

		Set_Read_Bar () ;

		if ( index >= end_index ) break;

		Sleep(param_int[20]);
	}

	Putthewordstoggrid_002 ();
	Return_Read_Bar () ;
	printf("Animation_5times_thread_validate_025_002 ends.\r\n");
	return 0;
}

//
int Putthewordstoggrid_002 ()
{
	int i, j;

	dlog_001 = log_001.update_log ( "void Initialize_firstset_017 () starts." );

	for ( i = 0; i<table_width; i++ ) {
		for ( j = 0; j<table_height; j++ ) {
			Set_Param_005a( i, j, (char*) gettheword_004( i, j ) ) ;
		}
	}

	dlog_001 = log_001.update_log ( "void Initialize_firstset_017 () ends." );
	return 0;
}

