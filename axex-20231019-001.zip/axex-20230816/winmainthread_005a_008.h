#ifndef _WINMAINTHREAD__008_
#define _WINMAINTHREAD__008_
//...
extern int winmainthread_005a_008 ();
extern int set_winmainthread_005a_008 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_winmainthread_005a_008 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int paint_wm_008 (int* b_Processed ) ;
extern int paint_wm_008_01 (int* b_Processed ) ;

#endif
