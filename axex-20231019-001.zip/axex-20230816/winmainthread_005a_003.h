#ifndef _WINMAINTHREAD__003_
#define _WINMAINTHREAD__003_
//...
extern int winmainthread_005a_003 ();
extern int set_winmainthread_005a_003 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_winmainthread_005a_003 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int Initialize_firstset_winmainthread_005a_01 () ;
extern int Caribration_winmainthread_005a_01 () ;
extern int Create_base_funcs_winmainthread_005a_01 () ;
extern int Create_base_cls_winmainthread_005a_01 ( char* clsname_h_cpp ) ;


#endif
