#ifndef _VUTIL_H_
#define _VUTIL_H_

class vUtil {

	public:
		int OnSideCones ( vPoint* p, vPoint* eye, vPoint** a, int n ) ;
		int InsideCones ( vPoint* p, vPoint* eye, vPoint** a, int n ) ;
		int SpreadSeed ( vPoint* from, vPoint* to, vPoint** seed, int* n) ;

};

#endif

