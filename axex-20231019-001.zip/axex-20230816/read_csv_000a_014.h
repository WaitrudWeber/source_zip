#ifndef _READ_CSV__014_
#define _READ_CSV__014_
//...
extern int read_csv_000a_014 ();
extern int set_read_csv_000a_014 (char** argv, int argc);
extern int initialize_read_csv_000a_014 (char** argv, int argc);

extern int memories_height ( int width, int height, char*** mem ) ;
extern int memories_width ( int from_w_i, int width, int height, char*** mem ) ;

extern int Set_Logging_read_csv_000a_014 ( Logging* log ) ;


#endif
