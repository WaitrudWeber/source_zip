#include <stdio.h>
#include <stdlib.h>


#include "winmainthread_005a_005.h"

extern char* filename_winmainthread_005a_005_ = (char*)"winmainthread_005a_005.txt";

int winmainthread_005a_005 ();
int set_winmainthread_005a_005 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_005 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

int winmainthread_005a_005 () {
	return 1;

}


int winmainthread_005a_set_005 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_005 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

