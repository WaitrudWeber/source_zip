#include <windows.h>
#include <winbase.h>
//#include <imapi2fs.h>
//#include <iostream>
//#include <cstring>
//#include <string>
#include <strsafe.h>
#include<stdio.h>

//#include "aDebug.h"
#include "array_counter.h"
#include "parse.h"
// #include "php_analyzer.h"
#include "list_directory.h"

//using namespace std;

FileControler::FileControler() {
	this->list_dummy_ary_index = 0;
	this->list_dummy_ary = nullptr;

}

int FileControler::print_char(char* p_char) {
	printf("print_char: %s\r\n", p_char);
	return 0;
}


int FileControler::windows_get_file_info () {
	HANDLE hFind = INVALID_HANDLE_VALUE;
//	FILE_INFO_BY_HANDLE_CLASS FileInformationClass;
//	LPVOID lpFileInformation lpFileInformation;
//	DWORD dwBufferSize;                      
	return 0;
}

/*
//
int FileControler:;windows_get_file_info () {
//	HANDLE hFind = INVALID_HANDLE_VALUE;
//	FILE_INFO_BY_HANDLE_CLASS FileInformationClass;
//	LPVOID lpFileInformation lpFileInformation;
//	DWORD dwBufferSize;                      
//	GetFileInformationByHandleEx( hFind

	return 0;

}
*/
//
// it refers all to
// https://stackoverflow.com/questions/11362771/list-files-in-directory-c
// https://bituse.info/winapi/31
//
// Parameters
//
// lpcstr_path
//
// Directory name which is going to be found files.
//
// Return Value
//
// char**
//
// File list under the lpcstr_path, which has fullpath.
//
char** FileControler::get_files ( char* lpcstr_path, int* file_num ) {
	WIN32_FIND_DATA ffd;
	HANDLE hFind = INVALID_HANDLE_VALUE;
	char* ffdc_filename;
	int dummy_filenum = 0;
	char* char_asterisk_path = (char*)"\0"; // .\abc\* if .\abc\*.php
	char* char_attr = (char*)"\0";
	int cnt = 0;
	int cnt_char_asterisk_path = 0;

	// this doesn't have asterisk.
	if ( m_contains ( lpcstr_path, "*" ) == 0 ) {
		*file_num = 1;
		this->put_string ( lpcstr_path );
		return get_strings();
	}

    // Prepare string for use with FindFile functions.  First, copy the
    // string to a buffer, then append '\*' to the directory name.
	cnt = array_count( lpcstr_path );
	int search_length = m_last_with( lpcstr_path, (char*)".");
	if ( search_length <= 0 ) {

		hFind = FindFirstFile( TEXT( lpcstr_path ), &ffd );
		char_asterisk_path = lpcstr_path;
		printf("char_asterisk_path: %s \r\n", char_asterisk_path );
	} else {

		// In this case, lpcstr_path is like ".\abc\*.php"
		char_asterisk_path = substring( lpcstr_path, 0, search_length );
		cnt_char_asterisk_path = array_count( char_asterisk_path );
		char_attr = substring( lpcstr_path, search_length, cnt - cnt_char_asterisk_path ); // max_count:cnt
		hFind = FindFirstFile( TEXT( char_asterisk_path ), &ffd );
	}

	//ffdc_filename = copyof( (char*)ffd.cFileName );
	//exit(-1);

	int index = 0;
    // List all the files in the directory with some info about them.
	do
	{
		ffdc_filename = copyof( (char*)ffd.cFileName );
		printf("ffdc_filename: %s \r\n", ffdc_filename );
		index++;
		char* char_directory = to_directory ( char_asterisk_path, ffdc_filename );

		if ( char_directory == NULL || m_compare( ffdc_filename, (char*)".") == 1 || m_compare( ffdc_filename, (char*)"..") == 1 ) {

			printf ( "skip away : %s\r\n", ffdc_filename );

		} else {

			if ( is_attribute ( ffdc_filename, char_attr ) == 1 ) {
				this->put_string ( char_directory );
			}

			if ( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) {
				char* listfiles = (char*) m_concat( (char*)char_directory, (char*)"\\*" );
				listfiles = (char*) m_concat( (char*)listfiles, (char*)char_attr );
				this->get_files( (char*) listfiles, &dummy_filenum );
			}

		}
	}
	while ( FindNextFile(hFind, &ffd ) != 0);

	FindClose(hFind);
	*file_num = this->get_strings_number () ;

	printf("*file_num %10d \r\n", *file_num );
	printf("End of FileControler::get_files \r\n");

	return get_strings();
}

//
//
//
//
//
int FileControler::get_file_info ( char *lpcstr_path, char **result ) {
	int cnt_array;
	printf( "int FileControler::get_file_info ( char *lpcstr_path, char **result ) starts. \r\n" );

	cnt_array = array_count (lpcstr_path);
	printf ("cnt_array=%d\r\n", cnt_array);
	int cnt_directory = m_last_with ( lpcstr_path, "\\" ) + 1;
	printf ("cnt_directory=%d\r\n", cnt_directory);
	int cnt_asterisk = m_last_with ( lpcstr_path, "*" );
	printf ("cnt_asterisk=%d\r\n", cnt_asterisk);
	int cnt_period = m_last_with ( lpcstr_path, "." );

	if ( cnt_period < 0 ) return -1;

	printf ("cnt_period=%d\r\n", cnt_period);
	char* str_directory = substring ( lpcstr_path, 0, cnt_directory );
	char* str_asterisk = substring ( lpcstr_path, cnt_directory, cnt_array );
	char* str_period = substring ( lpcstr_path, cnt_period, cnt_array );

	put_memories( str_directory );
	put_memories( str_asterisk );
	put_memories( str_period );

//	result = (char**) malloc ( sizeof(char*) * 3 );

	*(result + 0 ) = str_directory;
	*(result + 1 ) = str_asterisk;
	*(result + 2 ) = str_period; // attributes

	put_memories( (char *) result );

	printf(" %s %s %s \r\n", str_directory, str_asterisk, str_period );
	printf(" %s %s %s \r\n", *( result + 0), *( result + 1), *( result + 2) );

	printf( "int FileControler::get_file_info ( char *lpcstr_path, char **result ) ends. \r\n" );

	return 1;
}

int FileControler::get_file_info_012 ( char *lpcstr_path, char **result, int debug_num ) {
	int cnt_array;
	printf( "int FileControler::get_file_info_012 ( char *lpcstr_path, char **result ) starts. \r\n" );

	cnt_array = array_count (lpcstr_path);
	printf ("cnt_array=%d\r\n", cnt_array);
	int cnt_directory = m_last_with ( lpcstr_path, "\\" ) + 1;
	printf ("cnt_directory=%d\r\n", cnt_directory);
	int cnt_asterisk = m_last_with ( lpcstr_path, "*" );
	printf ("cnt_asterisk=%d\r\n", cnt_asterisk);
	int cnt_period = m_last_with ( lpcstr_path, "." );

	if ( cnt_period < 0 ) return -1;

	printf ("cnt_period=%d\r\n", cnt_period);
	char* str_directory = substring ( lpcstr_path, 0, cnt_directory );
	char* str_asterisk = substring ( lpcstr_path, cnt_directory, cnt_array );
	char* str_period = substring ( lpcstr_path, cnt_period, cnt_array );

	put_memories( str_directory );
	put_memories( str_asterisk );
	put_memories( str_period );

//	result = (char**) malloc ( sizeof(char*) * 3 );

	*(result + 0 ) = str_directory;
	*(result + 1 ) = str_asterisk;
	*(result + 2 ) = str_period; // attributes

	put_memories( (char *) result );

	printf(" %s %s %s \r\n", str_directory, str_asterisk, str_period );
	printf(" %s %s %s \r\n", *( result + 0), *( result + 1), *( result + 2) );

	printf( "int FileControler::get_file_info_012 ( char *lpcstr_path, char **result ) ends. \r\n" );

	return 1;
}

//
//
//
//
//
char** FileControler::get_files_001 ( char* lpcstr_path, int* file_num ) {
	WIN32_FIND_DATA ffd;
	HANDLE hFind = INVALID_HANDLE_VALUE;
	char* ffdc_filename;
	int dummy_filenum = 0;
	int cnt_char_asterisk_path = 0;

	printf("char** FileControler::get_files_001 ( char* lpcstr_path, int* file_num ) starts.\r\n");

	char** file_info = (char**) malloc ( sizeof(char*) * 3 );
	int success = this->get_file_info ( lpcstr_path, file_info );
	char* wild_directory = m_concat( *( file_info + 0 ), "*" );

	hFind = FindFirstFile( TEXT( wild_directory ), &ffd );
	int index = 0;
    // List all the files in the directory with some info about them.
	do
	{
		printf("001: %s starts.\r\n", ffdc_filename);
		ffdc_filename = copyof( (char*)ffd.cFileName );
		index++;
		char* fullpath = m_concat ( *( file_info + 0 ), ffdc_filename );

		if ( fullpath == NULL || m_compare( ffdc_filename, (char*)".") == 1 || m_compare( ffdc_filename, (char*)"..") == 1 ) {
			printf ( "skip away : %s\r\n", ffdc_filename );

		} else {

			printf("002: %s starts.\r\n", ffdc_filename);
			if ( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) {
				printf("002-01: |%s| |%s|starts.\r\n", ffdc_filename, file_info);
				//20190422
				char* char_directory = m_concat( *(file_info + 0  ), ffdc_filename );
				char_directory = m_concat( char_directory, copyof("\\") );
				printf("01: char_directory|%s|\r\n", char_directory);
				char_directory = m_concat( char_directory, *(file_info + 1  ) );
				printf("02: char_directory|%s|\r\n", char_directory);
				this->get_files_001( (char*) char_directory, &dummy_filenum );
				printf("002-02: %s ends.\r\n", ffdc_filename);

			} else if ( is_attribute ( ffdc_filename, *(file_info + 2) ) == 1 ) {
				printf("002-03: |%s| |%s| starts.\r\n", ffdc_filename, fullpath);
				this->put_string ( fullpath );
				printf("002-03: |%s| |%s| ends.\r\n", ffdc_filename, fullpath);
			}
			printf("002: %s ends.\r\n", ffdc_filename);

		}
		printf("001: %s ends.\r\n", ffdc_filename);
	} while ( FindNextFile(hFind, &ffd ) != 0);

	FindClose(hFind);
	*file_num = this->get_strings_number () ;

	printf("char** FileControler::get_files_001 ( char* lpcstr_path, int* file_num ) ends.\r\n");
	return this->get_strings();
}

//
char** FileControler::get_files_011 ( char* lpcstr_path, int* file_num ) {
	WIN32_FIND_DATA ffd;
	HANDLE hFind = INVALID_HANDLE_VALUE;
	char* ffdc_filename;
	int dummy_filenum = 0;
	int cnt_char_asterisk_path = 0;

	printf("char** FileControler::get_files_011 ( char* lpcstr_path, int* file_num ) starts.\r\n");

	char** file_info = (char**) malloc ( sizeof(char*) * 3 );
	int success = this->get_file_info ( lpcstr_path, file_info );
	char* wild_directory = m_concat( *( file_info + 0 ), "*" );

	hFind = FindFirstFile( TEXT( wild_directory ), &ffd );
	int index = 0;
    // List all the files in the directory with some info about them.
	do
	{
		printf("001: %s starts.\r\n", ffdc_filename);
		ffdc_filename = copyof( (char*)ffd.cFileName );
		index++;
		char* fullpath = m_concat ( *( file_info + 0 ), ffdc_filename );

		if ( fullpath == NULL || m_compare( ffdc_filename, (char*)".") == 1 || m_compare( ffdc_filename, (char*)"..") == 1 ) {
			printf ( "skip away : %s\r\n", ffdc_filename );

		} else {

			printf("002: %s starts.\r\n", ffdc_filename);
			if ( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) {
				printf("002-01: |%s| |%s|starts.\r\n", ffdc_filename, file_info);
				//20190422
				char* char_directory = m_concat( *(file_info + 0  ), ffdc_filename );
				char_directory = m_concat( char_directory, copyof("\\") );
				char_directory = m_concat( char_directory, *(file_info + 1  ) );
				this->get_files_011( (char*) char_directory, &dummy_filenum );
				printf("002-02: %s ends.\r\n", ffdc_filename);

			} else if ( is_attribute ( ffdc_filename, *(file_info + 2) ) == 1 ) {
				printf("002-02: |%s| |%s| starts.\r\n", ffdc_filename, fullpath);
//				this->put_string ( fullpath );
				this->write_log ( fullpath );
				printf("002-03: |%s| |%s| ends.\r\n", ffdc_filename, fullpath);
			}
			printf("002: %s ends.\r\n", ffdc_filename);

		}
		printf("001: %s ends.\r\n", ffdc_filename);
	} while ( FindNextFile(hFind, &ffd ) != 0);

	FindClose(hFind);
	*file_num = this->get_strings_number () ;

	printf("char** FileControler::get_files_011 ( char* lpcstr_path, int* file_num ) ends.\r\n");
	return this->get_strings();
}
// ffdc_filename. file_info
// get_files_012
//
char** FileControler::get_files_012 ( char* lpcstr_path, int* file_num, int debug_num ) {
	WIN32_FIND_DATA ffd;
	HANDLE hFind = INVALID_HANDLE_VALUE;
	char* ffdc_filename;
	int dummy_filenum = 0;
	int cnt_char_asterisk_path = 0;
	char* fullpath;
	FILE* wfp;
	int count = 0;
	printf("char** FileControler::get_files_012 ( char* lpcstr_path, int* file_num ) starts.\r\n");
	printf("000 debug_num = %d\r\n", debug_num );

	wfp = fopen( ".\\001-wirte-log-001\.txt", "wb");


	char** file_info = (char**) malloc ( sizeof(char*) * 3 );
	if ( file_info == NULL) {
		printf("file_info exits.\r\n");
		exit(-1);
	}
	int success = this->get_file_info ( lpcstr_path, file_info );
	char* wild_directory = m_concat( *( file_info + 2 ), "*" );

	printf("wild_directory: %s\r\n", wild_directory);
	hFind = FindFirstFile( TEXT( wild_directory ), &ffd );
	printf("end of FindFirstFile h Find %d (char*)ffd.cFileName=%s\r\n", hFind , (char*)ffd.cFileName);

	ffdc_filename = copyof( (char*)ffd.cFileName );
	fullpath = m_concat ( *( file_info + 0 ), ffdc_filename );

	printf("ffdc_filename %s fullpath %s\r\n", ffdc_filename, fullpath );

	int index = 0;
	for ( int i=0; i<3; i++ ) {
		printf("002 file_info %d %s\r\n", i, *( file_info + i ) );
	}

	printf("003 debug_num = %d\r\n", debug_num );
    if (debug_num == 3) exit(-1);

	printf("lpcstr_path %s *file_num %d\r\n", lpcstr_path , *file_num);
    if (debug_num ==4) exit(-1); 

    // List all the files in the directory with some info about them.
	do
	{
		printf("001: ffdc_filename %s starts.\r\n", ffdc_filename);
		ffdc_filename = copyof( (char*)ffd.cFileName );
		index++;
		fullpath = m_concat ( *( file_info + 0 ), ffdc_filename );
		fprintf(wfp, "fullpath:%s\r\n", fullpath );

		if ( fullpath == NULL || m_compare( ffdc_filename, (char*)".") == 1 || m_compare( ffdc_filename, (char*)"..") == 1 ) {
			printf ( "skip away : %s\r\n", ffdc_filename );

		} else {

			printf("002: %s starts.\r\n", ffdc_filename);
			if ( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) {
				printf("002-01: |%s| |%s|starts.\r\n", ffdc_filename, file_info);
				//20190422
				char* char_directory = m_concat( *(file_info + 0  ), ffdc_filename );
				char_directory = m_concat( char_directory, copyof("\\") );
				char_directory = m_concat( char_directory, *(file_info + 1  ) );
				this->get_files_011( (char*) char_directory, &dummy_filenum );
				printf("002-02: %s ends.\r\n", ffdc_filename);

			} else if ( is_attribute ( ffdc_filename, *(file_info + 2) ) == 1 ) {
				printf("002-02: |%s| |%s| starts.\r\n", ffdc_filename, fullpath);
				this->put_string ( fullpath );
				this->write_log ( fullpath );
				count++;
				printf("002-03: |%s| |%s| ends.\r\n", ffdc_filename, fullpath);
			}
			printf("002: %s ends.\r\n", ffdc_filename);

		}

		printf("001: fullpath %s debug_num %d ends.\r\n", fullpath, debug_num);
	    if (debug_num == 5 ) exit(-1); 
	
	} while ( FindNextFile(hFind, &ffd ) != 0);

	FindClose(hFind);

//	*file_num = this->get_strings_number () ;
	*file_num = count;

	fclose(wfp);
	printf("char** FileControler::get_files_012 ( char* lpcstr_path, int* file_num ) ends.\r\n");
	return this->get_strings();
}
//
//
//
//
//
int FileControler::is_attribute ( char* ffdc_filename, char* char_attr ) {

	printf ("ffdc_filename: %s | char_attr: %s\r\n", ffdc_filename , char_attr );


	if ( char_attr == nullptr ) return -1;

	char *a = copyof("*");

	if ( m_compare( char_attr, a ) == 1 ) {
		// think about free
		free(a);
		return 1;
	}


	if ( m_compare( char_attr, (char*)"" ) == 1 ) return -1;

	//printf ("%s | %s\r\n", ffdc_filename , char_attr );

	int last = m_last_with ( ffdc_filename, char_attr );

	//printf( "last = %d\r\n", last );

	if ( last == -1 ) {
		return -1;
	}

	return 1;
}

//
// Return Value
//
// char* list_dummy_ary
//
// Not extern, excluded, int, number of strings which you put with put_string.
//
int FileControler::get_strings_number () {
	// printf("FileControler::get_strings_number: return: %d\r\n", this->list_dummy_ary_index);
	return this->list_dummy_ary_index;
}


//
// Return Value
//
// char* list_dummy_ary
//
// Not extern, char string array.
//
char** FileControler::get_strings () {
	return this->list_dummy_ary;
}

//
// Parameters
//
// char* str
//
// char string which is going to be copiied in memories.
//
// Return Value
//
// char* mem
//
// copied char string from str.
//
char* FileControler::fc_copyof ( char* str ) {
	int ac = array_count(str);
	char* mem = (char*)malloc( sizeof(char) * (ac + 1) );

	for ( int i=0; i<ac; i++) {
		mem[i] = str[i];
	}

	mem[ac] = '\0';
	return mem;
}


//
// Return Value
//
// char* str
//
// Not extern, char string list_dummy_ary.
//
char** FileControler::put_string ( char* str ) {
	printf("char** FileControler::put_string ( char* str ) |%s|%d| starts.\r\n", str, list_dummy_ary_index );
	if ( list_dummy_ary_index == 0 ) {
		list_dummy_ary = (char **) malloc( sizeof(char*) );
		list_dummy_ary_index = 1;
		*( list_dummy_ary + 0 ) = (char*) str;
	} else {
		list_dummy_ary_index++;
		list_dummy_ary = (char **) realloc( list_dummy_ary, sizeof(char*)* list_dummy_ary_index );
		*( list_dummy_ary + list_dummy_ary_index - 1 ) = (char*)str;
	}

	printf("char** FileControler::put_string ( char* str ) ends.\r\n");
	return list_dummy_ary;
}

void FileControler::write_log ( char* str ) {
	FILE *lfp;
	printf("char** FileControler::str ( char* str ) |%s| starts.\r\n", str );
	lfp = fopen(".\\file-search-001.log", "ab");
	fprintf( lfp, "<img src=\"%s\">\r\n", str );
	fclose(lfp);
	printf("char** FileControler::str ( char* str ) ends.\r\n");
}


//
//
//
//
//
void FileControler::print_strings () {

	for ( int i=0; i<list_dummy_ary_index; i++) {
		printf("list_dummy_ary[%d]=%s\r\n", i, (char*)list_dummy_ary[i] );
	}

}

//
//
//
//
//
char* FileControler::to_directory(char* lpcstr_path, char* filename )
{
	int comp1 = m_compare ( filename, (char*)".");
	// printf( "comp1: %d\r\n", comp1 );

	int comp2 = m_compare ( filename, (char*)"..");
	// printf( "comp2: %d\r\n", comp2 );

	int index = m_last_with( (char *) lpcstr_path, "\\" );
	// printf( "index: %d\r\n", index );

	if ( (index > 0) && (comp1 != 1) && (comp2 != 1) ) {

		char* string_directory = substring( (char *) lpcstr_path, 0, index + 1 );
		//printf("string_directory1: %s\r\n", string_directory );
		char* to_directory = m_concat( string_directory, filename );
		// printf("to_directory: %s\r\n", to_directory );

		return to_directory;

	}

	return NULL;
}

//
// it refers all to
// https://stackoverflow.com/questions/11362771/list-files-in-directory-c
// https://bituse.info/winapi/31
//
// Parameters
//
// lpcstr_path
//
// Directory name which is going to be found files.
//
// Return Value
//
// void
//
void FileControler::List_Files(char* lpcstr_path )
{
	WIN32_FIND_DATA ffd;
	HANDLE hFind = INVALID_HANDLE_VALUE;
	char* ffdc_filename;

    // Prepare string for use with FindFile functions.  First, copy the
    // string to a buffer, then append '\*' to the directory name.
	hFind = FindFirstFile( TEXT( lpcstr_path ), &ffd );
	ffdc_filename = TEXT( ffd.cFileName );

	printf ( "filename: %s\r\n", ffdc_filename );
	printf ( "lpcstr_path: %s\r\n", TEXT( lpcstr_path ) );

    // List all the files in the directory with some info about them.
	do
	{
		ffdc_filename = TEXT( ffd.cFileName );
		if ( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
		{
			//If it's a directory, nothing should happen. Just continue with the next file.
			char* char_directory = to_directory ( lpcstr_path, ffdc_filename );
			if ( char_directory == NULL ) {
				printf( "skip away : %s\r\n", char_directory );
			} else {
				char* listfiles = (char*) m_concat( (char*)char_directory, (char*)"\\*" );
				this->List_Files( (char*) listfiles );
			}
			// free ( char_directory );
		}
		else
		{
			printf( "filename 2:%s\r\n", ffdc_filename );

			if ( file_type ( (char*)ffdc_filename, (char*)"*.php") == 1 ) {
				char* char_fullpath = m_fullpath ( lpcstr_path, ffdc_filename );

				// exit(-1);
				// parser starts 20190103
//				printf ("put_string %s\r\n", char_fullpath );
//				put_string( char_fullpath );
				// exit(-1);
//				int php_return = php_parse( char_fullpath );
			}

		}
		//free ( ffdc_filename );
	}
	while ( FindNextFile(hFind, &ffd ) != 0);

	//free ( lpcstr_path );

	FindClose(hFind);
}

// https://docs.microsoft.com/en-us/windows/desktop/api/fileapi/nf-fileapi-findnextfilea
// BOOL FindNextFileA(
//   HANDLE             hFindFile,
//   LPWIN32_FIND_DATAA lpFindFileData
// );
//
// Parameters
//
// hFindFile
//
// The search handle returned by a previous call to the FindFirstFile or FindFirstFileEx function.
//
// lpFindFileData
//
// A pointer to the WIN32_FIND_DATA structure that receives information about the found file or subdirectory.

// Return Value
// 
// If the function succeeds, the return value is nonzero and the lpFindFileData parameter contains information about the next file or directory found.
// 
// If the function fails, the return value is zero and the contents of lpFindFileData are indeterminate. To get extended error information, call the GetLastError function.
// 
// If the function fails because no more matching files can be found, the GetLastError function returns ERROR_NO_MORE_FILES.
// 
// Remarks
// 
// This function uses the same search filters that were used to create the search handle passed in the hFindFile parameter. For additional information, see FindFirstFile and FindFirstFileEx.
// 
// The order in which the search returns the files, such as alphabetical order, is not guaranteed, and is dependent on the file system. If the data must be sorted, the application must do the ordering after obtaining all the results.
// 
// Note  In rare cases or on a heavily loaded system, file attribute information on NTFS file systems may not becurrent at the time this function is called. To be assured of getting the current NTFS file system fileattributes, call the GetFileInformationByHandle function.
// 
//  
// The order in which this function returns the file names is dependent on the file system type. With the NTFSfile system and CDFS file systems, the names are usually returned in alphabetical order. With FAT file systems,the names are usually returned in the order the files were written to the disk, which may or may not be inalphabetical order. However, as stated previously, these behaviors are not guaranteed. 
// If the path points to a symbolic link, the WIN32_FIND_DATA buffer contains information about the symbolic link, not the target.
// 
// In Windows 8 and Windows Server 2012, this function is supported by the following technologies.
// 
// 
// 
// Technology
// 
// Supported
// 
// Server Message Block (SMB) 3.0 protocol  Yes  
// SMB 3.0 Transparent Failover (TFO)  Yes  
// SMB 3.0 with Scale-out File Shares (SO)  Yes  
// Cluster Shared Volume File System (CsvFS)  Yes  
// Resilient File System (ReFS)  Yes  
//
// Transacted Operations
// If there is a transaction bound to the file enumeration handle, then the files that are returned are subject to transaction isolation rules. 
// Examples
//
// For an example, see Listing the Files in a Directory.
//
//
// Requirements
//
//
//
//
//
//
//
//
// Minimum supported client Windows XP [desktop apps | UWP apps] 
// Minimum supported server Windows Server 2003 [desktop apps | UWP apps] 
// Target Platform Windows 
// Header fileapi.h (include Windows.h) 
// Library Kernel32.lib 
// DLL Kernel32.dll 
//
// See Also
//
// File Management Functions
//
// FindClose
//
// FindFirstFile
//
// FindFirstFileEx
//
// GetFileAttributes
//
// SetFileAttributes
//
// Symbolic Links
//
// WIN32_FIND_DATA
//
//






//
//
//
//
//
//
char* FileControler::m_fullpath_001 ( char *strPath,  char *filename ) {

	int index = m_last_with( (char *) strPath, (char*)"\\" );

	char* string_directory = substring( (char *) strPath, 0, index + 1 );
	printf("string_directory3: %s\r\n", string_directory );
	char* fullpath = m_concat( string_directory, (char *) filename );
	printf("filename fullpath = %s\r\n", fullpath );

	return fullpath;
}

//
//
//
//
//
//
char* FileControler::m_fullpath ( char* strPath, char* filename ) {

	int index = m_last_with( (char *) strPath, (char*)"\\" );

	char* string_directory = substring( (char *) strPath, 0, index + 1 );
	printf("string_directory3: %s\r\n", string_directory );
	char* fullpath = m_concat( (char *)string_directory, (char *) filename );
	printf("filename fullpath_c = %s\r\n", fullpath );

	return fullpath;
}

//
//
//
//
//
//
//
void FileControler::Sub_List_Files ()
{
    WIN32_FIND_DATA ffd;
	HANDLE hFind = FindFirstFile(TEXT("C:\\Users\\Andre\\Dropbox\\Programmering privat\\Diablo III DPS Calculator\\Debug\\SavedProfiles\\*"), &ffd);

	if (INVALID_HANDLE_VALUE != hFind)
	{

		do
		{
			//...
			int a = 0;

		} while(FindNextFile(hFind, &ffd) != 0);

		FindClose( hFind );

	} else {

		// Report failure.
		int b = 0;
	}

}

