#include <stdio.h>
#include <stdlib.h>


#include "winmainthread_005a_007.h"

extern char* filename_winmainthread_005a_007_ = (char*)"winmainthread_005a_007.txt";

int winmainthread_005a_007 ();
int set_winmainthread_005a_007 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_007 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

int winmainthread_005a_007 () {
	return 1;

}


int winmainthread_005a_set_007 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_007 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

