#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "read_csv_000a_014.h"

char logmsg[255];
static Logging* log_001;
static LOG_001* dlog_001 = NULL;

extern char* filename_read_csv_000a_014_ = (char*)"read_csv_000a_014.txt";

int read_csv_000a_014 ();
int set_read_csv_000a_014 (char** argv, int argc);
int initialize_read_csv_000a_014 (char** argv, int argc);

int print_log_result_003 (char*** result) ;
int print_log_result_002 (char** result) ;
int print_log_result_001 (char* result) ;
int print_log_result_num (int num) ;
int print_log_result_msg_003 (char* msg, char*** result) ;
int print_log_result_msg_002 (char* msg, char** result) ;
int print_log_width_height_result ( int i, int j ) ;
int print_log_width_height_mem_result ( int i, int j , char* result ) ;
int print_log_width_height_mem_address_result ( int i, int j , char** result ) ;



char***	realloc_char_003_01 ( char*** restr, int num ) ;
char**	realloc_char_002_01 ( char** restr, int num ) ;
char***	malloc_char_003_01 ( int num ) ;
char**	malloc_char_002_01 ( int num ) ;

int memories_height ( int width, int height, char*** mem ) ;
int memories_width ( int from_w_i, int width, int height, char*** mem ) ;

int Set_Logging_read_csv_000a_014 ( Logging* log ) ;

int memories_width ( int from_w_i, int width, int height, char*** mem ) {

	int i, j;
	dlog_001 = log_001->update_log ( (char*)"int memories_width ( int from_w_i, int width, int height, char*** mem ) starts.");

	mem = (char***) realloc_char_003_01 ( mem, width );
	print_log_result_003 (mem);
	for ( i = from_w_i; i<width; i++ ) {
		print_log_width_height_result ( i, j );
		mem[i] = (char**) realloc_char_002_01  ( mem[i], height );
		print_log_result_002 ( mem[i] );
		for ( j=0; j<height; j++ ) {
			print_log_width_height_mem_address_result ( i, j, (char**)&(mem[i][j])  );
			mem[i][j] = csvcopyof_005 ( (char*)"-" );
			print_log_width_height_mem_result ( i, j, (char*)mem[i][j] );
		}
	}

	print_log_result_003 (mem);
	dlog_001 = log_001->update_log ( (char*)"int memories_width ( int from_w_i, int width, int height, char*** mem ) ends.");
	return 0;
}

int memories_height ( int width, int height, char*** mem ) {

	int i,j;
	dlog_001 = log_001->update_log ( (char*)"int memories_height ( int width, int height, char*** mem ) starts.");

	mem = (char***) realloc_char_003_01 ( mem, width );
	print_log_result_003 (mem);
	for ( i = 0; i<width; i++ ) {
		mem[i] = (char**) realloc_char_002_01  ( mem[i], height );
		print_log_result_002 ( mem[i] );
		for ( j=0; j<height; j++ ) {
			print_log_width_height_mem_result ( i, j, (char*)mem[i][j] );
		}
	}

	print_log_result_003 (mem);
	dlog_001 = log_001->update_log ( (char*)"int memories_height ( int width, int height, char*** mem ) ends.");
	return 0;
}

//
char***	malloc_char_003_01 ( int num ) {
	char*** result;
	dlog_001 = log_001->update_log ( (char*)"char***	malloc_char_003_01 ( int num ) starts.");
	print_log_result_num ( num );

	result = (char***)malloc ( sizeof (char**) * num ) ;
	print_log_result_003 ((char***)result);
	if (result == NULL ) {
		dlog_001 = log_001->update_log ( (char*)"We cannot allocate the result. m 003_01");
		exit(-1);
	}

	dlog_001 = log_001->update_log ( (char*)"char***	malloc_char_003_01 ( int num ) ends.");
	return result;
}

//
char**	malloc_char_002_01 ( int num ) {
	char** result;
	dlog_001 = log_001->update_log ( (char*)"char**	malloc_char_002_01 ( int num ) starts.");
	print_log_result_num ( num );

	result = (char**)malloc ( sizeof (char*) * num ) ;
	print_log_result_002 ((char**)result);
	if (result == NULL ) {
		dlog_001 = log_001->update_log ( (char*)"We cannot allocate the result. m 002_01");
		exit(-1);
	}

	dlog_001 = log_001->update_log ( (char*)"char**	malloc_char_002_01 ( int num ) ends.");
	return result;
}

//
char***	realloc_char_003_01 ( char*** restr, int num ) {
	char*** result;
	dlog_001 = log_001->update_log ( (char*)"char***	realloc_char_003_01 ( char*** restr, int num ) starts.");
	print_log_result_num ( num );

	result = (char***)realloc ( restr, sizeof (char**) * num ) ;
	print_log_result_msg_003 ( (char*)"restr", (char***)restr);
	print_log_result_msg_003 ( (char*)"result", (char***)result);

	if ( result == NULL ) {
		result = restr;
		print_log_result_msg_003 ( (char*)"restr -> result", (char***)result);
	}

	if (result == NULL ) {
		dlog_001 = log_001->update_log ( (char*)"We cannot allocate the result. re 003_01");
		exit(-1);
	}

	dlog_001 = log_001->update_log ( (char*)"char***	realloc_char_003_01 ( char*** restr, int num ) ends.");
	return result;
}

//
char**	realloc_char_002_01 ( char** restr, int num ) {
	char** result;
	dlog_001 = log_001->update_log ( (char*)"char**	realloc_char_002_01 ( char** restr, int num ) starts.");
	print_log_result_num ( num );

	result = (char**)realloc ( restr, sizeof (char*) * num ) ;
	print_log_result_msg_002 ((char*)"restr", (char**)restr);
	print_log_result_msg_002 ((char*)"result", (char**)result);

	if ( result == NULL ) {
		result = restr;
		print_log_result_msg_003 ( (char*)"restr -> result", (char***)result);
	}

	if (result == NULL ) {
		dlog_001 = log_001->update_log ( (char*)"We cannot allocate the result. re 002_01");
		exit(-1);
	}

	dlog_001 = log_001->update_log ( (char*)"char**	realloc_char_002_01 ( char** restr, int num ) ends.");
	return result;
}


int print_log_result_003 (char*** result) {
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_003 (char*** result) starts. ");
	sprintf( logmsg, "result(char***)|%p|\0", (char***)result );
	dlog_001 = log_001->update_log ( (char*)logmsg);
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_003 (char*** result) ends. ");
	return 0;
}

int print_log_result_002 (char** result) {
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_002 (char** result) starts. ");
	sprintf( logmsg, "result(char**)|%p|\0", (char**)result );
	dlog_001 = log_001->update_log ( (char*)logmsg);
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_002 (char** result) ends. ");
	return 0;
}

int print_log_result_001 (char* result) {
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_001 (char* result) starts. ");
	sprintf( logmsg, "result(char*)|%p|\0", (char*)result );
	dlog_001 = log_001->update_log ( (char*)logmsg);
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_001 (char* result) ends. ");
	return 0;
}

int print_log_result_msg_003 (char* msg, char*** result) {
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_msg_003 (char* msg, char*** result) starts. ");
	sprintf( logmsg, "%s(char***)|%p|\0", (char*)msg, (char***)result );
	dlog_001 = log_001->update_log ( (char*)logmsg);
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_msg_003 (char* msg, char*** result) ends. ");
	return 0;
}

int print_log_result_msg_002 (char* msg, char** result) {
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_msg_002 (char* msg, char** result) starts. ");
	sprintf( logmsg, "%s(char**)|%p|\0", (char*)msg, (char**)result );
	dlog_001 = log_001->update_log ( (char*)logmsg);
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_msg_002 (char* msg, char** result) ends. ");
	return 0;
}


int print_log_result_num (int num) {
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_num (int num) starts. ");
	sprintf( logmsg, "num|%d|\0", num );
	dlog_001 = log_001->update_log ( (char*)logmsg);
	dlog_001 = log_001->update_log ( (char*)"int print_log_result_num (int num) ends. ");
	return 0;
}

int print_log_width_height_result ( int i, int j ) {
	dlog_001 = log_001->update_log ( (char*)"int print_log_width_height_result ( int i, int j ) starts. ");
	sprintf( logmsg, "index i|%d|j|%d|\0", i, j );
	dlog_001 = log_001->update_log ( (char*)logmsg);
	dlog_001 = log_001->update_log ( (char*)"int print_log_width_height_result ( int i, int j ) ends. ");
	return 0;
}


int print_log_width_height_mem_result ( int i, int j , char* result ) {
	dlog_001 = log_001->update_log ( (char*)"int print_log_width_height_mem_result ( int i, int j , char* result ) starts. ");
	sprintf( logmsg, "mem ( %d, %d ) = |%p| %s\0", i, j, result , result );
	dlog_001 = log_001->update_log ( (char*)logmsg);
	dlog_001 = log_001->update_log ( (char*)"int print_log_width_height_mem_result ( int i, int j , char* result ) ends. ");
	return 0;
}

int print_log_width_height_mem_address_result ( int i, int j , char** result ) {
	dlog_001 = log_001->update_log ( (char*)"int print_log_width_height_mem_address_result ( int i, int j , char** result ) starts. ");
	sprintf( logmsg, "memaddress |%p|i|%d|j|%d| %s\0", (char**)result,  i, j );
	dlog_001 = log_001->update_log ( (char*)logmsg);
	dlog_001 = log_001->update_log ( (char*)"int print_log_width_height_mem_address_result ( int i, int j , char** result ) ends. ");
	return 0;
}

int read_csv_000a_014 () {
	return 1;

}


int read_csv_000a_set_014 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_014 (char** argv, int argc) {
 	return 1;
 
}

//
int Set_Logging_read_csv_000a_014 ( Logging* log ) {
	printf("int Set_Logging_read_csv_000a_014 ( Logging* log ) starts. ");
	log_001 = (Logging*)log;
	printf("int Set_Logging_read_csv_000a_014 ( Logging* log ) ends. ");
	return 0;
}
