

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "wEvent.h"
#include "wButton.h"
#include "wButtonController.h"
#include "wCanvasController.h"

#include "ReturnableParam.h"
#include "vDisplayController_002.h"



int vDisplayController_002::SetCanvas ( wCanvasController *l_canvas ) {
	this->canvas = l_canvas;
}

int vDisplayController_002::draw_canvas_buffer () {

	this->canvas->Set_Buffer( 10, 10, 0, 128);

	return 0;
}

int vDisplayController_002::print_condition (vPoint** p_array, int num ) {
	printf("int vDisplayController_002::print_condition (vPoint** p_array, int num ) ends\r\n");

	printf("p_array|%p|\r\n", p_array);
	vPoint* a_b = nullptr;
	for ( int i=0; i<num; i++ ) {
		a_b = (vPoint*)p_array[i];
		printf("|%p|%d|", a_b, i);
		a_b->print();
	}

	printf("int vDisplayController_002::print_condition (vPoint** p_array, int num ) starts\r\n");
}

// You should consider that positon, if you lift it on your car by the Jackey.
//
// URL: http://qwerudsjhdfl.iiblog.jp/article/498175665.html
// Frame like window of it
int vDisplayController_002::set_condition (double x, double y, double thick ) {
//	vCaculation Calc;
	vPoint op( 0.0f, 0.0f, 0.0f );
	vPoint right ( 1.0f, 0.0f, 0.0f );
	vPoint up ( 0.0f, 1.0f, 0.0f );
	vPoint depth ( 0.0f, 0.0f, 1.0f );
	vPoint X, Y, Z;
	vPoint unP[4];
	vPoint upP[4];

	this->Calc.scalize(right, x, &X );	
	this->Calc.scalize(up, y, &Y );	
	this->Calc.scalize(up, thick, &Z );	

	unP[0].setPoint( 0.0f, 0.0f, 0.0f );
	this->Calc.add( op,    X, &unP[1]);
	this->Calc.add( unP[1], Y, &unP[2]);
	this->Calc.subtract( unP[2], X, &unP[3]);

	this->Calc.add( upP[0], Z, &upP[1]);
	this->Calc.add( upP[1], Z, &upP[2]);
	this->Calc.add( upP[2], Z, &upP[3]);
	this->Calc.add( upP[3], Z, &upP[4]);


	printf("p_head|%p|\r\n", (vPoint**)&unP[0]);
	this->print_condition( (vPoint**)&unP[0], 4 );
	printf("p_head|%p|\r\n", (vPoint**)&upP[0]);
	this->print_condition( (vPoint**)&upP[0], 4 );
	
	return 0;
}


int vDisplayController_002::malloc_main_002 () {
	char *string_001 = NULL;
	int i;
	FILE *fp = NULL;
	printf("int malloc_main_002 ( int argc, char** argv ) starts.\r\n");

	fp = fopen ( (char*) "001-malloc_main-002-02.txt", "wb" );

	//
	string_001 = (char*)char_string_012(10);
	for( i=0; i<10; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	int a = (int)mchar_string_002(string_001, 16);
	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	fclose(fp);
	printf("int malloc_main_002 ( int argc, char** argv ) ends.\r\n");
	return 0;
}

int vDisplayController_002::malloc_main_001 () {
	char *string_001 = NULL;
	int i;
	FILE *fp = NULL;
	printf("int malloc_main_001 ( int argc, char** argv ) starts.\r\n");

	fp = fopen ( (char*) "001-malloc_main-002.txt", "wb" );

	//
	string_001 = (char*)char_string(10);
	for( i=0; i<10; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	fclose(fp);
	printf("int malloc_main_001 ( int argc, char** argv ) ends.\r\n");
	return 0;
}

int vDisplayController_002::malloc_main () {
	char *string_001 = NULL;
	char *string_003 = NULL;
	int i;
	FILE *fp = NULL;
	printf("int main ( int argc, char** argv ) starts.\r\n");

	fp = fopen ( (char*) "001-malloc_main-001.txt", "wb" );

	//
	string_001 = (char*)char_string(10);
	for( i=0; i<10; i++ ) {
		fprintf(fp,"string[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	string_003 = (char*)mchar_string(string_001, 16);
	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 03[%d]=|%p|%d|\r\n", i, string_003 + i, *(string_003+i));
	}

	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_003 + i, *(string_001 + i));
	}

	fclose(fp);
	printf("int main ( int argc, char** argv ) ends.\r\n");
	return 0;
}

int vDisplayController_002::realloc_main () {
	char *string_001 = NULL;
	char *string_003 = NULL;
	int i;
	FILE *fp = NULL;
	printf("int main ( int argc, char** argv ) starts.\r\n");

	fp = fopen ( (char*) "001-realloc_main-001.txt", "wb" );

	//
	string_001 = (char*)char_string(10);
	for( i=0; i<10; i++ ) {
		fprintf(fp,"string[%d]=|%p|\r\n", i, *(string_001+i));
	}

	string_003 = (char*)rechar_string(string_001, 16);
	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 03[%d]=|%p|\r\n", i, *(string_003+i));
	}

	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|\r\n", i, *(string_001 + i));
	}

	fclose(fp);
	printf("int main ( int argc, char** argv ) ends.\r\n");
	return 0;
}

// char* vDisplayController_002::rechar_string (char* string_002, int num)
// int vDisplayController_002::realloc_main ()
char* vDisplayController_002::rechar_string (char* string_002, int num) {
	printf("char* rechar_string (char* string_002, int num) starts.\r\n");

	string_002 = (char*) realloc ( string_002, num );
	if ( string_002 == NULL ) {
		printf("13: |%p|\r\n", string_002);
		exit(-1);
	}

	printf("char* rechar_string (char* string_002, int num) ends.\r\n");
	return string_002;
}

// char* vDisplayController_002::rechar_string (char* string_002, int num)
// int vDisplayController_002::realloc_main ()
char* vDisplayController_002::mchar_string (char* string_002, int num) {
	char *tmp, *w;
	printf("char* mchar_string (char* string_002, int num) starts.\r\n");

	tmp = (char*) malloc ( num );
	if ( tmp == NULL ) {
		printf("14: |%p|\r\n", tmp);
		exit(-1);
	}
	w = string_002;
	string_002 = tmp;
	free(w);
	printf("char* mchar_string (char* string_002, int num) ends.\r\n");
	return string_002;
}

// char* vDisplayController_002::rechar_string (char* string_002, int num)
// int vDisplayController_002::realloc_main ()
int vDisplayController_002::mchar_string_001 (char* string_002, int num) {
	char *tmp, *w;
	printf("int mchar_string_001 (char* string_002, int num) starts.\r\n");

	tmp = (char*) malloc ( num );
	if ( tmp == NULL ) {
		printf("14: |%p|\r\n", tmp);
		exit(-1);
	}
	w = string_002;
	string_002 = tmp;
	free(w);
	printf("int mchar_string_001 (char* string_002, int num) ends.\r\n");
	return 0;
}

// char* vDisplayController_002::rechar_string (char* string_002, int num)
// int vDisplayController_002::realloc_main ()
int vDisplayController_002::mchar_string_002 (char* string_002, int num) {
	char *tmp, *w;
	printf("int mchar_string_002 (char* string_002, int num) starts.\r\n");

	printf("001: w|%p| tmp|%p| param: string_002|%p|\r\n", w, tmp, string_002 );
	tmp = char_string_012(num);
	w = tmp;
	string_002 = tmp;
	aFree(w);
	printf("002: w|%p| tmp|%p| param: string_002|%p|\r\n", w, tmp, string_002 );
	printf("int mchar_string_002 (char* string_002, int num) ends.\r\n");
	return 0;
}

int vDisplayController_002::create_img_buffer_print_its_adress (char* filename, int width, int height, int flag) {
	float* img_003 = NULL;
	FILE *fp;
	float* f;
	int i;

	fp = fopen ( (char*) filename, "wb" );
	if (fp == NULL) {
		printf("file: %s is unstable for its open as wb.\r\n", filename );
		exit(-1);
	}
	img_003 = (float*) malloc(sizeof(float*)*width*height);
	if (img_003 == NULL) {
		printf("img_003 is not memoried(allocated).\r\n");
		exit(-1);
	}

	for(i=0; i<width*height; i++) {
		f = (float*)(img_003 + i );
		fprintf( fp, "|%p|\r\n", f);
	}

	fclose(fp);
}


// int Set_Buffer (int xx, int yy, int col, unsigned char vv ) ;
// display_004.DisplayBonesGear (); ->
// 0: red
// 1: blue
// 2: green
// 3: transparent
//
int vDisplayController_002::create_img_buffer_002 (char* filename, int width, int height, int flag) {
	float*** img_003 = NULL;
	int i, j;

	printf("int vDisplayController_002::create_img_buffer_002 (char* filename, int width, int height, int flag) starts.\r\n");

	img_003 = (float***) malloc(sizeof(float***)*width);
	if (img_003==NULL) {
		printf("img_003 is NULL\r\n");
		exit(-1);
	}
	for ( i=0; i<width; i++ ) {
		img_003[i] = (float**) malloc(sizeof(float**)*height);
		if (img_003[i]==NULL) {
			printf("img_003[%d] is NULL\r\n", i);
			exit(-1);
		}
		for ( j=0; j<height; j++ ) {
			img_003[i][j] = (float*) malloc (sizeof(float*) * 4 );
			if (img_003[i][j]==NULL) {
				printf("img_003[%d][%d] is NULL\r\n", i, j);
				exit(-1);
			}
		}
	}

	ppm_img = (float***)img_003;
	ppm_width = width;
	ppm_height = height;
	ppm_filename = filename;


	printf("int vDisplayController_002::create_img_buffer_002 (char* filename, int width, int height, int flag) ends.\r\n");
	return 0;
}

// display_004.DisplayBonesGear (); ->
// 0: red
// 1: blue
// 2: green
// 3: transparent
//
int vDisplayController_002::create_img_buffer (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) {
	float*** img_003 = NULL;
	int i, j;

	printf("int vDisplayController_002::create_img_buffer (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) starts.\r\n");

	img_003 = (float***) malloc(sizeof(float***));
	for ( i=0; i<width; i++ ) {
		img_003[i] = (float**) malloc(sizeof(float**));
		for ( j=0; j<height; j++ ) {
			img_003[i][j] = (float*) malloc (sizeof(float*) * 4 );
		}
	}

	printf("int vDisplayController_002::create_img_buffer (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) ends.\r\n");
	return 0;
}

// 	if ( 0>i && 0>j && i>=width && j>=height ) continue;
//  if ( a<0.0 && i<0 ) break;
//  if ( a<0.0 && j<0 ) break;
//  if ( a>0.0 && i>=width ) break;
//  if ( a>0.0 && j>=height ) break;
// img[x][y][red]
int vDisplayController_002::draw_line_002 (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) {
	int i, j, plus;
	float up, down, a, axex, abs_a;

	printf("int vDisplayController_002::write_ppm_002 (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) starts.\r\n");

	down = x2 - x1;
	up = y2 - y1;
	a = up / down;
	abs_a = abs(a);

	if ( a < 0.0f ) plus=1;
	else plus=-1;

	printf("a=%0.5f abs_a=%f plus=%d\r\n", a, abs_a, plus );
	if ( abs_a < 0.5 ) {
		for ( i= 0; i<x1; i++ ) {
			if ( 0>i && 0>j && i>=width && j>=height ) continue;
			printf("i:%d\r\n", i);
			axex += a;
			img[i][(int)axex][2] = 1.0f;
		}
	} else {
		for ( j= 0; j<y1; j++ ) {
			if ( 0>i && 0>j && i>=width && j>=height ) continue;
			printf("j:%d\r\n", j);
			axex += a;
			img[(int)axex][j][2] = 1.0f;
		}
	}

	printf("int vDisplayController_002::write_ppm_002 (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) ends.\r\n");
}

//
int vDisplayController_002::init_buffer (char* buffer, int size, int flag) {

	printf("int vDisplayController_002::init_buffer (char* buffer, int size, int flag) starts.\r\n");

	for ( int i=0; i<size; i++ )
		buffer[i] = flag;

	printf("int vDisplayController_002::init_buffer (char* buffer, int size, int flag) ends.\r\n");
	return 0;
}

//
int vDisplayController_002::read_ppm_002 (char* filename, float*** img, int* width, int* height, int flag) {
	int i, j;
	FILE *fp;
	FILE *start_fp;
	char w[1];
	char head[128];
	int count = 0, index = 0;
	int mode = 0;
	int a;
	int *density;

	printf("int read_ppm_002 starts.\n");

	for ( i = 0; i<128; i++ )
		head[i] = 0;

	fp = fopen ( (char*) filename, "rb" );
	if ( fp == NULL ) {
		printf("fp=%d |%s|\n", fp, filename);
		exit(-1);
	}

	for ( i = 0; i<128 && count<3; i++ ) {
		m_fread( &head[i], 1, fp );
		printf("|%c|%d|%s\ncount=%d\n", head[i], head[i], head, count );
		switch ( head[i] ) {
		case '\r':
			if ( m_compare( (char*)head, (char*)"P6" ) == 1 && count == 0 ) {
				printf("P6\n");
				count++;
				i = 0;
				exit(-1);
			} else if ( '0'< head[0] < '9') {
				printf("%s\n", head);
				count++;
				i = 0;
				exit(-1);
			} else if ( '#'< head[0] ) {
				printf("%s\n", head);
				i = 0;
				exit(-1);
			}
			printf("line end \\r|%d|\n", '\r' );
			exit(-1);
			break;
		case '\n':
			if ( m_start_with ( (char*)head, (char*)"P6" ) == 1 && count == 0 ) {
				printf("P6\n");
				count++;
				i = -1;
				a = init_buffer( (char*)head, 128, 0 );
			} else if ( '0'< head[0] && head[0] < '9' ) {
				printf("head: %s |%d|<->|%d| |%d|\n", head, '0', '9', head[i] );
				switch ( count ) {
				case 1:
					a = param_int ( head, width, height);
					break;
				case 2:
					a = param_int ( head, density );
					break;
				}
				count++;
				i = -1;
				a = init_buffer( (char*)head, 128, 0 );
			} else if ( '#'== head[0] ) {
				printf("#head: %s\n", head);
				i = -1;
				a = init_buffer( (char*)head, 128, 0 );
			}
			printf("line end \\n|%d|\n", '\n' );
			break;
		}
	}

	fclose(fp);

	printf("int read_ppm_002 ends.\n");

	return 0;
}


int vDisplayController_002::param_int (char* head, int* width, int* height) {
	int i, j;
	char a[5], b[5];
	printf("int vDisplayController_002::param_int (char* head, int* width, int* height) starts.\r\n");

	for ( i=0; i<5; i++ ) {
		a[i] = head[i];
		if ( head[i] == ' ' ) {
			a[i] = '\0';
			break;
		}
	}

	printf("num1 %d a %s int|%d|\r\n", i, a, atoi(a) );

	i++;
	for ( j=0; j<5; j++ ) {
		b[j] = head[i+j];
		if ( head[i+j] == '\0' || head[i+j] < '0' || head[i+j] > '9' ) {
			b[j] = '\0';
			break;
		}
	}

	printf("num2 %d b[0] %d b |%s| int|%d|\r\n", j, b[0], b, atoi(b) );

	*width = atoi ( a );
	*height = atoi ( b );

	printf("int vDisplayController_002::param_int (char* head, int* width, int* height) ends.\r\n");
	return 0;
}


int vDisplayController_002::param_int ( char* head, int* density ) {
	int i;
	printf("int vDisplayController_002::param_int (char* head,  int* density ) starts.\r\n");

	for ( i=0; i<5; i++ ) {
		if ( head[i] == '\n' ) break;
	}

	printf("num %d head %s\r\n", i, head);
//	printf("atoi(head)=%d\r\n", atoi ( (const char*)head ));
//*density = atoi ( (const char*)head );
//	printf("density=%d\r\n", *density );

	printf("int vDisplayController_002::param_int (char* head,  int* density ) ends.\r\n");
	return 0;
}

// C:\Users\Beneton\Desktop\desktop-20220313-001\ppm-20220121
//
//
int vDisplayController_002::write_ppm_002 (char* filename, float*** img, int width, int height, int flag) {
	int i, j;
	FILE *fp;
	FILE *start_fp;
	char w[1];
	char head[128];
	int count = 0, index = 0;

	printf("int write_ppm_002 starts.\n");


	for ( i = 0; i<128; i++ )
		head[i] = 0;

	fp = fopen ( (char*) filename, "wb" );
	start_fp = fp;

	sprintf( head, "P6\r%d %d\r%d\r", width, height, 255 ); 

	// count the buffer.
	for ( i = 0; i<128; i++ ) {
		if ( head[i] == '\r' )
			count++; 

		if ( count == 3 ) {
			index = i;
			break;
		}
	}

	printf("index %d flag %d filename %s\n", index, flag, filename );
	printf("start|fp| to |fp| = |%p| to |%p|\n", start_fp, fp);

	fwrite( (char*)head, 128, index, fp ); 

	printf("start|fp| to |fp| = |%p| to |%p|\n", start_fp, fp);

	if ( flag == 1 ) {
		for ( j = 0; j< height; j++ ) {
			for ( i = 0; i< width; i++ ) {
				printf(" i, j = %d, %d\n", i, j );
				w[0] = 255.0f * img[j][i][0];
				fwrite( (char*) w, 1, 1,  fp );
				w[0] = 255.0f * img[j][i][1];
				fwrite( (char*) w, 1, 1,  fp );
				w[0] = 255.0f * img[j][i][2];
				fwrite( (char*) w, 1, 1,  fp );
			}
		}
	} else if ( flag == 0 ) {
		printf("We are going to Print the message in the header.\n");
		fprintf(fp, "#Print Only Header flag %d.\n", flag);
	}

	printf("start|fp| to |fp| = |%p| to |%p|\n", start_fp, fp);
	fclose (fp);

	printf("int write_ppm_002 ends. fp=|%p|\n", fp);

	return 0;
}

// position
// demsity
// integral: https://en.wikipedia.org/wiki/Integral
int vDisplayController_002::DisplaySolid (vPoint center ) {
	float a, c, x, y;
	float m_pi = 3.141592;

	printf("vDisplayController_002:: DisplaySolid (vPoint center ) starts.\r\n");
	c = 20.0f;
	for ( int i=0; i<10; i++ ) {
		printf("i %d / 10\r\n", i);
		a = i / 5;
		a = m_pi / a;
		printf("a=%f\r\n", a );
		x = c * sin(a);
		y = c * cos(a);
		this->draw_line_002 ( this->ppm_filename, ppm_img, (int)x, (int)y, (int)center.x, (int)center.y, this->ppm_width,  this->ppm_height, 0 );
	}
	printf("vDisplayController_002::DisplaySolid (vPoint center ) ends.\r\n");
}

int vDisplayController_002::DisplayLightHouse () {
	//vPoint bones_001[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;
	int slide_pow = 10.0f;
	vPoint *slide = nullptr;
	int upward_pow = 50.0f;
	vPoint *upward = nullptr;

	printf("vDisplayController_002:: DisplayLightHouse () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	printf("01: this->canvas |%p|/nullptr|%p|\r\n", this->canvas, nullptr );
	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	// 
	slide = memorizevPoint ( 1.0f, 0.0f, 0.0f );
	upward = memorizevPoint ( 0.0f, 1.0f,0.0f );
	this->Calc.scale( slide, slide_pow );
	this->Calc.scale( upward, slide_pow );
	bones_001[ 0 ].setPoint ( 0.0f, 0.0f, 0.0f );
	bones_001[ 0 ].print();

	for ( int j=1; j<10; j++ ) {
		printf("j=%d\r\n", j);
		this->Calc.add( bones_001[ j*2 - 2], *slide, &bones_001[ j*2 - 1] );
		this->Calc.add( bones_001[ j*2 - 1], *upward, &bones_001[ j*2 ] );
		bones_001[ j*2 - 1 ].print();
		bones_001[ j*2 ].print();
//		exit(-1);
	}
//	free_point ( slide );
//	free_point ( upward );
//	exit(-1);

	printf("01: this->canvas |%p|\r\n", this->canvas );
	this->canvas->AXEX_2D_002_Index = 0;
	printf("02: this->canvas->AXEX_2D_002_Index %d\r\n", this->canvas->AXEX_2D_002_Index);
	exit(-1);
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("vDisplayController_002:: DisplayLightHouse () ends.\r\n");
	exit(-1);
	return 0;
}

int vDisplayController_002::DisplayPillar () {
	int i;
	printf("int vDisplayController_002::DisplayPillar () starts.\r\n");
	vBox** box_001 = nullptr;

	box_001 = (vBox**)malloc ( sizeof(vBox*) * 8 );
	if ( box_001 == nullptr ) {
		printf("box_001 array is null \r\n.");
		exit(-1);
	}

	for ( i=0; i<8; i++ ) {
		box_001[i] = new vBox ( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);
	}

	printf("int vDisplayController_002::DisplayPillar () ends.\r\n");
	return 1;
}

// [1].Calculation_Axex_002 
int vDisplayController_002::DisplayAxex () {
	printf("int vDisplayController_002::DisplayAxex () starts.\r\n");

	vAxex_2D* local_axex = new vAxex_2D ();
	local_axex->SetCenter( 1.0, 1.0, 1.0 );
	local_axex->SetDepth( 0.0, 0.0, 5.0 );
// x	local_axex->Calculation_Axex_002 ();
	local_axex->Calculation_Axex_002 ();

//	local_axex->right->print ();
//	local_axex->up->print ();
//	local_axex->depth->print ();

	printf("int vDisplayController_002::DisplayAxex () ends.\r\n");
	return 1;
}

int vDisplayController_002::DisplayBones_002 () {
	//vPoint bones_001[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;

	printf("vDisplayController_002:: DisplayBones_002 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		this->canvas = new wCanvasController ();
		printf("this->canvas is allocated |%p|.\r\n", this->canvas );
	}


	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones_001[0].setPoint (  0.0f,  0.0f,    0.0f );
	bones_001[1].setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones_001[1], bones_001[0], &w1 );
	for ( int j=2; j<10; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones_001[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones_001[j-1].print();
			bones_001[j].print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones_001[ j ].setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("vDisplayController_002:: DisplayBones_002 () ends.\r\n");
//	exit(-1);
	return 0;
}

//
int vDisplayController_002::SetBaseAxex () {
	printf("vDisplayController_002:: SetBaseAxex () starts.\r\n");

	if ( axex_line_3d_002 == nullptr ) {
		printf("vDisplayController:: SetBaseAxex () allocation: %d\r\n", axex_line_max);
		axex_line_3d_002 = (vLine**) malloc ( sizeof (vLine*) * axex_line_max );
		printf("vDisplayController:: SetBaseAxex () allocation: end\r\n");
	}

	axex_line_3d_002[0] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
	axex_line_3d_002[1] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
	axex_line_3d_002[2] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );

	printf("vDisplayController:: All in 3D has just finished to set.\r\n");

	this->DisplayBaseAxex();

	printf("vDisplayController_002:: SetBaseAxex () ends.\r\n");
	return 0;
}

int vDisplayController_002::DisplayBaseAxex () {
	float x1, x2, y1, y2;
	printf("vDisplayController_002:: DisplayBaseAxex () starts.\r\n");

	printf("axex_line_3d_002 |%p|\r\n", axex_line_3d_002 );
	if ( axex_line_3d_002 == nullptr) {
		printf("axex_line_3d_002 is nullptr.\r\n");
		exit(-1);
	}
	this->canvas->AXEX_2D_LINE_Index = 0;
	for ( int j=0; j<axex_line_max; j++ ) {
		printf("002: code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( *(axex_line_3d_002[j]->p1), &x1, &y1 );
		a = screen_006.get_cooordinate_on_screen ( *(axex_line_3d_002[j]->p2), &x2, &y2 );
		this->canvas->Set_Axex_Line ( x1, y1, x2, y2 );
		printf("002: code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_LINE_Index );
	}

	printf("vDisplayController_002:: DisplayBaseAxex () ends.\r\n");
	return 0;
}

int vDisplayController_002::DisplayBaseAxexFixed () {
	float add_y;
	printf("vDisplayController_002:: DisplayBaseAxexFixed () starts.\r\n");

	add_y = 0.0f;
	this->canvas->AXEX_2D_LINE_Index = 0;
	for ( int j=0; j<axex_line_max; j++ ) {
		this->canvas->Set_Axex_Line ( 50.0f, 50.f, 300.0f + add_y, 300.0f );
		add_y += 50.0f;
	}

	printf("vDisplayController_002:: DisplayBaseAxexFixed () ends.\r\n");
	return 0;
}

int vDisplayController_002::SetEye (float x, float y, float z) {
	printf("vDisplayController_002:: SetEye () starts.\r\n");

	vPoint* eye = memorizevPoint( x, y, z );
	screen_006.setEye ( *eye );
	screen_006.calculation_up_UV();

	//---
	this->Set_Canvas_Bones();
	//---

	this->DisplayBaseAxex();

	free_point ( eye );

	printf("vDisplayController_002:: SetEye () ends.\r\n");
	return 0;
}

int vDisplayController_002::Set_Canvas_Bones () {
	float x, y;
	printf("vDisplayController_002:: Set_Canvas_Bones () starts.\r\n");
	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}
	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);
	printf("vDisplayController_002:: Set_Canvas_Bones () ends.\r\n");
	return 0;
}


//int vDisplayController_002::SetCanvasBones_002 () {
//
//	return 0;
//}

/*int vDisplayController_002::SetCanvasBones () {
	printf("vDisplayController_002:: SetCanvasBones () starts.\r\n");
	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);
	printf("vDisplayController_002:: SetCanvasBones () ends.\r\n");
}*/

//
int vDisplayController_002::DisplayBonesGear () {
	//vPoint bones_001[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;

	printf("vDisplayController_002:: DisplayBonesGear () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	/*
	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones_001[0].setPoint (  0.0f,  0.0f,    0.0f );
	bones_001[1].setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones_001[1], bones_001[0], &w1 );
	for ( int j=2; j<10; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones_001[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones_001[j-1].print();
			bones_001[j].print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones_001[ j ].setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}*/

	float radius = 100.0f;
	float theta = 0.0f;
	int num = 10;
	float aM_PI = 3.14159265358979;

	for ( int i=0; i< 10; i++ ) {
		x = radius * sin ( i * 2.0* aM_PI/ (double)num );
		y = radius * cos ( i * 2.0* aM_PI/ (double)num );
		bones_001[ i ].setPoint( x, y, 0.0f );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("vDisplayController_002:: DisplayBonesGear () ends.\r\n");
//	exit(-1);
	return 0;
}
//

// 1. copy this function as _003.
// 2. use aFree in vCaculation.
// 3. set a moved point as selected.
int vDisplayController_002::MoveSelectedPoint_002 () {
	float x, y;
	vCalculation calc;
	const float c = 5.0f;
	vPoint* range_001;

	printf("int vDisplayController::MoveSelectedPoint_002 () starts.\r\n");

	vPoint* up_001 = &(screen_006.up);
	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones_001[selected] );

	//scalize * = *, *
	range_001 = calc.scalize ( up_001, c );

	// ADD calculation * = * , *
	vPoint* moved_point = calc.add ( selected_point, range_001 );

	printf("selected_point=");
	selected_point->print();

	printf("up_001=");
	up_001->print();


	printf("moved_point=");
	moved_point->print();

	// convert value, p, p
	int a = screen_006.get_cooordinate_on_screen ( *moved_point, &x, &y );
	int stored = this->canvas->AXEX_2D_002_Index;
	this->canvas->AXEX_2D_002_Index = selected;
	this->canvas->Set_vAxex_2D( x, y );
	this->canvas->AXEX_2D_002_Index = stored;

	printf("1002 x, y = %f, %f\r\n", x, y);

	printf("int vDisplayController::MoveSelectedPoint_002 () ends.\r\n");
	return 0;
}
// From u to x
// 1. copy this function as _003.
// 2. use aFree or free_point in vCaculation.
// 3. set a moved point as selected.
//
int vDisplayController_002::MoveSelectedPoint_003 () {
	float x, y;
	vCalculation calc;
	const float c = 50.0f;
	vPoint* range_001;

	printf("int vDisplayController_002::MoveSelectedPoint_002 () starts.\r\n");

	vPoint* up_001 = &(screen_006.up);
	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones_001[selected] );

	//scalize * = *, *
	range_001 = calc.scalize ( up_001, c );

	// ADD calculation * = * , *
	vPoint* moved_point_003 = calc.add ( selected_point, range_001 );
	this->bones_001[ selected ].setPoint( moved_point_003->x, moved_point_003->y, moved_point_003->z );

	printf("selected_point=");
	selected_point->print();

	printf("up_001=");
	up_001->print();

	printf("range_001=");
	range_001->print();

	printf("moved_point_003=");
	moved_point_003->print();

	printf("bones_001=");
	this->bones_001[ selected ].print();

	// convert value, p, p
	int a = screen_006.get_cooordinate_on_screen ( this->bones_001[ selected ], &x, &y );
	int stored = this->canvas->AXEX_2D_002_Index;
	this->canvas->AXEX_2D_002_Index = selected;
	this->canvas->Set_vAxex_2D( x, y );
	this->canvas->AXEX_2D_002_Index = stored;

	printf("1002 x, y = %f, %f\r\n", x, y);

	free_point ( up_001 );
	free_point ( selected_point );
	free_point ( moved_point_003 );
	//free_point ( range_001 );
	free ( range_001 );

	//printf("range_001_a=");
	//range_001->print();

	printf("int vDisplayController_002::MoveSelectedPoint_002 () ends.\r\n");
	return 0;
}

// 1. Add the switch-case for the axex.
int vDisplayController_002::MoveSelectedPoint_004 (int number) {
	float x, y;
	vCalculation calc;
	const float c = 50.0f;
	vPoint* range_001;

	printf("int vDisplayController_002::MoveSelectedPoint_004 () starts.\r\n");

	vPoint* mv_002 = nullptr;
	switch (number) {
		case 1:
			mv_002 = &(screen_006.up);
			break;
		case 2:
			mv_002 = &(screen_006.right);
			break;
		case 3:
			mv_002 = &(screen_006.depth);
			break;
		default:
			mv_002 = &(screen_006.up);
			break;
	}
	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones_001[selected] );

	//scalize * = *, *
	range_001 = calc.scalize ( mv_002, c );

	// ADD calculation * = * , *
	vPoint* moved_point_003 = calc.add ( selected_point, range_001 );
	this->bones_001[ selected ].setPoint( moved_point_003->x, moved_point_003->y, moved_point_003->z );

	printf("selected_point=");
	selected_point->print();

	printf("mv_002=");
	mv_002->print();

	printf("range_001=");
	range_001->print();

	printf("moved_point_003=");
	moved_point_003->print();

	printf("bones_001=");
	this->bones_001[ selected ].print();

	// convert value, p, p
	int a = screen_006.get_cooordinate_on_screen ( this->bones_001[ selected ], &x, &y );
	int stored = this->canvas->AXEX_2D_002_Index;
	this->canvas->AXEX_2D_002_Index = selected;
	this->canvas->Set_vAxex_2D( x, y );
	this->canvas->AXEX_2D_002_Index = stored;

	printf("1002 x, y = %f, %f\r\n", x, y);

	free_point ( mv_002 );
	free_point ( selected_point );
	free_point ( moved_point_003 );
	//free_point ( range_001 );
	free ( range_001 );

	//printf("range_001_a=");
	//range_001->print();

	printf("int vDisplayController_002::MoveSelectedPoint_004 () ends.\r\n");
	return 0;
}

//
int vDisplayController_002::Reflection_Figure_with_Screen ( ) {
	float x, y;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint* eye = nullptr;
	vBox box( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);

	printf("int vDisplayController_002::Reflection_Figure_with_Screen ( ) starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();


	int a = screen_006.get_cooordinate_on_screen ( p1, &x, &y );

	printf("int vDisplayController_002::Reflection_Figure_with_Screen ( ) ends.\r\n");
	return 0;
}

int vDisplayController_002 :: Reflection_Figure_Setting (vTriangle *tri ) {
	vPoint p1, p2, p3;
	vPoint sp1, sp2, sp3;
	vCalculation calc;
	float f_001 = 3.0f;

	if ( tri == nullptr ) {
		printf("012: tri|%p|\r\n", tri);
		exit(-1);
	}

	p1.setPoint ( 10, 10, 0);
	p2.setPoint ( 50, 20, 0);
	p3.setPoint ( 20, 50, 0);

	calc.subtract( &p1, &(screen_006.eye), &sp1);
	calc.subtract( &p2, &(screen_006.eye), &sp2);
	calc.subtract( &p3, &(screen_006.eye), &sp3);

	calc.scalize( &sp1, f_001, &(tri->p1) );
	calc.scalize( &sp2, f_001, &(tri->p2) );
	calc.scalize( &sp3, f_001, &(tri->p3) );

	calc.add( screen_006.eye, tri->p1, &(tri->p1) );
	calc.add( screen_006.eye, tri->p2, &(tri->p2) );
	calc.add( screen_006.eye, tri->p3, &(tri->p3) );

	return 0;
}
// ( tri->p1, tri->p2, tri->p3, eye, *intersection_point, reflection_point );
// vLine** vDisplayController_002::CreateTriangleLine( vPoint p1, vPoint p2, vPoint p3, vPoint p4, vPoint p5, vPoint p6, ReturnableParam *result )
// vLine** vDisplayController_002::CreateTriangleLine( vPoint p1, vPoint p2, vPoint p3, vPoint p4, vPoint p5, vPoint p6, int* result_num )
//
vLine** vDisplayController_002::CreateTriangleLine( vPoint p1, vPoint p2, vPoint p3, vPoint p4, vPoint p5, vPoint p6, ReturnableParam *result )
{
	int num = 5;
	vLine** lines_2D_002 = nullptr;

	printf("vLine** vDisplayController_002::CreateTriangleLine( vPoint p1, vPoint p2, vPoint p3, int* result_num ) starts.\r\n");

	lines_2D_002 = (vLine**) malloc ( sizeof(vLine*) * num );
	if ( lines_2D_002 == nullptr ) {
		printf("lines_2D_002 is nullptr.\r\n");
		exit(-1);
	}

	lines_2D_002[0] = (vLine*) memorizevLine( memorizevPoint( p1.x, p1.y, p1.z) ,  memorizevPoint( p2.x, p2.y, p2.z ) );
	lines_2D_002[1] = (vLine*) memorizevLine( memorizevPoint( p2.x, p2.y, p2.z) ,  memorizevPoint( p3.x, p3.y, p3.z ) );
	lines_2D_002[2] = (vLine*) memorizevLine( memorizevPoint( p3.x, p3.y, p3.z) ,  memorizevPoint( p1.x, p1.y, p1.z ) );

	lines_2D_002[3] = (vLine*) memorizevLine( memorizevPoint( p4.x, p4.y, p4.z) ,  memorizevPoint( p5.x, p5.y, p5.z ) );
	lines_2D_002[4] = (vLine*) memorizevLine( memorizevPoint( p5.x, p5.y, p5.z) ,  memorizevPoint( p6.x, p6.y, p6.z ) );

	result->points = (vPoint**) memorizevPoint( p5.x, p5.y, p5.z );
	result->lines = (vLine**) lines_2D_002;

	result->line_num = num;
	result->point_num = 1;

	printf("vLine** vDisplayController_002::CreateTriangleLine( vPoint p1, vPoint p2, vPoint p3, int* result_num ) points|%p| lines|%p|ends.\r\n", result->points, result->lines );

	return lines_2D_002;
}

//
int vDisplayController_002 :: Reflection_Figure (vTriangle *tri, vPoint eye, vPoint direction, vPoint **points, vLine **lines) {
	vPoint p1, p2, p3,  ray, lp;
	float x[3], y[3], ix, iy;
	int a;
	vCalculation calc;

	printf("int vDisplayController_002 :: Reflection_Figure (vTriangle *tri, vPoint eye, vPoint direction, vPoint **points, vLine **lines) starts.\r\n");

	// Direction
	eye.setPoint ( 50.0, 50.0, 50.0 );
	lp.setPoint ( 45.0, 42.0, 40.0 );
	calc.subtract( &(lp), &eye, &ray );
	calc.normal( &ray );

	// Triangle
	tri->p1.setPoint(  0.0,  0.0,  0.0 );
	tri->p2.setPoint( 50.0,  0.0,  0.0 );
	tri->p3.setPoint(  0.0, 10.0, 40.0 );

	vPoint* nml = tri->getNormal();

	// Intersection
	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	vPoint* point_intersection = intersection->Intersect( *tri, eye, ray );
	
	this->Reflection_Figure_with_Screen ( );

	printf("int vDisplayController_002 :: Reflection_Figure (vTriangle *tri, vPoint eye, vPoint direction, vPoint **points, vLine **lines) points|%p| lines|%p|ends.\r\n", points, lines);
	return 0;
}

//
int vDisplayController_002::Reflection_Figure (vTriangle *tri, ReturnableParam *result) {
	vPoint p1, p2, p3,  ray, lp;
	int a;
	vCalculation calc;
	vPoint eye;
	vPoint reflection_point, right, up, depth, eye1, ref1, right1, up1, depth1;
	float x, y, x1, y1, x2, y2;

	printf("int vDisplayController_002 :: Reflection_Figure (vTriangle *tri, ReturnableParam *result) starts.\r\n");


	this->Reflection_Figure_with_Screen ( );

	// Direction
	calc.subtract( &(screen_006.C), &(screen_006.eye), &ray );
	calc.normal( &ray );

	// Trinangle
	this->Reflection_Figure_Setting ( tri );
	vPoint* nml = tri->getNormal();

	// Local Axex
	vAxex_2D *local_axex = new vAxex_2D ();
	local_axex->SetUp( nml->x, nml->y, nml->z );
	local_axex->SetCenter( tri->p1.x, tri->p1.y, tri->p1.z );
	local_axex->SetDepth( tri->p3.x - tri->p2.x, tri->p3.y - tri->p2.y, tri->p3.z - tri->p2.z );
	local_axex->Calculation_Axex_002 ();

	// Intersection
	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	vPoint* point_intersection = intersection->Intersect( *tri, screen_006.eye, ray );


	// reflection_point from axex
	calc.subtract( screen_006.eye, *point_intersection, &eye1 );
	calc.scalize( local_axex->right, eye1.x, &right );
	calc.scalize( local_axex->up, eye1.y, &up );
	calc.scalize( local_axex->depth, eye1.z, &depth );
	calc.scalize( right, eye1.x, &right1 );
	calc.scalize( up,   -eye1.y, &up1 );
	calc.scalize( depth, eye1.z, &depth1 );
	calc.add( *point_intersection, right1, &reflection_point );
	calc.add( reflection_point, up1, &reflection_point );
	calc.add( reflection_point, depth1, &reflection_point ); 

	this->CreateTriangleLine( tri->p1, tri->p2, tri->p3, screen_006.eye, *point_intersection, reflection_point, result );

	// Set to canvas
	printf("points|%p| num %d lines|%p| num %d \r\n", result->points, result->point_num, result->lines, result->line_num );
	if ( this->canvas == nullptr) {
		printf("this->canvas is null.\r\n");
		exit(-1);
	}

	this->canvas->AXEX_2D_LINE_Index = 0;
	for ( int i=0; i<result->line_num; i++ ) {
		a = screen_006.get_cooordinate_on_screen ( *(result->lines[i]->p1), &x1, &y1 );
		a = screen_006.get_cooordinate_on_screen ( *(result->lines[i]->p2), &x2, &y2 );
		this->canvas->Set_Axex_Line( x1, y1, x2, y2 );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int i=0; i<result->point_num; i++ ) {
		a = screen_006.get_cooordinate_on_screen ( *(result->points[i]), &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
	}

	printf("int vDisplayController_002 :: Reflection_Figure (vTriangle *tri, ReturnableParam *result) points|%p| lines|%p|ends.\r\n", result->points, result->lines );
	return 0;
}

int vDisplayController_002::Reflection_Figure_Check_Triangle (vTriangle *tri, ReturnableParam *result) {

	this->Reflection_Figure_with_Screen ( );

	// Trinangle
	this->Reflection_Figure_Setting ( tri );

	vPoint* nml = tri->getNormal();

	printf("screen_006.eye:\r\n");
	screen_006.eye.print();

	printf("tri:\r\n");
	tri->print();

	printf("nml->print:\r\n");
	nml->print();
	return 0;
}

//
//
int vDisplayController_002::Reflection_Figure_Play () {
	vTriangle tri;
	ReturnableParam result;

	printf("int vDisplayController_002::Reflection_Figure_Play (vTriangle *tri, ReturnableParam *result) starts.\r\n");

	this->Reflection_Figure ( &tri, &result);

	printf("int vDisplayController_002::Reflection_Figure_Play (vTriangle *tri, ReturnableParam *result) ends.\r\n");

	return 0;
}

//
int vDisplayController_002::Reflection_Figure_Play_001 () {
	vTriangle tri;
	ReturnableParam result;

	printf("int vDisplayController_002::Reflection_Figure_Play_001 (vTriangle *tri, ReturnableParam *result) starts.\r\n");

	this->Reflection_Figure_Check_Triangle ( &tri, &result);

	printf("int vDisplayController_002::Reflection_Figure_Play_001 (vTriangle *tri, ReturnableParam *result) ends.\r\n");

	return 0;
}


int vDisplayController_002::Draw_Line_001 () {
	printf("int vDisplayController_002::Draw_Line_001 () starts.\r\n");

	this->canvas->SetPixelCanvas ( 100, 50, 4, 4 );
	this->canvas->set_color_001 ();

//	this->canvas->step_cursol_test_001();
//	exit(-1);
	this->canvas->draw_line_001( 1, 1, 30, 28, 0, 255 );
	this->canvas->draw_line_001( 30, 2, 1, 28, 1, 255 );
	this->canvas->draw_line_001( 5, 1, 35, 35, 2, 255 );

	printf("int vDisplayController_002::Draw_Line_001 () ends.\r\n");
	return 0;
}

//---
int vDisplayController_002::create_candidate_corss_step ( int x, int y, ReturnableParam *result ) {
	unsigned char rgbt[4];
	int xdef[] = { 1, -1, 0, 0 };
	int ydef[] = { 0, 0, 1, -1 };
	int i, a;
	int count = 0;
	vPoint** point_001 = nullptr;

	printf("int vDisplayController_002::create_candidate_corss_step ( int x, int y, ReturnableParam *result ) starts.\r\n");

	point_001 = (vPoint**) malloc (sizeof( vPoint* ) * 4 );
	for ( i=0; i<4; i++ ) {
		point_001[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
	}

	for ( i=0; i<4; i++ ) {
		a = this->canvas->get_pixel_buffer( x + xdef[i], y + ydef[i],  &rgbt[0] );
		printf("i %d rgbt[0] %d  (%0.0f, %0.0f) \r\n", i, rgbt[0], (float)(x + xdef[i]), (float)(y + ydef[i]) );
		if ( rgbt[0] == 0 ) {
			point_001[count]->setPoint( (float)(x + xdef[i]), (float)(y + ydef[i]), 0.0f);
			printf(" (%0.0f, %0.0f) \r\n", point_001[i]->x, point_001[i]->y );
			count++;
		}
	}

	result->points = point_001;
	result->point_num = count;

	printf("int vDisplayController_002::create_candidate_corss_step ( int x, int y, ReturnableParam *result ) |%p|%d| ends.\r\n", result->points, result->point_num);
	return 0;
}

//
int vDisplayController_002::spread_from_middlepoint (vTriangle* tri) {
	ReturnableParam *result, *m_result, *me_result;
	vPoint p1, p2, p3;
	double mx, my;
	int i, j, a, flg_end, count, b_count;
	vCalculation calc;
	unsigned char rgbt[4];

	printf("int vDisplayController_002::spread_from_middlepoint (vTriangle* tri) starts.\r\n");

	printf("001 j %d |%p| |%p| |%p|\r\n", j, m_result, me_result, result);
//	m_result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) );
//	me_result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) );
//	result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) );
	m_result = (ReturnableParam*) new ReturnableParam ();
	me_result = (ReturnableParam*) new ReturnableParam ();
	result = (ReturnableParam*) new ReturnableParam ();
	printf("001 j %d |%p| |%p| |%p|\r\n", j, m_result, me_result, result);
	printf("m  poitns|%p| points_num|%d|\r\n", m_result->points, m_result->point_num);
	printf("me poitns|%p| points_num|%d|\r\n", me_result->points, me_result->point_num);
//	exit(-1);

	calc.add ( tri->p1, tri->p2, &p1);
	calc.add ( tri->p3, p1, &p2);
	a = calc.scalize ( p2, 1.0f/3.0f, &p3);

	printf("Base %d, %d\r\n", (int)p3.x, (int)p3.y );

	b_count = 0;
	count = 0;
	a = create_candidate_corss_step( (int)p3.x, (int)p3.y, result );
	count += result->point_num;
	for ( i=0; 1; i++ ) {
		for ( j=b_count; j<result->point_num; j++ ) {
			a = spread_seed( (int)result->points[j]->x, (int)result->points[j]->y) ;
		}
		b_count = count;

		for ( j=0; j<result->point_num; j++ ) {
			a = create_candidate_corss_step( result->points[j]->x, result->points[j]->y, m_result );
			count += m_result->point_num;
			printf("001 j %d |%p| |%p| |%p|\r\n", j, m_result, me_result, result);
			printf("m  poitns|%p| points_num|%d|\r\n", m_result->points, m_result->point_num);
			printf("me poitns|%p| points_num|%d|\r\n", me_result->points, me_result->point_num);
//			exit(-1);
			a = merge_returnable_param_001 ( m_result, me_result );
			printf("m  poitns|%p| points_num|%d|\r\n", m_result->points, m_result->point_num);
			printf("me poitns|%p| points_num|%d|\r\n", me_result->points, me_result->point_num);
//			exit(-1);
			printf("001 j %d |%p| |%p| |%p|\r\n", j, m_result, me_result, result);
		}
		printf("002 i %d |%p| |%p| |%p|\r\n", i, m_result, me_result, result);
//		exit(-1);
		a = merge_returnable_param_001 ( me_result, result );
		printf("result points|%p| points_num|%d|\r\n", result->points, result->point_num);
		printf("002 i %d |%p| |%p| |%p|\r\n", i, m_result, me_result, result);
		if ( this->param_print == 1 )  {
			printf("Base %d, %d Next to:\r\n", (int)p3.x, (int)p3.y );
			for ( j=0; j<result->point_num; j++) {
				printf("|%p|(%f,%f) rgbt ", result->points[j], result->points[j]->x,  result->points[j]->y);
				this->canvas->get_pixel_buffer( result->points[j]->x, result->points[j]->y,  &rgbt[0] );
				printf("%d %d %d %d \r\n", rgbt[0], rgbt[1], rgbt[2], rgbt[3] );
			}
			printf("001 this->debug=%d\r\n", this->debug);
			exit(-1);
			if ( this->debug == 2 ) {
				this->canvas->CheckMSG_001 ("001: print messages."); 
				exit(-1);
				return 0;
			}
		}
		printf("002 this->debug=%d\r\n", this->debug);
		exit(-1);
		if ( this->debug == 2 ) {
			this->canvas->CheckMSG_001 ("002: print messages."); 
			exit(-1);
			return 0;
		}
	}

	printf("int vDisplayController_002::spread_from_middlepoint (vTriangle* tri) ends.\r\n");
	return 0;
}

//
int vDisplayController_002::spread_from_middlepoint_001 (vTriangle* tri) {
	ReturnableParam *result, *m_result, *me_result;
	vPoint p1, p2, p3;
	double mx, my;
	int i, j, a, flg_end, count, b_count;
	vCalculation calc;

	printf("int vDisplayController_002::spread_from_middlepoint_001 (vTriangle* tri) starts.\r\n");

	printf("001 j %d |%p| |%p| |%p|\r\n", j, m_result, me_result, result);
	m_result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) );
	me_result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) );
	result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) );
	printf("001 j %d |%p| |%p| |%p|\r\n", j, m_result, me_result, result);

	calc.add ( tri->p1, tri->p2, &p1);
	calc.add ( tri->p3, p1, &p2);
	a = calc.scalize ( p2, 1.0f/3.0f, &p3);

	printf("Base %d, %d\r\n", (int)p3.x, (int)p3.y );

	 b_count = 0;
	count = 0;
	a = create_candidate_corss_step( (int)p3.x, (int)p3.y, result );
	count += result->point_num;
	for ( i=0; 1; i++ ) {
		for ( j=b_count; j<result->point_num; j++ ) {
			printf("point %d, %d \r\n", (int)result->points[j]->x, (int)result->points[j]->y);
			a = spread_seed( (int)result->points[j]->x, (int)result->points[j]->y) ;
		}
		b_count = count;
		exit(-1);
	}
	
	printf("int vDisplayController_002::spread_from_middlepoint_001 (vTriangle* tri) ends.\r\n");
	return 0;
}

//
int vDisplayController_002::spread_from_middlepoint_002 (vTriangle* tri) {
	ReturnableParam *result, *m_result, *me_result;
	vPoint p1, p2, p3;
	double mx, my;
	int i, j, a, flg_end, count, b_count;
	vCalculation calc;

	printf("int vDisplayController_002::spread_from_middlepoint_002 (vTriangle* tri) starts.\r\n");

	printf("001 j %d |%p| |%p| |%p|\r\n", j, m_result, me_result, result);
	m_result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) );
	me_result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) );
	result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) );
	printf("001 j %d |%p| |%p| |%p|\r\n", j, m_result, me_result, result);

	calc.add ( tri->p1, tri->p2, &p1);
	calc.add ( tri->p3, p1, &p2);
	a = calc.scalize ( p2, 1.0f/3.0f, &p3);

	printf("Base %d, %d\r\n", (int)p3.x, (int)p3.y );

	 b_count = 0;
	count = 0;
	a = create_candidate_corss_step( (int)p3.x, (int)p3.y, result );
	count += result->point_num;

	for ( i = 0; i<result->point_num; i++ ) {
//		printf("%d/%d |%p| (%0.0f, %0.0f)\r\n", i, result->point_num, &(result->points[i]), result->points[i].x, result->points[i].y );
		printf("%d/%d |%p| (%0.0f, %0.0f)\r\n", i, result->point_num, result->points[i], result->points[i]->x, result->points[i]->y );
	}

	printf("int vDisplayController_002::spread_from_middlepoint_002 (vTriangle* tri) ends.\r\n");
	return 0;
}


//
int vDisplayController_002::merge_returnable_param  ( ReturnableParam result1, ReturnableParam *result2 ) {
	int i, a;

	printf("int vDisplayController_002::merge_returnable_param  ( ReturnableParam result1, ReturnableParam *result2 ) starts.\r\n");

	printf("result1|%p| result2|%p| result2->points|%p|\r\n", &result1, result2, result2->points);

	if ( result2 == nullptr || result2->point_num == 0 ) {
		printf("result2 is nullptr\r\n");
		result2->points = (vPoint**)malloc (sizeof(vPoint*) * result1.point_num );
		for ( i = 0; i<result1.point_num; i++ ) {
			result2->points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
			result2->points[i]->setPoint(result1.points[i]->x, result1.points[i]->y, 0.0f );
		}
		result2->point_num = result1.point_num;
		printf("int vDisplayController_002::merge_returnable_param  ( ReturnableParam result1, ReturnableParam *result2 ) |%p| result2->point_num=%d return 1.\r\n", result2, result2->point_num);
		return 1;
	}

	a = result1.point_num + result2->point_num;
	printf("%d + %d = %d\r\n", result1.point_num, result2->point_num, a );

	printf("result2->points|%p|\r\n", result2->points);
//	result2->points = (vPoint**) realloc ( (vPoint**)result2->points, sizeof(vPoint*) * a );
	result2->points = (vPoint**) realloc ( (vPoint**)result2->points, sizeof(vPoint*) * a );
	printf("result2->points|%p|\r\n", result2->points);

	if (result2->points==nullptr) {
		printf("result2->points exits.\r\n");
		exit(-1);
	}

	for ( i = 0; i<result1.point_num; i++ ) {
		printf("i %d/%d to %d\r\n", i, result1.point_num, result2->point_num);
		result2->points[i] = result1.points[i];
	}

	for ( i=result1.point_num; i < result2->point_num; i++ ) {
		printf("i %d/%d\r\n", i, result2->point_num);
		result2->points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result2->points[i]->setPoint( result1.points[i]->x, result1.points[i]->y, 0.0f );
	}

	result2->point_num = a;

	printf("int vDisplayController_002::merge_returnable_param  ( ReturnableParam result1 p|%p|, ReturnableParam *result2|%p| ) ends.\r\n", &result1, result2);

	return 0;
}

//
int vDisplayController_002::merge_returnable_param_001  ( ReturnableParam *result1, ReturnableParam *result2 ) {
	int i, a;

	printf("int vDisplayController_002::merge_returnable_param_001  ( ReturnableParam *result1, ReturnableParam *result2 ) starts.\r\n");

	printf("result1|%p| result2|%p| result2->points|%p|\r\n", result1, result2, result2->points);

	if ( result2 == nullptr || result2->point_num == 0 ) {
		printf("result2 is nullptr\r\n");
		result2->points = (vPoint**)malloc (sizeof(vPoint*) * result1->point_num );
		for ( i = 0; i<result1->point_num; i++ ) {
			result2->points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
			result2->points[i]->setPoint(result1->points[i]->x, result1->points[i]->y, 0.0f );
		}
		result2->point_num = result1->point_num;
		printf("int vDisplayController_002::merge_returnable_param_001  ( ReturnableParam result1, ReturnableParam *result2 ) |%p| result2->point_num=%d return 1.\r\n", result2, result2->point_num);
		return 1;
	}

	a = result1->point_num + result2->point_num;
	printf("%d + %d = %d\r\n", result1->point_num, result2->point_num, a );

	printf("result2->points|%p|\r\n", result2->points);
	result2->points = (vPoint**) realloc ( (vPoint**)result2->points, sizeof(vPoint*) * a );
	printf("result2->points|%p|\r\n", result2->points);

	if (result2->points==nullptr) {
		printf("result2->points exits.\r\n");
		exit(-1);
	}

	for ( i=result2->point_num; i < a; i++ ) {
		printf("i %d/%d |%p|\r\n", i, a,  result2->points[i] );
		result2->points[i] = result1->points[i - result2->point_num ];
		printf("Set i %d/%d |%p|\r\n", i, a,  result2->points[i] );
	}

	result2->point_num = a;

	printf("points|%p| points_num|%d|\r\n", result2->points, result2->point_num);
	printf("int vDisplayController_002::merge_returnable_param_001  ( ReturnableParam *result1 p|%p|, ReturnableParam *result2|%p| ) ends.\r\n", result1, result2);

	return 0;
}


//
int vDisplayController_002::spread_seed ( int x, int y ) {
	unsigned char rgbt[4];

	printf("int vDisplayController_002::spread_seed ( int x, int y ) starts.\r\n");

	this->canvas->get_pixel_buffer( x, y,  &rgbt[0] );
	if ( rgbt[0] > 0 ) return -1;

	rgbt[0] = 255;
	this->canvas->put_pixel_buffer(  x, y, rgbt );

	printf("int vDisplayController_002::spread_seed ( int x, int y ) ends.\r\n");
	return 1;
}


int vDisplayController_002::Create_Paint_Triangle () {

	printf("int vDisplayController_002::Create_Paint_Triangle () starts.\r\n");

	printf( "this->canvas->Init_Pixel_Buffer_001 = %d\r\n", this->canvas->Init_Pixel_Buffer_001 );
	if ( this->canvas->Init_Pixel_Buffer_001 == 0 ) {
		this->canvas->Initialize_Buffer();
		this->canvas->Init_Pixel_Buffer_001 = 1;
//		exit(-1);
	}

	vTriangle* tri = new vTriangle ();
	tri->p1.setPoint (  1.0f,  1.0f, 0.0f );
	tri->p2.setPoint ( 30.0f,  5.0f, 0.0f );
	tri->p3.setPoint ( 15.0f, 30.0f, 0.0f );

	this->spread_from_middlepoint ( tri );
// o	this->spread_from_middlepoint_001 ( tri );
// o	this->spread_from_middlepoint_002 ( tri );

	this->canvas->Draw_Pixel_Buffer_001 = 1;
	printf("int vDisplayController_002::Create_Paint_Triangle () ends.\r\n");
//	exit(-1);
	return 0;
}

//---
// 011
int vDisplayController_002:: merge_test () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test () starts.\r\n");

	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);

	printf("int vDisplayController_002:: merge_test () ends.\r\n");
	return 0;
}


int vDisplayController_002::PrintBones ( ) {
	float x, y;
	vCalculation calc;
	printf("int vDisplayController_002::PrintBones () starts.\r\n");

	printf("bones_001 bones_max_index %d: \r\n", this->bones_max_index );
	for ( int i =0; i<this->bones_max_index; i++ ) {
		this->bones_001[i].print();
	}

	printf("int vDisplayController_002::PrintBones () ends.\r\n");
	exit(-1);
	return 0;
}

int vDisplayController_002::PrintBones_001 ( ) {
	float x, y;
	vCalculation calc;
	printf("int vDisplayController_002::PrintBones_001 () starts.\r\n");

	printf("bones_001 bones_max_index %d: \r\n", this->bones_max_index );
	for ( int i =0; i<this->bones_max_index; i++ ) {
		this->bones_001[i].print();
	}

	printf("int vDisplayController_002::PrintBones_001 () ends.\r\n");
	return 0;
}

// 011
int vDisplayController_002:: merge_test_000 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_000 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_000 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_001 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_001 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_001 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_002 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_002 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_002 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_003 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_003 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_003 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_004 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_004 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_004 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_005 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_005 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_005 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_006 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_006 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_006 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_007 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_007 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_007 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_008 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_008 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_008 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_009 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_009 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_009 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_010 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_010 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_010 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_011 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_011 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_011 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_012 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_012 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_012 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_013 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_013 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_013 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_014 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_014 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_014 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_015 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_015 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_015 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_016 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_016 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_016 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_017 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_017 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_017 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_018 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_018 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_018 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_019 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_019 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_019 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_020 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_020 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_020 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_021 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_021 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_021 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_022 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_022 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_022 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_023 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_023 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_023 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_024 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_024 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_024 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_025 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_025 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_025 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_026 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_026 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_026 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_027 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_027 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_027 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_028 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_028 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_028 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_029 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_029 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_029 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_030 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_030 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_030 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_031 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_031 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_031 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_032 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_032 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_032 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_033 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_033 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_033 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_034 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_034 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_034 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_035 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_035 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_035 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_036 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_036 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_036 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_037 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_037 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_037 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_038 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_038 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_038 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_039 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_039 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_039 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_040 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_040 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_040 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_041 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_041 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_041 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_042 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_042 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_042 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_043 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_043 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_043 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_044 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_044 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_044 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_045 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_045 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_045 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_046 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_046 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_046 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_047 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_047 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_047 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_048 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_048 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_048 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_049 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_049 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_049 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_050 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_050 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_050 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_051 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_051 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_051 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_052 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_052 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_052 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_053 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_053 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_053 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_054 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_054 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_054 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_055 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_055 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_055 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_056 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_056 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_056 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_057 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_057 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_057 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_058 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_058 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_058 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_059 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_059 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_059 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_060 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_060 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_060 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_061 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_061 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_061 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_062 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_062 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_062 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_063 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_063 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_063 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_064 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_064 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_064 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_065 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_065 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_065 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_066 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_066 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_066 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_067 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_067 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_067 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_068 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_068 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_068 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_069 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_069 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_069 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_070 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_070 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_070 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_071 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_071 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_071 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_072 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_072 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_072 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_073 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_073 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_073 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_074 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_074 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_074 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_075 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_075 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_075 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_076 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_076 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_076 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_077 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_077 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_077 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_078 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_078 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_078 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_079 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_079 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_079 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_080 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_080 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_080 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_081 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_081 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_081 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_082 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_082 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_082 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_083 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_083 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_083 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_084 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_084 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_084 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_085 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_085 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_085 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_086 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_086 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_086 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_087 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_087 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_087 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_088 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_088 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_088 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_089 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_089 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_089 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_090 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_090 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_090 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_091 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_091 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_091 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_092 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_092 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_092 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_093 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_093 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_093 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_094 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_094 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_094 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_095 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_095 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_095 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_096 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_096 () starts.\r\n");

	
	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d \r\n", i );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param ( me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);



	printf("int vDisplayController_002:: merge_test_096 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_097 () {
	ReturnableParam *result, *me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_097 () starts.\r\n");

	result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) * 1 );
	printf("result |%p| \r\n", result);
	me_result = (ReturnableParam*) malloc ( sizeof(ReturnableParam) * 1 );
	printf("result |%p| \r\n", me_result);

	result->point_num = 4;
	result->points = (vPoint**)malloc (sizeof(vPoint*) * result->point_num );
	printf("i %d |%p|\r\n", i, (vPoint**)result->points );
	for ( i = 0; i<result->point_num; i++ ) {
		printf("i %d \r\n", i );
		result->points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result->points[i]->setPoint(result->points[i]->x, result->points[i]->y, 0.0f );
	}

	printf("next one:\r\n");
	me_result->point_num = 4;
	me_result->points = (vPoint**)malloc (sizeof(vPoint*) * me_result->point_num );
	printf("i %d |%p|\r\n", i, (vPoint**)me_result->points );
	for ( i = 0; i<me_result->point_num; i++ ) {
		printf("i %d \r\n", i );
		me_result->points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result->points[i]->setPoint(me_result->points[i]->x, me_result->points[i]->y, 0.0f );
	}

	a = merge_returnable_param_001 ( me_result, result );
	printf("merge |%p| and |%p| to |%p|\r\n", me_result, result, result);
	a = merge_returnable_param_001 ( me_result, result );
	printf("merge |%p| and |%p| to |%p|\r\n", me_result, result, result);

	printf("int vDisplayController_002:: merge_test_097 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_098 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_098 () starts.\r\n");

	printf("int vDisplayController_002:: merge_test_098 () ends.\r\n");
	return 0;
}


// 011
int vDisplayController_002:: merge_test_099 () {
	ReturnableParam result, me_result;
	int i, a;
	printf("int vDisplayController_002:: merge_test_099 () starts.\r\n");

	result.point_num = 4;
	result.points = (vPoint**)malloc (sizeof(vPoint*) * result.point_num );
	printf("i %d |%p|\r\n", i, (vPoint**)result.points );
	for ( i = 0; i<result.point_num; i++ ) {
		printf("i %d \r\n", i );
		result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		result.points[i]->setPoint(result.points[i]->x, result.points[i]->y, 0.0f );
	}

	printf("next one:\r\n");
	me_result.point_num = 4;
	me_result.points = (vPoint**)malloc (sizeof(vPoint*) * me_result.point_num );
	printf("i %d |%p|\r\n", i, (vPoint**)me_result.points );
	for ( i = 0; i<me_result.point_num; i++ ) {
		printf("i %d \r\n", i );
		me_result.points[i] = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f );
		me_result.points[i]->setPoint(me_result.points[i]->x, me_result.points[i]->y, 0.0f );
	}

	a = merge_returnable_param_001 ( &me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);
	a = merge_returnable_param_001 ( &me_result, &result );
	printf("merge |%p| and |%p| to |%p|\r\n", &me_result, &result, &result);

	printf("int vDisplayController_002:: merge_test_099 () ends.\r\n");
	return 0;
}


