#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <windows.h> // ADD: 20200104

#include "array_counter.h"	// ADD: 20200104
#include "sender.h"			// ADD: 20200104
#include "Print.h"			// ADD: 20200104

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"
#include "vPointStructure.h"
#include "vPointLinear.h"

static vLine* dummy_line = nullptr;

// Qualified : 20200105
//
//
//
//
void vPointLinear::FirstCreation_OnRails( ) {
	log_msg_003("void vPointLinear::FirstCreation_OnRails( )\r\n");
	this->numPS = 5;
	aPS = (vPointStructure**)malloc( sizeof(vPointStructure*) * this->numPS );

	for ( int i=0; i<this->numPS; i++) {
		aPS[i] = (vPointStructure*) new vPointStructure();
		aPS[i]->Set_Anchor( (vPoint*) memorizevPoint( 10.0f, 0.0f, 10.f) );
	}
	this->PrintAnchors();

	vPoint* Straight_Blur = (vPoint*) memorizevPoint( 40.0f, 0.0f, 0.f);
	vPoint* Up_Blur = (vPoint*) memorizevPoint( 5.0f, 20.0f, -5.0f);

	vPoint* Straight = (vPoint*) memorizevPoint( 30.0f, 5.0f, 30.0f);
	vPoint* Up = (vPoint*) memorizevPoint( 0.0f, 20.0f, 0.0f);
	vPoint* Current = (vPoint*) memorizevPoint( -300.0f, 0.0f, -300.0f);

	srand(time(NULL));   // Initialization, should only be called once.
	int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.

	float rand = ((double)r) / RAND_MAX;
	rand = rand * 15.0f;

	vCalculation* calc = new vCalculation();

	// 20200104 START
	log_msg_003("aPS[0]->Anchor %p Current %p\r\n", aPS[0]->Anchor, Current);
	aPS[0]->Anchor->setPoint( Current->x, Current->y, Current->z );
	//free(Current);
	log_msg_003("aPS[0]->Anchor %p Current %p\r\n", aPS[0]->Anchor, Current);
	for ( int i=1; i<this->numPS; i++) {
		Straight = calc->add( Straight, Straight_Blur );
		log_msg_003("Current %p, Straight %p\r\n", i, Current, Straight );
		Current = calc->add( Current, Straight );
		log_msg_003("aPS[%3d]->Anchor %p Current %p\r\n", i, aPS[i]->Anchor, Current);
		Current->x += rand;
		Current->print();
		log_msg_003("aPS[%3d]->Anchor %p Current %p\r\n", i, aPS[i]->Anchor, Current);
		aPS[i]->Anchor->setPoint( Current->x, Current->y, Current->z );
		aPS[i]->Anchor->print();
		//free(Current);
	}
	//exit(-1);
	// 20200104 END

	// TEST CALL: 20191219
	// this->CurveRevisement( aPS[1]->C2, aPS[1]->Anchor, aPS[1]->C1, aPS[1]->Anchor);
	this->FirstRevisement( );
	// exit(-1);
	log_msg_003("void vPointLinear::FirstCreation_OnRails( ) ends.\r\n");
}


// Created: 20191229
//
//
//
//
vPointLinear* vPointLinear::copy_point_linear ( vPointLinear* vPL ) {
	if ( vPL == nullptr ) return nullptr;

	log_msg_003("vPointLinear* vPointLinear::copy_point_linear ( vPointLinear* vPL ) starts.\r\n");
	vPL->numPS = this->numPS;

	for( int i=0; i<vPL->numPS; i++ ) {
		// Base Copy
		vPL->aPS[i]->C1->x = this->aPS[i]->C1->x;
		vPL->aPS[i]->C1->y = this->aPS[i]->C1->y;
		vPL->aPS[i]->C1->z = this->aPS[i]->C1->z;
		vPL->aPS[i]->C2->x = this->aPS[i]->C2->x;
		vPL->aPS[i]->C2->y = this->aPS[i]->C2->y;
		vPL->aPS[i]->C2->z = this->aPS[i]->C2->z;
		vPL->aPS[i]->Anchor->x = this->aPS[i]->Anchor->x;
		vPL->aPS[i]->Anchor->y = this->aPS[i]->Anchor->y;
		vPL->aPS[i]->Anchor->z = this->aPS[i]->Anchor->z;
	}

	log_msg_003("vPointLinear* vPointLinear::copy_point_linear ( vPointLinear* vPL ) vPL %p ends.\r\n", vPL);
	return vPL;
}

// Created: 20191219
//
void vPointLinear::put_line ( vLine* l_line ) {
	printf("vPointLinear::put_line STARTS.\r\n");
	printf("put_line: this->print_lines_num=%d\r\n", this->print_lines_num);

	if ( this->print_lines_num == 0 ) {
		this->print_lines = (vLine**) malloc( sizeof(vLine*) * print_lines_num_max );
	} else if ( this->print_lines_num >= this->print_lines_num_max ) {
		print_lines_num_max *= 2;
		this->print_lines = (vLine**) realloc( this->print_lines, sizeof(vLine*) * print_lines_num_max );
	}

	this->print_lines [ print_lines_num ] = l_line;

	print_lines_num++;

	printf("put_line: this->print_lines_num=%d\r\n", this->print_lines_num);
	printf("PointLinear::put_line ENDS.\r\n");
	// exit(-1); //20191219
}

// Before calling this: We finished to memorize Controls at 20191219.
//
//
//
//
vLine** vPointLinear::generateControls() {

	// 20191219: 
	printf("vPointLinear::generateControls(): STARTS\r\n");
	printf("put_line: this->print_lines_num=%d this->numPS=%d\r\n", this->print_lines_num, this->numPS);
	for( int i=0; i<this->numPS; i++ ) {
		printf("i: %d \r\n", i );
		dummy_line = new vLine();
		dummy_line->setLine( (vPoint*) this->aPS[i]->C1, (vPoint*) this->aPS[i]->C2 );
		dummy_line->c1 = (char*)"c1";
		dummy_line->c2 = (char*)"c2";
		dummy_line->print();
		this->put_line ( dummy_line );
		// l_lines[i]->p1->print();
		// l_lines[i]->p2->print();
	}

	printf("this->print_lines_num = %d \r\n",this->print_lines_num); 
	printf("vPointLinear::generateControls(): ENDS\r\n");
	//exit(-1); // 20191219
	return this->print_lines;
}

// Temporarily Qualified: 20191219
//
//
void vPointLinear::CurveRevisement () {
	printf("void vPointLinear::CurveRevisement () STARTS\r\n");
//	this->CurveRevisement( this->aPS[0]->Anchor, this->aPS[0]->C2, this->aPS[1]->C1, this->aPS[1]->Anchor);
	for( int i=0; i<this->numPS-1; i++ ) {
		this->CurveRevisement( this->aPS[i]->Anchor, this->aPS[i]->C2, this->aPS[i + 1]->C1, this->aPS[i + 1]->Anchor);
	}

	for( int i=0; i<this->curve_points_num - 1; i++ ) {
		dummy_line = new vLine();
		dummy_line->setLine( curve_points[ i ], curve_points[ i + 1 ] );
//		dummy_line->c1 = (char*)"r1";
//		dummy_line->c2 = (char*)"r2";
		this->put_line( dummy_line );
	}

	printf("this->curve_points_num = %d \r\n",this->curve_points_num ); 
	printf("this->print_lines_num = %d \r\n",this->print_lines_num ); 
	printf("void vPointLinear::CurveRevisement () ENDS.\r\n");
	//exit(-1); //20191219
}

// p1: Anchor
// p2: setting controls
//
// p3: setting controls
// p4: Anchor(next)
//
int vPointLinear::CurveRevisement ( vPoint* p1, vPoint* p2, vPoint* p3, vPoint* p4) {

	printf("int vPointLinear::CurveRevisement:\r\n");
	vCurveCalculation* calc_curve = new vCurveCalculation ();
	vCalculation* calc = new vCalculation();

	if ( curve_points == nullptr ) {
		curve_points = (vPoint**) malloc( sizeof(vPoint*) * 32 );
		curve_points_num = 0;
	} else if ( curve_points_num >= curve_points_max ) {
		//realloc
		curve_points_max *= 2;
		curve_points = (vPoint**) realloc( curve_points, sizeof(vPoint*) * curve_points_max );
	}

	//p1 = memorizevPoint (  10.0f,  10.0f,  10.0f);
	//p2 = memorizevPoint (  30.0f,  30.0f,  30.0f);
	//p3 = memorizevPoint ( 110.0f, 110.0f, 110.0f);
	//p4 = memorizevPoint (  80.0f,  80.0f,  80.0f);

	printf("p1 : |%p| \r\n", p1 );
	printf("p2 : |%p| \r\n", p2 );
	printf("p3 : |%p| \r\n", p3 );
	printf("p4 : |%p| \r\n", p4 );
	printf("curve_points : |%p| \r\n", curve_points );

	int devide = 5;
	for( int i=0; i<devide; i++ ) {
		float t = (float)i / (float) devide;
		printf("i=%3d/%3d \r\n", i, devide );
		vPoint* curve_p = (vPoint*) calc_curve->BattleField ( p1, p2, p3, p4, t );
		// put_points( curve_p );
		printf("curve_p : |%p| \r\n", curve_p );
		curve_p->print();

		curve_points[curve_points_num] = (vPoint*) curve_p ;
		curve_points_num++;
		if ( curve_points_num >= curve_points_max ) {
			//realloc
			curve_points_max *= 2;
			curve_points = (vPoint**) realloc( curve_points, sizeof(vPoint*) * curve_points_max );
		}
	}
	// exit(-1); //20191230

	// free(p1);
	// free(p2);
	// free(p3);
	// free(p4);

	printf("p1 : |%p| \r\n", p1 );
	printf("p2 : |%p| \r\n", p2 );
	printf("p3 : |%p| \r\n", p3 );
	printf("p4 : |%p| \r\n", p4 );

	calc->Print_Point_Memories ();

	printf("int vPointLinear::CurveRevisement: return 0:\r\n");
	return 0;
}

//
//
//
//
//
void vPointLinear::PrintAnchors( ) {

	vCalculation* calc = new vCalculation();

	for ( int i=0; i<this->numPS; i++) {
		aPS[i]->Anchor->print ();
		if ( i > 0 ) {
			printf("dsitance from %d to %d: %lf\r\n", i -1, i, calc->length(  calc->subtract( (vPoint*)aPS[i -1]->Anchor, (vPoint*)aPS[i]->Anchor )) );
		}
	}

}

//
//
//
//
//
void vPointLinear::PrintControls( ) {

	printf("vPointLinear::PrintControls: STARTS.\r\n");
	vCalculation* calc = new vCalculation();

	for ( int i=0; i<this->numPS; i++) {
		printf("C1 ");
		aPS[i]->C1->print ();
		printf("C2 ");
		aPS[i]->C2->print ();
		double distance = calc->length( calc->subtract( (vPoint*)aPS[i]->C2, (vPoint*)aPS[i]->C1 ) );
		printf("distance %lf\r\n", distance );
	}
	printf("vPointLinear::PrintControls: END.\r\n");

}

//
//
//
//
//
//
void vPointLinear::FirstCreation( ) {
	aPS = (vPointStructure**)malloc( sizeof(vPointStructure*) * 6 );
	this->numPS = 6;
	for ( int i=0; i<this->numPS; i++)
		aPS[i] = (vPointStructure*) new vPointStructure();

	// vPoint* p = (vPoint*)new vPoint( 1.0f, 1.0f, 1.0f );
	// aPS[0]->Anchor = p;
	// aPS[0]->Set_Anchor( p );

	aPS[0]->Anchor = (vPoint*)new vPoint( -110.0f, 0.0f, 100.0f );
	aPS[1]->Anchor = (vPoint*)new vPoint( 20.0f, 50.0f, 200.0f );
	aPS[2]->Anchor = (vPoint*)new vPoint( 30.0f, 100.0f, 400.0f );
	aPS[3]->Anchor = (vPoint*)new vPoint( 40.0f, 150.0f, 600.0f );
	aPS[4]->Anchor = (vPoint*)new vPoint( 50.0, 120.0f, 800.0f );
	aPS[5]->Anchor = (vPoint*)new vPoint( 60.0f, 100.0f, 1000.0f );

	// TEST CALL: 20191219
	// this->CurveRevisement( aPS[1]->C2, aPS[1]->Anchor, aPS[1]->C1, aPS[1]->Anchor);
	this->FirstRevisement( );
}

//
// Modified : 20191202
// ReCreation of Controls : 20191202
// Modified : 20191219
//
//
void vPointLinear::FirstRevisement( ) {

	// can not revise.
	if ( this->numPS <=2 ) return;

	vCalculation* calc = nullptr;
	calc = new vCalculation();

	float length = 40.0f;

	for ( int i=0; i<this->numPS; i++ ) {
		aPS[i]->C1 = (vPoint*)memorizevPoint( 0.0f, 0.0f, 0.0f );
		aPS[i]->C2 = (vPoint*)memorizevPoint( 0.0f, 0.0f, 0.0f );
	}

	// Sst C2s and C1s
	for ( int i=1; i<this->numPS - 1; i++ ) {
		printf("Loop FirstRevisement: %d starts.\r\n", i);
		vPoint* aa = calc->subtract( aPS[ i ]->Anchor, aPS[ i - 1 ]->Anchor ) ;
		vPoint* ab = calc->subtract( aPS[ i + 1 ]->Anchor, aPS[ i ]->Anchor ) ;
		vPoint* ac = calc->add( aa, ab ); //too big
		printf("ac: %d: ", i );
		ac->print();
		printf("ac normal 1.0: %d: ", i );
		calc->normal( ac );
		ac->print();
		calc->scale( ac, length ); // means multiple //20191202
		printf("ac scale absolute 0.0f: %d ", i );
		ac->print();
		aPS[ i ]->C2 = calc->add( aPS[ i ]->Anchor, ac ); // 20191202 check:
		vPoint* ba = calc->subtract( aPS[ i ]->Anchor, aPS[ i ]->C2 );
		aPS[ i ]->C1 = calc->add( aPS[ i ]->Anchor, ba );

		// revisement, which means return.
		// aPS[ i ]->C2 = subtracr->add( aPS[ i ]->Anchor, ba );

		// print control points
		printf("%d C1 ", i);
		aPS[ i ]->C1->print();
		printf("%d C2 ", i);
		aPS[ i ]->C2->print();
		printf("Loop FirstRevisement: %d ends\r\n", i);

	}
	//exit( -1 ); //20191202

	// index = 0.
	aPS[ 0 ]->C2->setPoint( aPS[ 1 ]->C1->x, aPS[ 1 ]->C1->y, aPS[ 1 ]->C1->z );
	vPoint* ba = calc->subtract( aPS[ 0 ]->Anchor, aPS[ 0 ]->C2 );
	calc->normal( ba );
	calc->scale( ba, length );

	aPS[ 0 ]->C1 = calc->add( aPS[ 0 ]->Anchor, ba );
	aPS[ 0 ]->C2 = calc->subtract( aPS[ 0 ]->Anchor, ba );

	ba->print();
	aPS[ 1 ]->C1->print();
	aPS[ 1 ]->C2->print();
	aPS[ 0 ]->C1->print();
	aPS[ 0 ]->C2->print();

	printf("aPS[ 0 ]->Anchor: ");
	aPS[ 0 ]->Anchor->print();

	// index = num -1, which means last.
	aPS[ this->numPS - 1 ]->C1->setPoint ( aPS[ this->numPS - 2 ]->C2->x, aPS[ this->numPS - 2 ]->C2->y, aPS[ this->numPS - 2 ]->C2->z ); 
	vPoint* bb = calc->subtract( aPS[ this->numPS - 1 ]->Anchor, aPS[ this->numPS - 1 ]->C1 );
	calc->normal( bb );
	calc->scale( bb, length );
	aPS[ this->numPS - 1 ]->C2 = calc->add( aPS[ this->numPS - 1 ]->Anchor, bb );
	aPS[ this->numPS - 1 ]->C1 = calc->subtract( aPS[ this->numPS - 1 ]->Anchor, bb );
}

//
//
//
//
//
void vPointLinear::GetNormal ( vPoint* p1, vPoint* p2, vPoint* p3, vPoint* normal ) {

	vCalculation* calc = nullptr;
	calc = new vCalculation();

	calc->cross( p1, p2, normal );

}

//
//
//
//
//
vLine** vPointLinear::FirstCreateLines( vPointStructure** ps, int num_devide ) {


	this->FirstCreation();

}

//
//
//
//
//
vLine** vPointLinear::generateLines( vPointStructure** ps, int num_devide ) {



	return nullptr;
}


//
// Modified: 20191130
// Modified: 20191219: should be second revisement.
//
//
vLine** vPointLinear::generateControlsLines(  ) {

	// Allocation: 20190708
	if ( this->print_lines_num == 0 ) {

		this->print_lines = (vLine**) malloc( sizeof(vLine*) * ( this->numPS + 1 )  );
		for( int i=0; i<this->numPS; i++ ) {
			// x vLine* allocation_line = (vLine*) malloc ( sizeof(vLine) * 1 );
			// x vLine* allocation_line = new vLine();
			this->print_lines[i] = (vLine*) new vLine();
		}
		this->print_lines_num = this->numPS;

		printf( "Allocated: 0 \r\n" );
	} else if (  this->print_lines_num <= this->numPS ) {

		this->print_lines = (vLine**) realloc( this->print_lines, sizeof(vLine*) * this->numPS );
		for( int i=this->print_lines_num; i<this->numPS; i++ ) {
			this->print_lines[i] = new vLine();
		}
		this->print_lines_num = this->numPS;
	}

	printf("local lines:\r\n");
	for( int i=0; i<this->print_lines_num; i++ ) {
		printf("i: %d ", i );
		this->print_lines[i]->setLine( (vPoint*) this->aPS[i]->C1, (vPoint*) this->aPS[i]->C2 );
		this->print_lines[i]->c1 = (char*)"c1";
		this->print_lines[i]->c2 = (char*)"c2";
		this->print_lines[i]->print();
		// l_lines[i]->p1->print();
		// l_lines[i]->p2->print();
	}

	// Add Allocation of Anchors : 20191202
/*	int num_previous = this->print_lines_num;
	this->print_lines_num += this->numPS - 1;
	this->print_lines = (vLine**) realloc( this->print_lines, sizeof(vLine*) * ( this->numPS + 1 ) * 2 );
	for( int i=num_previous; i<this->print_lines_num; i++ ) {
		this->print_lines[ i ] = (vLine*) new vLine();
		this->print_lines[ i ]->setLine( this->aPS[ i - num_previous ]->Anchor, this->aPS[ i - num_previous + 1 ]->Anchor );
		this->print_lines[ i ]->c1 = (char*) "A";
	}
*/
	return this->print_lines;
}

void vPointLinear::calculation_array () {

	// aPS = new vPointStructure[ 10 ];
}

//
//
//
//
//
void vPointLinear::calculation () {
	vPoint	*p1, *p2, *p3, *p4;
	vCalculation* calc = nullptr;

	printf("start: void vPointLinear::calculation () \r\n");

	calc = new vCalculation();
	p1 = new vPoint ( 1.0f, 2.0f, 3.0f );
	p2 = new vPoint ( 1.5f, 2.5f, 3.5f );

	p3 = calc->scalize( p1, 5.0f );
	p4 = calc->scalize( p2, 5.0f );

	p1->print();
	p2->print();
	p3->print();
	p4->print();

	printf("end: void vPointLinear::calculation () \r\n");
	// exit(-1);
}

//
// 0<= t <= 1
//
vPoint vPointLinear::position( vPoint* c1, vPoint* c2, float t ) {

	//20190505
	double c = 3.0; // 1/length
	vPoint* start = new vPoint();
	vPoint* end = new vPoint();
	vCalculation* calc = nullptr;

//	vPoint a = calc->scale( start, t*t  );
//	vPoint b = calc->scale( end, 1 - t*t  );
//	vPoint c1 = calc->add ( a, b ) ;

	vPoint result;

	return result;
}

//
//
//
//
//
vPoint vPointLinear::additional_positionP( vPoint* c1, vPoint* c2, float t ) {

	//20190505
	double c = 3.0; // 1/length
	vPoint* start = new vPoint();
	vPoint* end = new vPoint();
	vCalculation* calc = nullptr;
	calc = new vCalculation();

	vPoint a = calc->scale( *start, t*t  );
//	vPoint b = calc->scale( end, 1.0 - t*t  );
//	vPoint c1 = calc->add ( a, b );

	vPoint result;

	return result;
}

//
//
//
//
//
vPoint vPointLinear::additional_position (vPointStructure* ps1, vPointStructure* ps2, float t ) {

	vPoint p;

	return p;
}
