/* timestamp example */
#include <stdio.h>      /* printf */
#include <time.h>       /* time_t, time (for timestamp in second) */
#include <sys/timeb.h>  /* ftime, timeb (for timestamp in millisecond) */
#include <sys/time.h>   /* gettimeofday, timeval (for timestamp in microsecond) */

#include "array_counter.h"

char* get_datetime_info () ;
char* takeout_line_end ( char* a );

char* get_datetime_info () {

	time_t rtime;
	char * chrtime;
	time_t timestamp_sec; /* timestamp in second */

	rtime = time(&timestamp_sec);  /* get current time; same as: timestamp_sec = time(NULL)  */
	chrtime = ctime( &rtime );
	// printf( "chrtime=%s" , chrtime );

	chrtime = takeout_line_end ( chrtime );

	return chrtime;
}

char* takeout_line_end ( char* a ) {
	int index = 0;
	int keep_index = 0;
	char* b;
	char	c;
	char e[2];
	// if ( a == NULL ) return a;
	b = a;
	e[0] = ' ';

/*
	for ( ; index < 100; ) {

		c = *b;
		b++;
		index++;
		e[0] = c;
		printf ( "count index=%d c=%d e=%s \r\n", index, c, e );

		e[0] = e[1];
		e[1] = c;

		if ( c == '\0' ) break;
		if ( m_compare ( "\r\n", e ) == 1 ) break;
		if ( c == '\n' ) break;
	}
*/

	index = 0;
	for ( ;; ) {

		c = *a;
		if ( index > 100 ) break;

		// printf( "a: %s index %d\r\n", e , index );
		if ( c == '\0' ) {

			while ( index > 0) {
				index--;
				a--;

				c = *a;
				e[0] = e[1];
				e[1] = c;

				// printf( "e: %s : index %d : a: %s\r\n", e , index, a );

//				if ( m_compare ( e, "\r\n" ) == 1 ) {
				if ( m_compare ( e, "\n" ) == 1 ) {
					keep_index = index;
					*a = '\0';
					break;
				}

			}

			break;
		}
		a++;
		index++;
	}

	// printf( "buffer_a: %s keep_index %d \r\n", b, keep_index );

	return b;
}

