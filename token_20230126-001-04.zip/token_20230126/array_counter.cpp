#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include <windows.h>

#include "Print.h"
#include "array_counter.h"

static char* dummy_allocation_001 = NULL;
char** dummy_ary = nullptr;
int dummy_ary_index = 0;
int dummy_ary_index_max = 0;
char** replace_dummy_ary = nullptr;


char* char_line_end = (char*)"\r\n";
//char* char_line_end_001 = (char*) "\r\n";

int array_count( char *ary );
char* concat( char *head, char *tail );
char* set_array(char *arry, int n, char c);
void print_string( char *head );
int m_compare ( char* tkn, char* m );

char* m_print_buffer( char* buffer);

char* front_trim( char* c_str ) ;
char* back_trim( char* c_str ) ;
char* m_trim( char* c_str ) ;
int m_start_with ( char *head, char *tail ) ;
int m_contains ( char* c_str, char* c_ref ) ;

char* m_substring ( char* string, int start, int length );



//int main ( int argc, char *argv[] ) {
//
//	int ac = array_count((char *)"abcdefg");
//
//	err_msg_006("count=%d\n", ac );
//
//	return 0;
//}

void print_memories ();
void print_memories_002 ();
char** put_memories ( char* str );
char** put_memories_002 ( char* str );

void slide_to_back ( char *msg, int i, int count ) ;
void place_char ( char *p_char, char c ) ;

char* m_replace ( char* char_string, char* from_string, char* to_string ) ;
void aFree ( char* str ) ;
void aFree_001 ( char* str ) ;
int sub_aFree ( char* str ) ;
int sub_aFree_001 ( char* str ) ;
int sub_aFree_002 ( char* str ) ;

char* char_string ( int num_memories ) ;
char* char_string_010 ( int num_memories ) ;
char* char_string_002 ( int num_memories ) ;
char* char_string_012 ( int num_memories ) ;

void a_sleep_thread () ;
void a_sleep_thread_002 () ;

char* copyof ( char* str ) ;
char* copyof_001 ( char* str ) ;
char* copyof_002 ( char* str ) ;
char* copyof_012 ( char* str ) ;

void a_sleep_thread () {
	err_msg_001("a_sleep_thread starts.\r\n");
	Sleep(100);
	err_msg_001("a_sleep_thread ends.\r\n");
}

void a_sleep_thread_002 () {
	printf("a_sleep_thread_002 starts.\r\n");
	Sleep(10);
	printf("a_sleep_thread_002 ends.\r\n");
}

char* m_substring ( char* string, int start, int length ) {
	err_msg_001("m_substring starts. %d %d |%s|\r\n", start, length, string );

	int ac = array_count( string );
	err_msg_001("array count %d \r\n", ac );

	dummy_allocation_001 = (char*)malloc( sizeof(char) * ( length ) + 1 );
	put_memories( dummy_allocation_001 );

	for ( int i= start; i < start + length && i < ac; i++ ) {
		*(dummy_allocation_001 + i - start ) = *(string + i );
	}

	*(dummy_allocation_001 + length) = '\0';

	print_memories ();
	err_msg_001("m_substring ends.\r\n");
	return dummy_allocation_001;
}


void clean_null_array() {

	replace_dummy_ary = ( char**) malloc ( sizeof( char* ) * dummy_ary_index );

	int index = 0;
	for( int i=0; i< dummy_ary_index; i++) {
		if ( dummy_ary[i] == nullptr ) {
			replace_dummy_ary[ index ] = dummy_ary[i];
			index++;
		}
	}

	free( dummy_ary );

	dummy_ary = replace_dummy_ary;
}

//
//
//
// '\r': 13
// '\n': 10
void place_char ( char *p_char, char c ) {
	char* result_001;
	// result_001 = err_msg_001 ( "start of place_char ");
	// o result_001 = err_msg_001 ( "%d %d %d", p_char, 0, c );
	// x result_001 = err_msg_001 ( "%d %c %d", p_char, *p_char, c );
	//   4249052 3 13
	// x result_001 = err_msg_001 ( "%d %c %d", p_char, *p_char, c );
	// print_memories( p_char ) ;
	// result_001 = err_msg_001 ( "%d %d %d %d", p_char, '\n', '\r', c );
	*p_char = (char) c;
	// o *result_001 = (char) c;
	//   *p_char = *result_001;
	// result_001 = err_msg_001 ( "end of place_char ");
}

//
//
//
//
//
void slide_to_back ( char *msg, int start_i, int count ) {
	char *result_001;
	char c;
	char back_c;

	// result_001 = err_msg_001 ( "slide_to_back: start ");
	for( int i = start_i; i<count - 1; i++ ) {
		// result_001 = err_msg_001 ( "slide_to_back: loop satrt i=%d count %d ", i , count);
		// 003
		if ( i == start_i ) {
			c = *( msg + i );
		} else {
			c = back_c;
		}

		back_c = *( msg + i + 1 );
		// result_001 = err_msg_001 ( "|%3d|", c );	// 001
		place_char ( msg + i + 1, c );				// 002
		// exit(-1);
		// place_char ( msg + i + 1, c ); // slide 1 to back and ensured to place.
		// result_001 = err_msg_001 ( "slide_to_back: loop end   i=%d count %d c=%3d c=%c", i , count, c, c );
	}

	//004
	place_char ( msg + count, '\0' );
	// result_001 = err_msg_001 ( "slide_to_back: end ");
}

//
//
//
//
//
char* m_replace ( char* char_string_m,
	char* from_string, char* to_string ) {
	char c1, c2, c11;
	int index_max = 0;

	err_msg_001("char* m_replace ( char* char_string_m, char* from_string, char* to_string ) starts.\r\n");

	int count = array_count( char_string_m );
	int a_f = array_count( from_string );
	int a_t = array_count( to_string );
	int a_c = 0;
	index_max = ( count + a_t - 1 );

	char* char_string_2 = char_string_010 ( sizeof (char)* index_max );

	err_msg_001("char_string_2 was allocated p|%p| size|%d|.\r\n", char_string_2, index_max );
	/*for ( int i=0; i<3; i++) {
		if (char_string_2 != NULL ) {
			err_msg_001(" it can not allocate memories enough, so, it is sleeping in one second,\r\n");
			sleep(1);
			break;
		}
	}*/

	if (char_string_2 == NULL ) {
		err_msg_001("m_replace can not allocate memories enough, so , it exit(-1).\r\n");
		exit(-1);
	}

	c2 = 0;
	int cnt_replace = 0;
	for ( int i = 0; i<count; i++ ) {
		err_msg_001("loop starts: \r\n");
		c1 = *( char_string_m + i ) ;
		a_c = 0;
		for ( int j=0; j<a_f && j <count; j++ ) {
			c11 = *( char_string_m + i + j ) ;
			c2 = *( from_string + j ) ;
			if ( c11 != c2 ) break;
			a_c++;
		}

		err_msg_001("i|%d| c1|%d|=|%c| a_c=%d a_f=%d c2|%d||%c|\r\n", i, c1, c1, a_c, a_f, c2, c2 );
		if ( a_c == a_f && cnt_replace >= 0) {
			// match
			int to = i + a_f;
			for( int k=0; k<a_t; k++ ) {
				err_msg_001 ("replace string k=|%d|%c|\r\n", k, *( to_string + k ));
				int put_index_001 = + i + k + cnt_replace*(a_t- a_f );
				if ( index_max <= put_index_001 ) {
					index_max *= 2;
					char_string_2 = (char*) realloc ( char_string_2, sizeof(char) * index_max );
				}
				*( char_string_2 + put_index_001 ) = 
				  *( to_string + k );
			}
			i = to - 1;
			cnt_replace++;
		} else {
			int put_index_002 = i + cnt_replace*(a_t- a_f );
			if ( index_max <= put_index_002 ) {
				index_max *= 2;
				char_string_2 = (char*) realloc ( char_string_2, sizeof(char) * index_max );
			}
			*( char_string_2 + put_index_002 ) = c1;
		}
		err_msg_001("loop ends: \r\n");
	}
	*( char_string_2 + count + cnt_replace*( a_t - a_f ) ) = '\0';
	err_msg_001("char_string_m |%s| ends.\r\n", char_string_m );
	err_msg_001("m_replaced |%p||%s| ends.\r\n", char_string_2, char_string_2 );

	return char_string_2;
}

//
void aFree ( char* str ) {
	int a;
	err_msg_101("void aFree ( char* str ) |%p| starts.\r\n", str);

	for (int i=0; 1; i++ ) {
		a = sub_aFree_001 ( str );
		if ( a == -1 ) break;
	}

	err_msg_101("void aFree ( char* str ) |%p| ends.\r\n", str);
	return;
}

void aFree_001 ( char* str ) {
	int a;
	printf("void aFree_001 ( char* str ) |%p| starts.\r\n", str);

	for (int i=0; 1; i++ ) {
		a = sub_aFree ( str );
		if ( a == -1 ) break;
	}

	printf("void aFree_001 ( char* str ) |%p| ends.\r\n", str);
	return;
}

int sub_aFree_001 ( char* str ) {
	err_msg_101("sub_aFree_001 starts. as free index |%d/%d| str |%p|\r\n", dummy_ary_index, dummy_ary_index_max, str);

	free(str);
	dummy_ary_index--;
	err_msg_101("sub_aFree_001 ends. as free index |%d/%d| str |%p|\r\n", dummy_ary_index, dummy_ary_index_max, str);
}

int sub_aFree_002 ( char* str ) {
	err_msg_101("sub_aFree_002 starts. as free index |%d/%d| str |%p|\r\n", dummy_ary_index, dummy_ary_index_max, str);

	free(str);
	dummy_ary_index -= 1;
	err_msg_101("sub_aFree_002 ends. as free index |%d/%d| str |%p|\r\n", dummy_ary_index, dummy_ary_index_max, str);
}

//
int sub_aFree ( char* str ) {
	int stored_index = -1;
	err_msg_101("sub_aFree starts.\r\n");
	err_msg_101("We are going to free |%d| from array [%d]\r\n", str, dummy_ary_index );

	for ( int i=0; i<dummy_ary_index; i++) {
		err_msg_101 ("sub_aFree 01: i %d/ %d\r\n", i, dummy_ary_index );
//		if ( m_compare ( str, dummy_ary[i] ) == 1 ) {
		if (  str == dummy_ary[i] ) {
			stored_index = i;
			err_msg_101("free |%p| |%4d/%4d| |%s|%s|\r\n", dummy_ary[i], stored_index, dummy_ary_index, dummy_ary[i], str );
			free( dummy_ary[i] );
			dummy_ary[i] = NULL;
			err_msg_101("free %d |%p|\r\n", i, dummy_ary[i] );
			Sleep(25);
			break;
		}
	}

	err_msg_101("001 stored_index %d/\r\n", stored_index);
	if (stored_index == -1) {
		err_msg_101("sub_aFree ends. thre is no free.\r\n");
		exit(-1);
		return -1;
	}

	err_msg_101("002 stored_index %d/\r\n", stored_index);
	for ( int i=stored_index; i<dummy_ary_index -1; i++) {
		err_msg_101 ("sub_aFree 02: i %d/ %d stored_index %d\r\n", i, dummy_ary_index, stored_index );
		dummy_ary[ i ] = dummy_ary[ i + 1 ];
	}

	err_msg_101("003 dummy_ary_index %d/ -> ", dummy_ary_index);
	dummy_ary_index--;
	err_msg_101("004 dummy_ary_index %d/\r\n", dummy_ary_index);
	err_msg_101("sub_aFree ends. return 1.\r\n");

	exit(-1);
	return 1;
}

//
//
//
//
//
char** put_memories ( char* str ) {

	err_msg_001("char** put_memories ( char* str ) starts. index %d: index_max %d\r\n", dummy_ary_index, dummy_ary_index_max);

	if ( dummy_ary_index == 0 ) {
		dummy_ary_index_max = 8;
		dummy_ary = (char **) malloc( sizeof(char*) * dummy_ary_index_max );
		for ( int i=0; i<dummy_ary_index_max; i++ ) {
			dummy_ary[ i ] = NULL;
		}
		dummy_ary[ 0 ] = str;
		dummy_ary_index = 1;
	} else {
		dummy_ary_index++;
		if ( dummy_ary_index >= dummy_ary_index_max) {
			dummy_ary_index_max *= 2;
			dummy_ary = (char **) realloc( dummy_ary, sizeof(char*)*dummy_ary_index_max );
		}
		dummy_ary[ dummy_ary_index - 1 ] = str;
	}

	err_msg_001("char** put_memories ( char* str ) ends.\r\n");
	return dummy_ary;
}

char** put_memories_002 ( char* str ) {

	printf("char** put_memories_002 ( char* str ) starts. index %d: index_max %d\r\n", dummy_ary_index, dummy_ary_index_max);

	if ( dummy_ary_index == 0 ) {
		dummy_ary_index_max = 8;
		dummy_ary = (char **) malloc( sizeof(char*) * dummy_ary_index_max );
		for ( int i=0; i<dummy_ary_index_max; i++ ) {
			dummy_ary[ i ] = NULL;
		}
		dummy_ary[ 0 ] = str;
		dummy_ary_index = 1;
	} else {
		dummy_ary_index++;
		if ( dummy_ary_index >= dummy_ary_index_max) {
			dummy_ary_index_max *= 2;
			dummy_ary = (char **) realloc( dummy_ary, sizeof(char*)*dummy_ary_index_max );
		}
		dummy_ary[ dummy_ary_index - 1 ] = str;
	}

	printf("char** put_memories_002 ( char* str ) ends.\r\n");
	return dummy_ary;
}

//
//
//
//
//
void print_memories () {
	err_msg_001("void print_memories () starts.\r\n");

	for ( int i=0; i<dummy_ary_index; i++) {
		err_msg_001("p|%p|:dummy_ary[%d]=|%s|\r\n", dummy_ary[i], i, dummy_ary[i] );
	}

	err_msg_001("void print_memories () ends.\r\n");
}

void print_memories_002 () {
	printf("void print_memories_002 () starts.\r\n");

	for ( int i=0; i<dummy_ary_index; i++) {
		printf("p|%p|:dummy_ary[%d]=|%s|\r\n", dummy_ary[i], i, dummy_ary[i] );
	}

	printf("void print_memories_002 () ends.\r\n");
}

//
//
//
//
//
//
char* m_print_buffer( char* buffer)
{
	char ALetter[1];
	int a = level_error_msg;

	level_error_msg = 6;

	for( int i=0; 1; i++ ) {
		ALetter[0] = buffer[i];

		if ( buffer[i] == '\0' ) break;

		err_msg_006("i: %2d : %4d ALetter |%s| |%2d|%2d|%2d|\r\n", i, buffer[i], ALetter, '\r', '\n', '\0');
	}

	level_error_msg =  a;
}

//
//
//
//
//
//
int array_count( char *ary )
{
	char c;
	int a = level_error_msg;

	level_error_msg = 6;
	err_msg_006("start function: array_count:\r\n");

	if ( ary == nullptr ) {
//		err_msg_006("end function: array_count: return -1\r\n");
		return -1;
	}

//	err_msg_006("middle of function: array_count: return -1\r\n");
	int count = 0;
	for ( ;; ) {
		c = *ary;
		if ( c == '\0' ) {
			break;
		}
		ary++;
		count++;
	}

//	err_msg_006("end function: array_count: return %d\r\n", count);

	level_error_msg =  a;
	return count;
}

//
//
//
//
//
//
int m_compare ( char* tkn, char* m ) {

	int a = level_error_msg;
	level_error_msg = 6;
	err_msg_006("function: m_compare:");

	int count_t = array_count( tkn );
	int count_m = array_count( m );

//	err_msg_006(" %d | %d | %s | %s \r\n", count_t, count_m, tkn, m );

	if ( count_t != count_m ) {
		level_error_msg =  a;
		return -1;
	}

	// match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) {
			level_error_msg =  a;
			return -1;
		 }
	}

	level_error_msg =  a;
	return 1;
}

//
//
//
//
//
int m_start_with ( char *head, char *tail ) {
	int nh, nt, min;
	char c1, c2;

	nh = array_count( head );
	nt = array_count( tail );
	min = nh;
	if ( min > nt ) {
		min = nt;
	}

	for ( int i=0; i<min; i++ ) {
		c1 = *(head + i ) ;
		c2 = *(tail + i ) ;
		if ( c1 != c2 ) {
			return 0;
		}
	}

	return 1;
}

//
//
//
//
//
//
//
char* m_concat( char *head, char *tail ) {
	int nh, nt;
	static int alloc = 0;
	char* c_head;
	char* result = NULL;
	char* l_dummy_allocation_001 = NULL;

	printf("char* m_concat( char *head, char *tail ) starts.\r\n");

	nh = array_count( head );
	nt = array_count( tail );
	if ( nh < 0 ) nh = 0; 
	if ( nt < 0 ) nt = 0; 
	printf("array_count: nh %d nt %d | %s %s \r\n", nh, nt, head, tail);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		} else {
			break;
		}
	}

	if ( alloc == 0 ) {
		alloc = 1;
		for ( int i=0; i<100; i++) {
			l_dummy_allocation_001 = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
			if ( l_dummy_allocation_001 != NULL ) break;

			sleep(1);
			char* d_a = (char *) malloc( 1 );
			free(d_a);
		}
		alloc = 0;
	}

	if (l_dummy_allocation_001==NULL) {
		printf("l_dummy_allocation_001 is null.\r\n");
		exit(-1);
	}

	for( int i=0; i< nh; i++ ) {
		*( l_dummy_allocation_001 + i ) = *(head + i);
	}

	for( int i=0; i< nt; i++ ) {
		printf("function m_concat: i %d\r\n", i);
		*( l_dummy_allocation_001 + nh + i ) = *(tail + i);
	}

	// 2 + 2 = 4 p[4] = "\n"
	*( l_dummy_allocation_001 + nh + nt ) = '\0';
	result = copyof_002 (l_dummy_allocation_001);
//	put_memories( result );
	printf("011: result|%p|=|%d| l_dummy_allocation_001|%p|=|%d|\r\n", result, array_count(result), l_dummy_allocation_001, array_count(l_dummy_allocation_001) );

	free(l_dummy_allocation_001);
//	printf("012: result|%p|=|%s| l_dummy_allocation_001|%p|\r\n", result, array_count(result), l_dummy_allocation_001 );

	printf("char* m_concat( char *head, char *tail ) ends.\r\n");
	return result;
}

//
//
//
//
//
//
void print_string( char *head )
{
	int nh;
	char aa[] = { '\0', '\0' };
	int a = level_error_msg;

	level_error_msg = 6;

	nh = array_count( head );
	for( int i=0; i<nh; i++ ) {
		aa[0] = *(head + i);
		err_msg_006( "|%s|%3d|\n", (char*)aa, aa[0] );
	}

	level_error_msg =  a;
}

//
// do not use realloc in under sublootin.
// better solution usually by use of macro of realloc in C.
//
// use global value for allocation.
char* concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
	char ch, ct;
	char* c_head;

	int a = level_error_msg;
	level_error_msg = 6;

	nh = array_count( head );
	nt = array_count( tail );
	// o if ( nh + nt == 6 ) exit(-1);
	err_msg_006("array_count: %d %d\n", nh, nt);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		}
		break;
	}
	err_msg_006("alloc=%d\n", alloc);

	if ( alloc == 0 ) {
		alloc = 1;
//		c_head = (char *) realloc( head , sizeof( char ) * ( nh + nt + 1) );
		c_head = (char *) realloc( head , 100 );

		dummy_allocation_001 = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
//		dummy_allocation_001 = (char *) malloc( sizeof(char *) * ( nh + nt + 1 ) );
//		dummy_allocation_001 = (char *) malloc( 100 * ( nh + nt + 1 ) );

//		*( head + nh + nt) = '\0';
		// x *(head) = 0;
		// o head = tail;
		err_msg_006("allocation blocks(head)=%d\n", sizeof( head ) );
		err_msg_006("allocation blocks(*head)=%d\n", sizeof( *head ) );
//		err_msg_006("allocation blocks(array_count(head))=%d\n", array_count(head) );

		err_msg_006("allocation blocks(c_head)=%d\n", sizeof( c_head ) );
		err_msg_006("allocation blocks(tail)=%d\n", sizeof( tail ) );

		// x *(head + 3 ) = ' ';
		//set_array( head, 3, ' ');
		err_msg_006("allocation blocks(array_count(head))=%d\n", array_count(head) );


//		*( dummy_allocation_001 + nh + nt ) = '\0';
		*( dummy_allocation_001 + 1 ) = '\0';
		err_msg_006("allocation blocks( dummy_allocation_001 )=%d\n", sizeof( dummy_allocation_001 ) );
		err_msg_006("allocation blocks( array_count( dummy_allocation_001 ) ) = %d\n", array_count(dummy_allocation_001) );

		alloc = 0;
	}

// o	head = tail;
// x	*head = *tail;
// o	ch = *head;
//	exit(-1);

	head += nh;
	for( int i=0; i<nt; i++ ) {
		// x head[ nh + i ] = tail[ i ];
		// x head[ 0 ] = tail[ i ];
		// x *(head + nt + i) = *( tail + i);
		// x *(head + nt + i) = *( tail);
		// x *(head + nt + i) = 0;
		// o head = tail;
		// x *head = *tail;
		// x *head = 0;
		// x *(head) = 0;

		ch = *head;
		ct = *tail;

		// o *(head + 3) = ct;
		// x *( head + nh + i ) = ct;
		// x *head = ct;

		head = tail;

		tail++;
		head++;
	}

	level_error_msg =  a;

	return head;
}

//
//
//
//
//
//
char* set_array(char *arry, int n, char c) {

	static char *returnable;

	int a = level_error_msg;
	level_error_msg = 6;

	returnable = arry;
	arry++;
	*arry = c;
	////arry = c;
	//arry = returnable;

	level_error_msg =  a;

	return returnable;
}

// alloc's
//
//
char* char_string ( int num_memories ) {
	err_msg_001("char* char_string ( int num_memories ) starts. dummy_allocation_001=%p\r\n", dummy_allocation_001);
// 20210731
//	dummy_allocation_001 =NULL;
	print_memories();
	for ( int i =0; i<10; i++) {
		err_msg_001("character i %d/10 num_memories %d about|%p|\r\n", i, num_memories, dummy_allocation_001);
		dummy_allocation_001 = (char*) malloc( sizeof(char) * num_memories );
		err_msg_001("dummy_allocation_001|%p|\r\n", dummy_allocation_001);
		if ( dummy_allocation_001 != NULL ) {
			break;
		}
		a_sleep_thread ();
	}
	put_memories( dummy_allocation_001 );
	err_msg_001("char* char_string ( int num_memories ) ends.\r\n");
	return dummy_allocation_001;
}

char* char_string_012 ( int num_memories ) {
	printf("char* char_string_012 ( int num_memories ) starts. num_memories=%d dummy_allocation_001=%p\r\n", num_memories, dummy_allocation_001);
// 20210731
//	dummy_allocation_001 =NULL;
//	print_memories_002();
	for ( int i =0; i<10; i++) {
		printf("character i %d/10 num_memories %d about|%p|\r\n", i, num_memories, dummy_allocation_001);
		dummy_allocation_001 = (char*) malloc( sizeof(char) * num_memories );
		printf("dummy_allocation_001|%p|\r\n", dummy_allocation_001);
		if ( dummy_allocation_001 != NULL ) {
			break;
		}
		a_sleep_thread ();
	}
	put_memories_002( dummy_allocation_001 );
	printf("char* char_string_012 ( int num_memories ) ends.\r\n");
	return dummy_allocation_001;
}

char* char_string_002 ( int num_memories ) {
	printf("char* char_string_002 ( int num_memories ) starts. dummy_allocation_001=%p\r\n", dummy_allocation_001);
// 20210731
//	dummy_allocation_001 =NULL;
	print_memories_002();
	for ( int i =0; i<10; i++) {
		printf("character i %d/10 num_memories %d about|%p|\r\n", i, num_memories, dummy_allocation_001);
		dummy_allocation_001 = (char*) malloc( sizeof(char) * num_memories );
		printf("dummy_allocation_001|%p|\r\n", dummy_allocation_001);
		if ( dummy_allocation_001 != NULL ) {
			break;
		}
		a_sleep_thread ();
	}
	put_memories_002( dummy_allocation_001 );
	printf("char* char_string_002 ( int num_memories ) ends.\r\n");
	return dummy_allocation_001;
}


// alloc's
//
//
char* char_string_010 ( int num_memories ) {
	err_msg_001("char* char_string_010 ( int num_memories ) starts. dummy_allocation_001=%p\r\n", dummy_allocation_001);
// 20210731
//	dummy_allocation_001 =NULL;
	for ( int i =0; i<10; i++) {
		err_msg_001("character i %d/10 num_memories %d about|%p|\r\n", i, num_memories, dummy_allocation_001);
		dummy_allocation_001 = (char*) malloc( sizeof(char) * num_memories );
		if ( dummy_allocation_001 != NULL ) {
			for ( int j=0; j<num_memories; j++ ) {
				dummy_allocation_001[j] = (char)' ';
			}
			break;
		}
		a_sleep_thread ();
	}
	err_msg_001("dummy_allocation_001=|%p| |%s| array count=%d\r\n", dummy_allocation_001, dummy_allocation_001, array_count(dummy_allocation_001));
	err_msg_001("char* char_string_010 ( int num_memories ) ends.\r\n");
	return dummy_allocation_001;
}


// alloc's
//
//
char* copyof ( char* str ) {
	err_msg_001("char* copyof ( char* str ) starts.\r\n");
	int ac = array_count(str);
	err_msg_001("array_count %d\r\n", ac );
	dummy_allocation_001 = (char*)malloc( sizeof(char) * (ac + 1) );
	a_sleep_thread ();
	if ( dummy_allocation_001 == NULL ) {
		err_msg_001("dummy_allocation_001 is null.\r\n");
		exit(-1);
	}
	err_msg_001("dummy_allocation_001 point|%p|\r\n", dummy_allocation_001 );
	put_memories( dummy_allocation_001 );

	for ( int i=0; i<ac; i++) {
		dummy_allocation_001[i] = str[i];
	}

	dummy_allocation_001[ac] = '\0';

	err_msg_001("char* copyof ( char* str ) ends.\r\n");
	return dummy_allocation_001;
}

char* copyof_001 ( char* str ) {
	err_msg_001("char* copyof_001 ( char* str ) starts.\r\n");
	int ac = array_count(str);
	err_msg_001("array_count %d\r\n", ac );
	dummy_allocation_001 = char_string ( ac + 1 );
	a_sleep_thread ();
	if ( dummy_allocation_001 == NULL ) {
		err_msg_001("dummy_allocation_001 is null.\r\n");
		exit(-1);
	}
	err_msg_001("dummy_allocation_001 point|%p|\r\n", dummy_allocation_001 );
//	put_memories( dummy_allocation_001 );

	for ( int i=0; i<ac; i++) {
		dummy_allocation_001[i] = str[i];
	}

	dummy_allocation_001[ac] = '\0';

	err_msg_001("char* copyof_001 ( char* str ) ends.\r\n");
	return dummy_allocation_001;
}

char* copyof_012 ( char* str ) {
	printf("char* copyof_012 ( char* str ) starts.\r\n");
	int ac = array_count(str);
	printf("array_count %d\r\n", ac );
	dummy_allocation_001 = char_string_012 ( ac + 1 );
	a_sleep_thread_002 ();
	if ( dummy_allocation_001 == NULL ) {
		printf("dummy_allocation_001 is null.\r\n");
		exit(-1);
	}
	printf("dummy_allocation_001 point|%p|\r\n", dummy_allocation_001 );
//	put_memories( dummy_allocation_001 );

	for ( int i=0; i<ac; i++) {
		dummy_allocation_001[i] = str[i];
	}

	dummy_allocation_001[ac] = '\0';
	printf("str |%p| dummy_allocation_001 |%p|=|%s|\r\n", str, dummy_allocation_001, dummy_allocation_001 );
	printf("char* copyof_012 ( char* str ) ends.\r\n");
	return dummy_allocation_001;
}

char* copyof_002 ( char* str ) {
	printf("char* copyof_002 ( char* str ) starts.\r\n");
	int ac = array_count(str);
	printf("array_count %d\r\n", ac );
	dummy_allocation_001 = char_string_002 ( ac + 1 );
	a_sleep_thread_002 ();
	if ( dummy_allocation_001 == NULL ) {
		printf("dummy_allocation_001 is null.\r\n");
		exit(-1);
	}
	printf("dummy_allocation_001 point|%p|\r\n", dummy_allocation_001 );
//	put_memories( dummy_allocation_001 );

	for ( int i=0; i<ac; i++) {
		dummy_allocation_001[i] = str[i];
	}

	dummy_allocation_001[ac] = '\0';
	printf("str |%p| dummy_allocation_001 |%p|\r\n", str, dummy_allocation_001 );
	printf("char* copyof_002 ( char* str ) ends.\r\n");
	return dummy_allocation_001;
}


//
//
//
//
//
char* m_trim( char* c_str ) {

	char* result = "\0";
	char* return_result = "\0";

	err_msg_001("m_trim: notrim |%s| starts.\r\n", c_str);

	result = front_trim ( c_str );
	err_msg_001("front_trim |%s|\r\n", result);
	return_result = back_trim ( result );
	err_msg_001("back_trim |%s|\r\n", return_result);

	aFree( result );

	err_msg_001("m_trim ends.\r\ns");
	return return_result;
}


//
//
//
//
//
char* back_trim( char* c_str ) {

	int skip = 0;
	int count = 0;
	int f_continue = 0;
	char* result = "\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	err_msg_001("back_trim starts.\r\n");

	for ( int i=length -1; i >= 0; i-- ) {
		c = c_str[i];
		err_msg_001("c |%c|%d| / |%s|\r\n", c, c, c_str);
		switch ( c ) {
		case ' ':
			count++;
			break;
		default:
			err_msg_001("count %d in back_trim.\r\n", count);
			char* returnable = m_substring ( c_str, 0, length - count);
			err_msg_001("back_trim |%s|\r\n", returnable);
			return returnable;
		}
	}

	err_msg_001("back_trim ends.|%s|\r\n", result);
	return result;
}

//
//
//
//
//
char* front_trim( char* c_str ) {

	int skip = 0;
	int count = 0;
	int f_continue = 0;
	char* result = "\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	int a = level_error_msg;
	level_error_msg = 6;

	for ( int i=0; i< length; i++) {
		c = c_str[i];
		switch ( c ) {
		case ' ':
			count++;
			break;
		default:
			err_msg_001("count %d in front_trim.\r\n", count);
			return m_substring( c_str, count, length - count );
			break;
		}
	}

	level_error_msg = a;

	return result;
}

//
//
//
//
//
int m_contains ( char* c_str, char* c_ref ) {

	int unmatch = 0;
	int ref_length = array_count( c_ref );

	int a = level_error_msg;
	level_error_msg = 6;

	int length = array_count( c_str );
	for ( int i=length -1; i >= 0; i-- ) {
		if ( c_str[i] == c_ref[ ref_length -1 ])
			for ( int j=ref_length -1; j >= 0 && i >= 0; j-- ) {
				// serr_msg_006("m_contains:|%d|%d|\r\n", c_str[i] , c_ref[j] );
				err_msg_001("m_contains:|%d|%d|%c|%c\r\n", c_str[i] , c_ref[j], c_str[i] , c_ref[j] );
				if ( c_str[i] != c_ref[ j ] ) {
					unmatch = 1;
					break;
				}
				if ( j == 0 ) unmatch = 2;
				i--;
			}

		if ( unmatch == 2 ) return 1;
		else unmatch = 0;
	}

	level_error_msg = a;

	return 0;
}

