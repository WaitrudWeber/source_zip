#pragma once

//#include "Print.h"

extern int set_level_error_msg;
extern int level_error_msg;
extern int print_socket_msg;

extern void PrintErrorMsg(const char* fmt, ...);
extern wchar_t* vformat(const char* fmt, va_list args);
extern wchar_t* _toChars(char * m_string);
extern char* toChars(LPSTR str);

extern char* PrintError(const char* mem, const char* fmt, ...);
extern void err_msg(const char *fmt, ...);
extern char* err_msg_001(const char *fmt, ...);
extern char* err_msg_002(const char *fmt, ...);
extern char* err_msg_003(const char *fmt, ...);
extern void err_msg_004(const char *fmt, ...);
extern void err_msg_005(const char *fmt, ...);
extern void err_msg_006(const char *fmt, ...);

extern char* log_msg_003(const char *fmt, ...);
