

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "wEvent.h"
#include "wButton.h"
#include "wButtonController.h"
#include "wCanvasController.h"

#include "vDisplayController.h"


void vDisplayController::Set_Lines (vLine** l ) {
	lines = l;
}

void vDisplayController::Set_Lines_2D (vLine** l_2D ) {
	lines_2D = l_2D;
}

//
int vDisplayController::Approach_vAxex_2D( vPoint* ap ) {
	printf("002: int Approach_vAxex_2D( vPoint* ap ) starts.\r\n");

	vPoint* to_vector = Calc.subtract( ap, AXEX_2D_002[0].center ) ;
	double distance = Calc.length ( to_vector );

	if ( distance >= 1.0 ) {
		Calc.normal(to_vector);
		vPoint* progress =  Calc.scalize( to_vector, 5.0f );
		vPoint* next_p = Calc.add ( AXEX_2D_002[0].center, progress);
		AXEX_2D_002[0].SetCenter( next_p->x, next_p->y, next_p->z );
		AXEX_2D_002[0].SetDepth ( next_p->x, next_p->y, next_p->z );
		AXEX_2D_002[0].Calculation_Axex_002 ( );
		free_point( progress );
		free_point( next_p );
	}
	free_point( to_vector );

	AXEX_2D_002[0].CheckAxex();

	vPoint* to_vector_001 = Calc.subtract( ap, AXEX_2D_002[1].center ) ;
	distance = Calc.length ( to_vector );
	if ( distance >= 1.0 ) {
		Calc.normal(to_vector_001);
		vPoint* progress_001 =  Calc.scalize( to_vector_001, 5.0f );
		vPoint* next_p_001 = Calc.add ( AXEX_2D_002[1].center, progress_001);
		AXEX_2D_002[1].SetCenter( next_p_001->x, next_p_001->y, next_p_001->z );
		AXEX_2D_002[1].SetDepth ( next_p_001->x, next_p_001->y, next_p_001->z );
		AXEX_2D_002[1].Calculation_Axex_002 ( );
		free_point( progress_001 );
		free_point( next_p_001 );
	}
	free_point( to_vector_001 );

	AXEX_2D_002[1].CheckAxex();

	vPoint* to_vector_002 = Calc.subtract( ap, AXEX_2D_002[2].center ) ;
	distance = Calc.length ( to_vector );
	if ( distance >= 1.0 ) {
		Calc.normal(to_vector_002);
		vPoint* progress_002 =  Calc.scalize( to_vector_002, 5.0f );
		vPoint* next_p_002 = Calc.add ( AXEX_2D_002[2].center, progress_002);
		AXEX_2D_002[2].SetCenter( next_p_002->x, next_p_002->y, next_p_002->z );
		AXEX_2D_002[2].SetDepth ( next_p_002->x, next_p_002->y, next_p_002->z );
		AXEX_2D_002[2].Calculation_Axex_002 ( );
		free_point( progress_002 );
		free_point( to_vector_002 );
		free_point( next_p_002 );
	}
	free_point( to_vector_002 );

	AXEX_2D_002[2].CheckAxex();

	printf("002: int Approach_vAxex_2D( vPoint* ap ) ends.\r\n");
	return 0;
}


int vDisplayController::DisplaytheBox () {
	float x, y;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint* eye = nullptr;
	vBox box( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);

	printf("v3dCalculation:: DisplaytheBox () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int i=0; i<8; i++ ) {
		printf("code block set loop %d starts.\r\n", i);
		int a = screen_006.get_cooordinate_on_screen ( *(box.p[i]), &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		printf("code block set loop %d ends.\r\n", i);
	}

	box.Print();

	printf("v3dCalculation:: DisplaytheBox () ends.\r\n");
}

int vDisplayController::SetBaseAxex () {
	printf("vDisplayController:: SetBaseAxex () starts.\r\n");

	if ( axex_line_3d_002 == nullptr ) {
		printf("vDisplayController:: SetBaseAxex () allocation: %d\r\n", axex_line_max);
		axex_line_3d_002 = (vLine**) malloc ( sizeof (vLine*) * axex_line_max );
		printf("vDisplayController:: SetBaseAxex () allocation: end\r\n");
	}

	axex_line_3d_002[0]->p1 = memorizevPoint ( 0.0f, 0.0f, 0.0f );
	axex_line_3d_002[1]->p1 = memorizevPoint ( 0.0f, 0.0f, 0.0f );
	axex_line_3d_002[2]->p1 = memorizevPoint ( 0.0f, 0.0f, 0.0f );

	axex_line_3d_002[0]->p2 = memorizevPoint ( 100.0f, 0.0f, 0.0f );
	axex_line_3d_002[1]->p2 = memorizevPoint ( 0.0f, 100.0f, 0.0f );
	axex_line_3d_002[2]->p2 = memorizevPoint ( 0.0f, 0.0f, 100.0f );

	this->DisplayBaseAxex();

	printf("vDisplayController:: SetBaseAxex () ends.\r\n");
	return 0;
}

int vDisplayController::DisplayBaseAxex () {
	float x1, x2, y1, y2;
	printf("vDisplayController:: DisplayBaseAxex () starts.\r\n");

	this->canvas->AXEX_2D_LINE_Index = 0;
	for ( int j=0; j<axex_line_max; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( *(axex_line_3d_002[j]->p1), &x1, &y1 );
		a = screen_006.get_cooordinate_on_screen ( *(axex_line_3d_002[j]->p2), &x2, &y2 );
		this->canvas->Set_Axex_Line ( x1, y1, x2, y2 );
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_LINE_Index );
	}

	printf("vDisplayController:: DisplayBaseAxex () ends.\r\n");
	return 0;
}

int vDisplayController::DisplayThreeBoxes () {
	float x, y;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint* eye = nullptr;
	vBox boxes[3];

	boxes[0].SetBox( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f );
	boxes[1].SetBox( 150.0f, 150.0f, 150.0f, 250.0f, 250.0f, 250.0f );
	boxes[2].SetBox( 300.0f, 300.0f, 300.0f, 400.0f, 400.0f, 400.0f );

	printf("v3dCalculation:: DisplaytheBox () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<3; j++ ) {
		for ( int i=0; i<8; i++ ) {
			printf("code block set loop %d starts.\r\n", i);
			int a = screen_006.get_cooordinate_on_screen ( *(boxes[j].p[i]), &x, &y );
			this->canvas->Set_vAxex_2D( x, y );
			printf("code block set loop %d ends.\r\n", i);
		}
	}

	for ( int j=0; j<3; j++ ) {
		boxes[j].Print();
	}

	printf("v3dCalculation:: DisplaytheBox () ends.\r\n");
}

int vDisplayController::DisplayTenTriangles () {
	vTriangle triangles[10];
	float x, y;
	vPoint* eye = nullptr;

	printf("v3dCalculation:: DisplayTenTriangles () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	for ( int j=0; j<10; j++ ) {
		triangles[j].p1.setPoint (  0.0f,  0.0f,    0.0f );
		triangles[j].p2.setPoint ( 100.0f, 10.0f,   0.0f );
		triangles[j].p3.setPoint ( 100.0f, 20.0f, 100.0f );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( triangles[j].p1, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		int b = screen_006.get_cooordinate_on_screen ( triangles[j].p2, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		int c = screen_006.get_cooordinate_on_screen ( triangles[j].p3, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		printf("code block set loop %d ends.\r\n", j);
	}

	for ( int j=0; j<10; j++ ) {
		printf("triangle print %d starts.\r\n", j);
		triangles[j].print();
		printf("triangle print %d ends.\r\n", j);
	}


	printf("v3dCalculation:: DisplayTenTriangles () ends.\r\n");

	return 0;
}

int vDisplayController::DisplayTenTriangles_001 () {
	vTriangle triangles[10];
	float x, y;
	vPoint* eye = nullptr;
	float up_triangle;

	printf("v3dCalculation:: DisplayTenTriangles () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	up_triangle = 0.0f;
	for ( int j=0; j<10; j++ ) {
		triangles[j].p1.setPoint (  0.0f,  0.0f + up_triangle,    0.0f );
		triangles[j].p2.setPoint ( 100.0f, 10.0f + up_triangle,   0.0f );
		triangles[j].p3.setPoint ( 100.0f, 20.0f + up_triangle, 100.0f );
		up_triangle +=30.0f;
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( triangles[j].p1, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		this->canvas->AXEX_2D_002_Index++;
		int b = screen_006.get_cooordinate_on_screen ( triangles[j].p2, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		this->canvas->AXEX_2D_002_Index++;
		int c = screen_006.get_cooordinate_on_screen ( triangles[j].p3, &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d ends.\r\n", j);
	}

	for ( int j=0; j<10; j++ ) {
		printf("triangle print %d starts.\r\n", j);
		triangles[j].print();
		printf("triangle print %d ends.\r\n", j);
	}

	printf("v3dCalculation:: DisplayTenTriangles () ends.\r\n");

	return 0;
}

int vDisplayController::DisplayBones_001 () {
	vPoint bones[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;

	printf("v3dCalculation:: DisplayBones () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}


	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones[0].setPoint (  0.0f,  0.0f,    0.0f );
	bones[1].setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones[1], bones[0], &w1 );
	for ( int j=2; j<10; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones[j-1].print();
			bones[j].print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones[ j ].setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones print %d starts.\r\n", j);
		bones[j].print();
		printf("bones print %d ends.\r\n", j);
	}

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("v3dCalculation:: DisplayBones () ends.\r\n");
//	exit(-1);
	return 0;
}



int vDisplayController::DisplayBones_002 () {
	vPoint bones[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;

	printf("v3dCalculation:: DisplayBones_002 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}


	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones[0].setPoint (  0.0f,  0.0f,    0.0f );
	bones[1].setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones[1], bones[0], &w1 );
	for ( int j=2; j<10; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones[j-1].print();
			bones[j].print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones[ j ].setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones print %d starts.\r\n", j);
		bones[j].print();
		printf("bones print %d ends.\r\n", j);
	}

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("v3dCalculation:: DisplayBones_002 () ends.\r\n");
//	exit(-1);
	return 0;
}

// 1: bones -> global points
// 2: We create input selected number from wCanvasController
// 3: We set call of vDisplayController at the start to wCanvasController.
//
int vDisplayController::DeleteSelectedPoint ( int number ) {
	float x, y;
	printf("v3dCalculation:: DeleteSelectedPoint () starts.\r\n");

	int max = this->canvas->AXEX_2D_002_Index -1;
	this->canvas->AXEX_2D_002_Index = this->canvas->AXEX_2D_002_Index_Selected;
	printf("from this->canvas->AXEX_2D_002_Index=%d max=%d\r\n", this->canvas->AXEX_2D_002_Index, max);

	for ( int i= this->canvas->AXEX_2D_002_Index_Selected; i <max; i++ ) {
		int a  = this->canvas->Get_vAxex_2D( i + 1, &x, &y ) ;  // always i + 1;
		this->canvas->Set_vAxex_2D ( x, y ); 
	}

	printf("to this->canvas->AXEX_2D_002_Index=%d max=%d\r\n", this->canvas->AXEX_2D_002_Index, max);

	// bones
	printf("bones:\r\n");
	for ( int i= this->canvas->AXEX_2D_002_Index_Selected; i <max; i++ ) {
		this->bones[i] = this->bones[ i + 1 ];
	}
	bones_max_index = max;

	printf("bones_max_index=%d bones_max=%d\r\n", bones_max_index, bones_max);
//	exit(-1);

	printf("v3dCalculation:: DeleteSelectedPoint () starts.\r\n");

	return 0;
}

int vDisplayController::DeleteSelectedPoint_001 ( int number ) {
	float x, y;
	printf("v3dCalculation:: DeleteSelectedPoint () starts.\r\n");

	int max = this->canvas->AXEX_2D_002_Index -1;
	this->canvas->AXEX_2D_002_Index = this->canvas->AXEX_2D_002_Index_Selected;
	printf("from this->canvas->AXEX_2D_002_Index=%d max=%d\r\n", this->canvas->AXEX_2D_002_Index, max);

	for ( int i= this->canvas->AXEX_2D_002_Index_Selected; i <max; i++ ) {
		int a  = this->canvas->Get_vAxex_2D( i + 1, &x, &y ) ;  // always i + 1;
		this->canvas->Set_vAxex_2D ( x, y ); 
	}

	printf("to this->canvas->AXEX_2D_002_Index=%d max=%d\r\n", this->canvas->AXEX_2D_002_Index, max);

	// bones
	for ( int i= this->canvas->AXEX_2D_002_Index_Selected; i <max; i++ ) {
		this->bones[i] = this->bones[ i + 1 ];
	}
	bones_max_index = max;

	printf("bones_max_index=%d bones_max=%d\r\n", bones_max_index, bones_max);

	// print bones
	printf("bones: max index %d\r\n", max );
	for ( int i= 0; i <max; i++ ) {
		this->bones[i].print();
	}

	printf("v3dCalculation:: DeleteSelectedPoint () starts.\r\n");
//	exit(-1);
	return 0;
}

// l -> q
// 1: direction 1:down, 2:up, 3: right, 4: left
// 2: find fixed up.
// 3:
int vDisplayController::MoveSelectedPoint_002 ( int number, int direction ) {
	float x, y;
	vCalculation calc;

	printf("int vDisplayController::MoveSelectedPoint_002 ( int number, int direction ) starts.\r\n");

	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones[selected] );

	printf("selected %d ", selected );
	selected_point->print ();

	printf("bones: canvas index %d\r\n", this->canvas->AXEX_2D_002_Index);
	for ( int i =0; i<this->canvas->AXEX_2D_002_Index; i++ ) {
		this->bones[i].print();
	}

	printf("bones_max_index %d bones_max %d\r\n", bones_max_index, bones_max );

	printf("int vDisplayController::MoveSelectedPoint_002 ( int number, int direction ) ends.\r\n");
	exit(-1);
	return 0;
}

// 1: direction 1:down, 2:up, 3: right, 4: left
// 2: find fixed up.
// 3:
int vDisplayController::MoveSelectedPoint_001 ( int number, int direction ) {
	float x, y;
	vCalculation calc;
	printf("int vDisplayController::MoveSelectedPoint ( int number, int direction ) starts.\r\n");

	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones[selected] );

	printf("selected %d ", selected );
	selected_point->print ();

	printf("bones: canvas index %d\r\n", this->canvas->AXEX_2D_002_Index);
	for ( int i =0; i<this->canvas->AXEX_2D_002_Index; i++ ) {
		this->bones[i].print();
	}

	printf("int vDisplayController::MoveSelectedPoint ( int number, int direction ) ends.\r\n");
	exit(-1);
	return 0;
}

// Press "l" -> and "n".
//
// 1: direction 1:down, 2:up, 3: right, 4: left
// 2: find fixed up.
// 3:
int vDisplayController::MoveSelectedPoint ( int number, int direction ) {
	float x, y;
	vCalculation calc;
	const float c = 5.0f;
	vPoint* range_001;

	printf("int vDisplayController::MoveSelectedPoint ( int number, int direction ) starts.\r\n");

	vPoint* up_001 = &(screen_006.up);
	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones[selected] );

	//scalize * = *, *
//	int b = calc.scale ( selected_point, c, range_001 );
	range_001 = calc.scalize ( up_001, c );

	// ADD calculation * = * , *
	vPoint* moved_point = calc.add ( selected_point, range_001 );

	printf("selected_point=");
	selected_point->print();

	printf("up_001=");
	up_001->print();


	printf("moved_point=");
	moved_point->print();

	// convert value, p, p
	int a = screen_006.get_cooordinate_on_screen ( *moved_point, &x, &y );
	int stored = this->canvas->AXEX_2D_002_Index;
	this->canvas->AXEX_2D_002_Index = selected;
	this->canvas->Set_vAxex_2D( x, y );
//	this->canvas->Set_vAxex_2D( 300, 300 );
	this->canvas->AXEX_2D_002_Index = stored;

	printf("1001 x, y = %f, %f\r\n", x, y);

	printf("int vDisplayController::MoveSelectedPoint ( int number, int direction ) ends.\r\n");
//	exit(-1);
	return 0;
}

int vDisplayController::DisplayBones ( ) {
	vPoint bones[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;

	printf("v3dCalculation:: DisplayBones () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	bones_max = 10;

	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones[0].setPoint (  0.0f,  0.0f,    0.0f );
	bones[1].setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones[1], bones[0], &w1 );
	for ( int j=2; j<bones_max; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones[j-1].print();
			bones[j].print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones[ j ].setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}
	bones_max_index = bones_max;

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<bones_max; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<bones_max; j++ ) {
		printf("bones print %d starts.\r\n", j);
		bones[j].print();
		printf("bones print %d ends.\r\n", j);
	}

	printf("bones_max_index=%d bones_max=%d\r\n", bones_max_index, bones_max);
//	exit(-1);

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("v3dCalculation:: DisplayBones () ends.\r\n");
//	exit(-1);
	return 0;
}

int vDisplayController::SetCanvas ( wCanvasController *l_canvas ) {
	this->canvas = l_canvas;
}


