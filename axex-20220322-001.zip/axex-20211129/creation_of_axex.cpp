#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"	// ADD: 20200125
#include "sender.h"			// ADD: 20200125
#include "Print.h"			// ADD: 20200125

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vScreen.h"

#include "vAxex_2D.h"
#include "creation_of_axex.h"

vAxex_2D AXEX_2D_002[30];

vAxex_2D** AXEX_2D_001 = nullptr;
vLine** Line_AXEX = nullptr;

vCalculation Calc;
vScreen* screen_001;


int Approach_vAxex_2D( vPoint* ap ) ;

int initialize_vAxex_2D_003() ;
int initialize_vAxex_2D_002() ;

int initialize_vAxex_2D_001() ;
int create_vLine_Axex_2D_001 () ;
int Set_vScreen (vScreen* vsc ) ;

int Set_vScreen (vScreen* vsc ) {
	screen_001 = vsc;
	return 0;
}

//
int Approach_vAxex_2D( vPoint* ap ) {
	printf("002: int Approach_vAxex_2D( vPoint* ap ) starts.\r\n");

	vPoint* to_vector = Calc.subtract( ap, AXEX_2D_002[0].center ) ;
	double distance = Calc.length ( to_vector );

	if ( distance >= 1.0 ) {
		Calc.normal(to_vector);
		vPoint* progress =  Calc.scalize( to_vector, 5.0f );
		vPoint* next_p = Calc.add ( AXEX_2D_002[0].center, progress);
		AXEX_2D_002[0].SetCenter( next_p->x, next_p->y, next_p->z );
		AXEX_2D_002[0].SetDepth ( next_p->x, next_p->y, next_p->z );
		AXEX_2D_002[0].Calculation_Axex_002 ( );
		free_point( progress );
		free_point( next_p );
	}
	free_point( to_vector );

	AXEX_2D_002[0].CheckAxex();

	vPoint* to_vector_001 = Calc.subtract( ap, AXEX_2D_002[1].center ) ;
	distance = Calc.length ( to_vector );
	if ( distance >= 1.0 ) {
		Calc.normal(to_vector_001);
		vPoint* progress_001 =  Calc.scalize( to_vector_001, 5.0f );
		vPoint* next_p_001 = Calc.add ( AXEX_2D_002[1].center, progress_001);
		AXEX_2D_002[1].SetCenter( next_p_001->x, next_p_001->y, next_p_001->z );
		AXEX_2D_002[1].SetDepth ( next_p_001->x, next_p_001->y, next_p_001->z );
		AXEX_2D_002[1].Calculation_Axex_002 ( );
		free_point( progress_001 );
		free_point( next_p_001 );
	}
	free_point( to_vector_001 );

	AXEX_2D_002[1].CheckAxex();

	vPoint* to_vector_002 = Calc.subtract( ap, AXEX_2D_002[2].center ) ;
	distance = Calc.length ( to_vector );
	if ( distance >= 1.0 ) {
		Calc.normal(to_vector_002);
		vPoint* progress_002 =  Calc.scalize( to_vector_002, 5.0f );
		vPoint* next_p_002 = Calc.add ( AXEX_2D_002[2].center, progress_002);
		AXEX_2D_002[2].SetCenter( next_p_002->x, next_p_002->y, next_p_002->z );
		AXEX_2D_002[2].SetDepth ( next_p_002->x, next_p_002->y, next_p_002->z );
		AXEX_2D_002[2].Calculation_Axex_002 ( );
		free_point( progress_002 );
		free_point( to_vector_002 );
		free_point( next_p_002 );
	}
	free_point( to_vector_002 );

	AXEX_2D_002[2].CheckAxex();

	printf("002: int Approach_vAxex_2D( vPoint* ap ) ends.\r\n");
	return 0;
}



int initialize_vAxex_2D_003() {
	printf("002: int initialize_vAxex_2D_003() starts.\r\n");

	printf ("initialize_vAxex_2D_002: malloc: 003\r\n");
	AXEX_2D_002[0].SetCenter (  200.0f, 100.0f,   0.0f );
	AXEX_2D_002[1].SetCenter (    0.0f, 100.0f, 100.0f );
	AXEX_2D_002[2].SetCenter (  200.0f,   0.0f, 100.0f );
	AXEX_2D_002[3].SetCenter (  200.0f, 100.0f,  50.0f );

	printf ("initialize_vAxex_2D_002: malloc: 003-01\r\n");
	AXEX_2D_002[0].SetUp (  0.0f, 1.0f, 0.0f );
	AXEX_2D_002[1].SetUp (  0.0f, 1.0f, 0.0f );
	AXEX_2D_002[2].SetUp (  0.0f, 1.0f, 0.0f );
	AXEX_2D_002[3].SetUp (  0.0f, 1.0f, 0.0f );

	printf ("initialize_vAxex_2D_002: malloc: 003-02\r\n");
	AXEX_2D_002[0].SetDepth (  0.1f, 0.4f, 1.0f );
	AXEX_2D_002[1].SetDepth (  0.2f, 0.3f, 1.0f );
	AXEX_2D_002[2].SetDepth (  0.3f, 0.2f, 1.0f );
	AXEX_2D_002[3].SetDepth (  0.4f, 0.1f, 1.0f );

	printf ("initialize_vAxex_2D_002: malloc: 004-00\r\n");
	AXEX_2D_002[0].Calculation_Axex_002 ( );
	printf ("initialize_vAxex_2D_002: malloc: 004-01\r\n");
	AXEX_2D_002[1].Calculation_Axex_002 ( );
	printf ("initialize_vAxex_2D_002: malloc: 004-02\r\n");
	AXEX_2D_002[2].Calculation_Axex_002 ( );
	printf ("initialize_vAxex_2D_002: malloc: 004-03\r\n");
	AXEX_2D_002[3].Calculation_Axex_002 ( );
	printf ("initialize_vAxex_2D_002: malloc: 004-04\r\n");

	printf("002: int initialize_vAxex_2D_003() ends.\r\n");
	return 0;
}


int initialize_vAxex_2D_002() {
	printf("002: int initialize_vAxex_2D_002() starts.\r\n");
	if ( screen_001 == nullptr ) {
		printf ("initialize_vAxex_2D_001: We are going to create vScreen as a object.\r\n");
		screen_001 = new vScreen ();
	}

	printf ("initialize_vAxex_2D_002: malloc: 001\r\n");
	AXEX_2D_001 = (vAxex_2D** ) malloc (sizeof(vAxex_2D*) * 4 );
	if ( AXEX_2D_001 == nullptr ) {
		printf("we cannot malloc memories as AXEX_2D_001.\r\n");
		exit(-1);
	}

	printf ("initialize_vAxex_2D_002: malloc: 002\r\n");
	AXEX_2D_001[0] = new vAxex_2D ( 358.526581f, 440.931427f, 19.409163f, 281.035797f );
	AXEX_2D_001[1] = new vAxex_2D ( 286.512665f, 205.333420f, 14.238716f, 269.707336f );
	AXEX_2D_001[2] = new vAxex_2D ( 108.304085f, 202.828461f, 15.178076f, 232.383194f );
	AXEX_2D_001[3] = new vAxex_2D ( 290.086975f, 176.929230f, 13.731193f, 250.389114f );

	printf ("initialize_vAxex_2D_002: malloc: 003\r\n");
	AXEX_2D_001[0]->SetCenter (  100.0f, 100.0f,   0.0f );
	AXEX_2D_001[1]->SetCenter (    0.0f, 100.0f, 100.0f );
	AXEX_2D_001[2]->SetCenter (  100.0f,   0.0f, 100.0f );
	AXEX_2D_001[3]->SetCenter (  100.0f, 100.0f,  50.0f );

	printf ("initialize_vAxex_2D_002: malloc: 003-01\r\n");
	AXEX_2D_001[0]->SetUp (  1.0f, 1.0f, 0.0f );
	AXEX_2D_001[1]->SetUp (  0.0f, 1.0f, 1.0f );
	AXEX_2D_001[2]->SetUp (  1.0f, 0.0f, 1.0f );
	AXEX_2D_001[3]->SetUp (  1.0f, 1.0f, 1.0f );

	printf ("initialize_vAxex_2D_002: malloc: 003-02\r\n");
	AXEX_2D_001[0]->SetDepth (  0.1f, 0.4f, 1.0f );
	AXEX_2D_001[1]->SetDepth (  0.2f, 0.3f, 1.0f );
	AXEX_2D_001[2]->SetDepth (  0.3f, 0.2f, 1.0f );
	AXEX_2D_001[3]->SetDepth (  0.4f, 0.1f, 1.0f );

	printf ("initialize_vAxex_2D_002: malloc: 004\r\n");
	AXEX_2D_001[0]->Calculation_Axex_002 ( );
	AXEX_2D_001[1]->Calculation_Axex_002 ( );
	AXEX_2D_001[2]->Calculation_Axex_002 ( );
	AXEX_2D_001[3]->Calculation_Axex_002 ( );

	printf("002: int initialize_vAxex_2D_002() ends.\r\n");
	return 0;
}

int initialize_vAxex_2D_001() {

	printf("002: int initialize_vAxex_2D_001() starts.");

	if ( screen_001 == nullptr ) {
		printf ("initialize_vAxex_2D_001: We are going to create vScreen as a object.\r\n");
		screen_001 = new vScreen ();
	}

	printf ("initialize_vAxex_2D_001: malloc: 001\r\n");
	AXEX_2D_001 = (vAxex_2D** ) malloc (sizeof(vAxex_2D*) * 30 );
	if ( AXEX_2D_001 == nullptr ) {
		printf("we cannot malloc memories as AXEX_2D_001.\r\n");
		exit(-1);
	}
	printf ("initialize_vAxex_2D_001: malloc: 002\r\n");
	printf ("initialize_vAxex_2D_001: set param: 001\r\n");
	AXEX_2D_001[0] = new vAxex_2D ( 358.526581f, 440.931427f, 19.409163f, 281.035797f );
	AXEX_2D_001[1] = new vAxex_2D ( 286.512665f, 205.333420f, 14.238716f, 269.707336f );
	AXEX_2D_001[2] = new vAxex_2D ( 108.304085f, 202.828461f, 15.178076f, 232.383194f );
	AXEX_2D_001[3] = new vAxex_2D ( 290.086975f, 176.929230f, 13.731193f, 250.389114f );
	AXEX_2D_001[4] = new vAxex_2D ( 3.945433f, 416.599640f, 15.201880f, 103.668327f );
	AXEX_2D_001[5] = new vAxex_2D ( 100.139778f, 168.696548f, 19.166235f, 167.329941f );
	AXEX_2D_001[6] = new vAxex_2D ( 340.596344f, 322.524506f, 12.938627f, 128.797272f );
	AXEX_2D_001[7] = new vAxex_2D ( 273.738831f, 301.635193f, 17.083651f, 182.039856f );
	AXEX_2D_001[8] = new vAxex_2D ( 10.371410f, 457.763000f, 17.043673f, 254.875336f );
	AXEX_2D_001[9] = new vAxex_2D ( 41.114536f, 382.013611f, 19.942625f, 125.855278f );
	AXEX_2D_001[10] = new vAxex_2D ( 194.810638f, 108.152718f, 10.625935f, 186.745804f );
	AXEX_2D_001[11] = new vAxex_2D ( 78.283638f, 383.258759f, 16.004211f, 107.013153f );
	AXEX_2D_001[12] = new vAxex_2D ( 457.435822f, 340.234985f, 11.757256f, 156.526382f );
	AXEX_2D_001[13] = new vAxex_2D ( 239.401840f, 267.884155f, 10.465102f, 242.655716f );
	AXEX_2D_001[14] = new vAxex_2D ( 36.192513f, 132.909332f, 15.228736f, 218.137146f );
	AXEX_2D_001[15] = new vAxex_2D ( 569.353333f, 109.266029f, 17.838984f, 115.851311f );
	AXEX_2D_001[16] = new vAxex_2D ( 496.011230f, 9.536424f, 15.560167f, 266.826385f );
	AXEX_2D_001[17] = new vAxex_2D ( 476.186401f, 33.633839f, 15.589770f, 157.667770f );
	AXEX_2D_001[18] = new vAxex_2D ( 141.234772f, 209.654831f, 11.255531f, 183.718369f );
	AXEX_2D_001[19] = new vAxex_2D ( 543.708008f, 461.850037f, 19.014862f, 154.158142f );
	AXEX_2D_001[20] = new vAxex_2D ( 28.203985f, 120.897247f, 10.313730f, 105.316322f );
	AXEX_2D_001[21] = new vAxex_2D ( 583.885010f, 251.301620f, 17.377850f, 278.429504f );
	AXEX_2D_001[22] = new vAxex_2D ( 457.709290f, 410.930511f, 16.984467f, 218.070007f );
	AXEX_2D_001[23] = new vAxex_2D ( 329.404572f, 417.830139f, 11.290933f, 247.630234f );
	AXEX_2D_001[24] = new vAxex_2D ( 107.425156f, 179.214447f, 19.775383f, 277.874084f );
	AXEX_2D_001[25] = new vAxex_2D ( 206.197693f, 477.553650f, 11.348613f, 205.032501f );
	AXEX_2D_001[26] = new vAxex_2D ( 364.600983f, 168.974884f, 10.711997f, 254.600662f );
	AXEX_2D_001[27] = new vAxex_2D ( 265.808899f, 368.756378f, 18.009277f, 127.027191f );
	AXEX_2D_001[28] = new vAxex_2D ( 138.305008f, 39.039276f, 15.844905f, 101.666313f );
	AXEX_2D_001[29] = new vAxex_2D ( 478.080994f, 273.773010f, 12.728660f, 155.165253f );

	printf ("002: initialize_vAxex_2D_001: set param: 002\r\n");

	AXEX_2D_001[0]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[1]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[2]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[3]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[4]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[5]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[6]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[7]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[8]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[9]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[10]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[11]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[12]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[13]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[14]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[15]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[16]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[17]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[18]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[19]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[20]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[21]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[22]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[23]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[24]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[25]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[26]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[27]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[28]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[29]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );

	printf ("002: initialize_vAxex_2D_001: set param: 003\r\n");

	AXEX_2D_001[0]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[1]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[2]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[3]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[4]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[5]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[6]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[7]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[8]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[9]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[10]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[11]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[12]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[13]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[14]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[15]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[16]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[17]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[18]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[19]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[20]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[21]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[22]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[23]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[24]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[25]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[26]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[27]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[28]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[29]->SetHeight (  (float)screen_001->getHeight() );

	printf ("002: initialize_vAxex_2D_001: set param: 004\r\n");

	AXEX_2D_001[0]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[1]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[2]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[3]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[4]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[5]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[6]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[7]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[8]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[9]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[10]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[11]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[12]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[13]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[14]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[15]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[16]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[17]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[18]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[19]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[20]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[21]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[22]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[23]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[24]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[25]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[26]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[27]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[28]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[29]->SetWidth (  (float)screen_001->getWidth() );

	printf ("002: initialize_vAxex_2D_001: set param: 005\r\n");

	printf("002: int initialize_vAxex_2D_001() ends.");

	return 0;
}

int initialize_vAxex_2D_001_org () {

	printf("int initialize_vAxex_2D_001() starts.");

	if ( screen_001 == nullptr ) {
		printf ("initialize_vAxex_2D_001: We are going to create vScreen as a object.\r\n");
		screen_001 = new vScreen ();
	}

	printf ("initialize_vAxex_2D_001: malloc: 001\r\n");
	AXEX_2D_001 = (vAxex_2D** ) malloc (sizeof(vAxex_2D*) * 30 );
	if ( AXEX_2D_001 == nullptr ) {
		printf("we cannot malloc memories as AXEX_2D_001.\r\n");
		exit(-1);
	}
	printf ("initialize_vAxex_2D_001: malloc: 002\r\n");
	printf ("initialize_vAxex_2D_001: set param: 001\r\n");
	AXEX_2D_001[0] = new vAxex_2D ( 358.526581f, 440.931427f, 19.409163f, 281.035797f );
	AXEX_2D_001[1] = new vAxex_2D ( 286.512665f, 205.333420f, 14.238716f, 269.707336f );
	AXEX_2D_001[2] = new vAxex_2D ( 108.304085f, 202.828461f, 15.178076f, 232.383194f );
	AXEX_2D_001[3] = new vAxex_2D ( 290.086975f, 176.929230f, 13.731193f, 250.389114f );
	AXEX_2D_001[4] = new vAxex_2D ( 3.945433f, 416.599640f, 15.201880f, 103.668327f );
	AXEX_2D_001[5] = new vAxex_2D ( 100.139778f, 168.696548f, 19.166235f, 167.329941f );
	AXEX_2D_001[6] = new vAxex_2D ( 340.596344f, 322.524506f, 12.938627f, 128.797272f );
	AXEX_2D_001[7] = new vAxex_2D ( 273.738831f, 301.635193f, 17.083651f, 182.039856f );
	AXEX_2D_001[8] = new vAxex_2D ( 10.371410f, 457.763000f, 17.043673f, 254.875336f );
	AXEX_2D_001[9] = new vAxex_2D ( 41.114536f, 382.013611f, 19.942625f, 125.855278f );
	AXEX_2D_001[10] = new vAxex_2D ( 194.810638f, 108.152718f, 10.625935f, 186.745804f );
	AXEX_2D_001[11] = new vAxex_2D ( 78.283638f, 383.258759f, 16.004211f, 107.013153f );
	AXEX_2D_001[12] = new vAxex_2D ( 457.435822f, 340.234985f, 11.757256f, 156.526382f );
	AXEX_2D_001[13] = new vAxex_2D ( 239.401840f, 267.884155f, 10.465102f, 242.655716f );
	AXEX_2D_001[14] = new vAxex_2D ( 36.192513f, 132.909332f, 15.228736f, 218.137146f );
	AXEX_2D_001[15] = new vAxex_2D ( 569.353333f, 109.266029f, 17.838984f, 115.851311f );
	AXEX_2D_001[16] = new vAxex_2D ( 496.011230f, 9.536424f, 15.560167f, 266.826385f );
	AXEX_2D_001[17] = new vAxex_2D ( 476.186401f, 33.633839f, 15.589770f, 157.667770f );
	AXEX_2D_001[18] = new vAxex_2D ( 141.234772f, 209.654831f, 11.255531f, 183.718369f );
	AXEX_2D_001[19] = new vAxex_2D ( 543.708008f, 461.850037f, 19.014862f, 154.158142f );
	AXEX_2D_001[20] = new vAxex_2D ( 28.203985f, 120.897247f, 10.313730f, 105.316322f );
	AXEX_2D_001[21] = new vAxex_2D ( 583.885010f, 251.301620f, 17.377850f, 278.429504f );
	AXEX_2D_001[22] = new vAxex_2D ( 457.709290f, 410.930511f, 16.984467f, 218.070007f );
	AXEX_2D_001[23] = new vAxex_2D ( 329.404572f, 417.830139f, 11.290933f, 247.630234f );
	AXEX_2D_001[24] = new vAxex_2D ( 107.425156f, 179.214447f, 19.775383f, 277.874084f );
	AXEX_2D_001[25] = new vAxex_2D ( 206.197693f, 477.553650f, 11.348613f, 205.032501f );
	AXEX_2D_001[26] = new vAxex_2D ( 364.600983f, 168.974884f, 10.711997f, 254.600662f );
	AXEX_2D_001[27] = new vAxex_2D ( 265.808899f, 368.756378f, 18.009277f, 127.027191f );
	AXEX_2D_001[28] = new vAxex_2D ( 138.305008f, 39.039276f, 15.844905f, 101.666313f );
	AXEX_2D_001[29] = new vAxex_2D ( 478.080994f, 273.773010f, 12.728660f, 155.165253f );

	printf ("initialize_vAxex_2D_001: set param: 002\r\n");

	AXEX_2D_001[0]->SetUp ( 0.050249f, 0.032792f, 0.200644f );
	AXEX_2D_001[1]->SetUp ( 0.252678f, 0.224174f, 0.043443f );
	AXEX_2D_001[2]->SetUp ( -0.465728f, 0.266015f, -0.192648f );
	AXEX_2D_001[3]->SetUp ( 0.426450f, -0.018143f, 0.151204f );
	AXEX_2D_001[4]->SetUp ( 0.415159f, -0.029069f, -0.229942f );
	AXEX_2D_001[5]->SetUp ( -0.054521f, 0.284265f, 0.422544f );
	AXEX_2D_001[6]->SetUp ( -0.204703f, 0.059709f, 0.381558f );
	AXEX_2D_001[7]->SetUp ( -0.218680f, -0.145314f, 0.210379f );
	AXEX_2D_001[8]->SetUp ( -0.266015f, -0.062304f, -0.136402f );
	AXEX_2D_001[9]->SetUp ( 0.392178f, -0.364803f, -0.322718f );
	AXEX_2D_001[10]->SetUp ( -0.034501f, 0.173238f, -0.114673f );
	AXEX_2D_001[11]->SetUp ( -0.413511f, -0.059160f, 0.093524f );
	AXEX_2D_001[12]->SetUp ( -0.279656f, -0.110614f, -0.179067f );
	AXEX_2D_001[13]->SetUp ( 0.448241f, -0.412778f, -0.252281f );
	AXEX_2D_001[14]->SetUp ( 0.113208f, 0.237144f, 0.420682f );
	AXEX_2D_001[15]->SetUp ( 0.055040f, -0.456114f, -0.438810f );
	AXEX_2D_001[16]->SetUp ( -0.421537f, 0.255943f, -0.275201f );
	AXEX_2D_001[17]->SetUp ( 0.247703f, 0.091144f, 0.222404f );
	AXEX_2D_001[18]->SetUp ( -0.350063f, -0.015000f, 0.382168f );
	AXEX_2D_001[19]->SetUp ( -0.282342f, 0.428556f, -0.251366f );
	AXEX_2D_001[20]->SetUp ( 0.115253f, 0.479369f, 0.160665f );
	AXEX_2D_001[21]->SetUp ( -0.200613f, 0.325098f, 0.453063f );
	AXEX_2D_001[22]->SetUp ( 0.361721f, 0.034959f, 0.486969f );
	AXEX_2D_001[23]->SetUp ( 0.207389f, -0.158132f, -0.023545f );
	AXEX_2D_001[24]->SetUp ( -0.317438f, 0.062120f, 0.446989f );
	AXEX_2D_001[25]->SetUp ( 0.170827f, -0.482330f, -0.039659f );
	AXEX_2D_001[26]->SetUp ( -0.433073f, 0.290643f, -0.052232f );
	AXEX_2D_001[27]->SetUp ( -0.383877f, -0.181997f, -0.287805f );
	AXEX_2D_001[28]->SetUp ( -0.331568f, -0.031388f, -0.194937f );
	AXEX_2D_001[29]->SetUp ( -0.146199f, 0.226279f, 0.474212f );

	printf ("initialize_vAxex_2D_001: set param: 003\r\n");

	AXEX_2D_001[0]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[1]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[2]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[3]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[4]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[5]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[6]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[7]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[8]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[9]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[10]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[11]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[12]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[13]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[14]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[15]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[16]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[17]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[18]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[19]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[20]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[21]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[22]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[23]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[24]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[25]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[26]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[27]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[28]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );
	AXEX_2D_001[29]->SetEye (  screen_001->eye.x, screen_001->eye.y, screen_001->eye.z );

	printf ("initialize_vAxex_2D_001: set param: 004\r\n");

	AXEX_2D_001[0]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[1]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[2]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[3]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[4]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[5]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[6]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[7]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[8]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[9]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[10]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[11]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[12]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[13]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[14]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[15]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[16]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[17]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[18]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[19]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[20]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[21]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[22]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[23]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[24]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[25]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[26]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[27]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[28]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );
	AXEX_2D_001[29]->SetCenter (  screen_001->C.x, screen_001->C.y, screen_001->C.z );

	printf ("initialize_vAxex_2D_001: set param: 005\r\n");

	AXEX_2D_001[0]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[1]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[2]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[3]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[4]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[5]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[6]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[7]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[8]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[9]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[10]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[11]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[12]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[13]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[14]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[15]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[16]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[17]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[18]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[19]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[20]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[21]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[22]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[23]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[24]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[25]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[26]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[27]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[28]->SetHeight (  (float)screen_001->getHeight() );
	AXEX_2D_001[29]->SetHeight (  (float)screen_001->getHeight() );

	printf ("initialize_vAxex_2D_001: set param: 005\r\n");

	AXEX_2D_001[0]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[1]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[2]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[3]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[4]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[5]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[6]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[7]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[8]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[9]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[10]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[11]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[12]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[13]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[14]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[15]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[16]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[17]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[18]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[19]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[20]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[21]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[22]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[23]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[24]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[25]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[26]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[27]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[28]->SetWidth (  (float)screen_001->getWidth() );
	AXEX_2D_001[29]->SetWidth (  (float)screen_001->getWidth() );

	printf ("initialize_vAxex_2D_001: set param: 006\r\n");

	AXEX_2D_001[0]->Calculation_Axex ( );
	AXEX_2D_001[1]->Calculation_Axex ( );
	AXEX_2D_001[2]->Calculation_Axex ( );
	AXEX_2D_001[3]->Calculation_Axex ( );
	AXEX_2D_001[4]->Calculation_Axex ( );
	AXEX_2D_001[5]->Calculation_Axex ( );
	AXEX_2D_001[6]->Calculation_Axex ( );
	AXEX_2D_001[7]->Calculation_Axex ( );
	AXEX_2D_001[8]->Calculation_Axex ( );
	AXEX_2D_001[9]->Calculation_Axex ( );
	AXEX_2D_001[10]->Calculation_Axex ( );
	AXEX_2D_001[11]->Calculation_Axex ( );
	AXEX_2D_001[12]->Calculation_Axex ( );
	AXEX_2D_001[13]->Calculation_Axex ( );
	AXEX_2D_001[14]->Calculation_Axex ( );
	AXEX_2D_001[15]->Calculation_Axex ( );
	AXEX_2D_001[16]->Calculation_Axex ( );
	AXEX_2D_001[17]->Calculation_Axex ( );
	AXEX_2D_001[18]->Calculation_Axex ( );
	AXEX_2D_001[19]->Calculation_Axex ( );
	AXEX_2D_001[20]->Calculation_Axex ( );
	AXEX_2D_001[21]->Calculation_Axex ( );
	AXEX_2D_001[22]->Calculation_Axex ( );
	AXEX_2D_001[23]->Calculation_Axex ( );
	AXEX_2D_001[24]->Calculation_Axex ( );
	AXEX_2D_001[25]->Calculation_Axex ( );
	AXEX_2D_001[26]->Calculation_Axex ( );
	AXEX_2D_001[27]->Calculation_Axex ( );
	AXEX_2D_001[28]->Calculation_Axex ( );
	AXEX_2D_001[29]->Calculation_Axex ( );

	printf ("initialize_vAxex_2D_001: set param: 007\r\n");

	int b = create_vLine_Axex_2D_001 ();

	printf("int initialize_vAxex_2D_001() ends.");

	return 0;
}

int create_vLine_Axex_2D_001 () {
	vPoint* p_001 = nullptr;
	vPoint* p_002 = nullptr;
	vPoint* p_003 = nullptr;
	vPoint* p_004 = nullptr;
	vPoint* p_005 = nullptr;
	vPoint* p_006 = nullptr;

	printf("int create_vLine_Axex_2D_001() starts.\r\n");

	if ( Line_AXEX == nullptr ) {
		Line_AXEX = (vLine**) malloc ( sizeof(vLine*) * 3 * 30 );
		if ( Line_AXEX == nullptr ) {
			printf ("We cannot allocate memories as the Line_AXEX.\r\n");
			exit(-1);
		}
	}

	printf("int create_vLine_Axex_2D_001() middle: 001\r\n");
	for ( int i = 0; i<30; i++ ) {

		printf("int create_vLine_Axex_2D_001() middle: 002\1-01 %d/30\r\n", i);

		p_001 = Calc.scalize( AXEX_2D_001[i]->right, 20.0f );
		p_002 = Calc.scalize( AXEX_2D_001[i]->up   , 20.0f );
		p_003 = Calc.scalize( AXEX_2D_001[i]->depth, 20.0f ); 

		printf("int create_vLine_Axex_2D_001() middle: 002\r\n");

		p_004 = Calc.add( AXEX_2D_001[i]->right, AXEX_2D_001[i]->center );
		p_005 = Calc.add( AXEX_2D_001[i]->up   , AXEX_2D_001[i]->center );
		p_006 = Calc.add( AXEX_2D_001[i]->depth, AXEX_2D_001[i]->center ); 

		printf("int create_vLine_Axex_2D_001() middle: 003\r\n");

		Line_AXEX[ i*3 + 0] = new vLine ( p_001, p_004 );
		Line_AXEX[ i*3 + 1] = new vLine ( p_002, p_005 );
		Line_AXEX[ i*3 + 2] = new vLine ( p_003, p_006 );

		printf("int create_vLine_Axex_2D_001() middle: 004\r\n");

		Put_Memories_vPoint ( (vPoint*) p_001 );
		printf("int create_vLine_Axex_2D_001() middle: 004-01\r\n");

		Put_Memories_vPoint ( (vPoint*) p_002 );
		Put_Memories_vPoint ( (vPoint*) p_003 );
		Put_Memories_vPoint ( (vPoint*) p_004 );
		Put_Memories_vPoint ( (vPoint*) p_005 );
		Put_Memories_vPoint ( (vPoint*) p_006 );

		printf("int create_vLine_Axex_2D_001() middle: 005\r\n");
		Put_Memories_vLine ( (vLine*) Line_AXEX[ i*3 + 0] );
		printf("int create_vLine_Axex_2D_001() middle: 005-01\r\n");

		Put_Memories_vLine ( (vLine*) Line_AXEX[ i*3 + 1] );
		Put_Memories_vLine ( (vLine*) Line_AXEX[ i*3 + 2] );

		printf("int create_vLine_Axex_2D_001() middle: 006\r\n");

	}

	printf("int create_vLine_Axex_2D_001() ends.\r\n");
	return 0;
}



/***

Very thanks to:

search circle:
1: https://docs.microsoft.com/en-us/windows/win32/learnwin32/draw-circle-sample
2: https://www.daniweb.com/programming/software-development/code/216344/draw-a-circle-on-a-windows-form
3: https://stackoverflow.com/questions/14063463/win32-gdi-drawing-a-circle

a = Ellipse(DrawHDC,X-R,Y+R,X+R,Y-R);
Ellipse(backbuffDC, temp_shape.left, temp_shape.top, temp_shape.right, temp_shape.bottom);

***/
