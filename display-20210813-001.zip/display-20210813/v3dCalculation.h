#ifndef _V3DCALCULATION_
#define _V3DCALCULATION_

class v3dCalculation {

	public:
		int calculation_thread () ;
		int calculation_thread_002 () ;
		int calculation_thread_003 () ;
		int calculation_thread_004 () ;
		int calculation_thread_005 () ;
		int calculation_thread_006 () ;
		int calculation_thread_007 () ;
		int calculation_thread_008 () ;
		int calculation_thread_009 () ;
		int calculation_thread_010 ();
		int calculation_thread_011 ();
		int calculation_thread_012 ();
		int calculation_thread_013 ();
		int calculation_thread_014 ();
		int calculation_thread_015 ();
		int calculation_thread_016 ();
		int calculation_thread_017 ();
};

#endif
