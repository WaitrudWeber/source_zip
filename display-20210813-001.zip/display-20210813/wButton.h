#ifndef WBUTTON_H
#define WBUTTON_H

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

class wButton {
	public:
		int x, y, width, height;
		char* button_name;

	private:
		int mode;

	public:
		wButton(char* bn);
		void setButton( int xx, int yy, int h, int w);
		//int wdrawButton( HDC hdc, char *button_name, RECT rect );
		int aaa();
		int drawButton( HDC hdc );
		void setMode ( int m );
		void paintCanvas ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
};

#endif
