#ifndef _V_DISPLAY_cONTROLLER_001_H_
#define _V_DISPLAY_cONTROLLER_001_H_

#include "vBox.h"
#include "wCanvasController.h"

// 1. copy vDisplayController_001.h vDisplayController_001.cpp.
// 2. renumber by use of replace vDisplayController_001 to vDisplayController_002 in them above.
// 3. add Makefile vDisplayController_001.cpp.

// C:\Users\Beneton\Desktop\desktop-20220313-001\ppm-20220121

class vDisplayController_001 {

	private:
		vPoint bones_001[10];
		int bones_max = 10;
		int bones_max_index = 0;
		wCanvasController* canvas = nullptr;
		vCalculation Calc;
		vScreenCG screen_006;

//		vBox box( 0.0f, 0.0f, 100.0f, 100.0f );

	public:
		int SetCanvas ( wCanvasController *l_canvas ) ;
		int PrintBones () ;
		int DisplayBones_002 () ;
//		int DisplayPillar (9;

} ;

#endif

