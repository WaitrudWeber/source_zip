

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "array_counter.h"
#include "parse.h"

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "wEvent.h"
#include "wButton.h"
#include "wButtonController.h"
#include "wCanvasController.h"

#include "vDisplayController_002.h"



int vDisplayController_002::SetCanvas ( wCanvasController *l_canvas ) {
	this->canvas = l_canvas;
}

int vDisplayController_002::draw_canvas_buffer () {

	this->canvas->Set_Buffer( 10, 10, 0, 128);

	return 0;
}

int vDisplayController_002::malloc_main_002 () {
	char *string_001 = NULL;
	int i;
	FILE *fp = NULL;
	printf("int malloc_main_002 ( int argc, char** argv ) starts.\r\n");

	fp = fopen ( (char*) "001-malloc_main-002-02.txt", "wb" );

	//
	string_001 = (char*)char_string_012(10);
	for( i=0; i<10; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	int a = (int)mchar_string_002(string_001, 16);
	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	fclose(fp);
	printf("int malloc_main_002 ( int argc, char** argv ) ends.\r\n");
	return 0;
}

int vDisplayController_002::malloc_main_001 () {
	char *string_001 = NULL;
	int i;
	FILE *fp = NULL;
	printf("int malloc_main_001 ( int argc, char** argv ) starts.\r\n");

	fp = fopen ( (char*) "001-malloc_main-002.txt", "wb" );

	//
	string_001 = (char*)char_string(10);
	for( i=0; i<10; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	fclose(fp);
	printf("int malloc_main_001 ( int argc, char** argv ) ends.\r\n");
	return 0;
}

int vDisplayController_002::malloc_main () {
	char *string_001 = NULL;
	char *string_003 = NULL;
	int i;
	FILE *fp = NULL;
	printf("int main ( int argc, char** argv ) starts.\r\n");

	fp = fopen ( (char*) "001-malloc_main-001.txt", "wb" );

	//
	string_001 = (char*)char_string(10);
	for( i=0; i<10; i++ ) {
		fprintf(fp,"string[%d]=|%p|%d|\r\n", i, string_001+i, *(string_001+i));
	}

	string_003 = (char*)mchar_string(string_001, 16);
	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 03[%d]=|%p|%d|\r\n", i, string_003 + i, *(string_003+i));
	}

	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|%d|\r\n", i, string_003 + i, *(string_001 + i));
	}

	fclose(fp);
	printf("int main ( int argc, char** argv ) ends.\r\n");
	return 0;
}

int vDisplayController_002::realloc_main () {
	char *string_001 = NULL;
	char *string_003 = NULL;
	int i;
	FILE *fp = NULL;
	printf("int main ( int argc, char** argv ) starts.\r\n");

	fp = fopen ( (char*) "001-realloc_main-001.txt", "wb" );

	//
	string_001 = (char*)char_string(10);
	for( i=0; i<10; i++ ) {
		fprintf(fp,"string[%d]=|%p|\r\n", i, *(string_001+i));
	}

	string_003 = (char*)rechar_string(string_001, 16);
	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 03[%d]=|%p|\r\n", i, *(string_003+i));
	}

	for( i=0; i<16; i++ ) {
		fprintf(fp,"string 01[%d]=|%p|\r\n", i, *(string_001 + i));
	}

	fclose(fp);
	printf("int main ( int argc, char** argv ) ends.\r\n");
	return 0;
}

// char* vDisplayController_002::rechar_string (char* string_002, int num)
// int vDisplayController_002::realloc_main ()
char* vDisplayController_002::rechar_string (char* string_002, int num) {
	printf("char* rechar_string (char* string_002, int num) starts.\r\n");

	string_002 = (char*) realloc ( string_002, num );
	if ( string_002 == NULL ) {
		printf("13: |%p|\r\n", string_002);
		exit(-1);
	}

	printf("char* rechar_string (char* string_002, int num) ends.\r\n");
	return string_002;
}

// char* vDisplayController_002::rechar_string (char* string_002, int num)
// int vDisplayController_002::realloc_main ()
char* vDisplayController_002::mchar_string (char* string_002, int num) {
	char *tmp, *w;
	printf("char* mchar_string (char* string_002, int num) starts.\r\n");

	tmp = (char*) malloc ( num );
	if ( tmp == NULL ) {
		printf("14: |%p|\r\n", tmp);
		exit(-1);
	}
	w = string_002;
	string_002 = tmp;
	free(w);
	printf("char* mchar_string (char* string_002, int num) ends.\r\n");
	return string_002;
}

// char* vDisplayController_002::rechar_string (char* string_002, int num)
// int vDisplayController_002::realloc_main ()
int vDisplayController_002::mchar_string_001 (char* string_002, int num) {
	char *tmp, *w;
	printf("int mchar_string_001 (char* string_002, int num) starts.\r\n");

	tmp = (char*) malloc ( num );
	if ( tmp == NULL ) {
		printf("14: |%p|\r\n", tmp);
		exit(-1);
	}
	w = string_002;
	string_002 = tmp;
	free(w);
	printf("int mchar_string_001 (char* string_002, int num) ends.\r\n");
	return 0;
}

// char* vDisplayController_002::rechar_string (char* string_002, int num)
// int vDisplayController_002::realloc_main ()
int vDisplayController_002::mchar_string_002 (char* string_002, int num) {
	char *tmp, *w;
	printf("int mchar_string_002 (char* string_002, int num) starts.\r\n");

	printf("001: w|%p| tmp|%p| param: string_002|%p|\r\n", w, tmp, string_002 );
	tmp = char_string_012(num);
	w = tmp;
	string_002 = tmp;
	aFree(w);
	printf("002: w|%p| tmp|%p| param: string_002|%p|\r\n", w, tmp, string_002 );
	printf("int mchar_string_002 (char* string_002, int num) ends.\r\n");
	return 0;
}

int vDisplayController_002::create_img_buffer_print_its_adress (char* filename, int width, int height, int flag) {
	float* img_003 = NULL;
	FILE *fp;
	float* f;
	int i;

	fp = fopen ( (char*) filename, "wb" );
	if (fp == NULL) {
		printf("file: %s is unstable for its open as wb.\r\n", filename );
		exit(-1);
	}
	img_003 = (float*) malloc(sizeof(float*)*width*height);
	if (img_003 == NULL) {
		printf("img_003 is not memoried(allocated).\r\n");
		exit(-1);
	}

	for(i=0; i<width*height; i++) {
		f = (float*)(img_003 + i );
		fprintf( fp, "|%p|\r\n", f);
	}

	fclose(fp);
}


// int Set_Buffer (int xx, int yy, int col, unsigned char vv ) ;
// display_004.DisplayBonesGear (); ->
// 0: red
// 1: blue
// 2: green
// 3: transparent
//
int vDisplayController_002::create_img_buffer_002 (char* filename, int width, int height, int flag) {
	float*** img_003 = NULL;
	int i, j;

	printf("int vDisplayController_002::create_img_buffer_002 (char* filename, int width, int height, int flag) starts.\r\n");

	img_003 = (float***) malloc(sizeof(float***)*width);
	if (img_003==NULL) {
		printf("img_003 is NULL\r\n");
		exit(-1);
	}
	for ( i=0; i<width; i++ ) {
		img_003[i] = (float**) malloc(sizeof(float**)*height);
		if (img_003[i]==NULL) {
			printf("img_003[%d] is NULL\r\n", i);
			exit(-1);
		}
		for ( j=0; j<height; j++ ) {
			img_003[i][j] = (float*) malloc (sizeof(float*) * 4 );
			if (img_003[i][j]==NULL) {
				printf("img_003[%d][%d] is NULL\r\n", i, j);
				exit(-1);
			}
		}
	}

	ppm_img = (float***)img_003;
	ppm_width = width;
	ppm_height = height;
	ppm_filename = filename;


	printf("int vDisplayController_002::create_img_buffer_002 (char* filename, int width, int height, int flag) ends.\r\n");
	return 0;
}

// display_004.DisplayBonesGear (); ->
// 0: red
// 1: blue
// 2: green
// 3: transparent
//
int vDisplayController_002::create_img_buffer (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) {
	float*** img_003 = NULL;
	int i, j;

	printf("int vDisplayController_002::create_img_buffer (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) starts.\r\n");

	img_003 = (float***) malloc(sizeof(float***));
	for ( i=0; i<width; i++ ) {
		img_003[i] = (float**) malloc(sizeof(float**));
		for ( j=0; j<height; j++ ) {
			img_003[i][j] = (float*) malloc (sizeof(float*) * 4 );
		}
	}

	printf("int vDisplayController_002::create_img_buffer (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) ends.\r\n");
	return 0;
}

// 	if ( 0>i && 0>j && i>=width && j>=height ) continue;
//  if ( a<0.0 && i<0 ) break;
//  if ( a<0.0 && j<0 ) break;
//  if ( a>0.0 && i>=width ) break;
//  if ( a>0.0 && j>=height ) break;
// img[x][y][red]
int vDisplayController_002::draw_line_002 (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) {
	int i, j, plus;
	float up, down, a, axex, abs_a;

	printf("int vDisplayController_002::write_ppm_002 (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) starts.\r\n");

	down = x2 - x1;
	up = y2 - y1;
	a = up / down;
	abs_a = abs(a);

	if ( a < 0.0f ) plus=1;
	else plus=-1;

	printf("a=%0.5f abs_a=%f plus=%d\r\n", a, abs_a, plus );
	if ( abs_a < 0.5 ) {
		for ( i= 0; i<x1; i++ ) {
			if ( 0>i && 0>j && i>=width && j>=height ) continue;
			printf("i:%d\r\n", i);
			axex += a;
			img[i][(int)axex][2] = 1.0f;
		}
	} else {
		for ( j= 0; j<y1; j++ ) {
			if ( 0>i && 0>j && i>=width && j>=height ) continue;
			printf("j:%d\r\n", j);
			axex += a;
			img[(int)axex][j][2] = 1.0f;
		}
	}

	printf("int vDisplayController_002::write_ppm_002 (char* filename, float*** img, int x1, int y1, int x2, int y2, int width, int height, int flag) ends.\r\n");
}

//
int vDisplayController_002::init_buffer (char* buffer, int size, int flag) {

	printf("int vDisplayController_002::init_buffer (char* buffer, int size, int flag) starts.\r\n");

	for ( int i=0; i<size; i++ )
		buffer[i] = flag;

	printf("int vDisplayController_002::init_buffer (char* buffer, int size, int flag) ends.\r\n");
	return 0;
}

//
int vDisplayController_002::read_ppm_002 (char* filename, float*** img, int* width, int* height, int flag) {
	int i, j;
	FILE *fp;
	FILE *start_fp;
	char w[1];
	char head[128];
	int count = 0, index = 0;
	int mode = 0;
	int a;
	int *density;

	printf("int read_ppm_002 starts.\n");

	for ( i = 0; i<128; i++ )
		head[i] = 0;

	fp = fopen ( (char*) filename, "rb" );
	if ( fp == NULL ) {
		printf("fp=%d |%s|\n", fp, filename);
		exit(-1);
	}

	for ( i = 0; i<128 && count<3; i++ ) {
		m_fread( &head[i], 1, fp );
		printf("|%c|%d|%s\ncount=%d\n", head[i], head[i], head, count );
		switch ( head[i] ) {
		case '\r':
			if ( m_compare( (char*)head, (char*)"P6" ) == 1 && count == 0 ) {
				printf("P6\n");
				count++;
				i = 0;
				exit(-1);
			} else if ( '0'< head[0] < '9') {
				printf("%s\n", head);
				count++;
				i = 0;
				exit(-1);
			} else if ( '#'< head[0] ) {
				printf("%s\n", head);
				i = 0;
				exit(-1);
			}
			printf("line end \\r|%d|\n", '\r' );
			exit(-1);
			break;
		case '\n':
			if ( m_start_with ( (char*)head, (char*)"P6" ) == 1 && count == 0 ) {
				printf("P6\n");
				count++;
				i = -1;
				a = init_buffer( (char*)head, 128, 0 );
			} else if ( '0'< head[0] && head[0] < '9' ) {
				printf("head: %s |%d|<->|%d| |%d|\n", head, '0', '9', head[i] );
				switch ( count ) {
				case 1:
					a = param_int ( head, width, height);
					break;
				case 2:
					a = param_int ( head, density );
					break;
				}
				count++;
				i = -1;
				a = init_buffer( (char*)head, 128, 0 );
			} else if ( '#'== head[0] ) {
				printf("#head: %s\n", head);
				i = -1;
				a = init_buffer( (char*)head, 128, 0 );
			}
			printf("line end \\n|%d|\n", '\n' );
			break;
		}
	}

	fclose(fp);

	printf("int read_ppm_002 ends.\n");

	return 0;
}


int vDisplayController_002::param_int (char* head, int* width, int* height) {
	int i, j;
	char a[5], b[5];
	printf("int vDisplayController_002::param_int (char* head, int* width, int* height) starts.\r\n");

	for ( i=0; i<5; i++ ) {
		a[i] = head[i];
		if ( head[i] == ' ' ) {
			a[i] = '\0';
			break;
		}
	}

	printf("num1 %d a %s int|%d|\r\n", i, a, atoi(a) );

	i++;
	for ( j=0; j<5; j++ ) {
		b[j] = head[i+j];
		if ( head[i+j] == '\0' || head[i+j] < '0' || head[i+j] > '9' ) {
			b[j] = '\0';
			break;
		}
	}

	printf("num2 %d b[0] %d b |%s| int|%d|\r\n", j, b[0], b, atoi(b) );

	*width = atoi ( a );
	*height = atoi ( b );

	printf("int vDisplayController_002::param_int (char* head, int* width, int* height) ends.\r\n");
	return 0;
}


int vDisplayController_002::param_int ( char* head, int* density ) {
	int i;
	printf("int vDisplayController_002::param_int (char* head,  int* density ) starts.\r\n");

	for ( i=0; i<5; i++ ) {
		if ( head[i] == '\n' ) break;
	}

	printf("num %d head %s\r\n", i, head);
//	printf("atoi(head)=%d\r\n", atoi ( (const char*)head ));
//*density = atoi ( (const char*)head );
//	printf("density=%d\r\n", *density );

	printf("int vDisplayController_002::param_int (char* head,  int* density ) ends.\r\n");
	return 0;
}

// C:\Users\Beneton\Desktop\desktop-20220313-001\ppm-20220121
//
//
int vDisplayController_002::write_ppm_002 (char* filename, float*** img, int width, int height, int flag) {
	int i, j;
	FILE *fp;
	FILE *start_fp;
	char w[1];
	char head[128];
	int count = 0, index = 0;

	printf("int write_ppm_002 starts.\n");


	for ( i = 0; i<128; i++ )
		head[i] = 0;

	fp = fopen ( (char*) filename, "wb" );
	start_fp = fp;

	sprintf( head, "P6\r%d %d\r%d\r", width, height, 255 ); 

	// count the buffer.
	for ( i = 0; i<128; i++ ) {
		if ( head[i] == '\r' )
			count++; 

		if ( count == 3 ) {
			index = i;
			break;
		}
	}

	printf("index %d flag %d filename %s\n", index, flag, filename );
	printf("start|fp| to |fp| = |%p| to |%p|\n", start_fp, fp);

	fwrite( (char*)head, 128, index, fp ); 

	printf("start|fp| to |fp| = |%p| to |%p|\n", start_fp, fp);

	if ( flag == 1 ) {
		for ( j = 0; j< height; j++ ) {
			for ( i = 0; i< width; i++ ) {
				printf(" i, j = %d, %d\n", i, j );
				w[0] = 255.0f * img[j][i][0];
				fwrite( (char*) w, 1, 1,  fp );
				w[0] = 255.0f * img[j][i][1];
				fwrite( (char*) w, 1, 1,  fp );
				w[0] = 255.0f * img[j][i][2];
				fwrite( (char*) w, 1, 1,  fp );
			}
		}
	} else if ( flag == 0 ) {
		printf("We are going to Print the message in the header.\n");
		fprintf(fp, "#Print Only Header flag %d.\n", flag);
	}

	printf("start|fp| to |fp| = |%p| to |%p|\n", start_fp, fp);
	fclose (fp);

	printf("int write_ppm_002 ends. fp=|%p|\n", fp);

	return 0;
}

// position
// demsity
// integral: https://en.wikipedia.org/wiki/Integral
int vDisplayController_002::DisplaySolid (vPoint center ) {
	float a, c, x, y;
	float m_pi = 3.141592;

	printf("vDisplayController_002:: DisplaySolid (vPoint center ) starts.\r\n");
	c = 20.0f;
	for ( int i=0; i<10; i++ ) {
		printf("i %d / 10\r\n", i);
		a = i / 5;
		a = m_pi / a;
		printf("a=%f\r\n", a );
		x = c * sin(a);
		y = c * cos(a);
		this->draw_line_002 ( this->ppm_filename, ppm_img, (int)x, (int)y, (int)center.x, (int)center.y, this->ppm_width,  this->ppm_height, 0 );
	}
	printf("vDisplayController_002::DisplaySolid (vPoint center ) ends.\r\n");
}

int vDisplayController_002::DisplayLightHouse () {
	//vPoint bones_001[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;
	int slide_pow = 10.0f;
	vPoint *slide = nullptr;
	int upward_pow = 50.0f;
	vPoint *upward = nullptr;

	printf("vDisplayController_002:: DisplayLightHouse () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	printf("01: this->canvas |%p|/nullptr|%p|\r\n", this->canvas, nullptr );
	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	// 
	slide = memorizevPoint ( 1.0f, 0.0f, 0.0f );
	upward = memorizevPoint ( 0.0f, 1.0f,0.0f );
	this->Calc.scale( slide, slide_pow );
	this->Calc.scale( upward, slide_pow );
	bones_001[ 0 ].setPoint ( 0.0f, 0.0f, 0.0f );
	bones_001[ 0 ].print();

	for ( int j=1; j<10; j++ ) {
		printf("j=%d\r\n", j);
		this->Calc.add( bones_001[ j*2 - 2], *slide, &bones_001[ j*2 - 1] );
		this->Calc.add( bones_001[ j*2 - 1], *upward, &bones_001[ j*2 ] );
		bones_001[ j*2 - 1 ].print();
		bones_001[ j*2 ].print();
//		exit(-1);
	}
//	free_point ( slide );
//	free_point ( upward );
//	exit(-1);

	printf("01: this->canvas |%p|\r\n", this->canvas );
	this->canvas->AXEX_2D_002_Index = 0;
	printf("02: this->canvas->AXEX_2D_002_Index %d\r\n", this->canvas->AXEX_2D_002_Index);
	exit(-1);
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("vDisplayController_002:: DisplayLightHouse () ends.\r\n");
	exit(-1);
	return 0;
}

int vDisplayController_002::DisplayPillar () {
	int i;
	printf("int vDisplayController_002::DisplayPillar () starts.\r\n");
	vBox** box_001 = nullptr;

	box_001 = (vBox**)malloc ( sizeof(vBox*) * 8 );
	if ( box_001 == nullptr ) {
		printf("box_001 array is null \r\n.");
		exit(-1);
	}

	for ( i=0; i<8; i++ ) {
		box_001[i] = new vBox ( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);
	}

	printf("int vDisplayController_002::DisplayPillar () ends.\r\n");
	return 1;
}

// [1].Calculation_Axex_002 
int vDisplayController_002::DisplayAxex () {
	printf("int vDisplayController_002::DisplayAxex () starts.\r\n");

	vAxex_2D* local_axex = new vAxex_2D ();
	local_axex->SetCenter( 1.0, 1.0, 1.0 );
	local_axex->SetDepth( 0.0, 0.0, 5.0 );
// x	local_axex->Calculation_Axex_002 ();
	local_axex->Calculation_Axex_002 ();

//	local_axex->right->print ();
//	local_axex->up->print ();
//	local_axex->depth->print ();

	printf("int vDisplayController_002::DisplayAxex () ends.\r\n");
	return 1;
}

int vDisplayController_002::DisplayBones_002 () {
	//vPoint bones_001[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;

	printf("vDisplayController_002:: DisplayBones_002 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		this->canvas = new wCanvasController ();
		printf("this->canvas is allocated |%p|.\r\n", this->canvas );
	}


	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones_001[0].setPoint (  0.0f,  0.0f,    0.0f );
	bones_001[1].setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones_001[1], bones_001[0], &w1 );
	for ( int j=2; j<10; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones_001[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones_001[j-1].print();
			bones_001[j].print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones_001[ j ].setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("vDisplayController_002:: DisplayBones_002 () ends.\r\n");
//	exit(-1);
	return 0;
}

//
int vDisplayController_002::SetBaseAxex () {
	printf("vDisplayController_002:: SetBaseAxex () starts.\r\n");

	if ( axex_line_3d_002 == nullptr ) {
		printf("vDisplayController:: SetBaseAxex () allocation: %d\r\n", axex_line_max);
		axex_line_3d_002 = (vLine**) malloc ( sizeof (vLine*) * axex_line_max );
		printf("vDisplayController:: SetBaseAxex () allocation: end\r\n");
	}

	axex_line_3d_002[0] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
	axex_line_3d_002[1] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
	axex_line_3d_002[2] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );

	printf("vDisplayController:: All in 3D has just finished to set.\r\n");

	this->DisplayBaseAxex();

	printf("vDisplayController_002:: SetBaseAxex () ends.\r\n");
	return 0;
}

int vDisplayController_002::DisplayBaseAxex () {
	float x1, x2, y1, y2;
	printf("vDisplayController_002:: DisplayBaseAxex () starts.\r\n");

	printf("axex_line_3d_002 |%p|\r\n", axex_line_3d_002 );
	if ( axex_line_3d_002 == nullptr) {
		printf("axex_line_3d_002 is nullptr.\r\n");
		exit(-1);
	}
	this->canvas->AXEX_2D_LINE_Index = 0;
	for ( int j=0; j<axex_line_max; j++ ) {
		printf("002: code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( *(axex_line_3d_002[j]->p1), &x1, &y1 );
		a = screen_006.get_cooordinate_on_screen ( *(axex_line_3d_002[j]->p2), &x2, &y2 );
		this->canvas->Set_Axex_Line ( x1, y1, x2, y2 );
		printf("002: code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_LINE_Index );
	}

	printf("vDisplayController_002:: DisplayBaseAxex () ends.\r\n");
	return 0;
}

int vDisplayController_002::DisplayBaseAxexFixed () {
	float add_y;
	printf("vDisplayController_002:: DisplayBaseAxexFixed () starts.\r\n");

	add_y = 0.0f;
	this->canvas->AXEX_2D_LINE_Index = 0;
	for ( int j=0; j<axex_line_max; j++ ) {
		this->canvas->Set_Axex_Line ( 50.0f, 50.f, 300.0f + add_y, 300.0f );
		add_y += 50.0f;
	}

	printf("vDisplayController_002:: DisplayBaseAxexFixed () ends.\r\n");
	return 0;
}

int vDisplayController_002::SetEye (float x, float y, float z) {
	printf("vDisplayController_002:: SetEye () starts.\r\n");

	vPoint* eye = memorizevPoint( x, y, z );
	screen_006.setEye ( *eye );
	screen_006.calculation_up_UV();

	//---
	this->Set_Canvas_Bones();
	//---

	this->DisplayBaseAxex();

	free_point ( eye );

	printf("vDisplayController_002:: SetEye () ends.\r\n");
	return 0;
}

int vDisplayController_002::Set_Canvas_Bones () {
	float x, y;
	printf("vDisplayController_002:: Set_Canvas_Bones () starts.\r\n");
	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}
	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);
	printf("vDisplayController_002:: Set_Canvas_Bones () ends.\r\n");
	return 0;
}


//int vDisplayController_002::SetCanvasBones_002 () {
//
//	return 0;
//}

/*int vDisplayController_002::SetCanvasBones () {
	printf("vDisplayController_002:: SetCanvasBones () starts.\r\n");
	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);
	printf("vDisplayController_002:: SetCanvasBones () ends.\r\n");
}*/

//
int vDisplayController_002::DisplayBonesGear () {
	//vPoint bones_001[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;

	printf("vDisplayController_002:: DisplayBonesGear () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}

	/*
	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones_001[0].setPoint (  0.0f,  0.0f,    0.0f );
	bones_001[1].setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones_001[1], bones_001[0], &w1 );
	for ( int j=2; j<10; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones_001[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones_001[j-1].print();
			bones_001[j].print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones_001[ j ].setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}*/

	float radius = 100.0f;
	float theta = 0.0f;
	int num = 10;
	float aM_PI = 3.14159265358979;

	for ( int i=0; i< 10; i++ ) {
		x = radius * sin ( i * 2.0* aM_PI/ (double)num );
		y = radius * cos ( i * 2.0* aM_PI/ (double)num );
		bones_001[ i ].setPoint( x, y, 0.0f );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("vDisplayController_002:: DisplayBonesGear () ends.\r\n");
//	exit(-1);
	return 0;
}
//

// 1. copy this function as _003.
// 2. use aFree in vCaculation.
// 3. set a moved point as selected.
int vDisplayController_002::MoveSelectedPoint_002 () {
	float x, y;
	vCalculation calc;
	const float c = 5.0f;
	vPoint* range_001;

	printf("int vDisplayController::MoveSelectedPoint_002 () starts.\r\n");

	vPoint* up_001 = &(screen_006.up);
	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones_001[selected] );

	//scalize * = *, *
	range_001 = calc.scalize ( up_001, c );

	// ADD calculation * = * , *
	vPoint* moved_point = calc.add ( selected_point, range_001 );

	printf("selected_point=");
	selected_point->print();

	printf("up_001=");
	up_001->print();


	printf("moved_point=");
	moved_point->print();

	// convert value, p, p
	int a = screen_006.get_cooordinate_on_screen ( *moved_point, &x, &y );
	int stored = this->canvas->AXEX_2D_002_Index;
	this->canvas->AXEX_2D_002_Index = selected;
	this->canvas->Set_vAxex_2D( x, y );
	this->canvas->AXEX_2D_002_Index = stored;

	printf("1002 x, y = %f, %f\r\n", x, y);

	printf("int vDisplayController::MoveSelectedPoint_002 () ends.\r\n");
	return 0;
}
// From u to x
// 1. copy this function as _003.
// 2. use aFree or free_point in vCaculation.
// 3. set a moved point as selected.
//
int vDisplayController_002::MoveSelectedPoint_003 () {
	float x, y;
	vCalculation calc;
	const float c = 50.0f;
	vPoint* range_001;

	printf("int vDisplayController_002::MoveSelectedPoint_002 () starts.\r\n");

	vPoint* up_001 = &(screen_006.up);
	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones_001[selected] );

	//scalize * = *, *
	range_001 = calc.scalize ( up_001, c );

	// ADD calculation * = * , *
	vPoint* moved_point_003 = calc.add ( selected_point, range_001 );
	this->bones_001[ selected ].setPoint( moved_point_003->x, moved_point_003->y, moved_point_003->z );

	printf("selected_point=");
	selected_point->print();

	printf("up_001=");
	up_001->print();

	printf("range_001=");
	range_001->print();

	printf("moved_point_003=");
	moved_point_003->print();

	printf("bones_001=");
	this->bones_001[ selected ].print();

	// convert value, p, p
	int a = screen_006.get_cooordinate_on_screen ( this->bones_001[ selected ], &x, &y );
	int stored = this->canvas->AXEX_2D_002_Index;
	this->canvas->AXEX_2D_002_Index = selected;
	this->canvas->Set_vAxex_2D( x, y );
	this->canvas->AXEX_2D_002_Index = stored;

	printf("1002 x, y = %f, %f\r\n", x, y);

	free_point ( up_001 );
	free_point ( selected_point );
	free_point ( moved_point_003 );
	//free_point ( range_001 );
	free ( range_001 );

	//printf("range_001_a=");
	//range_001->print();

	printf("int vDisplayController_002::MoveSelectedPoint_002 () ends.\r\n");
	return 0;
}

// 1. Add the switch-case for the axex.
int vDisplayController_002::MoveSelectedPoint_004 (int number) {
	float x, y;
	vCalculation calc;
	const float c = 50.0f;
	vPoint* range_001;

	printf("int vDisplayController_002::MoveSelectedPoint_004 () starts.\r\n");

	vPoint* mv_002 = nullptr;
	switch (number) {
		case 1:
			mv_002 = &(screen_006.up);
			break;
		case 2:
			mv_002 = &(screen_006.right);
			break;
		case 3:
			mv_002 = &(screen_006.depth);
			break;
		default:
			mv_002 = &(screen_006.up);
			break;
	}
	int selected = this->canvas->AXEX_2D_002_Index_Selected;
	vPoint* selected_point = &( this->bones_001[selected] );

	//scalize * = *, *
	range_001 = calc.scalize ( mv_002, c );

	// ADD calculation * = * , *
	vPoint* moved_point_003 = calc.add ( selected_point, range_001 );
	this->bones_001[ selected ].setPoint( moved_point_003->x, moved_point_003->y, moved_point_003->z );

	printf("selected_point=");
	selected_point->print();

	printf("mv_002=");
	mv_002->print();

	printf("range_001=");
	range_001->print();

	printf("moved_point_003=");
	moved_point_003->print();

	printf("bones_001=");
	this->bones_001[ selected ].print();

	// convert value, p, p
	int a = screen_006.get_cooordinate_on_screen ( this->bones_001[ selected ], &x, &y );
	int stored = this->canvas->AXEX_2D_002_Index;
	this->canvas->AXEX_2D_002_Index = selected;
	this->canvas->Set_vAxex_2D( x, y );
	this->canvas->AXEX_2D_002_Index = stored;

	printf("1002 x, y = %f, %f\r\n", x, y);

	free_point ( mv_002 );
	free_point ( selected_point );
	free_point ( moved_point_003 );
	//free_point ( range_001 );
	free ( range_001 );

	//printf("range_001_a=");
	//range_001->print();

	printf("int vDisplayController_002::MoveSelectedPoint_004 () ends.\r\n");
	return 0;
}


int vDisplayController_002::PrintBones ( ) {
	float x, y;
	vCalculation calc;
	printf("int vDisplayController_002::PrintBones () starts.\r\n");

	printf("bones_001 bones_max_index %d: \r\n", this->bones_max_index );
	for ( int i =0; i<this->bones_max_index; i++ ) {
		this->bones_001[i].print();
	}

	printf("int vDisplayController_002::PrintBones () ends.\r\n");
	exit(-1);
	return 0;
}

int vDisplayController_002::PrintBones_001 ( ) {
	float x, y;
	vCalculation calc;
	printf("int vDisplayController_002::PrintBones_001 () starts.\r\n");

	printf("bones_001 bones_max_index %d: \r\n", this->bones_max_index );
	for ( int i =0; i<this->bones_max_index; i++ ) {
		this->bones_001[i].print();
	}

	printf("int vDisplayController_002::PrintBones_001 () ends.\r\n");
	return 0;
}
