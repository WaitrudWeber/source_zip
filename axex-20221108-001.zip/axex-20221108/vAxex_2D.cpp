#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"	// ADD: 20200125
#include "sender.h"			// ADD: 20200125
#include "Print.h"			// ADD: 20200125

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vAxex_2D.h"

vAxex_2D::vAxex_2D () {
}

vAxex_2D::vAxex_2D ( float xx, float yy, float rr, float d_distance) {
	this->x = xx;
	this->y = yy;
	this->r = rr;
	this->distance = d_distance;
}

int vAxex_2D::SetWidth ( float w ) {

	this->width = w;

	return 0;
}

int vAxex_2D::SetHeight ( float h ) {

	this->height = h;

	return 0;
}


int vAxex_2D::SetUp ( float xx, float yy, float zz ) {

	if ( up == nullptr ) {
		up = new vPoint ( xx, yy, zz );
	} else {
		up->setPoint ( xx, yy, zz );
	}

	up = new vPoint ( xx, yy, zz );
	Calc.normal(up);

	return 0;
}

int vAxex_2D::SetRight ( float xx, float yy, float zz ) {

	if ( right == nullptr ) {
		right = new vPoint ( xx, yy, zz );
	} else {
		right->setPoint ( xx, yy, zz );
	}

	right = new vPoint ( xx, yy, zz );
	Calc.normal(right);

	return 0;
}


int vAxex_2D::SetDepth ( float xx, float yy, float zz ) {
	if ( depth == nullptr ) {
		depth = new vPoint ( xx, yy, zz );
	} else {
		depth->setPoint ( xx, yy, zz );
	}
	Calc.normal(depth);

	return 0;
}

int vAxex_2D::SetEye ( float xx, float yy, float zz ) {

	// postion
	if (eye_001 == nullptr ) { 
		eye_001 = new vPoint ( xx, yy, zz );
	} else {
		eye_001->setPoint ( xx, yy, zz );
	}

	return 0;
}

int vAxex_2D::SetCenter ( float xx, float yy, float zz ) {

	// postion
	if (center == nullptr ) { 
		center = new vPoint ( xx, yy, zz );
	} else {
		center->setPoint ( xx, yy, zz );
	}

	return 0;
}

// Use SetCenter amd SetDepth for memorization.
int vAxex_2D::Calculation_Axex ( ) {
	printf("int vAxex_2D::Calculation_Axex ( ) starts.\r\n");
	vPoint* arrow = nullptr;
	vPoint* depth_002 = nullptr;
	vPoint* right_002 = nullptr;
	vPoint* up_002 = nullptr;
	vPoint* depth_003 = nullptr;
	vPoint* right_003 = nullptr;
	vPoint* up_003 = nullptr;

	printf("int vAxex_2D::Calculation_Axex ( ) 000.\r\n");

	// we've already know the Center as screen
	// and we are going to revise it as an azex.

	// 002 depth
	printf("center|%p| eye_001|%p| depth_002|%p|.\r\n", center, eye_001, depth_002 );
	depth_002 = Calc.subtract ( center, eye_001);
	printf("center|%p| eye_001|%p| depth_002|%p|.\r\n", center, eye_001, depth_002 );
	Calc.normal ( depth_002 );
	printf("int vAxex_2D::Calculation_Axex ( ) 000-01.\r\n");

	// 003
	right_002 = Calc.cross ( up, depth_002 );	
	Calc.normal(right_002);
	up_002 = Calc.cross ( up, right_002 );	
	printf("int vAxex_2D::Calculation_Axex ( ) 001.\r\n");

	
	// 004
	x = x - this->width/2.0f;
	y = y - this->height/2.0f;
	vPoint* pp_001 = Calc.scalize( up_002 , y );
	vPoint* pp_002 = Calc.scalize( right_002 , x );
	vPoint* pp_003 = Calc.add( pp_001, this->center );
	vPoint* pp_004 = Calc.add( pp_002, pp_003 );

	printf("int vAxex_2D::Calculation_Axex ( ) 002.\r\n");

	//Reset Center
	this->SetCenter ( pp_004->x, pp_004->y, pp_004->z );
	depth_003 = Calc.subtract ( center, eye_001);
	Calc.normal ( depth_003 );
	right_003 = Calc.cross ( up, depth_003 );	
	Calc.normal ( right_003 );
	up_003 = Calc.cross ( right_003, depth_003 );	
	Calc.normal ( up_003 );

	printf("int vAxex_2D::Calculation_Axex ( ) 003.\r\n");


	this->SetDepth ( depth_003->x, depth_003->y, depth_003->z );
	this->SetRight ( right_003->x, right_003->y, right_003->z );
	this->SetUp ( up_003->x, up_003->y, up_003->z );

	printf("int vAxex_2D::Calculation_Axex ( ) 004.\r\n");

	free_point(pp_001);
	free_point(pp_002);
	free_point(pp_003);
	free_point(pp_004);
	free_point(arrow);
	free_point(up_002);
	free_point(right_002);
	free_point(depth_002);
	free_point(depth_003);
	free_point(up_003);
	free_point(right_003);

	printf("int vAxex_2D::Calculation_Axex ( ) ends.\r\n");
	return 0;
}

int vAxex_2D::CheckBaseAxexAndAllocation ( ) {
	printf("int vAxex_2D::CheckBaseAxexAndAllocation ( ) starts.\r\n");

	if ( this->up == nullptr ) {
		this->up = memorizevPoint ( 0.0, 1.0, 0.0 );
	}

	if ( this->depth == nullptr ) {
		this->depth = memorizevPoint ( 0.0, 1.0, 0.0 );
	}

	if ( this->right == nullptr ) {
		this->right = memorizevPoint ( 0.0, 1.0, 0.0 );
	}

	printf("int vAxex_2D::CheckBaseAxexAndAllocation ( ) ends.\r\n");
	return 0;
}

//
int vAxex_2D::Calculation_Axex_002 ( ) {
	printf("int vAxex_2D::Calculation_Axex_002 ( ) starts.\r\n");

	printf("center|%p| this->up|%p| this->depth|%p|.\r\n", center, this->up, this->depth );

	this->CheckBaseAxexAndAllocation ();
	vPoint* up_000 = this->up;
	vPoint* depth_001 = this->depth;

	printf("center|%p| up_000|%p| depth_001|%p|.\r\n", center, up_000, depth_001 );

        vPoint* right_001 = Calc.cross( depth_001, up_000 );
        vPoint* up_001 = Calc.cross( right_001, depth_001 );

	printf("center|%p| up_001|%p| depth_001|%p| right_001|%p|.\r\n", center, up_001, depth_001, right_001 );

        Calc.normal( up_001 );
        Calc.normal( depth_001 );
        Calc.normal( right_001 );
        this->SetRight ( right_001->x, right_001->y, right_001->z );
        this->SetUp ( up_001->x, up_001->y, up_001->z );
        this->SetDepth ( depth_001->x, depth_001->y, depth_001->z );

        free_point (up_000);
        free_point (up_001);
        free_point (right_001);
        free_point (depth_001);

	printf("center|%p| this->up|%p| this->depth|%p|.\r\n", center, this->up, this->depth );
	printf("int vAxex_2D::Calculation_Axex_002 ( ) ends.\r\n");
	return 0;
}

int vAxex_2D::CheckAxex () {
	printf("int vAxex_2D::CheckAxex ( ) starts.\r\n");

	double length = Calc.length ( (this->right) );
	if ( length > 1.0 + 0.0001 || length < 1.0 - 0.0001 ) {
		printf("axex right length %f\r\n", length);
		exit(-1);
	}

	length = Calc.length ( (this->up) );
	if ( length > 1.0 + 0.0001 || length < 1.0 - 0.0001 ) {
		printf("axex up length %f\r\n", length);
		exit(-1);
	}

	length = Calc.length ( (this->depth) );
	if ( length > 1.0 + 0.0001 || length < 1.0 - 0.0001 ) {
		printf("axex depth length %f\r\n", length);
		exit(-1);
	}

	printf("int vAxex_2D::CheckAxex ( ) ends.\r\n");
	return 0;
}


