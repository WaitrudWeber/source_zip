#ifndef _SETTLE_GRID_002_H_
#define _SETTLE_GRID_002_H_

extern int csv_once_002 (int *index, int *end_index ) ;
extern char* m_concat_c_002 ( char* word_002 , int c ) ;
extern int Set_Logging_read_csv_002 ( Logging* log ) ;
extern int Set_Filename_002 ( char* filename ) ;

#endif
