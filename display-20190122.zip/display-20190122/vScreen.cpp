#include "vPoint.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h";

#include "vScreen.h";

vScreen::vScreen ( ) {

	//Point U = new Point();
	//Point V = new Point();

	this_calc = new vCalculation ();
}

void vScreen::OntheScreen ( float* x, float* y) {
	vPoint px;
	vPoint py;

	OntheScreen( &px, &py );
	*x = px.x;
	*y = px.y;
}

void vScreen::OntheScreen ( vPoint* x, vPoint* y) {
	 vPoint px = subtract ( X, C );
	 vPoint py = subtract ( Y, C );
}

void vScreen::put_U ( vPoint a) {
	U = a;
}

void vScreen::put_V ( vPoint b) {
	V = b;
}

void vScreen::put_C ( vPoint c) {
	C = c;
}

void vScreen::calculation () {
	calculation_uvw();


}

void vScreen::calculation_uvw () {

	u = normal ( U ) ;
	v = normal ( V ) ;
	w = cross ( u, v ) ;

}

vPoint vScreen::normal( vPoint a) {
	vPoint result;

	result = this_calc->normal ( a ) ;
	return result;
}

vPoint vScreen::subtract( vPoint a, vPoint b) {
	vPoint result;

	result = this_calc->subtract ( a, b ) ;
	return result;
}

vPoint vScreen::cross( vPoint a, vPoint b) {
	vPoint result;

	result = this_calc->cross ( a, b ) ;
	return result;
}


