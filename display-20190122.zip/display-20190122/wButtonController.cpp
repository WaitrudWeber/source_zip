// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "wEvent.h"
#include "wButton.h"
#include "wButtonController.h"

// CursolNumber is public.
//
//
//
wButtonController::wButtonController () {

	this->mode = 0;
	this->number_button = 0;
	AryButton = nullptr;
}

//
//
//
//
void wButtonController::selectButton ( ) {

	if( this->CursolNumber < 0 ) {
		this->CursolNumber = this->number_button -1;
		//return;
	}

	if( this->CursolNumber >= this->number_button ) {
		this->CursolNumber = 0;
		//return;
	}

	for ( int i=0; i<this->number_button; i++ )
		AryButton[ i ]->setMode( 0 );

	AryButton[ this->CursolNumber ]->setMode( 1 );

}

//
//
//
//
//
void wButtonController::setEvent ( wEvent* evt ) {

	this->event = evt;
}

//
//
//
//
//
void wButtonController::Process () {

	switch ( this->event->uMsg ) {
	case WM_CREATE:
		break;
	case WM_CHAR:
		ProcessWmChar ();
		break;
	case WM_CLOSE:
		break;
	case WM_PAINT:
		ProcessWmPaint ();
		break;
	case WM_COMMAND:
		break;
	case WM_KEYUP:
		break;
	case WM_KEYDOWN:
		break;
	case WM_DESTROY:
		break;
	case WM_ENDSESSION:
		break;
	case WM_LBUTTONDOWN:
		break;
	case WM_LBUTTONDBLCLK:
		break;
	case WM_RBUTTONDBLCLK:
		break;
	case WM_SIZE:
		break;
	default:
		break;
	}

}

//
//
//
//
//
void wButtonController::ProcessWmChar () {
	int succ;

	//
	//
	// Send wTriger tp ButtonController
	// btc.setTriger( hTriger );

	switch ( this->event->main_mode ) {
	case 0:
		break;
	}

/*	switch( m_mode ) {
		case 0:
			break;
		case 1:
			break;
		case 2:
			getchar_something_word_proc( hWnd, uMsg, wParam, lParam );
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		case 8:
			// do not write anything
			break;
		case 9:
			getchar_display_threeD_proc( hWnd, uMsg, wParam, lParam );
			break;
	}
*/

	// for Edit
	/* if ( btc.CursolNumber == 7 ) {

		switch( key_w ) {
		case 'v':
			//succ_paste = ReadClip ( hWnd, m_pastestr );
			EditPaste();
			m_pastestr = m_concat(m_pastestr, ":did paste");
			break;
		case 'r':
			show_garbage_collection () ;
			m_pastestr = "show_garbage_collection () ;";
			// multithread_print();
			break;
		default:
			break;
		}

		if ( call_once_key == 1 ) {
			call_once_key = 0;
			//break;
		}


		switch( key_w ) {
		case 'o':
			btc.selectButton( (char *) "File Open - o -");
			break;
		case 's':
			btc.selectButton( (char *) "Something Sentence - s -");
			break;
		case 'w':
			btc.selectButton( (char *) "Something Word - w -");
			break;
		case 'd':
			btc.selectButton( (char *) "Dictionary Link - d -");
			break;
		case 'l':
			btc.selectButton( (char *) "Web Link - l -");
			break;
		case 'p':
			btc.selectButton( (char *) "Print Html - p -");
			break;
		case 'e':
			btc.selectButton( (char *) "Exit - e -");
			break;
		case '3':
			btc.selectButton( (char *) "Display 3D - 3 -");
			break;
		}


	} */
}

//
//
//
//
//
void wButtonController::ProcessWmPaint () {
	
}

//
//
//
//
//
void wButtonController::setTriger ( int h_triger ) {
	hTriger = h_triger;
}

//
//
//
//
//
void wButtonController::selectButton ( char* btn_nm ) {
	int ret;

	for ( int i=0; i<this->number_button; i++ ) {
		
		ret = strcmp( AryButton[ i ]->button_name, btn_nm );
		if ( ret == 0 ) {
			CursolNumber = i;
			AryButton[ i ]->setMode( 1 );
		} else
			AryButton[ i ]->setMode( 0 );
	}
}

//
//
//
//
//
void wButtonController::addButton ( wButton* b ) {
	if ( this->number_button ==0 || AryButton == nullptr ) {
		AryButton = ( wButton** ) malloc ( sizeof( wButton* ) * 1 );
		AryButton[ this->number_button ] = b;
		this->number_button = 1;
		return;
	}

	this->number_button++;
	AryButton = (wButton **) realloc( AryButton, this->number_button * sizeof(wButton *) );
	AryButton[ this->number_button - 1] = b;

}

//
//
//
//
//
void wButtonController::drawButtons ( HDC hdc ) {

	for ( int i=0; i<this->number_button; i++ ) {
		AryButton[ i ]->drawButton( hdc );
	}

}

//( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
//
//
// added 20190118
//
void wButtonController::kickEveentButtons ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	for ( int i=0; i<this->number_button; i++ ) {
		AryButton[ i ]->kickEveentButton( hWnd, uMsg, wParam, lParam );
	}

}

// void
