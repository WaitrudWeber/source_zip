// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.
//
class wButtonController {
	public:
		int CursolNumber;

	private:
		int number_button;
		int mode;
		wButton **AryButton;
		int hTriger = 0;
		wEvent* event = nullptr;

	public:
		wButtonController ();
		void addButton ( wButton* b );
		void drawButtons ( HDC hdc );
		void selectButton ( char* btn_nm );
		void selectButton ( );
		void kickEveentButtons ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
		void setTriger ( int h_triger ) ;
		void setEvent ( wEvent* evt ) ;
		void Process ( ) ;
		void ProcessWmChar () ;
		void ProcessWmPaint () ;

		//void setButton( int xx, int yy, int h, int w);
		//int wdrawButton( HDC hdc, char *button_name, RECT rect );
		//int aaa();
		//int drawButton( HDC hdc );
		//void setMode ( int m );

};



