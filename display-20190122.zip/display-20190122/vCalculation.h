#ifndef _VCALCULATION_
#define _VCALCULATION_

class vCalculation {

public:
	vPoint cross ( vPoint p1, vPoint p2);
	vPoint normal ( vPoint p1 );
	vPoint add ( vPoint p1, vPoint p2);
	vPoint subtract ( vPoint p1, vPoint p2);
	vPoint scale ( vPoint p1, float scale );

private:
	void cross ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	double normal ( float x1, float y1, float z1, float* x2, float* y2, float* z2 );
	void subtract ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	void add ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	void scale ( float x1, float y1, float z1, float scale, float* x3, float* y3, float* z3);

};

#endif
