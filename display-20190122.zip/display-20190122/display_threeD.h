#ifndef _DISPLAY_THREED_INITIALIZE_
#define _DISPLAY_THREED_INITIALIZE_

extern int display_threeD_initialize () ;
extern int getchar_display_threeD_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

#endif
