#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "wTextarea.h"
#include "clipboard.h"

#include "display_threeD.h"

#include "vPoint.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h";

#include "vScreen.h"

int display_threeD_initialize () ;
int getchar_something_word_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

vTriangle atri;
vPoint eye;
vPoint ray;
vPoint point_intersection;
float g_x, g_y;

vScreen* screen = nullptr;

int display_threeD_initialize () {

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	point_intersection = intersection->Intersect( atri, eye, ray );

	screen = new vScreen ();
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen->put_U ( *U );
	screen->put_V ( *V );
	screen->calculation();
	screen->OntheScreen( &g_x, &g_y );

	return 0;
}

int getchar_display_threeD_proc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	return 0;
}

