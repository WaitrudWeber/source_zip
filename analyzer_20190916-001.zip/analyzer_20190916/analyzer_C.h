#ifndef _ANALYZE_H_
#define _ANALYZE_H_

class Analyzer {

	public:
		int analyze_C (int argc, char** argv ) ;
		int filesize( FILE *fp ) ;
		int parse ( char* filename ) ;
		int skip_to( char* skip_to, int *i , int file_end, FILE *fp) ;

};

#endif
