#ifndef _PARSE_H_
#define _PARSE_H_

extern char* string_allocation (int size) ;
extern char* put_token (char c);
extern char* put_token_010 (char c);

extern char* string_allocation (int size) ;
extern int initialize_parse ();
extern int initialize_parse_001 ();
extern int m_fread ( char* dummy, int a, FILE *fp) ;
extern int line_end ( char c ) ;
extern int line_end_win ( char* c ) ;

extern int alphabet ( char c ) ;
extern int number ( char c ) ;
extern int parse_libraries ( FILE *fp, int file_end );

extern void clear_token() ;
extern char* m_trim( char* c_str ) ;
extern int m_contains ( char* c_str, char* c_ref ) ;
extern int m_last_with ( char* c_str, char* c_ref ) ;
extern int m_last_with_001 ( char* c_str, char* c_ref ) ;
extern int m_start_with ( char* c_str, char* c_ref );

extern char* substring( char* c_a, int start, int length );
extern int file_type (char* filename, char* type);
extern char* front_trim( char* c_str );

extern char** split ( char* filename, char c, int* number ) ;


extern int m_mode;
extern int m_cnt_tkn;
extern int m_count;
extern int m_size;
extern int m_line;
extern int m_raw;
extern char* m_filename;

extern char* token;

#endif
