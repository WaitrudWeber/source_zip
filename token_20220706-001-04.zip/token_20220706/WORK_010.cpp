#include "WORK_010.h"
#include "WORK_001.h"
void WORK_010::SetWORK_001( WORK001 *lWORK001 ){ 

}
