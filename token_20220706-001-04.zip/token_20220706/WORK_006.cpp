#include "WORK_006.h"
#include "WORK_007.h"
void WORK_006::SetWORK_007( WORK007 *lWORK007 ){ 

}
