#include "WORK_004.h"
#include "WORK_005.h"
void WORK_004::SetWORK_005( WORK005 *lWORK005 ){ 

}
