#include "wMethod.h"

//
//
//
//
//
wMethod::wMethod () {

}

//
//
//
//
//
void wMethod::Set_Method_Header_Line ( char* head_line ) {

	this->MethodHeaderLine = head_line;

}

//
//
//
//
//
void wMethod::Set_Method_Place ( char* method_name, char* l_filename, int l, int r ) {
	//this->MethodName = method_name;
	this->MethodMame = method_name;
	this->line = l;
	this->raw = r;
}

