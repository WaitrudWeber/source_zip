#ifndef _VCUTTINGPLANE_H_
#define _VCUTTINGPLANE_H_

class vCuttingPlane {

	private:
		vLine** lines = nullptr;

	public:
		vLine** gevLine();

};

#endif
