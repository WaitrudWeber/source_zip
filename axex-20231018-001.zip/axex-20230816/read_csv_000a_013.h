#ifndef _READ_CSV__013_
#define _READ_CSV__013_

typedef struct {
	FILE *fp;
	FILE *file_start;
	int index;
	int file_end_index;
} STRUCT_FILE;

//...
extern int read_csv_000a_013 ();
extern int set_read_csv_000a_013 (char** argv, int argc);
extern int initialize_read_csv_000a_013 (char** argv, int argc);
extern int caribration_memoreies_013 ();

#endif
