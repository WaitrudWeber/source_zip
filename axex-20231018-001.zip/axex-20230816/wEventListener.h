
class wEventListener {

	private:
		int number = 0;

	protected:
		void paint ();

	public:
		void setNumber( int a );
};
