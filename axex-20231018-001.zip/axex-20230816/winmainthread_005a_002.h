#ifndef _WINMAINTHREAD__002_
#define _WINMAINTHREAD__002_
//...
extern int winmainthread_005a_002 ();
extern int set_winmainthread_005a_002 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_winmainthread_005a_002 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

extern DWORD WINAPI Animation_5times_thread_validate_025_002 ( LPVOID hdc ) ;


#endif
