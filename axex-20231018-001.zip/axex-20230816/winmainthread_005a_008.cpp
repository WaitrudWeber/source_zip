#include <stdio.h>
#include <stdlib.h>

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-hProcess-in-mingw-what-to-use-instead
// #include <strsafe.h>

//#include <mmdeviceapi.h>

#include "resource.h"

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"

#include "clipboard.h"

#include "button.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "display_threeD.h"
#include "vPointStructure.h"


#include "vSoundBuffer_001.h"

#include "image_layer_001.h"

#include "wEvent.h"
#include "wEventListener.h"

#include "wJavaStructure.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

#include "wTextarea.h"
#include "wTextareaController.h"

#include "something_word.h"
#include "thread_print.h"


#include "wDisplayController.h"
//#include "wParamSynse_003.h"
#include "wCanvasController.h"

#include "cg_schema.h"


#include "ReturnableParam.h"

#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "log_001.h"

#include "csv_text_001.h"
#include "settle_grid_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_003.h"
#include "winmainthread_005a_002.h"
#include "winmainthread_005a_001.h"
#include "winmainthread_005a_000.h"
#include "winmainthread_005a_008.h"

#include "winmainthread_001.h"
#include "winmainthread_002.h"
#include "winmainthread_005.h"

#define _DRAW_PARAM_00000000000000000000000000000001_ 1
#define _DRAW_PARAM_00000000000000000000000000000010_ 2
#define _DRAW_PARAM_00000000000000000000000000000100_ 4
#define _DRAW_PARAM_00000000000000000000000000001000_ 8
#define _DRAW_PARAM_00000000000000000000000000010000_ 16
#define _DRAW_PARAM_00000000000000000000000000100000_ 32
#define _DRAW_PARAM_00000000000000000000000001000000_ 64
#define _DRAW_PARAM_00000000000000000000000010000000_ 128
#define _DRAW_PARAM_00000000000000000000000100000000_ 256
#define _DRAW_PARAM_00000000000000000000001000000000_ 512
#define _DRAW_PARAM_00000000000000000000010000000000_ 1024
#define _DRAW_PARAM_00000000000000000000100000000000_ 2048
#define _DRAW_PARAM_00000000000000000001000000000000_ 4096
#define _DRAW_PARAM_00000000000000000010000000000000_ 8192
#define _DRAW_PARAM_00000000000000000100000000000000_ 16384
#define _DRAW_PARAM_00000000000000001000000000000000_ 32768
#define _DRAW_PARAM_00000000000000010000000000000000_ 65536
#define _DRAW_PARAM_00000000000000100000000000000000_ 131072
#define _DRAW_PARAM_00000000000001000000000000000000_ 262144
#define _DRAW_PARAM_00000000000010000000000000000000_ 524288




extern char* filename_winmainthread_005a_008_ = (char*)"winmainthread_005a_008.txt";

int winmainthread_005a_008 ();
int set_winmainthread_005a_008 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_008 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int paint_wm_008 (int* b_Processed ) ;
int paint_wm_008_01 (int* b_Processed ) ;

int winmainthread_005a_008 () {
	return 1;

}


int winmainthread_005a_set_008 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_008 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int paint_wm_008_01 (int* b_Processed ) {
}
//
int paint_wm_008 (int* b_Processed ) {

	printf("int paint_wm_008 () DRAW_PARAM %d start.\r\n", DRAW_PARAM );

		hDC = BeginPaint( p_evt->hWnd, &ps_001 );
		p_evt->hDc = hDC;
		p_evt->ps = &ps_001;
		param_int[5] = 0;


		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000000001_ ) {
//$00000000000000000000000000000001
//			SelectObject( hDC, GetStockObject(GRAY_BRUSH)); 
//			Ellipse( hDC, RefreshRect.left, RefreshRect.top, RefreshRect.right, RefreshRect.bottom);
			SelectObject( hDC, GetStockObject(WHITE_BRUSH)); 
			Rectangle( hDC, RefreshRect.left, RefreshRect.top, RefreshRect.right, RefreshRect.bottom);
			printf("00000000000000000000000000000001\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000000010_ ) {
//$00000000000000000000000000000010

			printf("00000000000000000000000000000010\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000000100_ ) {
//$00000000000000000000000000000100
			param[0] = 1.0; // margin x;
			param[1] = 1.0; // margin y;
			param[2] = 10.0; // step x;
			param[3] = param[2] * 0.5 * sqrt( 3.0 ); // step y;
			param[4] = 640.0; // screen width
			param[5] = 480.0; // screen height
			param[6] = param[1]; // current x
			param[7] = param[2]; // current y
			param[8] = param[0] + 0.5 * param[2];
			param[9] = param[0];  // start of odd

			while ( param[7] < param[5] ) {

				SetPixel( p_evt->hDc, param[6], param[7], RGB( 0, 0, 255 ) );
				// inclement of cursol and turn
				if ( (param[6] += param[2] ) >= param[4]  ) {
					param[7] += param[3];

					if ( param[9] == param[0] ) param[6] = param[8];
					else param[6] = param[0];
					param[9] = param[6];
				}
			}

			printf("00000000000000000000000000000100\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000001000_ ) {
//$00000000000000000000000000001000
			for ( i =0; i<20; i++ ) {
				Rectangle(  (HDC) hDC, rect_xy[i].left, rect_xy[i].top, rect_xy[i].right, rect_xy[i].bottom );
			}

			printf("00000000000000000000000000001000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000010000_ ) {
//$00000000000000000000000000010000

			Rectangle(  (HDC) hDC, rect_xy[17].left, rect_xy[17].top, rect_xy[17].right, rect_xy[17].bottom );
//			DRAW_PARAM -= _DRAW_PARAM_00000000000000000000000000010000_;

			printf("00000000000000000000000000010000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000100000_ ) {
//$00000000000000000000000000100000

			SelectObject( hDC, GetStockObject(GRAY_BRUSH)); 
			Rectangle(  (HDC) hDC, rect_xy[15].left, rect_xy[15].top, rect_xy[15].right, rect_xy[15].bottom );

			printf("00000000000000000000000000100000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000001000000_ ) {
//$00000000000000000000000001000000
			// Graph 001:
			// on SetRect( &rect_xy[17], 10, 300, 630, 350 );//04
			// 10 + cursol
			// 325 + value
//			SetPixel( p_evt->hDc, 10 + param_int[17], 325 + param_int[15], RGB( 255, 0, 0 ) );

			for ( i = 10; i<638; i++ ) {
				SetPixel( p_evt->hDc, i, 325 + 127 * 0.2, RGB( 0, 0, 255 ) );
				SetPixel( p_evt->hDc, i, 325 - 127 * 0.2, RGB( 0, 0, 255 ) );
				SetPixel( p_evt->hDc, i, 325 + soundwave[(i-10)%255] * 0.2, RGB( 0, 0, 255 ) );
				param_int[5]+=3;
			}
//				SetPixel( p_evt->hDc, i, 127 + soundwave[ ( i - 10 ) % 255 ], RGB( 0, 0, 255 ) );

			sprintf( value_text[5], "%04d", param_int[5] );
			sprintf( value_text[6], "%04d", 0 );

			printf("00000000000000000000000001000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000010000000_ ) {
//$00000000000000000000000010000000
			TextOutA( (HDC) hDC, rect_xy[0].left, rect_xy[0].top, value_text[0], 4);
			TextOutA( (HDC) hDC, rect_xy[1].left, rect_xy[1].top, value_text[1], 4);
			TextOutA( (HDC) hDC, rect_xy[3].left, rect_xy[3].top, value_text[3], 4);
			TextOutA( (HDC) hDC, rect_xy[4].left, rect_xy[4].top, value_text[4], 4);
			TextOutA( (HDC) hDC, rect_xy[5].left, rect_xy[5].top, value_text[5], 4);
			TextOutA( (HDC) hDC, rect_xy[6].left, rect_xy[6].top, value_text[6], 4);
//			TextOutA( (HDC) hDC, rect_xy[15].left, rect_xy[15].top, value_text[15], 4);
			TextOutA( (HDC) hDC, rect_xy[16].left, rect_xy[16].top, value_text[16], 4);
			TextOutA( (HDC) hDC, rect_xy[17].left, rect_xy[17].top, value_text[17], 4);
			TextOutA( (HDC) hDC, rect_xy[18].left, rect_xy[18].top, value_text[18], 4);
			TextOutA( (HDC) hDC, rect_xy[19].left, rect_xy[19].top, value_text[19], 4);

//			DrawText( (HDC) hDC, TEXT( value_text[0] ), -1, &rect_xy[0], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[1] ), -1, &rect_xy[1], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[3] ), -1, &rect_xy[3], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[4] ), -1, &rect_xy[4], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[18] ), -1, &rect_xy[18], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[19] ), -1, &rect_xy[19], DT_NOCLIP );
			printf("00000000000000000000000010000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000100000000_ ) {
//$00000000000000000000000100000000
			printf("00000000000000000000000100000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000001000000000_ ) {
//$00000000000000000000001000000000
			printf("00000000000000000000001000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000010000000000_ ) {
//$00000000000000000000010000000000
			printf("00000000000000000000010000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000100000000000_ ) {
//$00000000000000000000100000000000
			printf("00000000000000000000100000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000001000000000000_ ) {
//$00000000000000000001000000000000
			printf("00000000000000000001000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000010000000000000_ ) {
//$00000000000000000010000000000000
			// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-drawtext
			SelectObject( hDC, GetStockObject(WHITE_BRUSH)); 
			SetBkColor(hDC, RGB(255,255,255));
			for( i = 0; i<96; i++ ) {
				Rectangle( (HDC) hDC, l_rect_xy[i].left, l_rect_xy[i].top, l_rect_xy[i].right, l_rect_xy[i].bottom );
			}

			hFont = CreateFont (20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);
			SetTextColor( hDC, RGB(0 ,0, 255) );

			for( i = 0; i<96; i++ ) {
				DrawText( (HDC) hDC, TEXT( param_d [0][i] ), -1, &l_rect_xy[i], DT_NOCLIP );
			}

			hPen = CreatePen(PS_DASHDOT,1,RGB(255,0,0));
			SelectObject(hDC, hPen);
			SetBkColor(hDC, RGB(200,255,200));
			SelectObject(hDC,CreateSolidBrush( RGB(200,255,200) ) );

			// https://learn.microsoft.com/en-us/windows/win32/api/gdipluscolor/nf-gdipluscolor-color-getgreen
			// https://learn.microsoft.com/en-us/windows/win32/wcs/rgb-color-spaces
			for( i = 0; i<12; i++ ) {
				Rectangle( (HDC) hDC, l_rect_xy_head[i].left, l_rect_xy_head[i].top, l_rect_xy_head[i].right, l_rect_xy_head[i].bottom );
			}

			hFont = CreateFont (10, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);

//			SetTextColor( hDC, RGB(255 ,255, 255) );
			for( i = 0; i<12; i++ ) {
				DrawText( (HDC) hDC, TEXT( param_c[i] ), -1, &rect_xy_head[i], DT_LEFT );
			}

			// Clean up
			DeleteObject(bgRgn);
			DeleteObject(hBrush);
			DeleteObject(hPen);

			printf("00000000000000000010000000000000\r\n");
			if (halt_invalidate == 1) exit(-1);
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000100000000000000_ ) {
//$00000000000000000100000000000000
			// 5
			for ( i = 0; i<5; i++ ) {
				log_a[i] = dlog_001->log_list[ i + dlog_001->from ];
			}
			for ( i = 0; i<5; i++ ) {
				sprintf( log_cursol[i], "%d", i + dlog_001->from + 1);
			}

			hPen = CreatePen(PS_DASHDOT,1,RGB( 255, 255, 128));
			SelectObject(p_evt->hDc, hPen);
			SetBkColor(p_evt->hDc, RGB( 0, 128, 0));
			SelectObject(p_evt->hDc, CreateSolidBrush(RGB(0,128,0)));
			for ( i = 0; i<5; i++ ) {
				Rectangle( (HDC) hDC, rect_log[i].left, rect_log[i].top, rect_log[i].right, rect_log[i].bottom );
				Rectangle( (HDC) hDC, rect_log_cursol[i].left, rect_log_cursol[i].top, rect_log_cursol[i].right, rect_log_cursol[i].bottom );
			}

			hFont = CreateFont (13, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);
			SetTextColor( hDC, RGB( 255, 255, 128) );
			for ( i = 0; i<5; i++ ) {
				DrawText( (HDC) hDC, TEXT( log_a[i] ), -1, &rect_log[i], DT_LEFT );
				DrawText( (HDC) hDC, TEXT( log_cursol[i] ), -1, &rect_log_cursol[i], DT_LEFT );
			}
			printf("00000000000000000100000000000000\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000001000000000000000_ ) {
//$00000000000000001000000000000000
			posx = 200;
			posy = 200;
			for( l =0; l<1; l++ ) {
				for( j = posy; j<posy + 100; j++ ) {
					for( i = posx; i<posx +100; i++ ) {
						SetPixel( p_evt->hDc, i, j, RGB( 255, 0, 255 ) );
					}
				}
				posx += 10;
				posy += 10;
			}

			printf("00000000000000001000000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000010000000000000000_ ) {
//$00000000000000010000000000000000
        // Fill the client area with a brush
        GetClientRect(p_evt->hWnd, &clientRect);
        bgRgn = CreateRectRgnIndirect(&clientRect);
        hBrush = CreateSolidBrush(RGB(200,200,200));
        FillRgn(hDC, bgRgn, hBrush);

        
        hPen = CreatePen(PS_DOT,1,RGB(0,255,0));
        SelectObject(hDC, hPen);
        SetBkColor(hDC, RGB(0,0,0));
        Rectangle(hDC, 10,10,200,200);
        
        // Text caption
        SetBkColor(hDC, RGB(255,255,255));
        SetRect(&textRect, 10, 210, 200,200);
        DrawText(hDC,TEXT("PS_DOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);

        hPen = CreatePen(PS_DASHDOTDOT,1,RGB(0,255,255));
        SelectObject(hDC, hPen);
        SetBkColor(hDC, RGB(255,0,0));
        SelectObject(hDC,CreateSolidBrush(RGB(0,0,0)));
        Rectangle(hDC, 210,10,400,200);
        
        // Text caption
        SetBkColor(hDC, RGB(255,200,200));
        SetRect(&textRect, 210, 210, 400,200);
        DrawText(hDC,TEXT("PS_DASHDOTDOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);

        hPen = CreatePen(PS_DASHDOT,1,RGB(255,0,0));
        SelectObject(hDC, hPen);
        SetBkColor(hDC, RGB(200,255,200));
        SelectObject(hDC,CreateSolidBrush(RGB(200,255,200)) );
        Rectangle(hDC, 410,10,600,200);
        
        // Text caption
        SetBkColor(hDC, RGB(200,255,200));
        SetRect(&textRect, 410, 210, 600,200);
        DrawText(hDC,TEXT("PS_DASHDOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);


			printf("00000000000000010000000000000000\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000100000000000000000_ ) {
//$00000000000000100000000000000000
			for( l =0; l<3; l++ ) {
				for( j = 0; j<il_001.get_height(l); j++ ) {
					for( i = 0; i<il_001.get_width(l); i++ ) {
						rgbt = (unsigned char*) il_001.get_image_layer( l, i, j);
						SetPixel( p_evt->hDc, i + il_001.get_posx(l), j  + il_001.get_posy(l), RGB( rgbt[0], rgbt[1], rgbt[2] ) );
					}
				}
			}
			printf("00000000000000100000000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000001000000000000000000_ ) {
//$00000000000001000000000000000000
			for( l =0; l<3; l++ ) {
				for( j = 0; j<il_001.get_height(l); j++ ) {
					for( i = 0; i<il_001.get_width(l); i++ ) {
						rgbt = (unsigned char*) il_001.get_image_layer_001( l, i, j);
						SetPixel( p_evt->hDc, i + il_001.get_posx(l), j  + il_001.get_posy(l), RGB( rgbt[0], rgbt[1], rgbt[2] ) );
					}
				}
			}
			printf("00000000000001000000000000000000 & DRAW_PARAM %d\r\n", DRAW_PARAM);
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000010000000000000000000_ ) {
//$00000000000010000000000000000000
			// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-drawtext
			SelectObject( hDC, GetStockObject(WHITE_BRUSH)); 
			SetBkColor(hDC, RGB(255,255,255));
			for( i = 0; i<20; i++ ) {
//				Ellipse( hDC, rect_xy[i].left, rect_xy[i].top, rect_xy[i].right, rect_xy[i].bottom);
				Rectangle( (HDC) hDC, rect_xy[i].left, rect_xy[i].top, rect_xy[i].right, rect_xy[i].bottom );
			}

			// GetClientRect(hwnd, &rect);
			// DrawText (hdc, TEXT ("http://"), -1, &rect,DT_SINGLELINE | DT_LEFT);
			// https://social.msdn.microsoft.com/Forums/en-US/155478d2-f151-4c84-a831-d5d9bd17d3ff/drawtext-amp-use-of-a-background-color?forum=vcgeneral
			// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getclientrect
			hFont = CreateFont (20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);
			SetTextColor( hDC, RGB(0 ,0, 255) );

			for( i = 0; i<20; i++ ) {
				DrawText( (HDC) hDC, TEXT( param_a[i] ), -1, &rect_xy[i], DT_NOCLIP );
			}


			hPen = CreatePen(PS_DASHDOT,1,RGB(255,0,0));
			SelectObject(hDC, hPen);
			SetBkColor(hDC, RGB(200,255,200));
			SelectObject(hDC,CreateSolidBrush( RGB(200,255,200) ) );
//			Rectangle(hDC, 410,10,600,200);

			// Text caption
//			SetBkColor(hDC, RGB(200,255,200));
//			SetRect(&textRect, 410, 210, 600,200);
//			DrawText(hDC,TEXT("PS_DASHDOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);

			// https://learn.microsoft.com/en-us/windows/win32/gdi/creating-colored-pens-and-brushes
			//GetClientRect(p_evt->hWnd, &clientRect);
			// Fill the client area with a brush
			//GetClientRect(p_evt->hWnd, &clientRect);
			//bgRgn = CreateRectRgnIndirect(&clientRect);
			//hBrush = CreateSolidBrush(RGB(200,200,200));
			//FillRgn(hdc, bgRgn, hBrush);

			// https://learn.microsoft.com/en-us/windows/win32/api/gdipluscolor/nf-gdipluscolor-color-getgreen
			// https://learn.microsoft.com/en-us/windows/win32/wcs/rgb-color-spaces
			for( i = 0; i<20; i++ ) {
				Rectangle( (HDC) hDC, rect_xy_head[i].left, rect_xy_head[i].top, rect_xy_head[i].right, rect_xy_head[i].bottom );
			}

			hFont = CreateFont (10, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);

			//SetBkMode(hdc,TRANSPARENT);
			//SetTextColor(hdc,RGB(0,255,0));
			//https://learn.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-setbkmode
//			SetBkMode( hDC, TRANSPARENT);
//			SetTextColor( hDC, RGB(255 ,255, 255) );
			for( i = 0; i<20; i++ ) {
				DrawText( (HDC) hDC, TEXT( param_b[i] ), -1, &rect_xy_head[i], DT_LEFT );
			}

			// Clean up
			DeleteObject(bgRgn);
			DeleteObject(hBrush);
			DeleteObject(hPen);

			printf("00000000000010000000000000000000\r\n");
		} 
		*b_Processed = 2;
		flg_paint = 1;
		printf("WM_PAINT=uMsg=%d flg_paint=%d hDC %d DRAW_PARAM %d\r\n", WM_PAINT, flg_paint, hDC, DRAW_PARAM );
	printf("int paint_wm_008 () DRAW_PARAM %d b_Processed %d ends.\r\n", DRAW_PARAM, *b_Processed );
	return 0;
	
}
