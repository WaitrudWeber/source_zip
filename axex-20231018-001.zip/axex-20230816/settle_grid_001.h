#ifndef _SETTLE_GRID_001_H_
#define _SETTLE_GRID_001_H_

class Settle_Grid_001 {
	public:
		char** csv = NULL;
		int csv_width = 0;
		int csv_height = 0;
		int csv_index = 0;

	private:
		Logging* logging = NULL;
		LOG_001* dlog_001 = NULL;
		FILE *rfp = NULL;
		FILE *wfp = NULL;
		char* file_name = NULL;
		char* read_file_name = NULL;
		char* write_file_name = NULL;
		int num_litteratures = 6;
		char** a_litteratures = NULL;
		char* litteratures[6] = { "\"", "\,", "\{", "\}", "\ ", "\r\n" };

	public:
		int csv_text_001() ;
		int csv_text_once_006( int* index, int* file_end, char** param, int num ) ;
		int csv_text_once_001( FILE *fp, int index, int file_end, char** param, int num ) ;
		int csv_text_once_002( FILE *fp, int index, int file_end, char** param, int num ) ;
		int csv_text_once_003( FILE *fp, int index, int file_end, char** param, int num ) ;
		int csv_text_once_004( FILE *fp, int index, int file_end, char** param, int num ) ;
		int csv_text_once_005( FILE *fp, int index, int file_end, char** param, int num ) ;
		int csv_save ( char* filename, char** param_d, int num_width, int num_height ) ;
		int set_log_001 (Logging* llog);
		int write_file_close () ;
		int write_file_open () ;
		int read_file_close () ;
		int read_file_open () ;
		int set_read_file_name (char* rfn) ;
		int set_write_file_name (char* rfn) ;
		int csv_read () ;
		int settle_position ( char** param_csv, int x, int y, char* value ) ;
		int settle_position_001 ( char** param_csv, int x, int y, int width, int height, char* value ) ;

	private:

};

#endif