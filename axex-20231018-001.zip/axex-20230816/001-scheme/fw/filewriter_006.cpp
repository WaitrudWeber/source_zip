int filewriter_006 ();

filewriter_006 () {
nreturn 1;

}


