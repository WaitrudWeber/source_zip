#ifndef _WINMAINTHREAD__004_
#define _WINMAINTHREAD__004_
//...
extern int winmainthread_005a_004 ();
extern int set_winmainthread_005a_004 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_winmainthread_005a_004 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
