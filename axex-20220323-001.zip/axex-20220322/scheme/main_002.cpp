#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Very thanks to:
// https://bytes.com/topic/c/answers/818961-frand#:~:text=There%20is%20no%20standard%20C%20function%20called%20%22frand%22.,a%20bug%20report.%20anyway.%20%22We%20must%20do%20something.
// https://bytes.com/topic/c/answers/818961-frand
// https://stackoverflow.com/questions/13408990/how-to-generate-random-float-number-in-c
// https://codingpointer.com/c-tutorial/generate-random-float-number
//
int main () {

	int i;
	float x, y, r, r_min, distance, distance_min, z;

	srand(time(NULL));

	r_min = 10.0f;
	distance_min = 100.0f;

	for ( i = 0; i <30; i++ ) {
		x = 640.0f;
		y = 480.0f;
		r = 10.f;
		distance = 200.0f;
		x = ((float)rand()/(float)(RAND_MAX)) * x;
		y= ((float)rand()/(float)(RAND_MAX)) * y;
		r= ((float)rand()/(float)(RAND_MAX)) * r + r_min;
		distance= ((float)rand()/(float)(RAND_MAX)) * distance + distance_min;
		printf("	AXEX_2D_001[%d] = new vAxex_2D ( %ff, %ff, %ff, %ff );\r\n", i, x, y, r, distance);
	}

	for ( i = 0; i <30; i++ ) {
		x = -0.5f;
		y = -0.5f;
		z = -0.5f;
		x += ((float)rand()/(float)(RAND_MAX)) ;
		y += ((float)rand()/(float)(RAND_MAX)) ;
		z += ((float)rand()/(float)(RAND_MAX)) ;
		printf("	AXEX_2D_001[%d].SetUp ( %ff, %ff, %ff );\r\n", i, x, y, z );
	}

	for ( i = 0; i <30; i++ ) {
		printf("	AXEX_2D_001[%d].SetEye (  screen->x, screen->y, screen->z );\r\n", i );
	}
	for ( i = 0; i <30; i++ ) {
		printf("	AXEX_2D_001[%d].Calculation_Axex ( );\r\n", i);
	}

	return 0;
}

/*
// https://stackoverflow.com/questions/13408990/how-to-generate-random-float-number-in-c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
    srand((unsigned int)time(NULL));

    float a = 5.0;
    for (int i=0;i<20;i++)
        printf("%f\n", ((float)rand()/(float)(RAND_MAX)) * a);
    return 0;
}
*/
