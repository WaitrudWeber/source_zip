
#include <stdio.h>

#iclude "wEventListener.h"


void wEventListener::paint () {
	printf("wEventListener::paint () starts.\r\n");

	printf("wEventListener::paint () endss.\r\n");
}

void wEventListener::setNumber( int a ) {
	printf("wEventListener::setNumber () starts.\r\n");

	printf("wEventListener::setNumber () ends.\r\n");

}


