#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "read_csv_003.h"

int endline_003 ( char bc, char c) ;

int endline_003 ( char bc, char c) {
	if ( bc == '\r' && c == '\n' ) return 1;
	return 0;
}

