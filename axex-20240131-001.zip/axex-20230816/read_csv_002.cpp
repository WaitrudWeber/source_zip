#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_002.h"
#include "read_csv_003.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

static Logging* log_001;
static LOG_001* dlog_001 = NULL;

static char* filename_002 = NULL;
static FILE* rfp = NULL;

int csv_once (int *index, int *end_index ) ;
char get_char_002 (int *index) ;
int endline_002 ( char bc, char c) ;
int puttheword_002 ( int ii, int jj, char* word_002 ) ;
char* m_concat_c_002 ( char* word_002 , int c ) ;
int Set_Logging_read_csv_002 ( Logging* log ) ;
char* gettheword_002_c () ;


char* word_002  = NULL;
char* word_002_c = NULL;

static int ii, jj;


// Add; mode and quotes
// example
int csv_once_002 (int *index, int *end_index ) {
	int i;
	static int mode = 0;
	int count = 0;
	char c, bc;
	int word_002_cnt;
	int continued_flg = 0;
	char msg[255];

	printf("int csv_once_002 (int *index, int *end_index ) starts.\r\n");
	dlog_001 = log_001->update_log ( (char*)"int csv_once_002 (int *index, int *end_index ) starts." );

	if ( *index == 0 ) { ii=0; jj=0; }

	for ( i = *index; i< 10 + *index && i < *end_index; i++ ) {
		count++;
		c = get_char_002 (&i);

		if ( mode == 11 && c == '\"' ) {
			// double quote
			dlog_001 = log_001->update_log ( (char*)"csv_once_002 if 001" );
			mode = 10;
		} else if ( mode == 0 && c == '\"' ) {
			dlog_001 = log_001->update_log ( (char*)"csv_once_002 if 002" );
			// double quote
			mode = 11;
		} else if ( mode == 10 && c == endline_003 ( bc, c) ) {
			dlog_001 = log_001->update_log ( (char*)"csv_once_002 if 003" );
			word_002_cnt = array_count (word_002);
			if (word_002_cnt > 0 ) word_002[ word_002_cnt - 1 ] = '\0';
			continued_flg = 2;
			mode = 0;
		} else if ( mode == 10 && c == '\,' ) {
			dlog_001 = log_001->update_log ( (char*)"csv_once_002 if 004" );
			continued_flg = 1;
			mode = 0;
		} else if ( mode == 0 && c == '\,' ) {
			dlog_001 = log_001->update_log ( (char*)"csv_once_002 if 005" );
			continued_flg = 1;
		} else if ( mode == 0 && endline_003 ( bc, c) ) {
			dlog_001 = log_001->update_log ( (char*)"csv_once_002 if 006" );
			word_002_cnt = array_count (word_002);
			if (word_002_cnt > 0 ) word_002[ word_002_cnt - 1 ] = '\0';
			continued_flg = 2;
		} 

		bc = c;

		if ( continued_flg != 0 ) {
			dlog_001 = log_001->update_log ( (char*)"csv_once_002 if 011" );

			sprintf( msg, "msg continued %d mode %d ii %d jj %d word_002 |%s|\0\0", continued_flg, mode, ii, jj, word_002 );
			dlog_001 = log_001->update_log ( (char*) msg );

			puttheword_004 ( ii, jj, (char*) word_002 );

			if ( continued_flg == 1 ) { ii++; }
			if ( continued_flg == 2 ) { ii =0; jj++; }

			word_002 = NULL;
			continued_flg = 0;
			continue;
		}

		dlog_001 = log_001->update_log ( (char*)"csv_once_002 if 012" );

		word_002_c = (char*) m_concat_c_002 ( (char*) word_002 , (int) c );
		csvafree_005(word_002);
		word_002 = word_002_c;
		word_002_c = NULL;

		sprintf( msg, "count %d word_002 |%s| word_002_c |%s| c|%d| mode %d", count, word_002, word_002_c, c, mode );
		dlog_001 = log_001->update_log ( (char*)msg );
	}

	*index += count;
	dlog_001 = log_001->update_log ( (char*)"int csv_once_002 (int *index, int *end_index ) ends." );
	printf("int csv_once_002 (int *index, int *end_index ) ends.\r\n");
	return 0;
}


//
char get_char_002 (int *index_r ) {
	char dummy[255];
	char rc;
	char msg[255];

	printf("char get_char_002 (int *index_r ) starts.\r\n");

	printf("filename_002 %s\r\n", filename_002);
	rfp = (FILE*) fopen( filename_002, "rb" );
	if (rfp == NULL) {
		exit(-1);
	}

	sprintf( msg, "SEEK index_r |%d|", *index_r );
	dlog_001 = log_001->update_log ( (char*)msg );

	fseek( rfp, *index_r, SEEK_SET);
	fread ( dummy, 1, 1, rfp );

	fclose(rfp);
	rc = dummy[0];
	printf("char get_char_002 (int *index_r ) ends.\r\n");
	return rc;
}

int endline_002 ( char bc, char c) {
	return 0;
}

char* gettheword_002_c () {
	dlog_001 = log_001->update_log ( (char*)"char* gettheword_002_c () starts." );
	dlog_001 = log_001->update_log ( (char*) m_concat( (char*) "word_002_c:", word_002_c ) );
	dlog_001 = log_001->update_log ( (char*)"char* gettheword_002_c () ends." );
	return word_002_c;
}

int puttheword_002 ( int ii, int jj, char* word_002 ) {
	return 0;
}


char* m_concat_c_002 ( char* word_002 , int c ) {
	static char* dummy = NULL;
	char cc;
	char msg[255];

	cc = (char)c;

	if ( dummy == NULL ) {
		dummy = (char*) malloc ( sizeof(char) * 4 );
		if ( dummy == NULL ) return NULL;
	}
	dummy[0] = c;
	dummy[1] = '\0';

	sprintf( msg, "msg dummy |%s| c|%d|", dummy, c );
	dlog_001 = log_001->update_log ( (char*)msg );

	return m_concat( word_002, dummy );
}

//
int Set_Logging_read_csv_002 ( Logging* log ) {
	printf("int Set_Logging_read_csv_002 ( Logging* log ) starts.\r\n");
	log_001 = (Logging*)log;
	printf("int Set_Logging_read_csv_002 ( Logging* log ) ends.\r\n");
	return 0;
}

int Set_Filename_002 ( char* filename ) {
	filename_002 = (char*)filename;
	return 0;
}
