#include "wKickEvent.h"

void wKickEvent::setId (int id ) {
	this->id_p = id;
}