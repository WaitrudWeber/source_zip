int filewriter_003 ();

filewriter_003 () {
nreturn 1;

}


