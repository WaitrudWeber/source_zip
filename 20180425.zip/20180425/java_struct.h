
typedef struct JavaKeywords JAVA_KEYWORDS;
typedef struct JavaClass JAVA_CLASS;


struct JavaClass {
	char* main_class;
	char* modifier;

	char** methods;
	int method_num;
	char** attributes;
	int attributes_num;

	JAVA_CLASS *sub_class;
	int sub_class_num;
};

struct JavaKeywords {
	char** package;
	int package_num;
	int package_num_size;

	char** import;
	int import_num;
	int import_num_size;

	char* main_class;

	JAVA_KEYWORDS *next;
};

//extern JAVA_KEYWORDS java_keywords;
extern int put_package( char* name_package );
extern int put_import ( char* name_import );

extern int initialize_java_keywords () ;

// for text
extern int check_structor ();

extern int set_main_class_modifier ( char* modifier ) ;
extern int set_main_class ( char* name_class ) ;

extern int print_main_class ( JAVA_CLASS j ) ;
extern int print_main_class ();


