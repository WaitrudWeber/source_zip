#include <stdio.h>
#include <stdlib.h>

#include "java_struct.h"
#include "array_counter.h"
#include "parse.h"

/*

	0: libraries
	1: class
	2: method
	3: 

*/


int parse ( char* filename );
int parse_origin ( char* filename );

// do not use usually.
int parse_slash ( int index, int file_end, FILE *fp );
int parse_check_counter ( FILE *fp, int file_end );

int parse_libraries ( FILE *fp, int file_end);
int parse_class ( FILE *fp, int file_end );
int parse_method ( FILE *fp, int file_end );

int parse_library_name ( FILE *fp, int file_end, char* _type );
int parse_comment_out ( FILE *fp, int file_end );

int token_check( );
int filesize( FILE *fp );
int analyze ( char* tkn );

int analyze_libraries ( char* tkn );
int compare ( char* tkn, char* m );

int almost_empty ( char* tkn );
int modifier ( char* tkn );
int analyze_class_modifier ( char* tkn ) ;



int main ( int argc, char *argv[] ) {

	initialize_java_keywords ();
	initialize_parse();

	m_filename = argv[1];
	parse ( argv[1] );

	return 0;
}

int token_check( ) {

	token[0] = 'a';
	printf("%d\n", token[0]);

	return 0;
}

int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

int parse_check_counter ( FILE *fp, int file_end ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		printf ( "i=%d c=%s c=%d m_count=%d m_cnt_tkn=%d m_size=%d\n", i, (char*)dummy, (int)dummy[0], m_count, m_cnt_tkn, m_size );

		printf( "parse_check_counter\n" );
		token = put_token ( dummy[0] );
	}

	printf("token:%s\n", token );
	return 1;
}

// return 2: changed m_mode
int parse_libraries ( FILE *fp, int file_end ) {
	char dummy[1];
	int success;

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		// 20180421
		if ( line_end ( dummy[0] ) == 1 && m_cnt_tkn == 0 ) {
			// printf(" line_end and m_cnt_tkn = 0\n");
			// exit( -1);
			break;
		}

		switch ( dummy[0] ) {
		case ' ':
			// 20180421 for debug.
			printf( "token: %s\n", token);
			// exit( - 1 );
			success = analyze_libraries ( token ) ;
			printf ( "success = %d \n", success );
			// exit ( -1 );
			switch ( success ) {
			case -1:
				// it could get token keyword other than "package" and "import".
				exit ( -1 );
				break;
			case 1:
				// it could get token keyword "package" or "import".
				parse_library_name ( fp, file_end, (char *) "package");
				m_cnt_tkn = 0;
				break;
			case 2:
				// it could get token keyword "package" or "import".
				parse_library_name ( fp, file_end, (char *) "import");
				m_cnt_tkn = 0;
				break;
			case 3:
				// it will pass it because token is almost empty.
				printf( "token is almost empty.\n" );
				exit ( -1 );
				m_cnt_tkn = 0;
				break;
			case 4:
				printf( "keywords: class modifier: %s\n", token );
				m_mode = 1;
				return 2;
				// it does not reset m_cbt_tkn and still have token.
				// m_cnt_tkn = 0;
				// exit ( -1 );
				// break;
			}
			break;
		case '/':
			if ( parse_comment_out ( fp, file_end ) == 1 ) return 1;
			break;
		}

		// 20180423
		if ( alphabet ( dummy[0] ) == 1 ) {
			// printf( "parse_libraries %s %d A:%d z:%d\n", dummy, dummy[0], 'A', 'z' );
			token = put_token ( dummy[0] );
		}

		// for debug
		if ( i - m_count > 100 ) {
			printf ( "over loop, so it stopped.\n" );
			exit ( -1 );
		}
	}

	return 1;
}

int parse_comment_out ( FILE *fp, int file_end ) {
	char dummy[1];
	int flag = 0;
	// 0, 1  -> to line end.
	// 10, 11 -> to */.

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( flag ) {
		case 0:
			switch ( dummy[0] ) {
			case '/':
				flag = 1; // to line end
				break;
			case '*':
				flag = 10; // to */
				break;
			}
			break;
		case 1:
			switch ( dummy[0] ) {
			case '\n':
				return 1;
				break;
			default:
				break;
			}
			break;
		case 10:
			switch ( dummy[0] ) {
			case '*':
				flag = 11;
				break;
			default:
				break;
			}
			break;
		case 11:
			switch ( dummy[0] ) {
			case '/':
				return 1;
			default:
				flag = 10;
				break;
			}
			break;
		}

		//token = put_token ( dummy[0] );
	}

	printf("comment out end: line %d raw %d\n", m_line, m_raw);
	exit( -1 );
}

int parse_library_name ( FILE *fp, int file_end, char* _type ) {
	char dummy[1];
	int end = -1;

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( dummy[0] ) {
//		case ' ':
//			break;
		case ';':
			end = 1;
			break;
		}
		if ( end == 1 ) break;

		// printf( "parse_library_name\n" );
		token = put_token ( dummy[0] );
	}

	if ( compare ( _type, (char*) "package" ) == 1 ) {
		put_package ( token );
		printf ( "package name=%s\n", token ) ;
//		exit( -1 );
		return 1;
	} else if ( compare ( _type, (char*) "import" ) == 1 ) {
		put_import ( token );
		printf ( "import name=%s\n", token ) ;
//		exit( -1 );
		return 1;
	}

	printf( "end of parse_library_name means it doesn't hit package and import.\n" );
	printf( "_type = %s\n", _type );
	exit( -1 );
	
	return 1;
}

int parse_class_name ( FILE *fp, int file_end  ) {
	char dummy[1];

	//printf( "parse_class_name=%s\n", token );
	//exit( -1 );

	for( int i=m_count; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( dummy[0] ) {
		case ' ':
			printf( "parse class name: %s\n", token);
			return 1;
			//exit( -1 );
			//break;
//		case '(':
//			printf( "parse class name: %s\n", token);
//			exit( -1 );
//			break;
		default:
			break;
		}

		token = put_token( dummy[0] );
		//printf( "token=%s\n", token );
	}

	return -1;
}

int parse_inside_class ( FILE *fp, int file_end  ) {
	char dummy[1];

	// token = put_token( 'a' );
	// printf( "m_cnt_tkn = %d token=%s\n", m_cnt_tkn, token );
	// exit ( -1 );

	for( int i=m_count; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		//printf("token:%s\n", token );

		switch ( dummy[0] ) {
		case ' ':
			if ( m_cnt_tkn != 0 ) {
				token = put_token( dummy[0] );
			}
			break;
		case '\n':
			if ( m_cnt_tkn != 0 ) {
				token = put_token( dummy[0] );
			}
			break;
		case ';':
			token = put_token( dummy[0]);
			printf( "code_line= %s\n", token ); 
			exit( -1 );
			break;
		default:
			token = put_token( dummy[0]);
			//printf("token= %s\n", token );
			//exit( -1 );
			break;
		}
	}

	exit( -1 );
	return -1;
}

int parse_class ( FILE *fp, int file_end  ) {
	char dummy[1];
	int readable = -1;

	// printf("parse_class\n");

	for( int i=m_count; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( dummy[0] ) {
		case ' ':
			if ( readable == 1 ) {

				printf("parse_class: token: %s\n", token);
				if ( compare ( (char *)"class", token ) == 1 ) {
					m_cnt_tkn = 0;
					parse_class_name ( fp, file_end ); 
					set_main_class ( token ) ;
					printf( "print_main_class:\n" );
					print_main_class();
				} else {
					printf("its not keyword: class.\n");
					exit( -1 );
				}

				// exit( -1 );
			}
			break;
//		case '/':
//			break;
		case '{':
			printf("Analiyzer found \'{\'. token:%s c:%s\n", token, dummy);
			m_cnt_tkn = 0;
			parse_inside_class ( fp, file_end ); 
			exit ( -1 );
			return 1;
		default:
			if ( readable == -1 && alphabet(dummy[0]) ) {

				token = put_token( dummy[0]);
				readable = 1;

			} else if ( readable == 1 && alphabet(dummy[0]) ){

				token = put_token( dummy[0]);
			} else {

				printf("parse_class: token: %s c=%s readable=%d\n", token, dummy, readable);
				exit( -1 );
			}
			break;
		}

		if ( i - m_count > 100 ) {
			printf("i=%d\n", i);
			printf("token:%s\n", token );
			exit( -1);
		}
	}

	return 1;
}

int parse_method ( FILE *fp, int file_end  ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		switch ( dummy[0] ) {
		case ' ':
			break;
		case '/':
			break;
		}
	}

	return 1;
}

int parse ( char* filename ) {

	FILE *fp;
	// char dummy[1];
	// int a;

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end; i++ ) {
		switch ( m_mode ) {
		case 0:
			if ( 2 == parse_libraries ( fp, file_end ) ) {
				analyze_class_modifier ( token ) ;
				// a = array_count ( token );
				// m_count -= a;
				m_mode = 1;
			}
			break;
		case 1:
			parse_class ( fp, file_end );
			break;
		case 2:
			parse_method ( fp, file_end );
			break;
		}
	}

	fclose(fp);

	return 1;
}

int analyze_class_modifier ( char* tkn ) {

	int m = -1;
//	JAVA_CLASS java_class;

	if ( ( m = modifier( tkn ) )== -1 ) {
		printf( "analyze_class_modifier: %d it's not modifier.", m);
		exit(-1);
	}

	printf ("modifier: %d\n", m);
	
	switch ( m ) {
	case 1:
		set_main_class_modifier( (char *)"public" );
		m_cnt_tkn = 0;
		return 1;
	case 2:
		set_main_class_modifier( (char *)"private" );
		m_cnt_tkn = 0;
		return 1;
	case 3:
		set_main_class_modifier( (char *)"protected" );
		m_cnt_tkn = 0;
		return 1;
	}

	// exit( -1 );
	return -1;
}

int parse_origin ( char* filename ) {

	FILE *fp;
	fp = fopen ( filename, "rb" );
	char dummy[1];

	int file_end = filesize ( fp );

	for( int i=0; i<file_end; i++ ) {

		m_fread ( dummy, 1, fp);

		switch( dummy[0] ) {
		case ' ':
			analyze ( token ) ;
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		printf( "parse_origin\n" );
		token = put_token ( dummy[0] );
//		printf( "%d %d\n", *token, token);
		printf ("dummy=%s token=%s token[%d]=%d token[%d]=%d\n", dummy, token, i, token[i], i + 1, token[ i + 1] );
	}

	printf("token=%s\n", token);

	for( int i=0; i<file_end; i++ ) {

		switch( dummy[0] ) {
		case ' ':
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		printf( "%d\n", token[i] );
	}

	fclose(fp);

	return 0;
}

//
// return 1 means package.
// return 2 means import.
// return 3 means pass which means token is empty.
// return 4 means modifier which means class modifier here.

int analyze_libraries ( char* tkn ) {

	// printf("analyze libraries line %d raw %d it's not keyword: %s\n", m_line, m_raw, tkn );
	// exit(-1);


	if ( compare ( tkn, (char *)"package" )  == 1 ) {

		printf("it's keyword: %s\n", tkn );
		return 1;

	} else if ( compare ( tkn, (char *)"import" ) == 1 ) {

		printf("it's keyword: %s\n", tkn );
		return 2;

	} else {

		// almost empty
		if ( almost_empty ( tkn ) == 1 ) return 3;

		// 20180424
		if ( modifier( (char *)tkn ) != -1 ) return 4;

		printf("line %d raw %d it's not keyword: %s\n", m_line, m_raw, tkn );

	}

	return 0;
}

// return 1: public
// return 2: private
// return 2: protected
int modifier ( char* tkn ) {

	if ( compare( tkn, (char*)"public" ) == 1 ) return 1;
	if ( compare( tkn, (char*)"private" ) == 1 ) return 2;
	if ( compare( tkn, (char*)"protected" ) == 1 ) return 3;

	return -1;
}

int almost_empty ( char* tkn ) {

	int a = array_count ( tkn );
	for ( int i=0; i<a; i++ ) {
		if ( tkn[i] != ' ' && line_end ( tkn[i] ) == 0 ) return -1; // error: not space and not line end.
	}

	return 1;
}

int compare ( char* tkn, char* m ) {

	int count_t = array_count( m );
	int count_m = array_count( m );

	if ( count_t != count_m ) return -1;

	// match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) return -1;
	}

	return 1;
}

int analyze ( char* tkn ) {

	m_mode = 0;
	
	switch(m_mode) {
	case 0:
		// keyword outside class
		printf("%s\n", tkn );
		exit( -1 );
		//analyze_libraries( tkn );
		break;
	case 1:
		// name outside class
		break;
	case 2:
		break;
	}

	return 0;
}

int parse_slash ( int index, int file_end, FILE *fp ) {

	char dummy[1];

	for( int i=index; i<file_end; i++ ) {

		m_fread ( dummy, 1, fp);
	}

	return 0;
}



