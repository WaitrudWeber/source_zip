

class v3dCalculation {

	void calculation_threed () ;

}:
