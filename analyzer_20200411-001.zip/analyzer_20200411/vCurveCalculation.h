#ifndef _VCURVECALCULATION_H_
#define _VCURVECALCULATION_H_

//----vCurveCalculation
class vCurveCalculation {
	public:
		int a = 0;

	private:
		int pa = 0;

	public:
		vPoint* BattleField (vPoint* p1, vPoint* p2, vPoint* p3, vPoint* p4, float t);
//		vPoint* Position (vPoint p1, vPoint* p2, vPoint *p3, vPoint* p4, float t);

	private:

};

#endif
