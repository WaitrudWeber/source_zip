// https://github.com/WaitrudWeber/source_zip/blob/master/winmain-20190109.zip
// https://docs.microsoft.com/en-us/windows/desktop/dataxchg/using-the-clipboard

//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-hProcess-in-mingw-what-to-use-instead
// #include <strsafe.h>

//#include <mmdeviceapi.h>

#include "resource.h"

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"

#include "clipboard.h"

#include "button.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "display_threeD.h"
#include "vPointStructure.h"


#include "vSoundBuffer_001.h"


#include "wEvent.h"
#include "wEventListener.h"

#include "wJavaStructure.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

#include "wTextarea.h"
#include "wTextareaController.h"

#include "something_word.h"
#include "thread_print.h"


#include "wDisplayController.h"
//#include "wParamSynse_003.h"
#include "wCanvasController.h"

#include "cg_schema.h"


#include "ReturnableParam.h"

#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "winmainthread_001.h"
#include "winmainthread_002.h"

#define _DRAW_PARAM_00000000000000000000000000000001_ 1
#define _DRAW_PARAM_00000000000000000000000000000010_ 2
#define _DRAW_PARAM_00000000000000000000000000000100_ 4
#define _DRAW_PARAM_00000000000000000000000000001000_ 8
#define _DRAW_PARAM_00000000000000000000000000010000_ 16
#define _DRAW_PARAM_00000000000000000000000000100000_ 32
#define _DRAW_PARAM_00000000000000000000000001000000_ 64
#define _DRAW_PARAM_00000000000000000000000010000000_ 128
#define _DRAW_PARAM_00000000000000000000000100000000_ 256
#define _DRAW_PARAM_00000000000000000000001000000000_ 512
#define _DRAW_PARAM_00000000000000000000010000000000_ 1024
#define _DRAW_PARAM_00000000000000000000100000000000_ 2048
#define _DRAW_PARAM_00000000000000000001000000000000_ 4096
#define _DRAW_PARAM_00000000000000000010000000000000_ 8192
#define _DRAW_PARAM_00000000000000000100000000000000_ 16384
#define _DRAW_PARAM_00000000000000001000000000000000_ 32768
#define _DRAW_PARAM_00000000000000010000000000000000_ 65536
#define _DRAW_PARAM_00000000000000100000000000000000_ 131072
#define _DRAW_PARAM_00000000000001000000000000000000_ 262144
#define _DRAW_PARAM_00000000000010000000000000000000_ 524288

LRESULT CALLBACK mainWindowProc_023 (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK mainWindowProc_023 (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;
    RECT clientRect;
    RECT textRect;
    HRGN bgRgn;
    HBRUSH hBrush;
    HPEN hPen;


    switch (message)
    {
    
    case WM_PAINT:
        {
        hdc = BeginPaint(hWnd, &ps);
        
        // Fill the client area with a brush
        GetClientRect(hWnd, &clientRect);
        bgRgn = CreateRectRgnIndirect(&clientRect);
        hBrush = CreateSolidBrush(RGB(200,200,200));
        FillRgn(hdc, bgRgn, hBrush);

        
        hPen = CreatePen(PS_DOT,1,RGB(0,255,0));
        SelectObject(hdc, hPen);
        SetBkColor(hdc, RGB(0,0,0));
        Rectangle(hdc, 10,10,200,200);
        
        // Text caption
        SetBkColor(hdc, RGB(255,255,255));
        SetRect(&textRect, 10, 210, 200,200);
        DrawText(hdc,TEXT("PS_DOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);

        
        hPen = CreatePen(PS_DASHDOTDOT,1,RGB(0,255,255));
        SelectObject(hdc, hPen);
        SetBkColor(hdc, RGB(255,0,0));
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
        Rectangle(hdc, 210,10,400,200);
        
        // Text caption
        SetBkColor(hdc, RGB(255,200,200));
        SetRect(&textRect, 210, 210, 400,200);
        DrawText(hdc,TEXT("PS_DASHDOTDOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);
        

        hPen = CreatePen(PS_DASHDOT,1,RGB(255,0,0));
        SelectObject(hdc, hPen);
        SetBkColor(hdc, RGB(255,255,0));
        SelectObject(hdc,CreateSolidBrush(RGB(100,200,255)));
        Rectangle(hdc, 410,10,600,200);
        
        // Text caption
        SetBkColor(hdc, RGB(200,255,200));
        SetRect(&textRect, 410, 210, 600,200);
        DrawText(hdc,TEXT("PS_DASHDOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);
        

        // When fnPenStyle is PS_SOLID, nWidth may be more than 1.
        // Also, if you set the width of any pen to be greater than 1, 
        // then it will draw a solid line, even if you try to select another style.
        hPen = CreatePen(PS_SOLID,5,RGB(255,0,0));
        SelectObject(hdc, hPen);
        // Setting the background color doesn't matter 
        // when the style is PS_SOLID
        SetBkColor(hdc, RGB(255,255,255));
        SelectObject(hdc,CreateSolidBrush(RGB(200,100,50)));
        Rectangle(hdc, 10,300,200,500);
        
        // Text caption
        SetBkColor(hdc, RGB(200,200,255));
        SetRect(&textRect, 10, 510, 200,500);
        DrawText(hdc,TEXT("PS_SOLID"),-1,&textRect, DT_CENTER | DT_NOCLIP);
    
        hPen = CreatePen(PS_DASH,1,RGB(0,255,0));
        SelectObject(hdc, hPen);
        SetBkColor(hdc, RGB(0,0,0));
        SelectObject(hdc,CreateSolidBrush(RGB(200,200,255)));
        Rectangle(hdc, 210,300,400,500);
        
        // Text caption
        SetBkColor(hdc, RGB(255,255,200));
        SetRect(&textRect, 210, 510, 400,200);
        DrawText(hdc,TEXT("PS_DASH"),-1,&textRect, DT_CENTER | DT_NOCLIP);

        hPen = CreatePen(PS_NULL,1,RGB(0,255,0));
        SelectObject(hdc, hPen);
        // Setting the background color doesn't matter 
        // when the style is PS_NULL
        SetBkColor(hdc, RGB(0,0,0));
        SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        Rectangle(hdc, 410,300,600,500);
        
        // Text caption
        SetBkColor(hdc, RGB(200,255,255));
        SetRect(&textRect, 410, 510, 600,500);
        DrawText(hdc,TEXT("PS_NULL"),-1,&textRect, DT_CENTER | DT_NOCLIP);
        
        
        // Clean up
        DeleteObject(bgRgn);
        DeleteObject(hBrush);
        DeleteObject(hPen);

        GetStockObject(WHITE_BRUSH);
        GetStockObject(DC_PEN);

        EndPaint(hWnd, &ps);
        break;
        }
    

    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}
//
