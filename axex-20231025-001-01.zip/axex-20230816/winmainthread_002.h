#ifndef _WINMAINTHREAD_002_H_
#define _WINMAINTHREAD_002_H_

//extern static LRESULT CALLBACK mainWindowProc_021 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
//extern LRESULT CALLBACK mainWindowProc_021 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
//extern LRESULT CALLBACK mainWindowProc_022 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern LRESULT CALLBACK mainWindowProc_025 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

#endif
