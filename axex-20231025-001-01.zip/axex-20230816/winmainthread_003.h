#ifndef _WINMAINTHREAD_003_H_
#define _WINMAINTHREAD_003_H_

extern LRESULT CALLBACK mainWindowProc_023 (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

#endif
