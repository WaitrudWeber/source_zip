#ifndef _VSOUNDBUFFER_001_H_
#define _VSOUNDBUFFER_001_H_

// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.


class vSoundBuffer_001 {
	public:
		int CursolNumber;
		char SoundBuffer[255];

	public:
		char getBuffer( int index );

};

#endif


