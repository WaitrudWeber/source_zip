int filewriter_009 ();

filewriter_009 () {
nreturn 1;

}


