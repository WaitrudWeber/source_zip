int filewriter_000 ();

filewriter_000 () {
nreturn 1;

}


