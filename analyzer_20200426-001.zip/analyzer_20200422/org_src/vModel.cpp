#include "vPoint.h"
#include "vTriangle.h"

#include "vModel.h"

vModel::getTriangleNumber() {

	return triangleMumber;
}

