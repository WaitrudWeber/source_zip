#ifndef SERVER_H
#define SERVER_H

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "27015"

// extern char recvbuf[DEFAULT_BUFLEN];
// extern int recvbuflen = DEFAULT_BUFLEN;

extern int server_console_line;

extern char* server_buffer_recv;
extern int update_thread;

extern int __cdecl server_main(void);
extern int __cdecl boot_console_server(void) ;

extern int writetext () ;

extern char* buffer_debug_log;

#endif
