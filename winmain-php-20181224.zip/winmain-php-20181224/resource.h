#define IDM_ABOUT 104
#define IDM_EXIT 105
#define IDC_HP 109
#define IDC_EDIT1 1001
