#nclude <stdio.h>
#nclude <stdlib.h>

// round backet: (
// curly backet: {
// square backet: [



int main( int argc, char* argv[] ) {

	return 0;
}


// 1.Find first alphabet anyway.



// 2.From the index of 1, You must judge
// 	if next word is modification.
// 	if next word is class.
// 	if next word is type.

// 3.From 2, Next word is function-name usually if threre is "(":round brace after the word.







