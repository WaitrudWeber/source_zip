

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"



#include "wEvent.h"
#include "wDisplayController.h"

#include "wButton.h"
#include "wButtonController.h"

/*void wDisplayController::Set_wEvent (wEvent* ev ) {
	p_evt = (wEvent*)ev;
}*/


void wDisplayController::Set_Lines (vLine** l ) {
	lines = l;
}

void wDisplayController::Set_Lines_2D (vLine** l_2D ) {
	lines_2D = l_2D;
}

int wDisplayController::nDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	return 0;
}

