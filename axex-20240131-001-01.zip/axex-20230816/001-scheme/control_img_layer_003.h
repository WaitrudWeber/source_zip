#ifndef _CONTROL_IMG_LAYER_003_
#define _CONTROL_IMG_LAYER_003_
//...
extern int control_img_layer_003 ();
extern int set_control_img_layer_003 (int ii, int jj, char* word);
extern int initialize_control_img_layer_003 (int ii, int jj, char* word);
#endif
