#ifndef _WPOINTLINEAR_H_
#define _WPOINTLINEAR_H_

class vPointLinear {

	public:
		vPointStructure PS1, PS2;
		float T; // 0 <= T <= 1
		vPointStructure** aPS = nullptr;
		int numPS = 0;
		vPoint** normal_faces = nullptr;

	private:

	public:
		vLine** generateLines( vPointStructure** ps, int num_devide );
		vPoint position( vPoint* c1, vPoint* c2, float t ) ;
		vPoint additional_positionP( vPoint* c1, vPoint* c2, float t ) ;
		vPoint additional_position ( vPointStructure* ps1, vPointStructure* ps2, float t ) ;
		void calculation () ;
		void calculation_array () ;
		vLine** FirstCreateLines( vPointStructure** ps, int num_devide ) ;
		void FirstCreatation();
		void GetNormal ( vPoint* p1, vPoint* p2, vPoint* p3, vPoint* normal ) ;
		void FirstRevisement( ) ;
		void PrintAnchors ();
		void PrintControls( );

	private:


};

#endif
