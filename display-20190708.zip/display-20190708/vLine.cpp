#include "vPoint.h"
#include "vLine.h"

vLine::vLine ( ) {

	this->p1 = new vPoint();
	this->p2 = new vPoint();
}

//
//
//
//
//
void vLine::setLine ( vPoint* ap1, vPoint* ap2 ) {
	p1->x = ap1->x;
	p2->x = ap2->x;
	p1->y = ap1->y;
	p2->y = ap2->y;
	p1->z = ap1->z;
	p2->z = ap2->z;
}

//
//
//
//
//
void vLine::print () {
	if ( this->p1 == nullptr || this->p2 == nullptr) {
		return;
	}

	this->p1->print();
	this->p2->print();
}

