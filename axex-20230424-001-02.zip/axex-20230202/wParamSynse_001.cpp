
#include "wParamSynse_001.h"

wParamSynse_001::wParamSynse_001 () {
}
