#ifndef _DISPLAY_THREED_INITIALIZE_
#define _DISPLAY_THREED_INITIALIZE_

extern int display_threeD_initialize () ;
extern int display_threeD_screen_initialize () ;
extern int getchar_display_threeD_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern int get_cooordinate_on_screen ( vPoint lp, float* lx, float* ly );
extern int wmpaint_display_threeD_proc_org ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern int wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern int wmpaint_display_patches ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int curve_initialization () ;
extern int eDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int fDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int gDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int hDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int iDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int jDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int kDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int lDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int mDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int nDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;

extern vLine* to_screen_line( vLine* ll ) ;
extern int print_screen ();

// 20210306
extern int convert_model_lines( vLine **lines, vLine **lines_2D, int line_index, int max_num ) ;
extern int create_model_lines( vLine **lines, int *line_index, int max_num ) ;
extern int create_curve_lines ( int num ) ;
extern int spin_screen() ;
extern int print_lines ();

// 20210802
extern int create_vaxex_test () ;

extern int convert_AXEX_2D () ;


extern vLine** lines;		// axes in the 3-D.
extern vLine** lines_2D;  // axes on the screen.
extern int line_index;

//20210810
extern vLine lines_001[30];
extern vLine lines_2D_001[30];

//20210930
extern int display_threeD_screen_initialize_004 () ;
extern int display_threeD_screen_initialize_005 () ;

//20211001
extern vScreen screen_004;

// 20210306
#define MAX_LINE 100

#endif
