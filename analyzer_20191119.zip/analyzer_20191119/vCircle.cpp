#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vCircle.h"




void vCircle::calculation( vPoint set_up, vPoint right_x ) {

	vPoint* next = nullptr;
	vPoint* base_xaxis = nullptr;
	vPoint* up = nullptr;
	vPoint* depth = nullptr;
	vPoint* right = nullptr;
	vPoint* start = nullptr;
	vCalculation* calc = nullptr;

	float PI = 3.141592f;
	float exact_length = this->R*PI;
	float length = 0.0f;

	calc = new vCalculation ();

	depth = new vPoint();
	right = new vPoint();
	up = &set_up;
	base_xaxis = &right_x;
	calc->cross( up , base_xaxis, depth );
	calc->cross( depth , up, right );
	calc->normal( up );
	calc->normal( right );
	calc->normal( depth );

	calc->scale( depth, this->R, start );
	//calc->scale( right, this->R );

	// malloc
	this->pixels = (vPoint**) malloc( sizeof(vPoint*) * this->max_pixel );
	for ( int i=0; i<this->max_pixel; i++ ) {

		if ( i < this->max_pixel ) {
			//realloc
			this->pixels = (vPoint**) realloc( this->pixels, sizeof(vPoint*) * this->max_pixel );
			this->max_pixel *= 2;
		}
		this->pixels[i] = new vPoint();

		// finish the next calculation.
		length += 10000.0f;
		if ( length > exact_length ) { 
			break;
		}

	}

}

