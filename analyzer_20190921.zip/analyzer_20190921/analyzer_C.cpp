#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "aToken.h"

#include "analyzer_C.h"

// argv[0] : file name
//
//
//
//
int Analyzer::analyze_C (int argc, char** argv ) {

	this->parse(argv[0]);

	return 0;
}

//
//
//
//
//
//
int Analyzer::skip_to( char* skip_to, int *index , int file_end, FILE *fp) {
	aToken *iToken = nullptr;
	iToken = new aToken ();

	return iToken->skip_to( skip_to, index, file_end, fp);
}

//
//
//
//
//
int Analyzer::parse ( char* filename ) {
	FILE *fp;
	aToken *iToken = nullptr;
	char *parse_token;
	int previous_index = 0;
	char dummy[256];

	iToken = new aToken();
	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end && i<2000; i++ ) {
		//m_fread ( dummy, 1, fp);
		printf("i: %d\r\n", i );
		parse_token = iToken->getToken( fp, &i, &file_end );
	}

	fclose(fp);
	return 1;

}

//
//
//
//
//
int Analyzer::parse_token ( char* filename ) {
	FILE *fp;
	aToken *iToken = nullptr;
	char *parse_token;
	int previous_index = 0;

	iToken = new aToken();
	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end && i<2000; i++ ) {
		// DEBUG
		previous_index = i;

		// the below has problem at 20190913.
		parse_token = iToken->getToken( fp, &i, &file_end );
		printf("001 parse_token: |%s|\r\n", parse_token );
		// this cannot scope the below function, but sucope it in aDebug.cpp at 20190303
		// DEBUG_SUB( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// DEBUG ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// o debug_msg_001 ();
		// DEBUG_002 ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// printf("msg: |%s|\r\n", msg );
		// err_msg_001 ( "parse_token: |%s|", parse_token ) ;

		if ( m_compare( parse_token, (char *) "void" ) == 1 ) {

			printf("void\r\n");
			exit(-1);

		} else if ( m_compare( parse_token, (char *) "#" ) == 1 ) {

			printf("found #\r\n");
			exit(-1);

		} else if ( m_compare( parse_token, (char *) "/*" ) == 1 ) {

			printf("001 comment out starts: i %d raw %d line %d\r\n", i, iToken->getRaw(), iToken->getLine() );
			int return_value = this->skip_to( "*/", &i , file_end, fp);
			printf("001 comment out ends: i %d raw %d line %d\r\n", i, iToken->getRaw(), iToken->getLine() );

			// reset token 001
			iToken->free_main_token();
			printf("002\r\n");
			free( parse_token );
			printf("003\r\n");

			//exit(-1);

		} else if ( m_compare( parse_token, (char *) "#define" ) == 1 ) {

			// We couldn't come here but well.
			printf("token: #define\r\n");
			exit(-1);

		} else {

			printf("else: %s \r\n", parse_token);
			printf("parse_token: |%s|\r\n", parse_token );
			iToken->free_main_token ();
			exit(-1);

		}

		printf("002 parse_token: |%s|\r\n", parse_token );

		// DEBUG
		if ( previous_index > i ) {
			printf("previous_index > i\r\n");
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		} else if ( previous_index == i ) {
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		}

		printf("003 parse_token: |%s|\r\n", parse_token );
	}

	fclose(fp);

	return 1;
}

//
//
//
//
//
int Analyzer::filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}




