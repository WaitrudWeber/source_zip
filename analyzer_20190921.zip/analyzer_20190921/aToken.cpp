#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

//#include <ctime>

#include "array_counter.h"
#include "parse.h"
#include "aToken.h"

aToken::aToken () {
	initialize_parse();
}

int aToken::clear_token()
{
	clear_token() ;

	return 1;
}

int aToken::getRaw()
{
	return m_raw - 1;
}

//
//
//
//
//
//
int aToken::getLine()
{
	return m_line;
}
// Qualified: 20190921: found #define: 
//
//
//
//
//
char* aToken::getToken( FILE *fp, int *index, int *file_end )
{
	static char dummy[256];
	int breakable = 0;
	int mode_token = 0;
	int found = 0;

	printf("start of aToken::getToken\r\n");

	for ( int i=( *index ); i< (*file_end) && breakable == 0 && i <1868; i++ ) {
		printf("g i: %d \r\n", i );
		m_fread ( dummy, 1, fp);
		token = put_token ( dummy[0] );
		printf("token: %s\r\n", token);
		switch ( mode_token ) {
		case 0: // find any first literals.
			found = found_first_literals( token, fp, &i, file_end);
			break;
		case 1:
			break;
		case 2:
			break;
		}

		printf("found %d \r\n", found );
		switch( found ) {
		case 1:
			this->skip_to( (char*) "*/", &i, (*file_end), fp);
			found = 0;
			// exit(-1);
			this->free_main_token();
			break;
		case 2: // found #define
			this->free_main_token();
			exit(-1);
			break;
		case 3: // found #include
			this->free_main_token();
			exit(-1);
			break;
		}

		(*index) = i;
	}

	printf("end of aToken::getToken return %s\r\n", token);
	exit(-1);

	return token;
}


// return 0: "\r\n", "\n" and space which means we could skip them.
// return 1: "/*" which means comment out.
// 
//
//
int aToken::found_first_literals( char* p_token, FILE *fp, int *index, int *file_end )
{
	static char dummy[256];
	int result = 0;
	int breakable = 0;
	printf("start of found_first_literals: %s\r\n", p_token );

	for ( int i=( *index ); i< (*file_end) && breakable == 0 && i < (*index) + 3; i++ ) {
		printf("g000 i: %d \r\n", i - (*index) );
		m_fread ( dummy, 1, fp);
		token = put_token ( dummy[0] );
		printf("g000 token=%s\r\n", token );

		switch( dummy[0] ) {
		case ' ':
		case '\n':
			this->free_main_token ();
			result = 0;
			break;
		default:
			if ( m_compare( token, "\r\n") == 1 ) {

				result = 0;
			} else if ( m_compare( token, "/*") == 1 ) {

				result = 1;
				breakable = 1;
			} else if ( m_compare( token, "#define") == 1 ) {
				result = 2;
				breakable = 1;
			} else if ( m_compare( token, "#include") == 1 ) {
				result = 3;
				breakable = 1;
			}
			// printf("g000 result=%d\r\n", result);
			// exit(-1);
			break;
		}

	}

	printf("end of found_first_literals: %d\r\n", result );

	return result;
}


//
//
//
//
//
char* aToken::getToken_002( FILE *fp, int *index, int *file_end )
{
	char dummy[256];
	int breakable = 0;

	printf("start of aToken::getToken\r\n");

	for ( int i=( *index ); i< (*file_end) && breakable == 0 && i <100; i++ ) {
		printf("g i: %d \r\n", i );
		m_fread ( dummy, 1, fp);
		token = put_token ( dummy[0] );
		printf("token: %s\r\n", token);
	}

	printf("end of aToken::getToken\r\n");
	exit(-1);

	return token;
}

// 20190227
// When we use tokenizer, we just call getToken.
//
//
//
char* aToken::getToken_001( FILE *fp, int *index, int *file_end )
{
	char *c_dummy;
	char dummy[256];
	int previous_index = 0;
	int mode_token = 0; // skip
	// 0: skip
	// 1: 
	// 2: 
	int breakable = 0;
	dummy[0] = '\0';

	printf("start of aToken::getToken\r\n");

	for ( int i=( *index ); i< (*file_end) && breakable == 0; i++ ) {
		previous_index = i;
		m_fread ( dummy, 1, fp);
		printf("i=%d mode_token=%d token=|%s|\r\n", i, mode_token );

		switch(mode_token) {
		case 0:
			switch(dummy[0]) {
			case ' ':
				break;
			default:
				if ( is_alphabet( dummy ) == 1 ) {
					mode_token = 1;
				} else {
					mode_token = 2;
				}
				token = put_token ( dummy[0] );
				// printf("token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				break;
			}
			break;
		case 1:
			//Judge if line end or not
			switch(dummy[0]) {
			case '\r':
				i++;
				m_fread ( dummy, 1, fp);
				if ( dummy[0] == '\n' ) mode_token = 0;
				else {
					printf("after \\r \r\n"); 
					exit(-1);
				}
				break;
			case '\n':
				mode_token = 0;
				break;
			default:
				token = put_token ( dummy[0] );
				break;
			}
			break;
		case 2:
			printf("case 2:token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
			if ( line_or_space ( dummy ) == 1 ) {
				breakable = 1;
				*index = i;
			} else {
				token = put_token ( dummy[0] );
				printf("case 2-2:token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				// judge comment out
				if ( m_compare( token, "/*" ) == 1 ) {
					breakable = 1;
					*index = i;
				}
			}
			break;
		}

		// DEBUG
		if ( previous_index > i ) {
			printf("getToken: previous_index > i\r\n");
			printf("getToken: i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		}

	}

	backward( dummy );
	c_dummy = copyof( dummy );
	c_dummy = m_trim ( c_dummy );

	printf("aToken::getToken token=%s\r\n", token);
	printf("aToken::getToken c_dummy=%s\r\n", c_dummy);
	// return token;

	// DEBUG check
	if ( m_contains ( c_dummy, (char*)"\r\n" ) == 1 || m_contains ( c_dummy, (char*)"\n" ) == 1 ) {
		exit(-1);
	}

	printf("end of aToken::getToken\r\n");
	return token;
}

//
//
//
//
//
//
int aToken::skip_to( char* skip_to, int *index , int file_end, FILE *fp) {
	char dummy[256];
	aToken *iToken = nullptr;
	char *parse_token;
	iToken = new aToken();
	int ii = *index;
	char *a_token = nullptr;
	char *b_token = nullptr;

	int counter = 0;

	printf("skip to: %s\r\n", skip_to);
	for( ii=*index; ii<file_end && ii<2000; ii++ ) {
		if ( ii % 100 == 98 ) {
			sleep (1);
		}

		printf("loop1:\r\n");
		m_fread ( dummy, 1, fp);
		printf("loop2:\r\n");
		a_token = m_concat( a_token, &dummy[0] );
		printf("loop3:\r\n");
		b_token = substring(a_token, counter - 2, 2);
		printf("loop4:\r\n");

		// b_token = copyof("*/");
		printf("ii: %d file_end: %d counter: %d a_token: %s b_token: %s \r\n", ii, file_end, counter, a_token, b_token );

		if ( m_compare( b_token, (char *) skip_to ) == 1 ) {
			// donot use token just use merge
			printf("comment out ends: ii %d raw %d line %d\r\n", ii, iToken->getRaw(), iToken->getLine() );

			free(a_token);
			clean_null_array ();
			*index = ii;
			return 1;
		}

		counter++;
	}

	*index = ii;
	return -1;
}


//
//
//
//
//
int aToken::line_or_space ( char* dummy ) {
	// space
	// "\r\n"

	if ( m_start_with ( dummy, "\n\r" ) == 1 ) {
		//exit( -1 );
		return 1;
	} else if ( m_start_with ( dummy, "\n" ) == 1 ) {
		//exit( -1 );
		return 1;
	} else if ( m_start_with ( dummy, " " ) == 1 ) {
		//exit( -1 );
		return 1;
	} else {

		return 0;
	}
}

//
//
//
// scope
//
void aToken::free_main_token () {
	m_cnt_tkn = 0;
	token[0] = '\0';
	token[1] = '\0';
}

void aToken::backward( char *dummy) {
	// int i = 0;
	char c1, c2;
	int cnt_dummy = array_count ( dummy ) ;

	for ( int i=0; i<cnt_dummy/2 && i<256*256; i++ ) {
		c1 = *( dummy + cnt_dummy - 1 - i );
		c2 = *( dummy + i );
		*( dummy + cnt_dummy -1 - i ) = c2;
		*( dummy + i ) = c1;
		printf("i %d %c %c\r\n",i,  c1, c2);
	}

	printf("backward dummy %s\r\n", dummy);
//	exit(-1);
}

//
//
//
//
//
//
int aToken::is_alphabet( char* char_dummy )
{
	return alphabet( char_dummy[0] );
}


