//   sample02.h
#define IDM_END        100
