
typedef struct JavaKeywords JAVA_KEYWORDS;

struct JavaKeywords {
	char** package;
	int package_num;
	int package_num_size;

	char** import;
	int import_num;
	int import_num_size;

	JAVA_KEYWORDS *next;
};

//extern JAVA_KEYWORDS java_keywords;
extern int put_package( char* name_package );
extern int put_import ( char* name_import );

extern int initialize_java_keywords () ;

// for text
extern int check_structor ();


