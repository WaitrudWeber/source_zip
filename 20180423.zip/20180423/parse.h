extern char* string_allocation (int size) ;
extern char* put_token (char c);

extern char* string_allocation (int size) ;
extern int initialize_parse ();
extern int m_fread ( char* dummy, int a, FILE *fp) ;
extern int line_end ( char c ) ;
extern int alphabet ( char c ) ;

extern int m_mode;
extern int m_cnt_tkn;
extern int m_count;
extern int m_size;
extern int m_line;
extern int m_raw;
extern char* m_filename;


extern char* token;


