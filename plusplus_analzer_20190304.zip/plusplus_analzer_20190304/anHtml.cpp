#include <stdio.h>

#include "aString.h"

#include "aHashMap.h"
#include "sHtml.h"
#include "anHtml.h"

int anHtml::analyze() {

	if ( mode == 0 && the_end_of_letter() == 1 ) {
		if ( exist_tag() == 1 ) {

			current_tag = new sHtml ();
			current_tag->tag_name = token;

		} else {
			return -1;
		}
	}

	return 0;
}

int anHtml::exist_tag() {

	//char* *usual_tags = { "html", "script", "body", "input" };
	const char* usual_tags[] = { "html", "script", "body", "input" };
	aString str;


//	if ( str.compare( token, "html" ) == 1 ) {
//		return 1;
//	}

	int size = sizeof(usual_tags);
	printf("size=%d\n", size);

	for( int i=0; i<size; i++) {
		if ( str.compare( token, (char *)usual_tags[i] ) == 1 ) {
			return 1;
		}
	}

	return 0;
}

int anHtml::the_end_of_letter() {

	switch( *current_letter ) {
	case ' ':
	case '\n':
	case '\t':
		return 1;
	default:
		break;
	}

	return 0;
}

