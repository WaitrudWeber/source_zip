
class aToken {

	public:
		char *head;
		int head_raw;
		int head_line;
		char *the_string;

	public:
		char* getToken( FILE *fp, int *index, int *file_end );
		int is_alphabet( char* char_dummy );
		void backward( char *dummy ) ;
		void free_main_token () ;


};

