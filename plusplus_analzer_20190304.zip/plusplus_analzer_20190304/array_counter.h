#ifndef ARRAY_H
#define ARRAY_H

extern int array_count( char *ary );
extern char* concat( char *head, char *tail );
extern char* m_concat( char *head, char *tail );
extern int m_compare ( char* tkn, char* m );

extern char* m_print_buffer( char* buffer);
extern void print_memories ();
extern char** put_memories ( char* str ) ;

extern char* char_line_end = (char*) "\r\n";

#endif
