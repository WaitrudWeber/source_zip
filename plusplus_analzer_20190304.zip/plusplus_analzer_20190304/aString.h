
class aString {

	public:
		int compare ( char* tkn, char* m );

};
