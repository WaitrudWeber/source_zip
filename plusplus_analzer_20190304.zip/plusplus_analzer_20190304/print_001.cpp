#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>

#include <windows.h>

#include "array_counter.h"
#include "Print.h"
#include "parse.h"

#include "sender.h"
#include "aDebug.h"
#include "debug_msg.h"


#include "aToken.h"


char msg[2048];

int parse ( char* filename ) ;
int filesize( FILE *fp ) ;
void backward( char *dummy, char *token ) ;

int main ( int argc, char *argv[] ) {
	int success;
	char* err_msg = "\r\nerr_msg\n";

	// initialize_parse();
	// success = parse ( argv[1] );

	char* msg = "err_msg";
	char* msg_2 = "err_msg 2";
	char* result_001;

	err_msg ( "{%s{ {%s{ ", msg, msg );

	result_001 = err_msg_001 ( "|%s{ |%s{ ", msg_2, msg_2 );
//	err_msg ( "|%s|--|%s|", result_001, result_001 );

	return 0;
}

//
//
//
//
//
char* change_line_end (char* msg) {
/*	int prvious_c;

	int count = array_counter( msg );
	for( int i=0; i<count; i++ ) {
		char c = *( msg + i ) ;
		switch ( c ) {
		case '\r':
			break;
		case '\n':
			if ( previous_c == '\n' ) {
				break;
			}
			break;
		}
	}
	*/

	return nullptr;
}


//
//
//
//
//
int parse ( char* filename ) {
	FILE *fp;
	aToken *iToken = nullptr;
	char *parse_token;
	int previous_index = 0;

	iToken = new aToken();
	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end && i<100; i++ ) {
		// DEBUG
		previous_index = i;
		printf("parse: i=%d\r\n", i);

		parse_token = iToken->getToken( fp, &i, &file_end );
		printf("parse_token: |%s|\r\n", parse_token );
		// this cannot scope the below function, but sucope it in aDebug.cpp at 20190303
		// DEBUG_SUB( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// DEBUG ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// o debug_msg_001 ();
		DEBUG_002 ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		printf("msg: |%s|\r\n", msg );

		if ( m_compare( parse_token, (char *) "void" ) == 1 ) {
			printf("void\r\n");
			exit( -1);
		} else {
//			m_free_token( parse_token );
//			free_main_token (); //scope
			iToken->free_main_token ();
//			free( parse_token );
//			token = (char*)"\0";
		}

		// DEBUG
		if ( previous_index > i ) {
			printf("previous_index > i\r\n");
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		} else if ( previous_index == i ) {
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		}

	}

	fclose(fp);

	return 1;
}

//
//
//
//
//
int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

