#ifdef _ADEBUG_H_
#define _ADEBUG_H_

extern int DEBUG ( char* f_name, char* p_ind, ...);
extern char* DEBUG_SUB(const char* mem, const char* fmt, ...);
extern void debug_msg () ;

#endif
