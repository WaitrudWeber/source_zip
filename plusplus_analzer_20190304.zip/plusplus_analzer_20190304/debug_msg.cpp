#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <cstdio>

#include <windows.h>

#include "sender.h"
#include "debug_msg.h"
#include "Print.h"

void debug_msg_001 () ;
void debug_msg_002 () ;
void DEBUG_002 (const char* mem, const char* fmt, ...) ;

void debug_msg_001 () {
}

void debug_msg_002 () {
}

void DEBUG_002 (const char* mem, const char* fmt, ...) {

	va_list ap;
	va_start(ap, fmt);
	char* result;
	char** argv; 
	int argc;
	int send_success = 0;

	argc = 3;
	argv = (char**) malloc( sizeof(char**) * argc ) ;

	set_sender_default_parameters ( &argc, argv ) ;

//	sprintf( (char *) mem, (char *) "%s", vformat( fmt, ap ) );
	wsprintf( (LPSTR) mem, (LPCSTR) "%s", vformat( fmt, ap ) );
	va_end(ap);

	result = NULL;
	result = (char *) mem;

	argv[2] = (char *) mem;
	argv[2] = (char *) "abc";

	send_success = sender_main ( argc, argv ) ;

}

