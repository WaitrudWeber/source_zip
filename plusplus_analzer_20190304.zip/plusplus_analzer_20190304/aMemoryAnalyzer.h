

class aMemoryAnalyzer {

	public:
		aMemoryAnalyzer ();
		void put_chars (char* p_c);


	private:
		char** m_array = nullptr;




};

