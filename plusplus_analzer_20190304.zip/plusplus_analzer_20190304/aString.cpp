#include "array_counter.h"
#include "aString.h"

int aString::compare ( char* tkn, char* m ) {

	int count_t = array_count( m );
	int count_m = array_count( m );

	if ( count_t != count_m ) return -1;

	// does not match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) return -1;
	}

	return 1;
}




