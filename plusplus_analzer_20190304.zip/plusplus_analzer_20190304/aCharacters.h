#ifndef _ACHARACTERS_
#define _ACHARACTERS_

class aCharacters {
	int compare ( char* tkn, char* m );



};

#endif
