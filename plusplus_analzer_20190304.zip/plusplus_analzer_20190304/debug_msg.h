#ifndef _DEBUG_MSG_H
#define _DEBUG_MSG_H

extern void debug_msg_001 () ;
extern void DEBUG_002 (const char* mem, const char* fmt, ...) ;

#endif


