#include <stdio.h>
#include <stdlib.h>

#include "aHashMap.h"
#include "sHtml.h"
#include "aHtml.h"
#include "parse.h"

int aHtml::parse ( char* filename ) {

	FILE *fp;
	// char dummy[1];
	// int a;

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end; i++ ) {
		switch ( m_mode ) {
		case 0:
//			if ( 2 == parse_libraries ( fp, file_end ) ) {
//				analyze_class_modifier ( token ) ;
//				// a = array_count ( token );
//				// m_count -= a;
//				m_mode = 1;
//			}

			analyze_start( fp, file_end );

			break;
		case 1:
//			parse_class ( fp, file_end );
			break;
		case 2:
//			parse_method ( fp, file_end );
			break;
		}
	}

	fclose(fp);

	return 1;
}

int aHtml::analyze_start( FILE *fp, int file_end ) {

	char dummy[1];
	int success;

	this->html = new sHtml ();
	this->html->isHead = 1;

	for( int i=m_count; m_count<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		// inside tag
		switch( dummy[0] ) {
		case '<':
			analyze_inside_tag( fp, file_end);
			break;
		}
	}

	return 0;
}

// 20190227
// When we use tokenizer, we just call getToken.
//
//
//
//
int aHtml::analyze_inside_tag( FILE *fp, int file_end ) {

	char dummy[1];
	int index;
	sHtml* s_html = nullptr;

	for( int i=m_count; m_count<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		token = put_token( dummy[0] );

		switch(dummy[0]) {
		case '\n':
			analyze_token_space ( token, fp, file_end );
			break;
		case ' ':
			s_html->tag_name = token;
			analyze_token_space ( token, fp, file_end );
			break;
		case '\t':
			// if tab
			analyze_token_space ( token, fp, file_end );
			break;
		case '=':
			analyze_token_equal ( token, fp, file_end );
			break;
		}

		index = i - m_count;
	}

	return 1;
}

int aHtml::analyze_token_space ( char* tkn, FILE *fp, int file_end ) {

	char dummy[1];

	//initialize token
	free(token);

	for( int i=m_count; m_count<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch(dummy[0]) {
		case '\n':
			// skip
			break;
		case ' ':
			// skip
			break;
		case '\t':
			// if tab
			// skip
			break;
		case '=':
			analyze_token_equal ( token, fp, file_end );
			break;
		}
	}

	return 1;
}

int aHtml::analyze_token_equal ( char* tkn, FILE *fp, int file_end ) {

	char dummy[1];
	char *token_name = nullptr;

	// memory current token
	token_name = tkn;

	//initialize token
	free(token);

	for( int i=m_count; m_count<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch(dummy[0]) {
		case '\n':
			// skip
			break;
		case ' ':
			html->values.put_value( token_name, token );
			// skip
			break;
		case '\t':
			// if tab
			// skip
			html->values.put_value( token_name, token );
			break;
		default:
//			printf("found \'=\' token=%s\n", token );
//			exit(-1);
			break;
		}
	}


	return 1;
}

int aHtml::filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

