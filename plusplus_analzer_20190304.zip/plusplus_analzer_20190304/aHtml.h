class aHtml {

	public:
		int m_mode = 0;
		sHtml *html = nullptr;

	public:
		int parse ( char* filename ) ;
		int filesize( FILE *fp );

	private:
		int analyze_start( FILE *fp, int file_end );
		int analyze_inside_tag( FILE *fp, int file_end );
		int analyze_token_space ( char* tkn, FILE *fp, int file_end );
		int analyze_token_equal ( char* tkn, FILE *fp, int file_end );

};


