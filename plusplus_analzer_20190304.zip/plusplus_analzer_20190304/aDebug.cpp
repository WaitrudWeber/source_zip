#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <cstdio>

//#include "stdafx.h"

//#include <tchar.h>
//#include <wchar.h>
#include <windows.h>


#include "Print.h"

#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NON_CONFORMING_SWPRINTFS

#include "sender.h"
#include "aDebug.h"

#define PRINTBUFFER	1024

char str_print[PRINTBUFFER];
char parse_token[PRINTBUFFER];

typedef struct buook_memories {
	char** book_memories;
	int index = 0;
	int index_max = 16;
} B_MEMORIES;

int DEBUG ( char* f_name, char* p_ind, ...);
char* DEBUG_SUB(const char* mem, const char* fmt, ...);
void debug_msg () ;

void debug_msg () {
}

//
// 1st: f_name : Function name
// 2nd: p_ind  : Parameter indicator
//
int DEBUG ( char* f_name, char* p_ind, ...) {

	DEBUG_SUB( str_print, "parse_token: |%s|\r\n", parse_token ) ;

	sprintf( str_print, "%s\n", f_name );


	return 0;
}

//
//
//
//
//
char* DEBUG_SUB(const char* mem, const char* fmt, ...) {

	va_list ap;
	va_start(ap, fmt);
	char* result;
	char** argv; 
	int argc;

	argc = 3;
	argv = (char**) malloc( sizeof(char**) * argc ) ;
	set_sender_default_parameters ( &argc, argv ) ;

	wsprintf( (LPSTR) mem, (LPCSTR) "%s", vformat( fmt, ap ) );
	va_end(ap);

	result = NULL;
	result = (char *) mem;

	argv[2] = (char *) mem;

	return	result;
}

