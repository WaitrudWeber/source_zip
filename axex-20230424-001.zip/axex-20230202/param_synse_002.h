#ifndef _PARAM_SYNSE_H_
#define _PARAM_SYNSE_H_

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

//
#include "wTextarea.h"
#include "wTextareaController.h"

class ParamSynse {

	public:
		wTextarea** box_param = nullptr;
		int box_param_num = 4;

	public:
		ParamSynse();

	private:
		int Initialization ();
} ;

#endif

