#ifndef _FILE_CONTROLER_H_

#define _FILE_CONTROLER_H_

using namespace std;

class FileControler
{
	public:
		// void List_Files () ;
		void List_Files(std::string strPath);

	private:
		void Sub_List_Files () ;

};

#endif
