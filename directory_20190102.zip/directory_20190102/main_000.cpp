#include <iostream>

#include "array_counter.h"
#include "parse.h"

#include "list_directory.h"

using namespace std;

//
//
//
//
//
int main ( int argc, char** argv ) {

	char* c_a = (char*)"c:\\aaa\\*";
	int n = 0;

//	char** split_a = split("*.php", '*', &n );
//	for ( int i=0; i<n; i++ ) {
//		printf("i: %d %s\r\n", i, split_a[i] );
//	}

	int start_index = m_start_with( c_a, (char*)"\\" );
	printf("start_index: %d\r\n", start_index );


	FileControler fc;
	fc.List_Files( ".\\*" );

	fc.List_Files( "c:\\aaa\\*" );

	int index = m_last_with( c_a, (char*)"\\" );
	printf("index: %d\r\n", index );

	// substring ( start, length ) ;
	char* string_directory = substring( c_a, 0, index );
	printf("string_directory: %s\r\n", string_directory );

	// filename
	printf ( "%d\r\n", file_type( "filename.php", "*.php" ) );		// 1
	printf ( "%d\r\n", file_type( "filename.php-", "*.php" ) );  	// -1
	printf ( "%d\r\n", file_type( "filename.php-", "*.php*" ) ); 	// 1

//
//	int a_index = m_aaa();
//	m_aaa();
//

	return 0;
}

