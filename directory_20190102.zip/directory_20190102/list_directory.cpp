#include <windows.h>
#include <iostream>
#include <cstring>
#include <string>
#include <strsafe.h>

#include "array_counter.h"
#include "parse.h"
#include "list_directory.h"

using namespace std;

//
//
// it refers all to
// https://stackoverflow.com/questions/11362771/list-files-in-directory-c
// https://bituse.info/winapi/31
//
//
//
//
//
void FileControler::List_Files(std::string strPath )
{
	TCHAR* Path = (TCHAR*)strPath.c_str();

	WIN32_FIND_DATA ffd;
	LARGE_INTEGER filesize;
	TCHAR szDir[MAX_PATH];
	size_t length_of_arg;
	HANDLE hFind = INVALID_HANDLE_VALUE;

	LPCSTR lpcstr_path = strPath.c_str();

    // Prepare string for use with FindFile functions.  First, copy the
    // string to a buffer, then append '\*' to the directory name.

	hFind = FindFirstFile( TEXT( lpcstr_path ), &ffd );
	printf ( "filename: %s\r\n", TEXT( ffd.cFileName ) );
	printf ( "lpcstr_path: %s\r\n", TEXT( lpcstr_path ) );

    StringCchCopy( szDir, MAX_PATH, Path);
    StringCchCat ( szDir, MAX_PATH, TEXT("\\*"));

    // List all the files in the directory with some info about them.
	do
	{
		if ( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
		{
			//If it's a directory, nothing should happen. Just continue with the next file.
			// string str_directory = new string( ffd.cFileName );
			string l_str_directory( ffd.cFileName );
			printf( "filename 3:%s\r\n", l_str_directory.c_str() );


			int comp1 = m_compare ((char *)l_str_directory.c_str(), ".");
			printf( "comp1: %d\r\n", comp1 );

			int comp2 = m_compare ((char *)l_str_directory.c_str(), "..");
			printf( "comp2: %d\r\n", comp1 );

			int index = m_last_with( (char *) strPath.c_str(), "\\" );
			printf( "index: %d\r\n", index );


			if ( (index > 0) && (comp1 != 1) && (comp2 != 1) ) {
//			if ( (index > 0) && (comp1 >= 1) && (comp2 >= 1) ) {

				
				char* string_directory = substring( (char *) strPath.c_str(), 0, index + 1 );
				printf("string_directory1: %s\r\n", string_directory );
				char* to_directory = m_concat( string_directory, (char *) l_str_directory.c_str() );
				printf("to_directory: %s\r\n", to_directory );

				List_Files( m_concat( to_directory, "\\*" ) );
			} else {
				printf( "skip away : %s\r\n", (char *)l_str_directory.c_str() );
			}
		}
		else
		{
			//convert from wide char to narrow char array
			char ch[260];
			char DefChar = ' ';

//          WideCharToMultiByte(CP_ACP,0, (ffd.cFileName),-1, ch,260,&DefChar, NULL);
			WideCharToMultiByte(CP_ACP,0, (LPWSTR) ( ffd.cFileName ), -1, ch, 260, &DefChar, NULL);

			//A std:string  using the char* constructor.
			std::string str(ch);
//			printf( "str:%s\r\n", (char*)str.c_str() );
//			cout << "str:" << str << "\r\n";

			lpcstr_path = str.c_str();
//			printf( "filename 1:%s\r\n", lpcstr_path );
			printf( "filename 2:%s\r\n", ffd.cFileName );

			// 20190101 commented out
//			String ^ sysStr = gcnew String(str.c_str());
//			String sysStr = new String( str.c_str() );
//
//			MessageBox::Show("File Found", "NOTE");
//			ListBoxSavedFiles->Items->Add (sysStr);
			// 20190101 commented out

		}
	}
	while ( FindNextFile(hFind, &ffd ) != 0);

	FindClose(hFind);
}

//
//
//
//
//
//
//
void FileControler::Sub_List_Files ()
{
    WIN32_FIND_DATA ffd;
	HANDLE hFind = FindFirstFile(TEXT("C:\\Users\\Andre\\Dropbox\\Programmering privat\\Diablo III DPS Calculator\\Debug\\SavedProfiles\\*"), &ffd);

	if (INVALID_HANDLE_VALUE != hFind)
	{

		do
		{
			//...
			int a = 0;

		} while(FindNextFile(hFind, &ffd) != 0);

		FindClose( hFind );

	} else {

		// Report failure.
		int b = 0;
	}

}

