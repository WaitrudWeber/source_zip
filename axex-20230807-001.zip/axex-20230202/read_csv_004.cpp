#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_004.h"

GRID_MATRIX_004* grid_matrix_004 = NULL;

static Logging* log_001;
static LOG_001* dlog_001 = NULL;

int Set_Logging ( Logging* log ) ;


int puttheword_004 ( int ii, int jj, char* word ) ;
int initialize_grid_matrix_004 () ;
int file_all_size ( char* filename, int *file_end ) ;
int filesize_004( FILE *fp ) ;

//
int puttheword_004 ( int ii, int jj, char* word ) {
	int a, i, rmode, ri;
	char msg[255];

	dlog_001 = log_001->update_log ( (char*)"int puttheword_004 ( int ii, int jj, char* word ) starts." );

	if ( grid_matrix_004 == NULL ) {
		a = initialize_grid_matrix_004 ();
	}

	rmode = 0;
	if (grid_matrix_004->width_index_num_max <= ii ) {
		rmode = 1;
		ri = grid_matrix_004->width_index_num_max;
		for ( i= 0; ii < grid_matrix_004->width_index_num_max; i++ ) {
			grid_matrix_004->width_index_num_max *= 2;
		}
		grid_matrix_004->grid_matrix = (char***)realloc ( grid_matrix_004->grid_matrix , sizeof(char**) * grid_matrix_004->width_index_num_max );
		for ( i = ri; i< grid_matrix_004->height_index_num_max; i++ ) {
			grid_matrix_004->grid_matrix[i] = (char**)realloc ( grid_matrix_004->grid_matrix[i], sizeof(char*) * grid_matrix_004->height_index_num_max );
		}
	}

	if (grid_matrix_004->height_index_num_max <jj ) {
		rmode = 2;
		for ( i= 0; jj < grid_matrix_004->height_index_num_max; i++ ) {
			grid_matrix_004->height_index_num_max *= 2;
		}
		for ( i = 0; i< grid_matrix_004->height_index_num_max; i++ ) {
			grid_matrix_004->grid_matrix[i] = (char**)realloc ( grid_matrix_004->grid_matrix[i], sizeof(char*) * grid_matrix_004->height_index_num_max );
		}
	}

	aFree(grid_matrix_004->grid_matrix[ii][jj]);
	grid_matrix_004->grid_matrix[ii][jj] = (char*) copyof ( word );

	sprintf( msg, "msg %d %d word %s\r\n", ii, jj, word  );
	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int puttheword_004 ( int ii, int jj, char* word ) end." );

	return 0;
}


//
int	initialize_grid_matrix_004 () {
	int i, j;

	grid_matrix_004 = (GRID_MATRIX_004*) malloc ( sizeof (GRID_MATRIX_004) );
	if ( grid_matrix_004 == NULL ) {
		exit(-1);
	}

	grid_matrix_004->grid_matrix = (char***)malloc ( sizeof(char**) * grid_matrix_004->width_index_num_max );
	for ( i = 0; i< grid_matrix_004->width_index_num_max; i++ ) {
		grid_matrix_004->grid_matrix[i] = (char**)malloc ( sizeof(char*) * grid_matrix_004->height_index_num_max );
		if ( grid_matrix_004->grid_matrix[i] == NULL ) {
			exit(-1);
		}
		for ( j = 0; j< grid_matrix_004->height_index_num_max; j++ ) {
			grid_matrix_004->grid_matrix[i][j] = (char*)copyof("g");
		}
	}

	return  0;
}


//
int file_all_size ( char* filename, int *file_end ) {
	FILE *fp;
	char msg[255];

	dlog_001 = log_001->update_log ( (char*)"int file_all_size ( char* filename, int *file_end ) starts." );

	fp = fopen ( filename, "rb" );
	*file_end = filesize_004 ( fp );

	fclose(fp);

	sprintf( msg, "msg %s file_end |%p| %d", filename, file_end, *file_end );

	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int file_all_size ( char* filename, int *file_end ) ends." );
}

//
int filesize_004( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

//
int Set_Logging_read_csv_004 ( Logging* log ) {
	log_001 = (Logging*)log;
	return 0;
}


