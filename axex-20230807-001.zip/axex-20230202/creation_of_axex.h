#ifndef _CREATION_OF_AXEX_H_
#define _CREATION_OF_AXEX_H_

extern vAxex_2D AXEX_2D_002[30];
extern vAxex_2D** AXEX_2D_001;
extern vLine** Line_AXEX;
extern int Set_vScreen (vScreen* vsc ) ;
extern int initialize_vAxex_2D_001() ;
extern int initialize_vAxex_2D_002() ;
extern int initialize_vAxex_2D_003() ;
extern int Approach_vAxex_2D( vPoint* ap ) ;

#endif
