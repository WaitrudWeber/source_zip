#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"

#include "log_001.h"


LOG_001* Logging::init_log () {
	log_001 = (LOG_001*) malloc (sizeof(LOG_001) * 1 );
	log_001->log_list = (char**)malloc ( sizeof(char*) * 255 );

	return this->log_001;
}

LOG_001* Logging::start_log () {
	this->log_001->from = 0;
	this->log_001->to = 5;

	this->log_001->cursol = 0;

	return this->log_001;
}

//
// 001: this->log_001->cursol=0
// 001-01: this->log_001->param_list=|00000000|
//
LOG_001* Logging::update_log_001 ( char* str_log ) {
	this->log_001->log_list[ this->log_001->cursol ] = (char*)copyof_012( str_log );
	this->update_log ( str_log );
}

// 5
// 255
//
LOG_001* Logging::update_log ( char* str_log ) {
	int i;

//	printf("LOG_001* Logging::update_log ( char* str_log ) starts.\r\n");

	this->log_001->log_list[ this->log_001->cursol ] = (char*)copyof(str_log);
	this->log_001->cursol++;

	if ( this->log_001->cursol > 255 ) {
		this->log_001->fp = (FILE*)fopen( this->log_001->file_name, "ab" );
		for ( i = 0; i<255; i++ ) {
			fwrite( this->log_001->log_list[i], 0, 0, this->log_001->fp );
			fwrite( "\r\n", 0, 0, this->log_001->fp );
		}
		fclose( this->log_001->fp );

		for ( i = 0; i<255; i++ ) {
			aFree( this->log_001->log_list[i] );
		}

		this->log_001->cursol = 0;
		this->start_log ();
	}

	if ( this->log_001->cursol % 5 == 0 )
		this->roll_log ();

//	printf("LOG_001* Logging::update_log ( char* str_log ) ends.\r\n");

	return this->log_001;
}

//
LOG_001* Logging::print_log () {
	int i;

	printf("LOG_001* Logging::print_log () starts.\r\n");

	this->log_001->fp = (FILE*)fopen( this->log_001->file_name, "ab" );

	printf("this->log_001->file_name %s\r\n", this->log_001->file_name, this->log_001->fp );
	printf("cursol %d fp %d\r\n", this->log_001->cursol );

	fprintf( this->log_001->fp, "this->log_001->file_name %s\r\n", this->log_001->file_name, this->log_001->fp );
	fprintf( this->log_001->fp, "cursol %d fp %d\r\n", this->log_001->cursol );

	for ( i = 0; i<this->log_001->cursol; i++ ) {
		fprintf( this->log_001->fp, "i %d ", i );
		fwrite( this->log_001->log_list[i], 1, array_count(this->log_001->log_list[i]), this->log_001->fp );
		fwrite( "\r\n", 1, 2, this->log_001->fp );
	}

	fprintf( this->log_001->fp, "LOG_001* Logging::print_log () ends.\r\n");

	fclose( this->log_001->fp );

	printf("LOG_001* Logging::print_log () ends.\r\n");
	return this->log_001;
}

// replace 5 to param
LOG_001* Logging::roll_log () {
	if ( this->log_001->to == this->log_001->cursol ) {
		this->log_001->from = this->log_001->to;
		this->log_001->to = log_001->from + 5;
	}

	return this->log_001;
}

LOG_001* Logging::end_log () {
	return this->log_001;
}

LOG_001* Logging::declose_log () {
	fclose( this->log_001->fp );
	return this->log_001;
}

void Logging::Set_Filename(char* l_filename) {
	this->log_001->file_name = (char*) l_filename;
}

FILE* Logging::Get_Fp() {
	return this->log_001->fp;
}

