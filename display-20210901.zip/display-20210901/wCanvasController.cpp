#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <stdio.h>

#include "array_counter.h"
#include "wEvent.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
#include "something_word.h"

#include "vPointStructure.h"
#include "vPointLinear.h"

#include "display_threeD.h"

#include "wJavaStructure.h"
#include "wCanvasController.h"

//
//
//
//
wCanvasController::wCanvasController() {
}

//
//
//
//
void wCanvasController::Print_struct(wJavaStructure top ) {


}

//
//
//
//
void wCanvasController::setEvent( wEvent* evt ) {

	this->event = evt;

}

//
//
//
//
void wCanvasController::kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

}

//
//
//
//
void wCanvasController::Process () {

	Processed = 0;
//	switch ( *( this->event->uMsg ) ) {
	switch ( this->event->Type ) {
	case WM_PAINT:
		ProcessWmPaint ();
		Processed = 1;
		break;
	case WM_CHAR:
//		ProcessWmChar ();
		Processed = 1;
		break;
	}

}

//
//
//
//
void wCanvasController::ProcessWmChar () {
	switch ( this->event->main_mode ) {
	case 2:
		//something_word
		//getchar_display_threeD_proc ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		//exit(-1);
		break;
	case 8:
		//getchar_display_threeD_proc ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		break;
	}
}

//
//
//
//
void wCanvasController::ProcessWmPaint () {

	static 	RECT rect;

	printf("void wCanvasController::ProcessWmPaint () starts.\r\n");

    SetRect(&rect, 300, 460, 600, 480 );
	SetTextColor( event->hDc, RGB( 0 , 0,  0 ) );

	Rectangle( event->hDc, 300, 460, 600, 480  );
	DrawText( event->hDc, TEXT( "Cavas 20210901" ), -1, &rect, DT_NOCLIP);

	switch ( this->event->main_mode ) {
	case 2:
		//something_word
//		wmpaint_somtehing_word_proc ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
		break;
	case 7:
		break;
	case 8:
//		wmpaint_display_threeD_proc ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
		break;
	}

	printf("void wCanvasController::ProcessWmPaint () ends.\r\n");
//	exit(-1);
}

