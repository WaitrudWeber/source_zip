#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// https://www.ibm.com/docs/ja/i/7.1?topic=ssw_ibm_i_71/rtref/strcat.html

int print_mouse_move_008 () ;
extern const char *byte_to_binary_008( int x );

int print_mouse_move_008 () {

	return 0;
}

// https://stackoverflow.com/questions/111928/is-there-a-printf-converter-to-print-in-binary-format
const char *byte_to_binary008
(
    int x
)
{
    static char b[33];
    b[0] = '\0';

    unsigned int z;
    unsigned long z_start;
    z_start = 256*256*256*128;

//    printf("z_start %d\r\n", z_start);

    for (z = 256*256*256*128; z > 0; z >>= 1)
    {
//   	printf("x %d z %d\r\n", x, z );
        strcat(b, ((x & z) == z) ? "1" : "0");
    }

	printf("b%s\r\n", b);
    return b;
}


