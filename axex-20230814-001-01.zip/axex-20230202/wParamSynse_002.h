#ifndef _WPARAM_SYNSE_002_H_
#define _WPARAM_SYNSE_002_H_

class wParamSynse_002 {

	public:
		wParamSynse_002();

	private:

} ;

#endif
