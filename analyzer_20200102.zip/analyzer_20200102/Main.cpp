#include <stdarg.h>			// ADD: 20191227
#include <stdio.h>			// ADD: 20191227
#include <windows.h>		// ADD: 20191227

#include "array_counter.h"	// ADD: 20191227
#include "sender.h"			// ADD: 20191227
#include "Print.h"			// ADD: 20191227

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vTriangle.h"
#include "vIntersection.h"
#include "vScreen.h"

vScreen* screen = nullptr;

int main () {

	vPoint up, eye, lookat;
	vPoint freep;
	float x, y;

	// set_level_error_msg = 3;
	level_error_msg = 2;
	printf("set_level_error_msg %d level_error_msg %d\r\n", set_level_error_msg, level_error_msg );

	up.setPoint( 0.0f, 1.0f, 0.0f );
	eye.setPoint( 50.0f, 50.0f, 50.0f );
	lookat.setPoint( 0.0f, 0.0f, 0.0f );
	freep.setPoint( 25.0f, 25.0f, 25.0f );

	screen = new vScreen();
	screen->setEye( eye );
	screen->LookAt( lookat );
	screen->setHowFarFromEye(500.0f); // ADD: 20191227
	screen->setHeight( 360 );
	screen->setWidth( 640 );
	screen->put_Up( up );
	screen->calculation_up_UV();
	screen->get_coordinate_on_screen( freep, &x , &y );

	return 0;
}
