//#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include "php_struct.h"
#include "array_counter.h"
#include "parse.h"

#include "aDebug.h"
#include "php_analyzer.h"

/*

	0: libraries
	1: class
	2: method
	3: 

*/

void write_debug_msg (char * function_name, int char_index_num ) ;
int	php_analyzer ( int* short_mode, char* short_token ) ;

char* tochar(const char* a) ;
int skip_to_classname ( FILE *fp, int* index, int file_end, char *token_class, char* dummy );
int skip_to( char* type, FILE *fp, int* index, int file_end, char* dummy );

int parse_skip_to_curly_brace_class  ( int* index, FILE *fp, int file_end, FILE *reverse_fp ) ;
int parse_skip_to_curly_brace  ( int index, FILE *fp, int file_end, FILE *reverse_fp ) ;
int parse_function  ( char* token_function,  FILE *fp, int file_end, FILE *reverse_fp ) ;


int analyze_token ( char* token,  FILE *fp, int file_end, FILE *reverse_fp ) ;

int php_analyze_principles ( char* tkn ) ;
int php_parse ( char* filename );
int parse_skip_to_class  ( FILE *fp, int file_end );

int parse ( char* filename );
int parse_origin ( char* filename );

// do not use usually.
int parse_slash ( int index, int file_end, FILE *fp );
int parse_check_counter ( FILE *fp, int file_end );

int parse_libraries ( FILE *fp, int file_end);
int parse_class ( FILE *fp, int file_end );
int parse_method ( FILE *fp, int file_end );

int parse_library_name ( FILE *fp, int file_end, char* _type );
int parse_comment_out ( FILE *fp, int file_end );

int token_check( );
int php_filesize( FILE *fp );
int analyze ( char* tkn );

int analyze_libraries ( char* tkn );
int compare ( char* tkn, char* m );

int almost_empty ( char* tkn );
int modifier ( char* tkn );
int analyze_class_modifier ( char* tkn ) ;

int parse_libraries ( FILE *fp, int file_end );
int php_parse_main ( int argc, char *argv[] ) ;

//
//
//
//
//
//
int php_parse_main ( int argc, char *argv[] ) {

	initialize_java_keywords ();
	initialize_parse();

	m_filename = argv[1];
//	parse ( argv[1] );
	php_parse ( argv[1] );

	return 0;
}

//
//
//
//
//
//
int token_check( ) {

	token[0] = 'a';
	printf("%d\n", token[0]);

	return 0;
}

//
//
//
//
//
//
int parse_check_counter ( FILE *fp, int file_end ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		printf ( "i=%d c=%s c=%d m_count=%d m_cnt_tkn=%d m_size=%d\n", i, (char*)dummy, (int)dummy[0], m_count, m_cnt_tkn, m_size );

		printf( "parse_check_counter\n" );
		token = put_token ( dummy[0] );
	}

	printf("token:%s\n", token );
	return 1;
}

//
//
//
//
char* tochar(const char* a) {
	return (char*) a;
}


//char* tochar(string a) {
//	return (char*) a.c_str();;
//}

//
//
//
// return 2: changed m_mode
//
int parse_libraries ( FILE *fp, int file_end ) {
	char dummy[1];
	int success;

	DEBUG( tochar("parse_libraries"), "fp: %d file_end %d\n", (int)fp, file_end );

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		// 20180421
		if ( line_end ( dummy[0] ) == 1 && m_cnt_tkn == 0 ) {
			// printf(" line_end and m_cnt_tkn = 0\n");
			// exit( -1);
			break;
		}

		switch ( dummy[0] ) {
		case ' ':
			// 20180421 for debug.
			printf( "token: %s\n", token);
			// exit( - 1 );
			success = analyze_libraries ( token ) ;
			printf ( "success = %d \n", success );
			// exit ( -1 );
			switch ( success ) {
			case -1:
				// it could get token keyword other than "package" and "import".
				exit ( -1 );
				break;
			case 1:
				// it could get token keyword "package" or "import".
				parse_library_name ( fp, file_end, (char *) "package");
				m_cnt_tkn = 0;
				break;
			case 2:
				// it could get token keyword "package" or "import".
				parse_library_name ( fp, file_end, (char *) "import");
				m_cnt_tkn = 0;
				break;
			case 3:
				// it will pass it because token is almost empty.
				printf( "token is almost empty.\n" );
				exit ( -1 );
				m_cnt_tkn = 0;
				break;
			case 4:
				printf( "keywords: class modifier: %s\n", token );
				m_mode = 1;
				return 2;
				// it does not reset m_cbt_tkn and still have token.
				// m_cnt_tkn = 0;
				// exit ( -1 );
				// break;
			}
			break;
		case '/':
			if ( parse_comment_out ( fp, file_end ) == 1 ) return 1;
			break;
		}

		// 20180423
		if ( alphabet ( dummy[0] ) == 1 ) {
			// printf( "parse_libraries %s %d A:%d z:%d\n", dummy, dummy[0], 'A', 'z' );
			token = put_token ( dummy[0] );
		}

		// for debug
		if ( i - m_count > 100 ) {
			printf ( "over loop, so it stopped.\n" );
			exit ( -1 );
		}
	}

	return 1;
}

//
//
//
//
//
//
int parse_comment_out ( FILE *fp, int file_end ) {
	char dummy[1];
	int flag = 0;
	// 0, 1  -> to line end.
	// 10, 11 -> to */.

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( flag ) {
		case 0:
			switch ( dummy[0] ) {
			case '/':
				flag = 1; // to line end
				break;
			case '*':
				flag = 10; // to */
				break;
			}
			break;
		case 1:
			switch ( dummy[0] ) {
			case '\n':
				return 1;
				break;
			default:
				break;
			}
			break;
		case 10:
			switch ( dummy[0] ) {
			case '*':
				flag = 11;
				break;
			default:
				break;
			}
			break;
		case 11:
			switch ( dummy[0] ) {
			case '/':
				return 1;
			default:
				flag = 10;
				break;
			}
			break;
		}

		//token = put_token ( dummy[0] );
	}

	printf("comment out end: line %d raw %d\n", m_line, m_raw);
	exit( -1 );
}

//
//
//
//
//
//
int parse_library_name ( FILE *fp, int file_end, char* _type ) {
	char dummy[1];
	int end = -1;

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( dummy[0] ) {
//		case ' ':
//			break;
		case ';':
			end = 1;
			break;
		}
		if ( end == 1 ) break;

		// printf( "parse_library_name\n" );
		token = put_token ( dummy[0] );
	}

	if ( compare ( _type, (char*) "package" ) == 1 ) {
		put_package ( token );
		printf ( "package name=%s\n", token ) ;
//		exit( -1 );
		return 1;
	} else if ( compare ( _type, (char*) "import" ) == 1 ) {
		put_import ( token );
		printf ( "import name=%s\n", token ) ;
//		exit( -1 );
		return 1;
	}

	printf( "end of parse_library_name means it doesn't hit package and import.\n" );
	printf( "_type = %s\n", _type );
	exit( -1 );
	
	return 1;
}

//
//
//
//
//
//
int parse_class_name ( FILE *fp, int file_end  ) {
	char dummy[1];

	//printf( "parse_class_name=%s\n", token );
	//exit( -1 );

	for( int i=m_count; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( dummy[0] ) {
		case ' ':
			printf( "parse class name: %s\n", token);
			return 1;
			//exit( -1 );
			//break;
//		case '(':
//			printf( "parse class name: %s\n", token);
//			exit( -1 );
//			break;
		default:
			break;
		}

		token = put_token( dummy[0] );
		//printf( "token=%s\n", token );
	}

	return -1;
}

//
//
//
//
//
//
int parse_inside_class ( FILE *fp, int file_end  ) {
	char dummy[1];

	// token = put_token( 'a' );
	// printf( "m_cnt_tkn = %d token=%s\n", m_cnt_tkn, token );
	// exit ( -1 );

	for( int i=m_count; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		//printf("token:%s\n", token );

		switch ( dummy[0] ) {
		case ' ':
			if ( m_cnt_tkn != 0 ) {
				token = put_token( dummy[0] );
			}
			break;
		case '\n':
			if ( m_cnt_tkn != 0 ) {
				token = put_token( dummy[0] );
			}
			break;
		case ';':
			token = put_token( dummy[0]);
			printf( "code_line= %s\n", token ); 
			exit( -1 );
			break;
		default:
			token = put_token( dummy[0]);
			//printf("token= %s\n", token );
			//exit( -1 );
			break;
		}
	}

	exit( -1 );
	return -1;
}

//
//
//
//
//
//
int parse_class ( FILE *fp, int file_end  ) {
	char dummy[1];
	int readable = -1;

	// printf("parse_class\n");

	for( int i=m_count; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( dummy[0] ) {
		case ' ':
			if ( readable == 1 ) {

				printf("parse_class: token: %s\n", token);
				if ( compare ( (char *)"class", token ) == 1 ) {
					m_cnt_tkn = 0;
					parse_class_name ( fp, file_end ); 
					set_main_class ( token ) ;
					printf( "print_main_class:\n" );
					print_main_class();
				} else {
					printf("its not keyword: class.\n");
					exit( -1 );
				}

				// exit( -1 );
			}
			break;
//		case '/':
//			break;
		case '{':
			printf("Analiyzer found \'{\'. token:%s c:%s\n", token, dummy);
			m_cnt_tkn = 0;
			parse_inside_class ( fp, file_end ); 
			exit ( -1 );
			return 1;
		default:
			if ( readable == -1 && alphabet(dummy[0]) ) {

				token = put_token( dummy[0]);
				readable = 1;

			} else if ( readable == 1 && alphabet(dummy[0]) ){

				token = put_token( dummy[0]);
			} else {

				printf("parse_class: token: %s c=%s readable=%d\n", token, dummy, readable);
				exit( -1 );
			}
			break;
		}

		if ( i - m_count > 100 ) {
			printf("i=%d\n", i);
			printf("token:%s\n", token );
			exit( -1);
		}
	}

	return 1;
}

//
//
//
//
//
//
int parse_method ( FILE *fp, int file_end  ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		switch ( dummy[0] ) {
		case ' ':
			break;
		case '/':
			break;
		}
	}

	return 1;
}

//
// 20181227
int parse ( char* filename ) {

	FILE *fp;
	// char dummy[1];
	// int a;

	fp = fopen ( filename, "rb" );
	int file_end = php_filesize ( fp );

	for( int i=0; i<file_end; i++ ) {
		switch ( m_mode ) {
		case 0:
			if ( 2 == parse_libraries ( fp, file_end ) ) {
				analyze_class_modifier ( token ) ;
				// a = array_count ( token );
				// m_count -= a;
				m_mode = 1;
			}
			break;
		case 1:
			parse_class ( fp, file_end );
			exit(-1);
			break;
		case 2:
			parse_method ( fp, file_end );
			break;
		}
	}

	fclose(fp);

	return 1;
}

//
//
//
//
//
//
int psrse_skip  ( FILE *fp ) {

	return 0;
}


// m_mode = 10;
// m_mode = 11;
//
//
//
//
//
int analyze_token ( char* token,  FILE *fp, int file_end, FILE *reverse_fp ) {

	if ( m_compare ( (char *)token, (char *)"class" ) == 1 ) {
		m_mode = 10;
		m_cnt_tkn = 0;
		return 1;
	} else if ( m_compare ( (char *)token, (char *)"function" ) == 1 )  {
		m_mode = 11;
		m_cnt_tkn = 0;
		return 1;
	}

	m_cnt_tkn = 0;
	return 0;
}

//
//
//
// to bracce
//
int parse_function  ( char* token_function,  FILE *fp, int file_end, FILE *reverse_fp ) {

	DEBUG( (char *)"parse_function", (char *)"fp: %d file_end %d\r\n", (int)fp, file_end );

	printf( "parse_function fp: %d file_end %d\r\n", fp, file_end );
	printf( "token_function: %s\r\n", token_function );
	exit(-1);
}

//
//
//
//
//
//
int parse_skip_to_curly_brace_short_mode  ( char c, int* short_mode ) {

	// 0:  start skipping space
	// 1:  function name ( alphabet, not space, under bar, number, like "good_manner_1234 ( $str, $num ); ")
	// 2:  space
	// 3:  round brace start is like "("
	//10:  round brace end is like ")"
	//11:  round brace end is like "{"

	switch ( *short_mode ) {
	case 0:
		if ( c == ' ' ) *short_mode = 0;
		else if ( alphabet( c ) == 1 ) *short_mode = 1;
		else if ( c == '_' ) *short_mode = 1;
		else if ( number( c ) ) *short_mode = 1;
		else return -1;
		break;
	case 1:
		if ( alphabet( c ) == 1 ) *short_mode = 1; // still keep.
		else if ( c == '_' ) *short_mode = 1; // still keep.
		else if ( number(c)  == 1 ) *short_mode = 1; // still keep.
		else if ( c == ' ' ) *short_mode = 2; // Next, extract round brace.
		else if ( c == '(' ) *short_mode = 3; // Next, extract round brace-end.
		else return -1;
		break;
	case 2:
		if (  c == '(' )  *short_mode = 3;
		else if ( c == ' ' ) *short_mode = 2;
		break;
	case 3:
		if (  c == ')' )  *short_mode = 10;
		break;
	case 10:
		if (  c == ' ' )  *short_mode = 10;
		else if ( c == '{' ) *short_mode = 11;
		else return -1;
		break;
	case 11:
		return 2; // end
	default:
		return -1;
	}

	return 1;
}

//
//
// for function
//
//
// to bracce
//
int parse_skip_to_curly_brace  ( int index, FILE *fp, int file_end, FILE *reverse_fp ) {

	char dummy[] = { '\0', '\0' };
	char dummies[]= { '\0', '\0', '\0' };
	int end = -1;
	int success;
	char* token_function = (char*) "\0";
	// 0:  start skipping space
	// 1:  function name ( alphabet, not space, under bar, number, like "good_manner_1234 ( $str, $num ); ")
	// 2:  space
	// 3:  round brace start is like "("
	// 4:  round brace end is like ")"
	// 5:  round brace end is like "{"
	int short_mode = 0;

	DEBUG( (char*)"parse_skip_to_curly_brace", "fp: %d file_end %d\n", (int)fp, file_end );

	for( int i=index; i<file_end; i++ ) {
		dummies[0] = dummy[0];
		m_fread ( dummy, 1, fp);
		dummies[1] = dummy[0];

		success = parse_skip_to_curly_brace_short_mode ( dummy[0] , &short_mode);

		if ( success == 2 ) break; // end
		if ( success == -1 ) break; // error

		token_function = m_concat ( (char *)token_function, (char *) dummy );
		printf( "token_function: %s | dummy: %s \r\n", (char *) token_function, (char *)dummy );

		if ( i > index + 1000 ) break;
	}

	printf ("success %d short_mode %d\r\n", success, short_mode );
	printf( "end of parse_skip_to_curly_brace fp: %d file_end %d\n", fp, file_end );

	if ( success == 2 ) { 
		printf("it reached to the end.");
		exit(-1);
	}

	return success;
}

//
//
//
//
//
//
int parse_skip_to_curly_brace_class  ( int* index, FILE *fp, int file_end, FILE *reverse_fp ) {

	char dummy[] = { '\0', '\0' };
	char dummies[]= { '\0', '\0', '\0' };
	int end = -1;
	int success;
	char* token_class = (char*) "\0";
	int short_mode = 0;
	int return_result = 0;

	DEBUG( (char*)"parse_skip_to_curly_brace starts", "fp: %d file_end %d\r\n", (int)fp, file_end );

	success = skip_to( " ", fp, index, file_end, dummy );
	if ( success == -1 ) return -1;

	success = skip_to_classname( fp, index, file_end, token_class, dummy );
	if ( success == 1 ) {
		DEBUG( (char*)"parse_skip_to_curly_brace", "token_class: %s\r\n", token_class );
		exit(-1);
	}

	DEBUG( (char*)"parse_skip_to_curly_brace ends and returns %d.", "fp: %d file_end %d\n", (int)fp, file_end, return_result );
	return 2;
}

//
//
//
//
// it remains last letter in dummy.
int skip_to_classname ( FILE *fp, int* index, int file_end, char *token_class, char* dummy ) {

	token_class[0] = dummy[0];

	for ( int i = *index; i<*index; i++ ) {
		m_fread( dummy, 1, fp );

		if ( alphabet ( dummy[0] ) || number( dummy[0] ) || dummy[0] == '_') {
			token_class = m_concat( (char *)token_class, (char *)dummy);
		} else {
			return -1;
		}
	}

}

//
//
//
//
//
int skip_to( char* type, FILE *fp, int* index, int file_end, char* dummy ) {
	int loop = 0;

	for ( int i=*index; i<file_end; i++ ) {
		m_fread( dummy, 1, fp );

		if ( m_compare( type, dummy ) != 1 ) return 1; // success
	}

	return -1; //failed at the end;
}

//
//
//
//
//
int parse_skip_to_class  ( FILE *fp, int file_end, FILE *reverse_fp ) {

	char dummy[1];
	char dummies[2];
	int end = -1;
	int success;
	int success_skip;

	// size-number which is going to decrease.
	// *reverse_fp = *fp;
	reverse_fp = fp;

	DEBUG( (char*)"parse_skip_to_class", "fp: %d file_end %d\n", (int)fp, file_end );

	for( int i=0; i<file_end; i++ ) {
		dummies[0] = dummy[0];
		m_fread ( dummy, 1, fp);
		dummies[1] = dummy[0];

		printf( "sub: index %d *fp %d fp %d *reverse_fp %d reverse_fp %d\r\n", i, *fp, fp, *reverse_fp, reverse_fp );
		if ( line_end_win ( (char *)dummy ) == 1 || line_end ( dummy[0] ) == 1 ) {
			printf("token: %s\r\n", (char *)token);
			success = analyze_token( token, fp, file_end, reverse_fp );
		} else {

			switch ( dummy[0] ) {
				case ' ':
					printf("token: %s\r\n", (char *)token );
					success = analyze_token( token, fp, file_end, reverse_fp );
					break;
			}

		}

		printf("success: %d\r\n", success );
		if ( success ) {
			printf("token: %s\r\n", (char *)token );
			//success_skip = parse_skip_to_curly_brace ( i, fp, file_end, reverse_fp );
			success_skip = parse_skip_to_curly_brace_class ( &i, fp, file_end, reverse_fp );
			m_cnt_tkn = 0;
			printf( "parse_skip_to_class: return %d\r\n" , success_skip);

			return success_skip;
		}

		// 20180423
		if ( alphabet ( dummy[0] ) == 1 ) {
			// printf( "parse_libraries %s %d A:%d z:%d\n", dummy, dummy[0], 'A', 'z' );
			token = put_token ( dummy[0] );
		}

		// for debug
		if ( i - m_count > 100 ) {
			printf ( "over loop, so it stopped.\n" );
			exit ( -1 );
		}
	}

	printf( "parse_skip_to_class: return 1\r\n" );

	return 1;
}

//
//
//
// class		:10
// function		:11
// scope		:15	(between '{' and '}' )
//
int	php_analyzer ( int* short_mode, char* short_token ) {

	static int function_counter = 0;
	static char* function_name = "\0";
	char* trim_token = m_trim ( short_token );
	char* tmp_function_name = "\0";

	static int debug_msg_index = 0;

	switch ( *short_mode ) {
	case 0:
		if ( m_compare ( trim_token, "function" ) == 1 ) {
			*short_mode = 11; // to function
			function_counter++;
		}
		break;
	case 1:
		break;
	case 2:
		break;
	case 3:
		break;
	case 4:
		break;
	case 5:
		break;
	case 6:
		break;
	case 7:
		break;
	case 10:
		break;
	case 11:
//		if ( m_compare( function_name, "\0" ) == 1 )
//			function_name = trim_token;

		if ( m_contains( trim_token, "{" ) == 1 ) {

			printf( "function_name: %s\r\n", function_name);
			*short_mode = 15;
			printf( "to 15 found curly brace : %s\r\n", trim_token);

			// 
			// save m_index for use of index with writing of debug message
			//
			//
			debug_msg_index = m_raw;

		} else {
			// specification of m_concat
			tmp_function_name = function_name;
			function_name = m_concat ( tmp_function_name, trim_token );
			//free( tmp_function_name );

			printf( "still 11 function_name: %s trim_token: %s\r\n", function_name, trim_token);
		}
		break;
	case 12:

		break;
	case 15:
		// inside scope
		printf( "inside scope: %s function_counter %d\r\n", trim_token, function_counter);
		// exit( -1 );
		write_debug_msg ( function_name, debug_msg_index );
		*short_mode = 0;
		function_name = "\0";
		break;
	}

	return 1;
}

//
//
//
//
//
//
void write_debug_msg (char * function_name, int char_index_num ) {

	char* debug_msg = "debug_msg( \" ";
	char* end_debug_msg = " \");\r\n";
	char* char_index_space = "\0";

	int fac = array_count(function_name);

	for( int i=0; i<char_index_num; i++ ) {
		char_index_space = m_concat ( char_index_space, " " );
	}

	if ( fac > 2 ) {
		if ( function_name[fac -1 ] == '\n' ) function_name[ fac - 1 ] = '\0';
		if ( function_name[fac -2 ] == '\r' ) function_name[ fac - 2 ] = '\0';
	}

	debug_msg = m_concat ( char_index_space, debug_msg );

	// tmp_filename
	fwrite( debug_msg, 1, array_count(debug_msg), write_fp);
	fwrite( function_name, 1, array_count(function_name), write_fp);
	fwrite( end_debug_msg, 1, array_count(end_debug_msg), write_fp);
}

//
//
//
//
//
//
int php_parse_20181231 ( char* filename ) {

	FILE *fp, *reverse_fp;
	char dummy[] = { ' ', '\0' };


	fp = fopen ( filename, "rb" );
	int file_end = php_filesize ( fp );
	printf("php_parse: filename %s fp %d file_end %d\r\n", filename, fp, file_end);

	for( int i=0; i<file_end; i++ ) {
		reverse_fp = fp;
//		printf( "index %d *fp %d fp %d reverse_fp %d\r\n", i, *fp, fp, reverse_fp );
//		m_fread( dummy, 1, fp );

		switch ( m_mode ) {
		case 0:
			if ( parse_skip_to_class( fp, file_end, reverse_fp ) == 2 ) {
				// it reached to end.
				printf( "00 index %d *fp %d fp %d reverse_fp %d\r\n", i, *fp, fp, reverse_fp );
				exit(-1);
				m_mode = 1;
			} else {
				fp = reverse_fp;
				printf( "m_mode: %d \r\n", m_mode );
				printf( "token: %\r\n", token );
				printf( "01 index %d *fp %d fp %d reverse_fp %d\r\n", i, *fp, fp, reverse_fp );
				m_fread( dummy, 1, fp );
				printf( "01 index %d *fp %d fp %d reverse_fp %d\r\n", i, *fp, fp, reverse_fp );
				m_cnt_tkn = 0;
				printf( "m_mode: %d \r\n", m_mode );
				exit ( -1 );
			}
			break;
		case 1:
			parse_class ( fp, file_end );
			break;
		case 2:
			parse_method ( fp, file_end );
			break;
		case 10:
			// class
			m_fread( dummy, 1, fp );
			printf( "dummy: %\r\n", dummy );
			break;
		case 11:
			// function
			m_fread( dummy, 1, fp );
			printf( "dummy: %\r\n", dummy );
			break;
		}
	}

	fclose(fp);
	printf( "php_parse: return 1\r\n" );

	return 1;
}

//
//
//
//
//
//
int analyze_class_modifier ( char* tkn ) {

	int m = -1;

	if ( ( m = modifier( tkn ) )== -1 ) {
		printf( "analyze_class_modifier: %d it's not modifier.", m);
		exit(-1);
	}

	printf ("modifier: %d\n", m);
	switch ( m ) {
	case 1:
		set_main_class_modifier( (char *)"public" );
		m_cnt_tkn = 0;
		return 1;
	case 2:
		set_main_class_modifier( (char *)"private" );
		m_cnt_tkn = 0;
		return 1;
	case 3:
		set_main_class_modifier( (char *)"protected" );
		m_cnt_tkn = 0;
		return 1;
	}

	// exit( -1 );
	return -1;
}

//
//
//
//
//
//
int parse_origin ( char* filename ) {

	FILE *fp;
	fp = fopen ( filename, "rb" );
	char dummy[1];

	int file_end = php_filesize ( fp );

	for( int i=0; i<file_end; i++ ) {

		m_fread ( dummy, 1, fp);

		switch( dummy[0] ) {
		case ' ':
			analyze ( token ) ;
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		printf( "parse_origin\n" );
		token = put_token ( dummy[0] );
//		printf( "%d %d\n", *token, token);
		printf ("dummy=%s token=%s token[%d]=%d token[%d]=%d\n", dummy, token, i, token[i], i + 1, token[ i + 1] );
	}

	printf("token=%s\n", token);

	for( int i=0; i<file_end; i++ ) {

		switch( dummy[0] ) {
		case ' ':
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		printf( "%d\n", token[i] );
	}

	fclose(fp);

	return 0;
}

//
// return 1 means package.
// return 2 means import.
// return 3 means pass which means token is empty.
// return 4 means modifier which means class modifier here.
//
int analyze_libraries ( char* tkn ) {

	// printf("analyze libraries line %d raw %d it's not keyword: %s\n", m_line, m_raw, tkn );
	// exit(-1);


	if ( compare ( tkn, (char *)"package" )  == 1 ) {

		printf("it's keyword: %s\n", tkn );
		return 1;

	} else if ( compare ( tkn, (char *)"import" ) == 1 ) {

		printf("it's keyword: %s\n", tkn );
		return 2;

	} else {

		// almost empty
		if ( almost_empty ( tkn ) == 1 ) return 3;

		// 20180424
		if ( modifier( (char *)tkn ) != -1 ) return 4;

		printf("line %d raw %d it's not keyword: %s\n", m_line, m_raw, tkn );

	}

	return 0;
}

//
// return 1 means nothing yet.
// return 2 means class.
// return 3 means pass which means token is empty.
// return 4 means modifier.
// return 5 means requre.
// return 6 means requre_once.
//
int php_analyze_principles ( char* tkn ) {

	// printf("analyze libraries line %d raw %d it's not keyword: %s\n", m_line, m_raw, tkn );
	// exit(-1);

	printf( "token: %s \r\n", tkn);

	if ( compare ( tkn, (char *)"class" ) == 1 ) {

		printf("it's keyword: %s\n", tkn );
		return 2;

	} else if ( compare ( tkn, (char *)"modifier" ) == 1 ) {

		return 4;

	} else if ( compare ( tkn, (char *)"requre" ) == 1 ) {

		return 5;

	} else if ( compare ( tkn, (char *)"requre_once" ) == 1 ) {

		return 6;

	} else {

		// almost empty
		if ( almost_empty ( tkn ) == 1 ) return 3;

		// 20180424
		if ( modifier( (char *)tkn ) != -1 ) return 4;

		printf("line %d raw %d it's not keyword: %s\n", m_line, m_raw, tkn );

	}

	return 0;
}

//
// return 1: public
// return 2: private
// return 3: protected
//

//
//
//
//
//
//
int modifier ( char* tkn ) {

	if ( compare( tkn, (char*)"public" ) == 1 ) return 1;
	if ( compare( tkn, (char*)"private" ) == 1 ) return 2;
	if ( compare( tkn, (char*)"protected" ) == 1 ) return 3;

	return -1;
}

//
//
//
//
//
//
int almost_empty ( char* tkn ) {

	int a = array_count ( tkn );
	for ( int i=0; i<a; i++ ) {
		if ( tkn[i] != ' ' && line_end ( tkn[i] ) == 0 ) return -1; // error: not space and not line end.
	}

	return 1;
}

//
//
//
//
//
//
int compare ( char* tkn, char* m ) {

	int count_t = array_count( m );
	int count_m = array_count( m );

	if ( count_t != count_m ) return -1;

	// match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) return -1;
	}

	return 1;
}

//
//
//
//
//
//
int analyze ( char* tkn ) {

	m_mode = 0;

	switch(m_mode) {
	case 0:
		// keyword outside class
		printf("%s\n", tkn );
		exit( -1 );
		//analyze_libraries( tkn );
		break;
	case 1:
		// name outside class
		break;
	case 2:
		break;
	}

	return 0;
}

//
//
//
//
//
//
int parse_slash ( int index, int file_end, FILE *fp ) {

	char dummy[1];

	for( int i=index; i<file_end; i++ ) {

		m_fread ( dummy, 1, fp);
	}

	return 0;
}



