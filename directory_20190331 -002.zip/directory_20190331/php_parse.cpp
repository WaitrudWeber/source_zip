#include <windows.h>
#include <iostream>
#include <cstring>
#include <string>
#include <strsafe.h>

#include "aDebug.h"
#include "array_counter.h"
#include "parse.h"
#include "php_parse.h"
#include "list_directory.h"


FILE *write_fp;

void php_file_list (std::string strPath ) ;
char* m_fullpath ( char* strPath, char* filename ) ;
int php_parse ( char* filename ) ;
int php_filesize( FILE *fp ) ;
int php_parse_analyzer ( int* short_mode, char* short_token ) ;
void php_write_debug_msg (char * function_name, int char_index_num ) ;

//
//
//
//
//
//
int php_filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

//
//
// it refers all to
// https://stackoverflow.com/questions/11362771/list-files-in-directory-c
// https://bituse.info/winapi/31
//
//
//
//
//
void php_file_list (std::string strPath )
{
	TCHAR* Path = (TCHAR*)strPath.c_str();

	WIN32_FIND_DATA ffd;
	HANDLE hFind = INVALID_HANDLE_VALUE;

	LPCSTR lpcstr_path = strPath.c_str();
	char* ffdc_filename;


    // Prepare string for use with FindFile functions.  First, copy the
    // string to a buffer, then append '\*' to the directory name.

	hFind = FindFirstFile( TEXT( lpcstr_path ), &ffd );
	ffdc_filename = TEXT( ffd.cFileName );

	printf ( "filename: %s\r\n", ffdc_filename );
	printf ( "lpcstr_path: %s\r\n", TEXT( lpcstr_path ) );

    // List all the files in the directory with some info about them.
	do
	{
		if ( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
		{
			//If it's a directory, nothing should happen. Just continue with the next file.
			ffdc_filename = TEXT( ffd.cFileName );
			printf( "filename 3:%s\r\n", ffdc_filename );
			printf ( "lpcstr_path3: %s\r\n", lpcstr_path );

			int comp1 = m_compare ( TEXT( ffd.cFileName ), (char*)".");
			printf( "comp1: %d\r\n", comp1 );

			int comp2 = m_compare ( TEXT( ffd.cFileName ), (char*)"..");
			printf( "comp2: %d\r\n", comp1 );

			int index = m_last_with( (char *) lpcstr_path, (char*)"\\" );
			printf( "index: %d\r\n", index );

			if ( (index > 0) && (comp1 != 1) && (comp2 != 1) ) {

				print_memories ();

				char* string_directory = substring( (char *) strPath.c_str(), 0, index + 1 );
				printf("string_directory1: %s\r\n", string_directory );
				char* to_directory = m_concat( string_directory, ffdc_filename );
				printf("to_directory: %s\r\n", to_directory );

				// free( string_directory );
				php_file_list ( m_concat( to_directory, (char*)"\\*" ) );
				// free( to_directory );

			} else {

				printf( "skip away : %s\r\n", TEXT( ffd.cFileName ) );
			}
		}
		else
		{
			//convert from wide char to narrow char array
			//char ch[260];
			//char DefChar = ' ';

// 20190103 start
//          WideCharToMultiByte(CP_ACP,0, (ffd.cFileName),-1, ch,260,&DefChar, NULL);
//			WideCharToMultiByte(CP_ACP,0, (LPWSTR) ( ffd.cFileName ), -1, ch, 260, &DefChar, NULL);

			//A std:string  using the char* constructor.
//			std::string str(ch);
//			printf( "str:%s\r\n", (char*)str.c_str() );
//			cout << "str:" << str << "\r\n";

//			lpcstr_path = str.c_str();
// 20190103 end

			printf( "filename 2:%s\r\n", TEXT ( ffd.cFileName ) );

			if ( file_type ( (char*)ffd.cFileName, "*.php") == 1 ) {
				//string l_path( ffd.cFileName );
				//char* char_fullpath = m_fullpath ( (char*) strPath.c_str(), (char*)l_path.c_str() );
				char* char_fullpath = m_fullpath ( (char*) strPath.c_str(), (char*)ffd.cFileName );

				//exit(-1);
				// parser starts 20190103
				int php_return = php_parse( char_fullpath );

			}

			// 20190101 commented out
//			String ^ sysStr = gcnew String(str.c_str());
//			String sysStr = new String( str.c_str() );
//
//			MessageBox::Show("File Found", "NOTE");
//			ListBoxSavedFiles->Items->Add (sysStr);
			// 20190101 commented out

		}
	}
	while ( FindNextFile(hFind, &ffd ) != 0);

	FindClose(hFind);
}

//
//
//
//
//
//
//
//
int php_parse ( char* filename ) {

	FILE *fp, *reverse_fp, *wfp;
	char dummy[] = { ' ', '\0' };
	int line_end = 0;
	int split = 0;
	char* tmp_filename = "";
	char* origin_filename = "";
	char tmp_test[] = "a";

	origin_filename = m_concat ( (char*)filename, (char*)"_origin.php" );
	tmp_filename = m_concat ( (char*)filename, (char*)"_tmp.php" );
	wfp = fopen ( tmp_filename, "wb" );
	write_fp = wfp; // store to global.

	fp = fopen ( filename, "rb" );

	int file_end = php_filesize ( fp );
	printf( "php_parse: filename %s fp %d file_end %d\r\n", filename, fp, file_end );
//	fwrite( tmp_test , 1 , sizeof(tmp_test) , wfp );

	for( int i=0; i<file_end; i++ ) {
		reverse_fp = fp;
		m_fread ( dummy, 1, fp);
		token = put_token ( dummy[0] );

//		fwrite( tmp_test , 1 , sizeof(tmp_test) - 1 , wfp );
		fwrite( dummy , 1 , 1 , wfp );
//		printf ("dummy=%s token=%s token[%d]=%d token[%d]=%d\n", dummy, token, i, token[i], i + 1, token[ i + 1 ] );

		switch( dummy[0] ) {
		case '	':
			line_end = 0;
			printf ("dummy=%s token=%s token[%d]=%d token[%d]=%d\n", dummy, token, i, token[i], i + 1, token[ i + 1 ] );
			php_parse_analyzer ( &m_mode, token );
			clear_token() ;
			break;
		case ' ':
			line_end = 0;
//			analyze ( token ) ;
			printf ("dummy=%s token=%s token[%d]=%d token[%d]=%d\n", dummy, token, i, token[i], i + 1, token[ i + 1 ] );
			php_parse_analyzer ( &m_mode, token );
			clear_token() ;
			break;
		case '\r':
			line_end = 1;
			break;
		case '\n':
			split = 1;
			printf ("dummy=%s token=%s token[%d]=%d token[%d]=%d\n", dummy, token, i, token[i], i + 1, token[ i + 1 ] );
			php_parse_analyzer ( &m_mode, token );
			clear_token() ;
			line_end = 0;
			break;
		default:
			line_end = 0;
			break;
		}
	}

	fclose( wfp );
	fclose( fp );
//	printf("sizeof(tmp_test)%d\r\n", sizeof(tmp_test));

	// CopyFile ( filename, origin_filename, FALSE ) ;
	// CopyFile ( tmp_filename, filename, FALSE ) ;

	printf( "php_parse: return 1\r\n" );

	return 1;
}

//
//
//
// class		:10
// function		:11
// scope		:15	(between '{' and '}' )
//
int	php_parse_analyzer ( int* short_mode, char* short_token ) {

	static int function_counter = 0;
	static char* function_name = "\0";
	char* trim_token = m_trim ( short_token );
	char* tmp_function_name = "\0";

	static int debug_msg_index = 0;

	switch ( *short_mode ) {
	case 0:
		if ( m_compare ( trim_token, "function" ) == 1 ) {
			*short_mode = 11; // to function
			function_counter++;
		}
		break;
	case 1:
		break;
	case 2:
		break;
	case 3:
		break;
	case 4:
		break;
	case 5:
		break;
	case 6:
		break;
	case 7:
		break;
	case 10:
		break;
	case 11:
//		if ( m_compare( function_name, "\0" ) == 1 )
//			function_name = trim_token;

		if ( m_contains( trim_token, "{" ) == 1 ) {

			printf( "function_name: %s\r\n", function_name);
			*short_mode = 15;
			printf( "to 15 found curly brace : %s\r\n", trim_token);

			// 
			// save m_index for use of index with writing of debug message
			//
			//
			debug_msg_index = m_raw;

		} else {
			// specification of m_concat
			tmp_function_name = function_name;
			function_name = m_concat ( tmp_function_name, trim_token );
			//free( tmp_function_name );

			printf( "still 11 function_name: %s trim_token: %s\r\n", function_name, trim_token);
		}
		break;
	case 12:

		break;
	case 15:
		// inside scope
		printf( "inside scope: %s function_counter %d\r\n", trim_token, function_counter);
		// exit( -1 );
		php_write_debug_msg ( function_name, debug_msg_index );
		*short_mode = 0;
		function_name = "\0";
		break;
	}

	return 1;
}



char* m_fullpath ( char* strPath, char* filename ) {

	int index = m_last_with( (char *) strPath, "\\" );

	char* string_directory = substring( (char *) strPath, 0, index + 1 );
	printf("string_directory3: %s\r\n", string_directory );
	char* fullpath = m_concat( (char *)string_directory, (char *) filename );
	printf("filename fullpath_c = %s\r\n", fullpath );

	return fullpath;
}

void php_write_debug_msg (char * function_name, int char_index_num ) {

	char* debug_msg = "debug_msg( \" ";
	char* end_debug_msg = " \");\r\n";
	char* char_index_space = "\0";

	int fac = array_count(function_name);

	for( int i=0; i<char_index_num; i++ ) {
		char_index_space = m_concat ( char_index_space, " " );
	}

	if ( fac > 2 ) {
		if ( function_name[fac -1 ] == '\n' ) function_name[ fac - 1 ] = '\0';
		if ( function_name[fac -2 ] == '\r' ) function_name[ fac - 2 ] = '\0';
	}

	debug_msg = m_concat ( char_index_space, debug_msg );

	// tmp_filename
	fwrite( debug_msg, 1, array_count(debug_msg), write_fp);
	fwrite( function_name, 1, array_count(function_name), write_fp);
	fwrite( end_debug_msg, 1, array_count(end_debug_msg), write_fp);
}
