#include<stdarg.h>
#include<stdio.h>

#include "array_counter.h"
#include "parse.h"

int sum(int, ...);
int file_open( char* char_filename ) ;
char* file_all_open( char* char_filename ) ;
int filesize( FILE *fp ) ;

int main(int argc, char **argv) {

	char* filename;
	filename = argv[1];
	int a = file_open( filename );

	initialize_parse();
	char* ca = file_all_open ( filename );
	printf("file all : %s\r\n", ca );

   return 0;
}

//
//
//
//
//
//
int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

//
// 
//
//
//
char* file_all_open( char* char_filename ) {
	FILE *fp;

//	printf("file_all_open\r\n");
	char* dummy = char_string ( 256 * 256 );
	fp = fopen( char_filename, "rb");
	int file_end = filesize ( fp );

	for ( int i=0; i< file_end; i++ ) {
//		printf("i: %4d/%4d ", i, file_end);
		m_fread( dummy, 1, fp );
		token = put_token( dummy[0] );
//		printf("dummy: %c|%3d|\r\n", dummy[0], dummy[0] );
	}

	fclose (fp);
	return token;
}

//
//
//
//
//
int file_open( char* char_filename ) {
	FILE *fp;
	char* dummy = char_string ( 256 * 256 );

	fp = fopen( char_filename, "rb");
	int file_end = filesize ( fp );
	for ( int i=0; i< file_end; i++ ) {
		m_fread( dummy, 1, fp );
	}

	fclose (fp);
}

int sum(int num_args, ...) {
   int val = 0;
   va_list ap;
   int i;

   va_start(ap, num_args);
   for(i = 0; i < num_args; i++) {
      val += va_arg(ap, int);
   }
   va_end(ap);
 
   return val;
}
