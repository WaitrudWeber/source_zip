#include<stdarg.h>
#include<stdio.h>
//#include<iostream>
#include <windows.h>
// x #include <fileapi.h>

#include "array_counter.h"
#include "sender.h"
#include "Print.h"
#include "aDebug.h"
#include "list_directory.h"
#include "parse.h"

int sum(int, ...);
int file_open( char* char_filename ) ;
char* file_all_open( char* char_filename ) ;
int filesize( FILE *fp ) ;
int file_list_main(int argc, char **argv) ;

void print_chars( char* char_string) ;
int filetime_main(int argc, char **argv) ;

//
//
//
//
//
int main(int argc, char **argv) {
	HANDLE hTime = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA ffd;
	int *number = 0;

	number = (int*) char_string(4);

	char* path_filename = copyof("C:\\Users\\soresore soreda\\source-002\\aDebug.cpp");
	char* spliter = copyof("\\");
	char** layers = split ( path_filename, spliter[0], number );
	char* concat_filename = nullptr;

	printf ("number: %d\r\n", *number);
	for( int i=0; i<*number; i++ ) {
		printf("i:%3d :%s \r\n", i, (char*)layers[i]);
		concat_filename = m_concat( concat_filename, layers[i] );
		concat_filename = m_concat( concat_filename, spliter );
	}

	printf ("concat_filename: %s \r\n", concat_filename );

	return 0;
}

//
//
//
//
//
int filetime_main(int argc, char **argv) {

	int success = 0;
	char* creationtime = nullptr;
	char* updatetime = nullptr;
	char* accesstime = nullptr;

	BOOL b_success = 0;
	HANDLE hTime = INVALID_HANDLE_VALUE;
	LPFILETIME lp_creationtime;
	LPFILETIME lp_updatetime;
	LPFILETIME lp_accesstime;
	WIN32_FIND_DATA ffd;
	LPFILETIME lp_updatetime_256;
	LPFILETIME lp_accesstime_256;
	LPFILETIME lp_creationtime_256;

	creationtime = char_string( 256 );
	updatetime = char_string( 256 );
	accesstime = char_string( 256 );

	lp_creationtime_256 = (LPFILETIME)char_string( 256 );
	lp_updatetime_256   = (LPFILETIME)char_string( 256 );
	lp_accesstime_256   = (LPFILETIME)char_string( 256 );

	hTime = FindFirstFile( copyof("C:\\Users\\soresore soreda\\source-002\\aDebug.cpp"), &ffd );

	b_success = GetFileTime(  hTime, (LPFILETIME)creationtime, (LPFILETIME)accesstime, (LPFILETIME)updatetime );
	b_success = GetFileTime(  hTime, lp_creationtime, lp_accesstime, lp_updatetime );

	// x printf( "lp_creationtime: %d: %d\r\n", lp_creationtime, *lp_creationtime);
	// x printf( "lp_creationtime: %d: %d\r\n", creationtime, *creationtime);
	printf( "creationtime: %d\r\n", creationtime);
	printf( "lp_creationtime: %d\r\n", lp_creationtime);
	printf( "lp_creationtime_256: %d\r\n", lp_creationtime_256);

	print_chars(creationtime);
	print_chars((char *)lp_creationtime_256);

	return 0;
}

//
//
//
//
//
void print_chars( char* char_string) {

	for( int i=0; 1; i++ ) {
		if ( char_string[i] == '\0' ) break;
		printf("n %3d: cn: %3d \r\n", i, char_string[i]);
	}

}

//
//
//
//
//
int file_list_main(int argc, char **argv) {

	char* filename;
	char **file_list;
	int number;
	FileControler *fc = nullptr;

	if ( argc < 2 ) {
		printf( "argc == %d \r\n", argc );
		exit(-1);
	}

	debug_allow_print_console = 1;
	//err_msg_001 ( "main: %d", argc);

	fc = new FileControler ();
	fc->print_char((char*)".\\*.cpp");
	printf("get_files: start: %s : %s\r\n", argv[1], copyof(".\\*.cpp"));
	// x file_list = (char**) fc->get_files (  (char*)argv[1] , number );
	file_list = (char**) fc->get_files (  copyof(".\\*.cpp") , &number );
	printf("get_files: end\r\n");

	fc->print_strings();

	printf("numnrt: %5d\r\n", number);
	for ( int i=0; i<(number); i++ ) {
		printf( "|%5d|%s|\r\n", i, *(file_list + i) );
	}

	return 0;
}

//
//
//
//
//
//
int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

//
// 
//
//
//
char* file_all_open( char* char_filename ) {
	FILE *fp;

//	printf("file_all_open\r\n");
	char* dummy = char_string ( 256 * 256 );
	fp = fopen( char_filename, "rb");
	int file_end = filesize ( fp );

	for ( int i=0; i< file_end; i++ ) {
//		printf("i: %4d/%4d ", i, file_end);
		m_fread( dummy, 1, fp );
		token = put_token( dummy[0] );
//		printf("dummy: %c|%3d|\r\n", dummy[0], dummy[0] );
	}

	fclose (fp);
	return token;
}

//
//
//
//
//
int file_open( char* char_filename ) {
	FILE *fp;
	char* dummy = char_string ( 256 * 256 );

	fp = fopen( char_filename, "rb");
	int file_end = filesize ( fp );
	for ( int i=0; i< file_end; i++ ) {
		m_fread( dummy, 1, fp );
	}

	fclose (fp);
}

int sum(int num_args, ...) {
   int val = 0;
   va_list ap;
   int i;

   va_start(ap, num_args);
   for(i = 0; i < num_args; i++) {
      val += va_arg(ap, int);
   }
   va_end(ap);
 
   return val;
}
