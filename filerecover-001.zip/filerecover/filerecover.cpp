//20200408: created:
#include <stdio.h>
#include <stdlib.h>

#define CHAR_MAX	256
#define PARSE_NUM	256

int filesize( FILE *fp ) ;


int main ( int argc, char** argv) {
	FILE *fp;
	char	char_word[CHAR_MAX];
	char	char_temp_word[CHAR_MAX];
	char* filename;

	if ( argc < 1 ) {
		printf("error: there is no parameter.");
		exit(-1);
	}

	printf("%s \r\n", argv[0] );
	exit(-1);

	filename = argv[1];

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end && i<PARSE_NUM; i++ ) {

		
		printf("i %d r\n", i );
	}

	return 0;
}

//
//
//
//
//
int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

