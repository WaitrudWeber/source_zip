#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdlib.h>

int main( int argc, char** argv ) {
	int i;
	FILE *rfp, *wfp;
	char dummy[255];
	printf("main starts.\r\n");

	rfp = (FILE*)fopen( "..\..\thunder.wav" ,"rb");


	for ( i=0; i<100; i++ ) {
		char c = fread ( dummy, 1, 1, rfp);
		printf("i:%d c|%d|%c|%s|%d|\r\n", i, c, c, dummy, rfp );
	}

	fclose(rfp);
	printf("main ends.\r\n");
	return 0;
}



