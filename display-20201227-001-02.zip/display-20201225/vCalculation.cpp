#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h> // ADD: 20200125

#include "array_counter.h"	// ADD: 20200125
#include "sender.h"			// ADD: 20200125
#include "Print.h"			// ADD: 20200125

#include "vPoint.h"
#include "vLine.h"

#include "vCalculation.h"


int dummy_vPoint_max = 0;
int dummy_vPoint_index = 0;

// x the below: 001
//static vPoint** dummy_vPoint = nullptr;
//static vPoint* dummy_p = nullptr;
//static vPoint* dummy_pp = nullptr;

int once_memorized = 0;

void put_memories( vPoint* dummy_vPoint );
vPoint* memorizevPoint( float a, float b, float c );
void print_point_memories ();
void put_points( vPoint* p );
void garbage_memories () ;
void free_point ( vPoint* p ) ;
void free_point_001 ( vPoint* p ) ;

//
//
//
//
//
void free_point ( vPoint* p ) {
	printf("free_point starts. |%p| dummy_vPoint_index|%d|\r\n", p, dummy_vPoint_index);

	dummy_vPoint_index--;
	if ( dummy_vPoint[dummy_vPoint_index] == nullptr ) {
		dummy_vPoint[dummy_vPoint_index] = memorizevPoint ( 0.0f, 0.0f, 0.0f );
	}

	for( int i=dummy_vPoint_index; i>=0; i-- ) {
		if ( dummy_vPoint[i] == p ) {
			// flip
			vPoint* w_p = dummy_vPoint[dummy_vPoint_index];
			dummy_vPoint[i] = dummy_vPoint[dummy_vPoint_index];
			dummy_vPoint[dummy_vPoint_index] = w_p;
		}
	}

	printf("free_point ends. |%p| dummy_vPoint_index{%d}\r\n", p, dummy_vPoint_index);
	// exit(-1);
}

//
//
//
//
//
void free_point_001 ( vPoint* p ) {
	printf("point |%p|\r\n", p);
	delete( p );
	printf("delete |%p|\r\n", p);
	// debug 20200213
	//if ( p == nullptr ) exit(-1);
	//exit(-1);
	vPoint *pp = new vPoint();
	printf("point |%p|\r\n", pp);
	delete(pp);
	printf("point |%p|\r\n", pp);
	// exit(-1);

	if ( once_memorized ) delete(dummy_pp);

	if ( dummy_pp == nullptr && once_memorized ) {
		printf("dummy_pp=%p\r\n", dummy_pp);
		exit(-1);
	}

	dummy_pp = new vPoint();
	once_memorized = 1;
}

// 
// int dummy_vPoint_max = 0;
// int dummy_vPoint_index = 0;
// vPoint** dummy_vPoint = nullptr;
// vPoint* dummy_p = nullptr;
// 
void put_points( vPoint* p ) {

	if ( dummy_vPoint_index >= dummy_vPoint_max ) {
		if ( dummy_vPoint_index == 0 ) dummy_vPoint_max = 8; // initialization
		dummy_vPoint_index *= 2;
		dummy_vPoint = (vPoint**) realloc ( dummy_vPoint, sizeof(vPoint*) * dummy_vPoint_max );
		printf("dummy_vPoint_max = %d \r\n", dummy_vPoint_max );
	}

	dummy_vPoint[ dummy_vPoint_index ] = (vPoint*)p;
	dummy_vPoint_index++;
}

//
float vCalculation::dot ( vPoint p1, vPoint p2) {
	float dot;

	this->dot( p1.x,p1.y,p1.z, p2.x,p2.y,p2.z, &dot );

	return dot;
}


//
//
//
//
//
void vCalculation::dot ( float x1, float y1, float z1, float x2, float y2, float z2, float* dot ) {

	*dot = x1*x2 + y1*y2 + z1*z2;
}

//
//
//
//
//
vPoint* vCalculation::add ( vPoint* p1, vPoint* p2) {
	printf("vCalculation::add starts\r\n");
	vPoint* p3 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	add( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );

	// comment out at 20191217
	// put_memories( p3 );

	printf("vCalculation::add returns |%p| \r\n", p3);
	return p3;
}

//
//
//
//
//
void vCalculation::add ( vPoint* p1, vPoint* p2, vPoint* p3) {
	add( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );
}


//
//
//
//
//
void vCalculation::cross ( vPoint* p1, vPoint* p2, vPoint* p3) {
	cross( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );
}

//
//
//
//
//
vPoint* vCalculation::cross ( vPoint p1, vPoint p2) {

	vPoint* p3 = memorizevPoint( 0.0f, 0.0f, 0.0f );

	cross( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(p3->x), &(p3->y), &(p3->z) );

	return p3;
}

//
//
//
vPoint* vCalculation::cross ( vPoint* p1, vPoint* p2) {

	vPoint* p3 = memorizevPoint( 0.0f, 0.0f, 0.0f );

	cross( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );

	return p3;
}

// 0, 0, 1  x  1, 0, 0 = 0, -1, 0     -> -z1*x2
// 1, 0, 0  x  0, 0, 1 = 0,  1, 0     ->  x1*z2

// 0, 1, 0  x  1, 0, 0 = 0, 0,  1
// 1, 0, 0  x  0, 1, 0 = 0, 0, -1
//
void vCalculation::cross ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = z1*y2 - y1*z2;
	*y3 = x1*z2 - z1*x2;
	*z3 = y1*x2 - x1*y2;

}

//
//
//
//
int vCalculation::subtract ( vPoint* p1, vPoint* p2, vPoint *p3) {
	float x, y, z;

	printf("int vCalculation::subtract starts p1|%p| p2|%p| p3|%p|\r\n", p1, p2);

	if( p3 == nullptr ) {
		printf("001: int vCalculation::subtract ends and set |%p| return -1.\r\n", p3);
	}

	subtract( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(x), &(y), &(z) );

	p3->setPoint( x, y, z );

	printf("int vCalculation::subtract ends and set |%p| return 0.\r\n", p3);

	return 0;
}

//
//
//
//
vPoint* vCalculation::subtract ( vPoint* p1, vPoint* p2) {
	printf("vPoint* vCalculation::subtract starts p1|%p| p2|%p|\r\n", p1, p2);

	float x, y, z;

	vPoint* result = nullptr;
	result = (vPoint*) memorizevPoint( 0.0f, 0.0f, 1.0f);
	printf("result|%p|\r\n", result);
	result->print();

	subtract( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(x), &(y), &(z) );

// commented out 20200410
//	put_memories ( (vPoint*)result );

// Set Result
//	result->x = x;
//	result->y = y;
//	result->z = z;

	result->setPoint( x, y, z );

	printf("vPoint* vCalculation::subtract ends and returns |%p|\r\n", result);
	return result;
}

//
vPoint* vCalculation::subtract_001 ( vPoint* p1, vPoint* p2) {
	printf("vPoint* vCalculation::subtract starts p1|%p| p2|%p|\r\n", p1, p2);

	float x, y, z;

	vPoint* result = nullptr;
	result = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f);

	subtract( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(x), &(y), &(z) );

// commented out 20200410
//	put_memories ( (vPoint*)result );

// Set Result
//	result->x = x;
//	result->y = y;
//	result->z = z;
	result->setPoint( x, y, z );

	printf("vPoint* vCalculation::subtract ends and returns |%p|\r\n", result);
	return result;
}


//
//
//
//
//
void vCalculation::Print_Point_Memories () {

	print_point_memories ();
}

// Qualfied: we could use %p on printf.
//
//
//
//
void print_point_memories () {

	vPoint* p = nullptr;

	for( int i=0; i<dummy_vPoint_index; i++ ) {
		p = dummy_vPoint[ i ];
		printf ("i: %3d p: %p\r\n", i, p );
	}

}


// Recreated: 20200218
// Recreated: 20200414
// Modified: 20200505
//
//
vPoint* memorizevPoint( float a, float b, float c ) {
	printf("memorizevPoint starts: %f %f %f dummy_vPoint_index %d dummy_vPoint_max %d\r\n", a, b, c, dummy_vPoint_index, dummy_vPoint_max);

	// Mallocation: initialize: 20200414
	if ( dummy_vPoint_max == 0 ) {
		dummy_vPoint_max = 8;
		dummy_vPoint_index = 0;
		dummy_vPoint = (vPoint**) malloc ( sizeof(vPoint*) * dummy_vPoint_max );
		for (int i = 0; i < dummy_vPoint_max; i++)
			dummy_vPoint[i] = nullptr;
	//		dummy_vPoint[i] = new vPoint(0.0f, 0.0f, 0.0f);
	}

	printf("Reallocation array only starts.\r\n");

	// Rallocation:
	if (dummy_vPoint_index >= dummy_vPoint_max - 1) {
		dummy_vPoint_max = dummy_vPoint_max * 2;
		printf("dummy_vPoint_max %d we found.\r\n", dummy_vPoint_max);
		dummy_vPoint = (vPoint**)realloc(dummy_vPoint, sizeof(vPoint*) * dummy_vPoint_max);
		printf("dummy_vPoint_max %d reallocated.\r\n", dummy_vPoint_max);
		for (int i = dummy_vPoint_index; i < dummy_vPoint_max; i++) // Recognistion: 20200508
			dummy_vPoint[i] = nullptr;

	}

	printf("Reallocation array only ends.\r\n");

	if ( dummy_vPoint_index < dummy_vPoint_max ) {
		dummy_p = dummy_vPoint[dummy_vPoint_index];
		if ( dummy_p != nullptr ) {
			dummy_vPoint_index++;
			printf("aReuse: %d/%d dummy_vPoint=%p\r\n", dummy_vPoint_index -1, dummy_vPoint_max, dummy_vPoint[dummy_vPoint_index - 1]);
			//exit(-1);
			dummy_vPoint[dummy_vPoint_index - 1]->setPoint( a, b, c);
			return dummy_vPoint[dummy_vPoint_index - 1];
		} else {
			// nullptr
			dummy_vPoint[dummy_vPoint_index] = new vPoint( a, b, c );
			dummy_vPoint_index++;
			printf("aNew: %d/%d dummy_vPoint=%p\r\n", dummy_vPoint_index -1, dummy_vPoint_max, dummy_vPoint[dummy_vPoint_index - 1]);
			return dummy_vPoint[dummy_vPoint_index - 1];
		}
	} else {
			printf("dummy_vPoint_index %d dummy_vPoint_max %d\r\n", dummy_vPoint_index, dummy_vPoint_max);
	}

	printf("memorizevPoint error ends.");
	exit(-1);
}

//
//
//
//
void put_memories ( vPoint* result ) {

	printf("Do not use: put_memories\r\n");
	exit(-1);


	if ( dummy_vPoint_index == 0 ) {
		dummy_vPoint_max = 8;
		dummy_vPoint = (vPoint**) malloc ( sizeof(vPoint*) * dummy_vPoint_max );
	}

	if ( dummy_vPoint_index >= dummy_vPoint_max - 1 ) {
		dummy_vPoint_max = dummy_vPoint_max * 2;
		dummy_vPoint = (vPoint**) realloc ( dummy_vPoint, sizeof(vPoint*) * dummy_vPoint_max );
	}

	dummy_vPoint[ dummy_vPoint_index ] = result;
	dummy_vPoint_index++;
}

//
//
//
//
//
void garbage_memories () {
	for( int i=0; i<dummy_vPoint_index; i++ ) {
		printf("|%3d|%p|\r\n", i, dummy_vPoint[i] );
		if ( dummy_vPoint[i] == nullptr ) {
			printf("we found freed memory.\r\n");
			exit(-1);
		}
	}

	// 20200126 temporalily we quit.
	if ( dummy_vPoint_index > 0 ) {
		printf("dummy_vPoint_index=|%3d|\r\n", dummy_vPoint_index );
		//exit(-1);
	}
}

//
//
//
//
vPoint* vCalculation::subtract ( vPoint p1, vPoint p2) {
	vPoint *result;
	printf("vPoint vCalculation::subtract:\r\n" );
//	vPoint* a_result = nullptr;
//	result = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f);
//	subtract( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(result->x), &(result->y), &(result->z) );

//	printf("vPoint vCalculation::subtract ends: \r\n" );
//	return *result;

	result = memorizevPoint ( 0.0f, 0.0f, 0.0f );
	subtract(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(result->x), &(result->y), &(result->z));
//	return *(memorizevPoint( 0.0f, 0.0f, 0.0f));

	printf("vPoint vCalculation::subtract ends: %p\r\n", result );
	return result;
}

//
//
//
//
void vCalculation::subtract ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {
	printf("vCalculation::subtract:001 starts.\r\n");
	printf("|%p|%p|%p| \r\n", x3,  y3, z3 );
	printf("|%f|%f|%f|%f|%f|%f| \r\n", x1,  y1, z1, x2, y2, z2 );
	*x3 = x1 - x2;
	*y3 = y1 - y2;
	*z3 = z1 - z2;
	printf("|%p|%p|%p| \r\n", x3,  y3, z3 );
	printf("|%p|=%f |%p|=%f |%p|=%f \r\n", x3, *x3,  y3, *y3, z3, *z3 );

	printf("vCalculation::subtract:001 ends.\r\n");
}

//
//
//
//
//
void vCalculation::add ( vPoint p1, vPoint p2, vPoint* p3 ) {
	printf("vPoint vCalculation::add: starts. |%p| |%p| |%p|\r\n", &p1, &p2, p3);

	add( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(p3->x), &(p3->y), &(p3->z) );

	printf("vPoint vCalculation::add: sets |%p|.\r\n", p3);
}

//
//
//
//
//
vPoint* vCalculation::add ( vPoint p1, vPoint p2) {
	printf("vPoint vCalculation::add: starts. |%p| |%p|\r\n", &p1, &p2);

	vPoint* result = memorizevPoint( 0.0f, 0.0f, 0.0f);

	add( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(result->x), &(result->y), &(result->z) );

	printf("vPoint vCalculation::add: returns |%p|.\r\n", result);
	return result;
}

//
//
//
//
//
void vCalculation::add ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = x2 + x1;
	*y3 = y2 + y1;
	*z3 = z2 + z1;

}

// expand
// scale
// strech
// enlarge
// magnification
vPoint* vCalculation::scalize ( vPoint* p1, float w_scale) {

//	vPoint* result = (vPoint*) malloc (sizeof(vPoint) * 1 );
	vPoint* result = memorizevPoint( 0.0f, 0.0f, 0.0f);

//	scale ( p1->x, p1->y, p1->z, w_scale, &(p1->x), &(p1->y), &(p1->z) );
	scale(p1->x, p1->y, p1->z, w_scale, &(result->x), &(result->y), &(result->z));

//	put_memories ( result );

	return p1;
}

//
//
//
//
//
vPoint* vCalculation::scale ( vPoint* p1, float w_scale, vPoint* result ) {
	printf("vPoint* vCalculation::scale |%p| |%f| |%p|\r\n",  p1, w_scale, result);

	scale ( p1->x, p1->y, p1->z, w_scale, &(result->x), &(result->y), &(result->z) );

//	put_memories ( result );

	printf("vPoint* vCalculation::scale |%p|\r\n", result);
	return result;
}


//
//
//
//
//
//
void vCalculation::scale ( vPoint* p1, float w_scale ) {
	printf("vCalculation::scale starts.\r\n");

	p1->x *= w_scale;
	p1->y *= w_scale;
	p1->z *= w_scale;

	printf("vCalculation::scale ends.\r\n");
}

//
//
//
//
//
vPoint* vCalculation::scale ( vPoint p1, float w_scale ) {
	printf("vCalculation::scale starts. |%p| %f\r\n", &p1, w_scale);

	vPoint* result = memorizevPoint( 0.0f, 0.0f, 0.0f );
	

	scale ( p1.x, p1.y, p1.z, w_scale, &(result->x), &(result->y), &(result->z) );

	printf("vCalculation::scale ends. return |%p|\r\n", &result);
	return result;
}

//
//
//
//
void vCalculation::scale ( float x1, float y1, float z1, float scale, float* x3, float* y3, float* z3) {

	*x3 = scale * x1;
	*y3 = scale * y1;
	*z3 = scale * z1;

}

void vCalculation::normal ( vPoint* p1, vPoint* p2 ) {
	this->normal((p1->x) ,(p1->y) ,(p1->z) ,&(p2->x), &(p2->y), &(p2->z) );
}

//
//
//
//
//
void vCalculation::normal ( vPoint* p1 ) {

	double scale = p1->x*p1->x + p1->y*p1->y + p1->z*p1->z;
	scale = sqrt( scale );

	p1->x = (( double ) p1->x) / scale;
	p1->y = (( double ) p1->y) / scale;
	p1->z = (( double ) p1->z) / scale;
}

//
//
//
//
vPoint* vCalculation::normal ( vPoint p1 ) {

	vPoint* p2 = memorizevPoint( 0.0f, 0.0f, 0.0f );
	// double scal = 0.0;
	// scal = normal( p1.x, p1.y, p1.z, &p2.x, &p2.y, &p2.z );

	normal( p1.x, p1.y, p1.z, &(p2->x), &(p2->y), &(p2->z) );

	return p2;
}

//
//
//
//
double vCalculation::normal ( float x1, float y1, float z1, float* x2, float* y2, float* z2 ) {

	double scale = x1*x1 + y1*y1 + z1*z1;
	scale = sqrt( scale );

	double x3 = (( double ) x1) / scale;
	double y3 = (( double ) y1) / scale;
	double z3 = (( double ) z1) / scale;

	*x2 = x3;
	*y2 = y3;
	*z2 = z3;

	return scale;
}

//
//
//
//
double vCalculation::length ( vPoint lp ) {

	return length ( lp.x, lp.y, lp.z );
}

//
//
//
//
double vCalculation::length ( vPoint* lp ) {

	return length ( lp->x, lp->y, lp->z );
}

//
//
//
//
double vCalculation::length ( float x1, float y1, float z1) {

	double scale = x1*x1 + y1*y1 + z1*z1;
	scale = sqrt( scale );

	return scale;
}

//
//
//
//
//
vLine* vCalculation::put_line( vLine* be_set, vLine* l1 ) {
	be_set = l1;
	// the below error 
	// l1->p1->print();
	// the below error 
	// be_set->p1->print();

	return l1;
}

//
//
// copy all points and would liket to refer to points at 20190213
//
vLine** vCalculation::Lines_from_Mesh ( vPoint* points, int** numbering, int num_patches, int base_num_patches) {
	vLine** p_result = nullptr;
	vLine** result = nullptr;
	//20180214
	int c = num_patches;
	int d_number = 0;
	vPoint* end_to_start = nullptr;

	printf("num_patches %d base_num_patches %d\r\n", num_patches, base_num_patches);

	for( int i=0; i<c; i++ ) {
		int* num_p = *( numbering + i );
		//20180214
//		int d = sizeof( num_p ) / sizeof( int* );
		int d = base_num_patches;

		p_result = ( vLine** ) malloc ( sizeof(vLine**) * d );
		d_number += d;
		result = ( vLine** ) realloc ( result, sizeof( vLine** ) * d_number );

		for( int j=0; j<d; j++ ) {
			int number = *( num_p + j );
			vLine* p_line = *( p_result + j );
			put_point( p_line->p1, points + number );

			if ( j == 0 ) {
				end_to_start = points + number;
			} else {
				put_point( p_line->p2, points + number - 1 );
			}
		}

		vLine* last = *( p_result + d - 1 );
		put_point( last->p2, end_to_start );

		for( int j= d_number - d; j<d_number; j++ ) {
			put_line( *(result + j), *(p_result + j - d_number + d) );
		}
	}

	Print_Lines ( result, d_number );
	printf("end of Lines_from_Mesh d_number %d\r\n", d_number);

	// cast vPoint** -> vPoint*
//	put_memories( (vPoint*) result );

	return result;
}

//
//
//
//
//
void vCalculation::Print_Lines ( vLine** array, int num ) {

	for ( int i=0; i<num; i++ ) {
		vLine* line = *( array + i );
		line->print();
	}

}

//
//
//
//
//
void vCalculation::put_point( vPoint* lp1, vPoint* points_number ) {
	printf( "start of put_point\r\n" );
	points_number->print();
	lp1 = points_number;
	lp1->print();
	printf( "end of put_point\r\n" );
	// exit(-1);
}

