#ifndef _WKICKEVENT_H_
#define _WKICKEVENT_H_

//Base class 
class wKickEvent 
{ 
    public: 
      int id_p; 

	public:
		void setId ( int id );
		void Execute () ;
		void Prefectured () ;
		void PreProcessor () ;
		void Processor () ;
		void Processor_001 ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam );
		virtual void wm_char() { }
		virtual void wm_paint() { }

}; 

#endif

