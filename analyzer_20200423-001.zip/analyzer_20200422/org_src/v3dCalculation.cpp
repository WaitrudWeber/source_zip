#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "aToken.h"
#include "wC_structure.h"
#include "analyzer_C.h"

#include "wTextarea.h"
#include "clipboard.h"
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
//#include "vLine.h"
#include "vCircle.h"

#include "vPointStructure.h"
#include "vPointLinear.h"
#include "display_threeD.h"

#include "v3dCalculation.h"

vCalculation calc;

// void vCalculation::Print_Point_Memories () {
//
int v3dCalculation::calculation_threed () {
	printf("v3dCalculation:: calculation_threed () starts.\r\n");
	calc.Print_Point_Memories ();

	display_threeD_screen_initialize_OnRails () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_threed () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_threed_002 () {
	printf("v3dCalculation:: rails_initialization () starts.\r\n");
	calc.Print_Point_Memories ();

	rails_initialization () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: rails_initialization () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_threed_003 () {
	printf("v3dCalculation:: memorizevpoint_tests () starts.\r\n");
	calc.Print_Point_Memories ();

	memorizevpoint_tests () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: memorizevpoint_tests () ends.\r\n");
	return 1;
}


