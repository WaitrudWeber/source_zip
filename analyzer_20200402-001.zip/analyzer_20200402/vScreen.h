#ifndef _VSCHEEN_
#define _VSCHEEN_

#include "vPoint.h"

class vScreen {

	public:
		vScreen ( );
		// vPoint Intersect( vTriangle tri, vPoint eye, vPoint ray );
		void put_U ( vPoint a) ;
		void put_V ( vPoint b) ;
		void put_C ( vPoint c) ;
		void put_Up ( vPoint up) ;
		void LookAt ( vPoint lookat );
		void setEye ( vPoint eye );
		vPoint subtract( vPoint a, vPoint b);
		vPoint normal( vPoint a );
		vPoint cross ( vPoint a, vPoint b);
		void setWidth( int w );
		void setHeight( int h );
		void calculation_uv_up ();
		void calculation ();
		void calculation_up_UV ();
		int OntheScreen ( vPoint lp, float* x, float* y ) ;
		int OntheScreen ( vPoint lp, vPoint* result ) ;
		void OntheScreen ( float* x, float* y);
		void OntheScreen ( vPoint* x, vPoint* y);
		int get_coordinate_on_screen ( vPoint lp, float* lx, float* ly ) ;
		void setHowFarFromEye ( float howfarfromeye ) ;

	private:
		vCalculation* this_calc = nullptr;
		//vPoint C;
		vPoint X; // SCREEN( X, Y )
		vPoint Y;
		vPoint u, v; // w is up.
		float width = 0.0f, height = 0.0f;
		vTriangle screen_tri;

	public:
		vPoint C;
		vPoint U;
		vPoint V;
		vPoint eye;
		vPoint up;
		vPoint lookat;
		float HowFarFromEye=640.0f;

};

#endif

