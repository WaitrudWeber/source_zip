#ifndef _WMOVEMENTRAILMAPPING_H_
#define _WMOVEMENTRAILMAPPING_H_

// Sub class inheriting from Base Class(Parent) 
//
class wMovementRailMapping : public wKickEvent { 
	public: 
		int id_c; 

	private:
		int pid;

	public:
		void setPid ( int id ) ;
};

#endif
