#include "wKickEvent.h"
#include "wMovementRailMapping.h"
//#include "wKickEventDisplayThreeD.h"
//#include "wKickEventDisplayThreeD.h"

void wMovementRailMapping::setPid ( int id ) {
	this->pid =id;
}
