#ifndef WTEXTAREAE_H
#define WTEXTAREAE_H

extern void wPrint ( char* buffer, char * format, ... );
extern void wExtractQue( char* buffer ) ;

#endif