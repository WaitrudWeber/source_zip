extern int DEBUG( char* ip, int argc, char **argv );
