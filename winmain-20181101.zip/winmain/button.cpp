#include <tchar.h>
#include <Windows.h>
#include <windowsx.h>

#include "button.h"

int drawButton( HDC hdc, char *button_name, RECT *rect );

// this function draws a button.
// button has a string.
// button has a rect which is one of shapes in this case.
int drawButton( HDC hdc, char *button_name, RECT *rect )
{

	SetTextColor( hdc, RGB(0 ,0, 255));

	Rectangle( hdc, rect->left, rect->top, rect->right, rect->bottom );
	DrawText( hdc, TEXT( button_name ), -1, rect, DT_NOCLIP);

	return 1;
}




