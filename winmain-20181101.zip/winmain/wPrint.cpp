#include <tchar.h>

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
// https://www.tutorialspoint.com/c_standard_library/c_function_strcat.htm
#include <string.h>

#include "wPrint.h"

char**	Ques;
int		Ques_Number = 0;
int		Ques_Number_Max = 256;

void wPrint ( char* buffer, char * format, ... );
void wPrintQue ( char* q ) ;
void wStacktBuffer ( char* q ) ;
void wPrintBuffer (char* buffer ) ;
void wExtractQue( char* buffer ) ;



void wExtractQue( char* buffer ) {
	wPrintBuffer ( buffer );
}

void wPrintBuffer (char* buffer ) {

	int i;
	for( i=0; i<Ques_Number; i++ ) {
		strcat( buffer, Ques[ Ques_Number ] );
	}

}

void wStacktQue (char* q ) {

//	char ** buffer = NULL;

	if( Ques_Number == 0 ) {
		Ques = (char **) malloc ( sizeof(char * ) * Ques_Number_Max );
	}

	Ques_Number++;
	if(Ques_Number >= Ques_Number_Max) {
		Ques_Number_Max *= 2;
		Ques = (char **) realloc ( Ques, sizeof(char * ) * Ques_Number_Max );
	}

	Ques[ Ques_Number ] = q;
}

void wPrint ( char* buffer, char * format, ... ) {
	va_list args;
	va_start ( args, format );
	vsnprintf ( buffer, 255, format, args);
	//do something with the error
	va_end (args);

	wStacktQue( buffer );
}


