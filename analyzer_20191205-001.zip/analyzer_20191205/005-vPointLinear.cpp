#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vPointStructure.h"
#include "vPointLinear.h"

//
//
//
//
//
void vPointLinear::PrintAnchors( ) {

	vCalculation* calc = new vCalculation();

	for ( int i=0; i<this->numPS; i++) {
		aPS[i]->Anchor->print ();
		if ( i > 0 ) {
			printf("dsitance from %d to %d: %lf\r\n", i -1, i, calc->length(  calc->subtract( (vPoint*)aPS[i -1]->Anchor, (vPoint*)aPS[i]->Anchor )) );
		}
	}

}

//
//
//
//
//
void vPointLinear::PrintControls( ) {

	vCalculation* calc = new vCalculation();

	for ( int i=0; i<this->numPS; i++) {
		printf("C1 ");
		aPS[i]->C1->print ();
		printf("C2 ");
		aPS[i]->C2->print ();
		double distance = calc->length( calc->subtract( (vPoint*)aPS[i]->C2, (vPoint*)aPS[i]->C1 ) );
		printf("distance %lf\r\n", distance );
	}

}

//
//
//
//
//
//
void vPointLinear::FirstCreation( ) {
	aPS = (vPointStructure**)malloc( sizeof(vPointStructure*) * 6 );
	this->numPS = 6;
	for ( int i=0; i<this->numPS; i++)
		aPS[i] = (vPointStructure*) new vPointStructure();

	// vPoint* p = (vPoint*)new vPoint( 1.0f, 1.0f, 1.0f );
	// aPS[0]->Anchor = p;
	// aPS[0]->Set_Anchor( p );

	aPS[0]->Anchor = (vPoint*)new vPoint( 1.0f, 0.0f, 0.0f );
	aPS[1]->Anchor = (vPoint*)new vPoint( 1.1f, 50.0f, 200.0f );
	aPS[2]->Anchor = (vPoint*)new vPoint( 1.2f, 100.0f, 400.0f );
	aPS[3]->Anchor = (vPoint*)new vPoint( 1.3f, 150.0f, 600.0f );
	aPS[4]->Anchor = (vPoint*)new vPoint( 1.4f, 120.0f, 800.0f );
	aPS[5]->Anchor = (vPoint*)new vPoint( 1.5f, 100.0f, 1000.0f );

	this->FirstRevisement( );
}

//
// Modified : 20191202
// ReCreation of Controls : 20191202
//
//
//
void vPointLinear::FirstRevisement( ) {

	// can not revise.
	if ( this->numPS <=2 ) return;

	vCalculation* calc = nullptr;
	calc = new vCalculation();

	for ( int i=0; i<this->numPS; i++ ) {
		aPS[i]->C1 = (vPoint*)new vPoint();
		aPS[i]->C2 = (vPoint*)new vPoint();
	}

	// Sst C2s and C1s
	for ( int i=1; i<this->numPS - 1; i++ ) {
		vPoint* aa = calc->subtract( aPS[ i ]->Anchor, aPS[ i - 1 ]->Anchor ) ;
		vPoint* ab = calc->subtract( aPS[ i + 1 ]->Anchor, aPS[ i ]->Anchor ) ;
		vPoint* ac = calc->add( aa, ab );
		aPS[ i ]->C2 = calc->add( aPS[ i ]->C2, ac );
		vPoint* ba = calc->subtract( aPS[ i ]->Anchor, aPS[ i ]->C2 );
		aPS[ i ]->C1 = calc->add( aPS[ i ]->Anchor, ba );
	}

	// index = 0.
	aPS[ 0 ]->C2->setPoint( aPS[ 1 ]->C1->x, aPS[ 1 ]->C1->y, aPS[ 1 ]->C1->z );
	vPoint* ba = calc->subtract( aPS[ 0 ]->Anchor, aPS[ 0 ]->C2 );
	aPS[ 0 ]->C1 = calc->add( aPS[ 0 ]->Anchor, ba );

	ba->print();
	aPS[ 1 ]->C1->print();
	aPS[ 1 ]->C2->print();
	aPS[ 0 ]->C1->print();
	aPS[ 0 ]->C2->print();

	printf("aPS[ 0 ]->Anchor: ");
	aPS[ 0 ]->Anchor->print();

	// index = num -1, which means last.
	aPS[ this->numPS - 1 ]->C1->setPoint ( aPS[ this->numPS - 2 ]->C2->x, aPS[ this->numPS - 2 ]->C2->y, aPS[ this->numPS - 2 ]->C2->z ); 
	vPoint* bb = calc->subtract( aPS[ this->numPS - 1 ]->Anchor, aPS[ this->numPS - 1 ]->C1 );
	aPS[ this->numPS - 1 ]->C2 = calc->add( aPS[ this->numPS - 1 ]->Anchor, bb );
}

//
//
//
//
//
void vPointLinear::GetNormal ( vPoint* p1, vPoint* p2, vPoint* p3, vPoint* normal ) {

	vCalculation* calc = nullptr;
	calc = new vCalculation();

	calc->cross( p1, p2, normal );

}

//
//
//
//
//
vLine** vPointLinear::FirstCreateLines( vPointStructure** ps, int num_devide ) {


	this->FirstCreation();

}

//
//
//
//
//
vLine** vPointLinear::generateLines( vPointStructure** ps, int num_devide ) {



	return nullptr;
}

//
// Modified: 20191130
//
//
//
vLine** vPointLinear::generateControlsLines(  ) {

	// Allocation: 20190708
	if ( this->line_num == 0 ) {

		this->print_lines = (vLine**) malloc( sizeof(vLine*) * ( this->numPS + 1 )  );
		for( int i=0; i<this->numPS; i++ ) {
			// x vLine* allocation_line = (vLine*) malloc ( sizeof(vLine) * 1 );
			// x vLine* allocation_line = new vLine();
			this->print_lines[i] = (vLine*) new vLine();
		}
		line_num = this->numPS;

		printf( "Allocated: 0 \r\n" );
	} else if (  this->line_num <= this->numPS ) {

		this->print_lines = (vLine**) realloc( this->print_lines, sizeof(vLine*) * this->numPS );
		for( int i=this->line_num; i<this->numPS; i++ ) {
			this->print_lines[i] = new vLine();
		}
		line_num = this->numPS;
	}

	printf("local lines:\r\n");
	for( int i=0; i<this->line_num; i++ ) {
		printf("i: %d ", i );
		this->print_lines[i]->setLine( (vPoint*) this->aPS[i]->C1, (vPoint*) this->aPS[i]->C2 );
		this->print_lines[i]->print();
		// l_lines[i]->p1->print();
		// l_lines[i]->p2->print();
	}

	return this->print_lines;
}

void vPointLinear::calculation_array () {

	// aPS = new vPointStructure[ 10 ];
}

//
//
//
//
//
void vPointLinear::calculation () {
	vPoint	*p1, *p2, *p3, *p4;
	vCalculation* calc = nullptr;

	printf("start: void vPointLinear::calculation () \r\n");

	calc = new vCalculation();
	p1 = new vPoint ( 1.0f, 2.0f, 3.0f );
	p2 = new vPoint ( 1.5f, 2.5f, 3.5f );

	p3 = calc->scalize( p1, 5.0f );
	p4 = calc->scalize( p2, 5.0f );

	p1->print();
	p2->print();
	p3->print();
	p4->print();

	printf("end: void vPointLinear::calculation () \r\n");
	// exit(-1);
}

//
// 0<= t <= 1
//
vPoint vPointLinear::position( vPoint* c1, vPoint* c2, float t ) {

	//20190505
	double c = 3.0; // 1/length
	vPoint* start = new vPoint();
	vPoint* end = new vPoint();
	vCalculation* calc = nullptr;

//	vPoint a = calc->scale( start, t*t  );
//	vPoint b = calc->scale( end, 1 - t*t  );
//	vPoint c1 = calc->add ( a, b ) ;

	vPoint result;

	return result;
}

//
//
//
//
//
vPoint vPointLinear::additional_positionP( vPoint* c1, vPoint* c2, float t ) {

	//20190505
	double c = 3.0; // 1/length
	vPoint* start = new vPoint();
	vPoint* end = new vPoint();
	vCalculation* calc = nullptr;
	calc = new vCalculation();

	vPoint a = calc->scale( *start, t*t  );
//	vPoint b = calc->scale( end, 1.0 - t*t  );
//	vPoint c1 = calc->add ( a, b );

	vPoint result;

	return result;
}

//
//
//
//
//
vPoint vPointLinear::additional_position (vPointStructure* ps1, vPointStructure* ps2, float t ) {

	vPoint p;

	return p;
}
