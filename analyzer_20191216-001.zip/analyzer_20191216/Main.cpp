#include "Parent.h"
#include "Child.h"

int main () {

	return 0;
}

