#include <stdio.h>

#include "vPoint.h"
#include "vPhoton.h"

vPhoton::vPhoton ( ) {

	this->photon1 = new vPoint();
	this->photon2 = new vPoint();
	this->c1 = (char*)" ";
	this->c2 = (char*)" ";
}

//
//
//
//
//
void vPhoton::setNormal(vPoint* normal)
{
	this->photon2 = normal;
}

//
//
//
//
//
void vPhoton::setPlace(vPoint* place)
{
	this->photon1 = place;
}

//
//
//
//
//
void vPhoton::print () {
	if ( this->photon1 == nullptr || this->photon1 == nullptr) {
		return;
	}

	printf("vPhoton: %p %p\r\n", this->c1, this->c2);

	this->photon1->print();
	this->photon2->print();
}

