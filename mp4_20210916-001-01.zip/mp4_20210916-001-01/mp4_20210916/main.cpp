#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include <stdlib.h>
#include <time.h>


#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"
#include "replace_main.h"

int replace_main (int argc, char** argv ) ;
int copyof_test () ;
int initialize_parse_test () ;
int read_sourcecode (char* filename ) ;

int main_002_test (int argc, char** argv ) ;
int main_006 (int argc, char** argv );
int main_007 (int argc, char** argv );
int main_008 (int argc, char** argv );
int main_009 (int argc, char** argv );

int read_mp4 (char* filename ) ;
int read_mp4_001 (char* filename ) ;
int read_mp4_002 (char* filename ) ;
int read_mp4_003 (char* filename ) ;
int read_mp4_004 (char* filename ) ;
int read_mp4_005 (char* filename ) ;

int write_mp4_block( char* w_filename, unsigned char* uc_string, int number ) ;


char* allocation = NULL;
unsigned char memory_allocation[255];
unsigned char c_memory_allocation[255];


int main ( int argc, char** argv ) {
	if ( argc < 1 ) {
		printf("argc %d\r\n", argc );
		return 0;
	}
	printf(" argc[i] filename = %s\r\n", (char*)argv[1]);
	int a = read_mp4_002 ( argv[1] );

	print_memories ();
}

int main_009 ( int argc, char** argv ) {
//	int a = initialize_parse_test ();
//	print_memories();


	if ( argc < 1 ) {
		printf("argc %d\r\n", argc );
		return 0;
	}

	printf(" argc[i] filename = %s\r\n", (char*)argv[1]);
	int a = read_csv_010 ( argv[1] );

	int b = print_csv ();

	print_memories ();
}

//https://qiita.com/satken2/items/d14b4113fe3fb5f5597b
//https://en.wikipedia.org/wiki/MPEG-4_Part_14
int read_mp4_005 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;
	char* typeofkey[3] = { "ftyp", "mdat", "moovt" };
	int m = 0;

	printf("int read_mp4 (char* filename ) starts.\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	fread ( c_memory_allocation, 1, 4, structure_fp.fp );

	for ( i=0; i<4; i++ ) {
		printf("i:%04d char %04d |%c|\r\n", i, c_memory_allocation[i],  c_memory_allocation[i]  );
	}

	fclose ( structure_fp.fp );

//	aFree ( p_dummy_token );

	printf("int read_mp4 (char* filename ) ends.\r\n"); 
	return 0;
}

//
int write_mp4_block( char* w_filename, unsigned char* uc_string, int number ) {
	FILE *wfp;
	int ac;

	printf("write_mp4_block starts.\r\n");

	wfp = fopen( w_filename, "wb");

//	ac = array_count ( c_string );

	fwrite( uc_string, sizeof(char), number, wfp);
	printf("uc_string:\r\n|%s|\r\n", uc_string);

	fclose(wfp);

	printf("write_mp4_block ends.\r\n");
}

//https://qiita.com/satken2/items/d14b4113fe3fb5f5597b
//https://en.wikipedia.org/wiki/MPEG-4_Part_14
int read_mp4_004 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;
	char* typeofkey[3] = { "ftyp", "mdat", "moovt" };
	int m = 0;

	printf("int read_mp4 (char* filename ) starts.\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	fread ( memory_allocation, 1, 4, structure_fp.fp );

	for ( i=0; i<4; i++ ) {
		printf("i:%04d unsigend char %04d\r\n", i, memory_allocation[i] );
	}

	p_dummy = (char*)memory_allocation;

	for ( i=0; i<4; i++ ) {
		printf("i:%04d char %04d\r\n", i, p_dummy[i] );
	}


	fclose ( structure_fp.fp );

//	aFree ( p_dummy_token );

	printf("int read_mp4 (char* filename ) ends.\r\n"); 
	return 0;
}


//https://qiita.com/satken2/items/d14b4113fe3fb5f5597b
//https://en.wikipedia.org/wiki/MPEG-4_Part_14
int read_mp4_003 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;
	char* typeofkey[3] = { "ftyp", "mdat", "moovt" };
	int m = 0;

	printf("int read_mp4 (char* filename ) starts.\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	fread ( memory_allocation, 1, 4, structure_fp.fp );

	for ( i=0; i<4; i++ ) {
		printf("i:%04d unsigend char %04d\r\n", memory_allocation[i] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	printf("int read_mp4 (char* filename ) ends.\r\n"); 
	return 0;
}

// EOI: 0xD9
//https://qiita.com/satken2/items/d14b4113fe3fb5f5597b
//https://en.wikipedia.org/wiki/MPEG-4_Part_14
int read_mp4_002 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	unsigned char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;
	char* typeofkey[3] = { "ftyp", "mdat", "moov" };
	int m = 0;

	printf("int read_mp4 (char* filename ) starts.\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <100; i++ ) {

		printf("i: %d loop starts. p_dummy_token = |%s| ", i, p_dummy_token );
		printf("struct_fp.fp |%d| \r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = (unsigned char*)get_string_002( structure_fp , 4);
		p_dummy[4] = '\0';

		printf( "p_dummy array_count %d address|%d|\r\n", array_count( (char*)p_dummy), (char*)p_dummy );

		for ( j = 0; j<3; j++ ) {
			if ( m_start_with ( (char*)p_dummy, (char*)typeofkey[j] ) == 1 && canread == 1 ) {
				printf("we could find |%s| as p_dummy |%s|  p_dummy[0]=|%c|%d|.\r\n", typeofkey[j], p_dummy, p_dummy[0], p_dummy[0]);
				sprintf( w_filename, "%s-001.txt", typeofkey[j] );
				printf("write filename: %s\r\n", w_filename);
				m_thread_sleep();
				write_mp4_block( w_filename, memory_allocation, m );
				m = -1;
//				exit(-1);
				break;
			}
		}

		for ( j =0 ; j<4; j++ ) {
			printf("p_dummy[%d] =|%d|\r\n", j, p_dummy[j] );
		}

		memory_allocation[m] = p_dummy[0];
		printf("p_dummy[0] = |%c| m|%d| memory_allocation %s\r\n", p_dummy[0], memory_allocation[m], memory_allocation);
		m++;
	}


	fclose ( structure_fp.fp );

	printf("Tell the file end of image 0xD9 = %d in 10.\r\n", 0xD9 );
	printf("int read_mp4 (char* filename ) ends.\r\n");
	return 0;
}


//https://qiita.com/satken2/items/d14b4113fe3fb5f5597b
//https://en.wikipedia.org/wiki/MPEG-4_Part_14
int read_mp4_001 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;
	char* typeofkey[3] = { "ftyp", "mdat", "moovt" };
	int m = 0;

	printf("int read_mp4 (char* filename ) starts.\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <100; i++ ) {

		printf("i: %d loop starts. p_dummy_token = |%s| ", i, p_dummy_token );
		printf("struct_fp.fp |%d| \r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		printf( "p_dummy array_count %d address|%d|\r\n", array_count( p_dummy), p_dummy );

		/*for ( j = 0; j<3; j++ ) {
			if ( m_start_with ( (char*)p_dummy, (char*)typeofkey[j] ) == 1 && canread == 1 ) {
				printf("we could find |%s| as p_dummy %s.\r\n", typeofkey[j], p_dummy );
				printf("head: %d : %s \r\n", i, p_dummy_token);
				aFree ( p_dummy_token );
				m_thread_sleep();
				exit(-1);
				break;
			}
		}*/

		memory_allocation[m] = p_dummy[0];
		printf("p_dummy[0] = |%c| m|%d| memory_allocation %s\r\n", p_dummy[0], memory_allocation[m], memory_allocation);
		p_dummy_token = put_token( p_dummy[0] );
		m++;
	}


	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	printf("int read_mp4 (char* filename ) ends.\r\n");
	return 0;
}

//https://qiita.com/satken2/items/d14b4113fe3fb5f5597b
//https://en.wikipedia.org/wiki/MPEG-4_Part_14
int read_mp4 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;
	char* typeofkey[3] = { "ftyp", "mdat", "moovt" };
	int m = 0;

	printf("int read_mp4 (char* filename ) starts.\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <100; i++ ) {

		printf("i: %d loop starts. p_dummy_token = |%s| ", i, p_dummy_token );
		printf("struct_fp.fp |%d| \r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		printf( "p_dummy array_count %d\r\n", array_count( p_dummy) );

		for ( j = 0; j<3; j++ ) {
			if ( m_start_with ( (char*)p_dummy, (char*)typeofkey[j] ) == 1 && canread == 1 ) {
				printf("we could find |%s| as p_dummy |%s|  p_dummy[0]=|%c|.\r\n", typeofkey[j], p_dummy, p_dummy[0] );
				m_thread_sleep();
				exit(-1);
				break;
			}
		}

		memory_allocation[m] = p_dummy[0];
		printf("p_dummy[0] = |%c| m|%d| memory_allocation %s\r\n", p_dummy[0], memory_allocation[m], memory_allocation);
		p_dummy_token = put_token( p_dummy[0] );
		m++;
	}


	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	printf("int read_mp4 (char* filename ) ends.\r\n");
	return 0;
}



int main_008  ( int argc, char** argv ) {
	int a = 0;

	printf("main: check if char_string_010 works well or not. : START\r\n");

	print_memories ();

	srand(time(NULL));   // Initialization, should only be called once.
//	int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.

	for ( int i=0; i<100; i++) {
		a = rand() % 256;
		printf("a = %d\r\n", a );
		allocation = char_string_010 ( a );
		put_memories (allocation);
		printf("allocation=|%p| |%s| array count=%d\r\n", allocation, allocation, array_count(allocation));
	}

	print_memories ();

	printf("main: check if char_string_010 works well or not. : END\r\n");
	return 0;
}

int main_007( int argc, char** argv ) {
//	int a = initialize_parse_test ();
//	print_memories();


	if ( argc < 1 ) {
		printf("argc %d\r\n", argc );
		return 0;
	}

	printf(" argc[i] filename = %s\r\n", (char*)argv[1]);
	int a = read_csv( argv[1] );
	print_memories ();
}

int main_006 (int argc, char** argv ) {
	int a = initialize_parse_test ();

//	int b = read_sourcecode(".\main_001.cpp");
//	int b = replace_main ( argc, argv) ;
	print_memories();
//	exit(-1);

	char* string = "<img src=\"\$00\">";
	char* url = "http://img-cdn.jg.jugem.jp/cf3/3928048/20210521_2120204.jpg";
	char* c_replace = m_replace( string, "\$00", url );

	printf("string|%s|\r\n", string);
	printf("url|%s|\r\n", url);
	printf("replaced|%s|\r\n", c_replace);

	print_memories();
	return 0;
}

int main_002_test (int argc, char** argv ) {
	int a = initialize_parse_test ();

//	int b = read_sourcecode(".\main_001.cpp");
//	int b = replace_main ( argc, argv) ;

	char* string = "aaabbcccc";
	char* c_replace = m_replace( string, "bb", "dddd" );

	printf("string|%s|\r\n", string);
	printf("replaced|%s|\r\n", c_replace);

	print_memories();
	return 0;
}


int main_001 (int argc, char** argv ) {
	int a = initialize_parse_test ();
//	int a = copyof_test ();
//	int a = replace_main ( argc, argv);
	print_memories();
	return 0;
}

//
int read_sourcecode (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 1 ) {
			printf("we could find line end.\r\n");
			clear_token();
			index++;
			col = 0;
			i++;
			aFree ( p_dummy_token );
			m_thread_sleep();
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "#" ) == 1 && canread == 1  ) {
			col++;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread++;
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && canread == 3 ) {
			printf("we could find double quote at the start.\r\n");
			canread = 4;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && canread == 4 ) {
			printf("we could find double quote at the end.\r\n");
			canread = 1;
			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "include" ) == 1 && canread == 2 ) {
			printf("Error: we could find enter before finding double quote end.\r\n");
			clear_token();
			i++;
			aFree ( p_dummy_token );
			m_thread_sleep();
			exit(-1);
		}

		p_dummy_token = put_token( p_dummy[0] );
	}


	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );
	return 0;
}

int initialize_parse_test () {
	printf("copyof_test () starts.\r\n");
	initialize_parse_001 ();
	printf("copyof_test () ends.\r\n");
	return 0;
}

//
int copyof_test () {
	char* p_dummy_alocation_001 = NULL;
	char aa[100];
	char* p_dummy_alocation_002 = NULL;

	printf("copyof_test () starts.\r\n");
	initialize_parse ();
	aa[0] = 'a';
	for ( int j =0; j<10; j++ ) { 
		printf("j=%d\r\n", j);
		for ( int i=0; i<10; i++ ) {
			printf("i=%d\r\n", i);
			p_dummy_alocation_001 = put_token( aa[0] );
		}
		p_dummy_alocation_002 = copyof_001(p_dummy_alocation_001);
		printf("|%p|%p| = ", p_dummy_alocation_001, p_dummy_alocation_002);
		printf("p_dummy_alocation_002=||%p|%s|", p_dummy_alocation_002, p_dummy_alocation_002);
		aFree(p_dummy_alocation_001);
		clear_token();
	}
	printf("copyof_test () ends.\r\n");
	return 0;
}

int replace_main (int argc, char** argv ) {
	printf("replace_main starts.\r\n");

//	char* a_001 = (char*)"a$00<><></>$00bbb\r\ncc$01c";
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$00", (char*)"ee" );
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$01", (char*)"ffff" );
//	printf("a_001 |%s|\r\n", a_001);

	if ( argc != 4 ) {
		printf("csv_replace {input-csv-file} {form-html-file} {output-html-file}\r\n");
	}

//	int a = read_csv(".\\001-csv-20210317-001\.txt");
//	int b = replace_csv ( ".\\001-form-20210317-001\.html", ".\\001-html-20210317-001\.txt");

	printf("input-csv: %s form-html-file: %s output-html-file: %s\r\n", argv[1], argv[2], argv[3]);
	sleep(2);

	int a = read_csv( argv[1] );
	print_memories ();
//	exit ( -1 );

//	int b = replace_csv ( argv[2], argv[3] );

//	char* string_all = read_all ( ".\\001-form-20210317-001\.html" );
//	printf("string_all:%s\r\n", string_all);

	printf("replace_main ends.\r\n");

	return 0;
}
