#include <stdio.h>

#include "vPoint.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h";

#include "vScreen.h";

vScreen::vScreen ( ) {

	//Point U = new Point();
	//Point V = new Point();

	this_calc = new vCalculation ();
}

int vScreen::OntheScreen ( vPoint lp, vPoint* result ) {

	// Screen( x, y );

	return 0;
}

int vScreen::OntheScreen ( vPoint lp, float* x, float* y ) {
	vCalculation calc;

	//printf("lp= ");
	//lp.print ();

	// Screen( x, y )
	// lp is surely on the screen.
	vPoint result = calc.subtract( lp , this->C );

	*x = calc.dot( lp, this->U ); // up
	*y = calc.dot( lp, this->V ); // right

	*x /= (double)this->width;
	*y /= (double)this->height;

	*x = *x + this->width / 2.0f;
	*y = -*y + this->height / 2.0f;

/*	result_x = calc.cross ( result, this->u ) ;
	result_y = calc.cross ( result, this->up ) ;

	// double -> float
	*x = (float) this_calc->length( result_x );
	*y = this->height - (float) this_calc->length( result_y );

	*x = *x + this->width / 2.0f;
	*y = ( -*y + this->height )  + this->height/2.0f; */

	return 0;
}

void vScreen::OntheScreen ( float* x, float* y ) {
	vPoint px;
	vPoint py;

	OntheScreen( &px, &py );
	*x = px.x;
	*y = px.y;
}

void vScreen::OntheScreen ( vPoint* x, vPoint* y) {
	 vPoint px = subtract ( X, C );
	 vPoint py = subtract ( Y, C );
}

void vScreen::LookAt ( vPoint lookat ) {
	this->lookat = lookat;
}

void vScreen::put_U ( vPoint a ) {
	U = a;
}

void vScreen::put_Up ( vPoint up ) {
	this->up = normal( up );
}

void vScreen::put_V ( vPoint b) {
	V = b;
}

void vScreen::put_C ( vPoint c) {
	C = c;
}

void vScreen::calculation () {
	calculation_uv_up();
}

void vScreen::calculation_uv_up () {

	u = normal ( U ) ;
	v = normal ( V ) ;
	this->up = cross ( u, v ) ;

}

void vScreen::calculation_up_UV () {
	vCalculation calc_this;

	printf("this->eye= ");
	this->eye.print();
	printf("lookat= ");
	this->lookat.print();

	this->C = calc_this.subtract ( this->lookat, this->eye );
	vPoint howfar = calc_this.normal(this->C);
	printf("howfar= ");
	howfar.print();

	howfar = calc_this.scale( howfar, this->HowFarFromEve );

	printf("howfar= ");
	howfar.print();

	this->C = calc_this.add( this->eye, howfar );

	this->up = normal ( this->up ) ;
	u = normal ( U ) ;
	v = normal ( V ) ;

	v = cross ( this->up, u ) ;
	up = cross ( u, v ) ;

	U = calc_this.scale( u, this->width );
	V = calc_this.scale( this->up, this->height );

	printf("u= ");
	u.print();
	printf("U= ");
	U.print();

	vPoint harfU = calc_this.scale( u, -this->width/2.0f );
	vPoint harfV = calc_this.scale( this->up, -this->height/2.0f );

	this->C = calc_this.add( this->C, harfU );
	this->C = calc_this.add( this->C, harfV );

	printf("this->C= ");
	this->C.print();
}


vPoint vScreen::normal( vPoint a) {
	vPoint result;

	result = this_calc->normal ( a ) ;
	return result;
}

vPoint vScreen::subtract( vPoint a, vPoint b) {
	vPoint result;

	result = this_calc->subtract ( a, b ) ;
	return result;
}

vPoint vScreen::cross( vPoint a, vPoint b) {
	vPoint result;

	result = this_calc->cross ( a, b ) ;
	return result;
}

//
//
//
void vScreen::setWidth( int w ) {
	this->width = w;
}

//
//
//
void vScreen::setHeight( int h ) {
	this->height = h;
}

//
//
//
void  vScreen::setEye ( vPoint leye ) {
	this->eye = leye;
}

