#ifndef _WINMAINTHREAD__006_
#define _WINMAINTHREAD__006_
//...
extern int winmainthread_005a_006 ();
extern int set_winmainthread_005a_006 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_winmainthread_005a_006 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
