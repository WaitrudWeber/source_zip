#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// https://www.ibm.com/docs/ja/i/7.1?topic=ssw_ibm_i_71/rtref/strcat.html

#include "print_mouse_move_012.h"

char* stored_buffer;
char* fnc_name;
char* buffer_function;

int set_stored_buffer (char* lsb);
int set_fnc_name (char* lf);
int set_buffer_function (char* bf);


int print_return_zero () {

	return 0;
}

int print_return_zero (char* stored_buffer, char* fnc_name, int i, char* buffer_function ) {
	printf("int print_return_zero (char* stored_buffer, char* fnc_name, int i, char* buffer_function ) starts.\r\n");

	sprintf( stored_buffer, "int %s_%03d () {\r\n%s\r\n}\r\n", fnc_name, i, buffer_function);

	printf("|%p|%s|\r\n", stored_buffer, stored_buffer );
	printf("int print_return_zero (char* stored_buffer, char* fnc_name, int i, char* buffer_function ) ends.\r\n");
	return 0;
}

int set_stored_buffer (char* lsb){
	stored_buffer = lsb;
	return 0;
}

int set_fnc_name (char* lf){
	fnc_name = lf;
	return 0;
}

int set_buffer_function(char* bf) {
	buffer_function = bf;
	return 0;
}

