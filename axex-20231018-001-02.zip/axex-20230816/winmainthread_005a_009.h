#ifndef _WINMAINTHREAD__009_
#define _WINMAINTHREAD__009_

extern DWORD ThreadId_001;
extern HANDLE ThreadHandle_001;

//CSVTEXT_001 csvtext_001;

//20230816
extern double param_percent;

extern int table_width;
extern int table_height;
extern char* param_d [8][96];
extern int param_d_index;
extern int param_d_index_max;
extern char* param_dcv[8]; //current value
extern char* param_ecv[1]; //current value

extern Logging log_001;
extern LOG_001* dlog_001;

extern RECT RefreshRect;
extern int param_int[20];
extern char value_text[20][4];

extern RECT l_rect_xy[96];
extern RECT l_rect_xy_head[12];
extern char* param_c[12];

extern RECT rect_xy[20];
extern RECT rect_xy_head[20];

extern RECT rect_log[5];
extern RECT rect_log_cursol[5];

extern char	soundwave[255];
extern char	voicewave[255];


extern char* log_a[5];
extern char log_cursol[5][4];
extern char* param_a[20];
extern char* param_b[20];
extern char log_message[255];

extern int halt_invalidate;

extern int index;
extern int end_index;

extern Settle_Grid_001 l_settle_grid;
extern Image_Layer_001 il_001;

extern int DRAW_PARAM;


extern 	int b_Processed;
extern 	HDC     hDC;
extern 	 PAINTSTRUCT ps_001;
extern 	 char x_b[4];
extern 	 char y_b[4];
extern 	 char c_b[4]; //
extern 	 char d_b[4]; // diff value
extern 	 RECT rect_x, rect_y;
extern 	 HFONT hFont, hFont2;
extern 	 int flg_paint;
extern 	double	param[16];
extern 	int i, j, l, by, posx, posy;
extern 	HBRUSH hBrush;
extern 	HRGN bgRgn;
extern 	HPEN hPen;
extern  RECT clientRect;
extern  RECT textRect;
extern unsigned char* rgbt;


//...
extern int winmainthread_005a_009 ();
extern int set_winmainthread_005a_009 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_winmainthread_005a_009 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);


#endif
