#include <stdio.h>
#include <stdlib.h>


#include "winmainthread_005a_006.h"

extern char* filename_winmainthread_005a_006_ = (char*)"winmainthread_005a_006.txt";

int winmainthread_005a_006 ();
int set_winmainthread_005a_006 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_006 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

int winmainthread_005a_006 () {
	return 1;

}


int winmainthread_005a_set_006 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_006 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

