#include <tchar.h>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>

#include "wJavaStructure.h"

#include "wEvent.h"
#include "wKickEvent.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wCanvasController.h"

#include "wControllerT.h"

// 20200306
// we must check if event-parameter sets or not.
int wControllerT::Process (){ 
	printf("wControllerT::Process () starts\r\n");
	printf("wControllerT::Process () m_btc %p : m_canvas %p\r\n", (wButtonController*)this->m_btc, (wCanvasController*)this->m_canvas);

	if ( m_btc == nullptr ) {
		printf("wControllerT::Process () return: m_btc %p\r\n", m_btc);
		return -1;
	} else if ( m_canvas == nullptr ) {
		printf("wControllerT::Process () return: m_canvas %p\r\n", m_canvas);
		return -1;
	} else {
		printf("wControllerT::Process () return: m_btc %p : m_canvas %p\r\n", m_btc, m_canvas);
	}

//	printf("WM_MESSG 003: %d *(p_evt->uMsg):%d\r\n", uMsg, *(p_evt->uMsg) );
	m_btc->Process ();
	m_canvas->Process ();
//	m_mode = p_evt->main_mode;
//	printf("WM_MESSG 004: %d *(p_evt->uMsg):%d uMsg:%d p_evt->uMsg: %d &uMsg: %d \r\n", uMsg, *(p_evt->uMsg), uMsg, p_evt->uMsg, &uMsg );
	printf("wControllerT::Process () ends\r\n");
	return 0;
}

//
void wControllerT::setKickEvent_001 ( int num, wKickEvent* kick_event) {
	printf("void wControllerT::setKickEvent_001 starts\r\n");
	m_btc->setKickEvent_001( num, kick_event);
	m_canvas->setKickEvent_001( num, kick_event);
	printf("void wControllerT::setKickEvent_001 ends\r\n");
}

void wControllerT::setButtonController ( wButtonController* btc ) {
	printf("wControllerT::setButtonController starts\r\n");
	m_btc = btc;
	printf("wControllerT::setButtonController ends\r\n");
	exit(-1);
}

void wControllerT::setCanvasController ( wCanvasController* canvas ) {
	printf("wControllerT::setCanvasController starts\r\n");
	m_canvas = canvas;
	printf("wControllerT::setCanvasController ends\r\n");
	exit(-1);
}

void wControllerT::kickEvent_001 () {
	printf("void wControllerT::kickEvent_001 starts\r\n");
	m_btc->kickEvent_001 ();
	m_canvas->kickEvent_001 ();
	printf("void wControllerT::kickEvent_001 ends\r\n");
}

