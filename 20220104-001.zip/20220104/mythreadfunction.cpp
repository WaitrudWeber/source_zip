// Special thanls to https://docs.microsoft.com/ja-jp/windows/desktop/ProcThread/creating-threads

#include <windows.h>
#include <tchar.h>
#include <strsafe.h>

#include "array_counter.h"
#include "server.h"

#define MAX_THREADS 1
#define BUF_SIZE 255

typedef struct MyData {
    int val1;
    int val2;
} MYDATA, *PMYDATA;

int thread_dispose = 0;
const char* debug_log = "debug.log";

const char* line_end = "\r\n";
static char* mythread_allocation;

int written_line = 0;

DWORD WINAPI MyThreadFunction( LPVOID lpParam ) ;
DWORD WINAPI MyThreadFunctionWriter( LPVOID lpParam ) ;


char* WriteTheOneLineFromTop( char* server_buffer_recv );
char* WriteTheOneLine( char* server_line, int number );

void RefreshServerBuffer ();
void wErrorHandler(TCHAR tchar) ;
void wErrorHandler(const char* c_char) ;

int multithread () ;
int writetext () ;

char* print_buffer( char* buffer);

// it does not use on the following:
void FileWriter();
void FileAppend();

//
//
//
//
//
DWORD WINAPI MyThreadFunction( LPVOID lpParam ) 
{
    HANDLE hStdout;
    PMYDATA pDataArray;

    TCHAR msgBuf[BUF_SIZE];
    size_t cchStringSize;
    DWORD dwChars;

    // Make sure there is a console to receive output results. 

    hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
    if( hStdout == INVALID_HANDLE_VALUE )
        return 1;

    // Cast the parameter to the correct data type.
    // The pointer is known to be valid because 
    // it was checked for NULL before the thread was created.
 
    pDataArray = (PMYDATA)lpParam;

    // Print the parameter values using thread-safe functions.

    StringCchPrintf(msgBuf, BUF_SIZE, TEXT( "Parameters = %d, %d\n" ), 
        pDataArray->val1, pDataArray->val2);

    StringCchLength(msgBuf, BUF_SIZE, &cchStringSize);
    WriteConsole( hStdout, msgBuf, (DWORD)cchStringSize, &dwChars, NULL );

	boot_console_server ();

    return 0;
}

//
//
//
//
//
void ErrorHandler(LPTSTR lpszFunction) 
{ 
    // Retrieve the system error message for the last-error code.

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
    DWORD dw = GetLastError(); 

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message.

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCTSTR) lpMsgBuf) + lstrlen((LPCTSTR) lpszFunction) + 40) * sizeof(TCHAR)); 
    StringCchPrintf((LPTSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf) / sizeof(TCHAR),
        TEXT("%s failed with error %d: %s"), 
        lpszFunction, dw, lpMsgBuf); 
    MessageBox(NULL, (LPCTSTR) lpDisplayBuf, TEXT("Error"), MB_OK); 

    // Free error-handling buffer allocations.

    LocalFree( lpMsgBuf );
    LocalFree( lpDisplayBuf );
}

//
//
//
//
//
int create_thread () {
}

//
//
//
//
//
int multithread ()
{
    PMYDATA pDataArray[MAX_THREADS];
    DWORD   dwThreadIdArray[MAX_THREADS];
    HANDLE  hThreadArray[MAX_THREADS]; 

    // Create MAX_THREADS worker threads.

    for( int i=0; i<MAX_THREADS; i++ )
    {
        // Allocate memory for thread data.

        pDataArray[i] = (PMYDATA) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
                sizeof(MYDATA));

        if( pDataArray[i] == NULL )
        {
           // If the array allocation fails, the system is out of memory
           // so there is no point in trying to print an error message.
           // Just terminate execution.
            ExitProcess(2);
        }

        // Generate unique data for each thread to work with.

        pDataArray[i]->val1 = i;
        pDataArray[i]->val2 = i+100;

        // Create the thread to begin execution on its own.

        hThreadArray[i] = CreateThread( 
            NULL,                   // default security attributes
            0,                      // use default stack size  
            MyThreadFunction,       // thread function name
            pDataArray[i],          // argument to thread function 
            0,                      // use default creation flags 
            &dwThreadIdArray[i]);   // returns the thread identifier 


        // Check the return value for success.
        // If CreateThread fails, terminate execution. 
        // This will automatically clean up threads and memory. 

        if (hThreadArray[i] == NULL) 
        {
           wErrorHandler(TEXT("CreateThread"));
           ExitProcess(3);
        }
    } // End of main thread creation loop.

	if ( thread_dispose == 1 ) {

	    // Wait until all threads have terminated.
	    WaitForMultipleObjects(MAX_THREADS, hThreadArray, TRUE, INFINITE);

		// Block2;
    	// Close all thread handles and free memory allocations.

		for(int i=0; i<MAX_THREADS; i++)
		{
			CloseHandle(hThreadArray[i]);
			if(pDataArray[i] != NULL)
			{
				HeapFree( GetProcessHeap(), 0, pDataArray[i] );
				pDataArray[i] = NULL;    // Ensure address will not be used angain.
			}
		}
    }

    return 0;
}

//
//
// tchar: ARRAY
void wErrorHandler(TCHAR tchar[]) {

//	TCHAR szAppName[] = TEXT( "TestApp" );
//	LPSTR lpString= "TestApp";
//	LPCSTR lpcString= "TestApp";

	LPSTR lpString = (LPSTR) tchar;
// x LPCSTR lpcString = (LPCSTR) tchar;

    ErrorHandler( lpString );
}

//
//
// c_char: const char*
//
void wErrorHandler( const char* c_char) {

//	TCHAR szAppName[] = TEXT( "TestApp" );
//	LPSTR lpString= "TestApp";
//	LPCSTR lpcString= "TestApp";
	LPSTR lpString = (LPSTR) c_char;
//	lpcString = (LPCSTR) c_char;

    ErrorHandler( lpString );
}

//
//
//
//
int writetext ()
{
    PMYDATA pDataArray[MAX_THREADS];
    DWORD   dwThreadIdArray[MAX_THREADS];
    HANDLE  hThreadArray[MAX_THREADS]; 

    // Create MAX_THREADS worker threads.
    for( int i=0; i<MAX_THREADS; i++ )
    {
        // Allocate memory for thread data.

        pDataArray[i] = (PMYDATA) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
                sizeof(MYDATA));

        if( pDataArray[i] == NULL )
        {
           // If the array allocation fails, the system is out of memory
           // so there is no point in trying to print an error message.
           // Just terminate execution.
            ExitProcess(2);
        }

        // Generate unique data for each thread to work with.

        pDataArray[i]->val1 = i;
        pDataArray[i]->val2 = i+100;

        // Create the thread to begin execution on its own.

        hThreadArray[i] = CreateThread( 
            NULL,                   // default security attributes
            0,                      // use default stack size  
            MyThreadFunctionWriter,       // thread function name
            pDataArray[i],          // argument to thread function 
            0,                      // use default creation flags 
            &dwThreadIdArray[i]);   // returns the thread identifier 


        // Check the return value for success.
        // If CreateThread fails, terminate execution. 
        // This will automatically clean up threads and memory. 

        if (hThreadArray[i] == NULL) 
        {
           wErrorHandler(TEXT("CreateThread"));
           ExitProcess(3);
        }
    } // End of main thread creation loop.

	if ( thread_dispose == 1 ) {

	    // Wait until all threads have terminated.
	    WaitForMultipleObjects(MAX_THREADS, hThreadArray, TRUE, INFINITE);

		// Block2;
    	// Close all thread handles and free memory allocations.

		for(int i=0; i<MAX_THREADS; i++)
		{
			CloseHandle(hThreadArray[i]);
			if(pDataArray[i] != NULL)
			{
				HeapFree( GetProcessHeap(), 0, pDataArray[i] );
				pDataArray[i] = NULL;    // Ensure address will not be used angain.
			}
		}
    }

    return 0;
}

//
// From w_line to c_line
//
char* extract_writable_line(int w_line, int c_line )
{
	char c_line_end, letter=0;
	int array_counter = 0;
	char ALetter[1];
	char SLetter[2];


	char* write_line;
	int skip = 0;
	int from = 0, to = 0;
	int r_from = 0, r_to = 0;

	printf("extract_writable_line\r\n");
	//server_buffer_recv = print_buffer( server_buffer_recv );

	array_counter = array_count ( server_buffer_recv );
	write_line = (char *) malloc( sizeof(char) * ( array_counter + 1 ) );

	for ( int i=0; i < array_counter ; i++ ) {
		SLetter[0] = letter;
		letter = server_buffer_recv [ i ];
		SLetter[1] = letter;
		ALetter[0] = letter;

		// printf("i: %2d letter: |%s|  \r\n", i, ALetter );


//		printf("skip:%d letter %s \r\n", skip, ALetter);
//		printf("from %d to %d\r\n", from , to);
//		printf("w_line %d c_line %d\r\n", w_line , c_line);

		/* if ( r_from == 0 && skip >= w_line ) {
			from = i;
			r_from = 1;
		}

		if ( skip >= c_line ) {
			printf("Found c_line \r\n");
			to = i;
			int k=0;
			for( int j=from; j<=to; j++) {
				write_line[k] = server_buffer_recv[j];
				k++;
			}
			write_line[k] = '\0';
			break;
		}

		if ( m_compare( (char *) ALetter, (char *) line_end ) == 1 ) {
			printf("Found Line End \r\n");
			skip++;
			printf("skip: %d\r\n", skip);
		} */
	}

//	int l_number = array_count(write_line);
//	printf( "l_number: %d write_line: %s\r\n" , l_number, write_line );

	return write_line;
}

//
//
//
//
//
void RefreshServerBuffer () {

	char* temp;
	char* newbuf;
	LPOVERLAPPED lpOverlapped;
	PDWORD pn;

	// o int l_number = array_count( server_buffer_recv );
	// o WriteTheOneLine(server_buffer_recv, l_number);
	// 

	//server_buffer_recv = print_buffer( server_buffer_recv );

	// From written_line to server_console_line
	// newbuf = extract_writable_line( written_line, server_console_line);
	// int l_number = array_count( newbuf );
	// printf ( "From %d To %d \r\n", written_line, server_console_line );
	// printf( "l_number: %d newbuf: %s" , l_number, newbuf );

	// x temp = WriteTheOneLine( newbuf, l_number);


	// File append -- start
/*
	HANDLE out = CreateFile( debug_log, FILE_APPEND_DATA, 0x0, nullptr,
			OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr );

	if ( out == INVALID_HANDLE_VALUE ) {
		printf( "Terminal failure: Unable to open file \"%s\" for write.\n", debug_log );
		return;
	}

	// Set the file pointer to the end-of-file:
	DWORD dwMoved = ::SetFilePointer( out, 0l, nullptr, FILE_END );
	if ( dwMoved == INVALID_SET_FILE_POINTER ) {
		printf( "Terminal failure: Unable to set file pointer to end-of-file.\n" );
		return;
	}

	// x WriteFile ( out, server_buffer_recv,  sizeof server_buffer_recv, pn, lpOverlapped );

	// int number = array_count( server_buffer_recv );
	// WriteFile ( out, server_buffer_recv, number, pn, lpOverlapped );

	WriteFile ( out, newbuf, l_number, pn, lpOverlapped );
	CloseHandle ( out );
*/
	// File append-- end

//	written_line = server_console_line;
//	free( newbuf );

	/* for ( ;server_console_line >= 1; ) {

		newbuf = WriteTheOneLineFromTop( server_buffer_recv );

//		int l_number = array_count( server_buffer_recv );
//		WriteTheOneLine(newbuf, l_number);


		temp = server_buffer_recv;
		server_buffer_recv = newbuf;
		free( temp );

		server_console_line--;
		if ( server_console_line <= 1 ) break;
	} */

}

//
//
//
//
//
char* WriteTheOneLineFromTop( char* server_buffer_recv )
{
	char c_line_end, letter=0;
	int array_counter = 0;
	char ALetter[2];
	char* write_line;

	array_counter = array_count ( server_buffer_recv );
	write_line = (char *) malloc( sizeof(char) * ( array_counter + 1 ) );


	for ( int i=0; i < array_counter ; i++ ) {
		ALetter[0] = letter;
		letter = server_buffer_recv [ i ];
		ALetter[1] = letter;

		write_line[i] = letter;

		if ( m_compare( (char * )ALetter, (char *) line_end ) == 1 ) {
			int size = array_counter - 1 - i;
			mythread_allocation = (char *) malloc( sizeof(char) * ( size + 1 ) );
			
			for ( int j=0; j<size; j++ ) {
				mythread_allocation[ j ] = server_buffer_recv[ i + 1 + j ]; // if i= 2, it starts from 3.
			}
			mythread_allocation[ size ] = '\0';
			write_line[ i + 1 ] = '\0';

			WriteTheOneLine( write_line, i );
			break;
		}

	}

	free( write_line );

	return mythread_allocation;
}

//
//
//
//
//
char* WriteTheOneLine( char* l_server_line, int number )
{
	LPOVERLAPPED lpOverlapped;
	HANDLE hFile;
	PDWORD pn;
	int l_number;

	printf("WriteTheOneLine\r\n");

	hFile = CreateFile( debug_log, FILE_APPEND_DATA, 0x0, nullptr,
			OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr );

	if ( hFile == INVALID_HANDLE_VALUE ) {
		printf( "Terminal failure: Unable to open file \"%s\" for write.\n", debug_log );
		return NULL;
	}

	// Set the file pointer to the end-of-file:
	DWORD dwMoved = ::SetFilePointer( hFile, 0l, nullptr, FILE_END );
	if ( dwMoved == INVALID_SET_FILE_POINTER ) {
		printf( "Terminal failure: Unable to set file pointer to end-of-file.\n" );
		return NULL;
	}

	// x WriteFile ( hFile, l_server_line, number, pn, lpOverlapped );
	// x printf( "number %d written one line: %s", number, l_server_line );

	l_number = array_count( l_server_line );
	printf( "l_number %d written one line: %s", l_number, l_server_line );
	WriteFile ( hFile, l_server_line, l_number, pn, lpOverlapped );

// x 	int g_number = array_count( server_buffer_recv );
// x	WriteFile ( hFile, server_buffer_recv, g_number, pn, lpOverlapped );

	CloseHandle ( hFile );

//
//	printf("pn:%s\r\n", pn);
//
//	printf( "l_number %d written one line: %s", l_number, l_server_line );
//

	return l_server_line;
}

//
//
//
//
//
DWORD WINAPI MyThreadFunctionWriter( LPVOID lpParam ) 
{ 
	FileAppend();

/*
	HANDLE out = CreateFile( debug_log, FILE_APPEND_DATA, 0x0, nullptr,
			OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr );

	if ( out == INVALID_HANDLE_VALUE ) {
		printf( "Terminal failure: Unable to open file \"%s\" for write.\n", debug_log );
		return NULL;
	}

	// Set the file pointer to the end-of-file:
	DWORD dwMoved = ::SetFilePointer( out, 0l, nullptr, FILE_END );
	if ( dwMoved == INVALID_SET_FILE_POINTER ) {
		printf( "Terminal failure: Unable to set file pointer to end-of-file.\n" );
		return NULL;
	}

	// x WriteFile ( out, server_buffer_recv,  sizeof server_buffer_recv, pn, lpOverlapped );

	int number = array_count( server_buffer_recv );
	WriteFile ( out, server_buffer_recv, number, pn, lpOverlapped );

	CloseHandle ( out );
*/





	// RefreshServerBuffer ();
	// Write in File. --- end ---








    // Make sure there is a console to receive output results. 

//    hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
//    if( hStdout == INVALID_HANDLE_VALUE )
//        return 1;

    // Cast the parameter to the correct data type.
    // The pointer is known to be valid because 
    // it was checked for NULL before the thread was created.

//    pDataArray = (PMYDATA)lpParam;
//
//	Print the parameter values using thread-safe functions.
//	StringCchPrintf(msgBuf, BUF_SIZE, TEXT( "Parameters = %d, %d\n" ), 
//		pDataArray->val1, pDataArray->val2);
//
//	StringCchLength(msgBuf, BUF_SIZE, &cchStringSize);
//	WriteConsole( hStdout, msgBuf, (DWORD)cchStringSize, &dwChars, NULL );
//	 boot_console_server ();
	
    return 0;
}

//
// Thanks to
// https://stackoverflow.com/questions/18933283/how-to-append-text-to-a-file-in-windows
// this is not used usually
//
void FileWriter() {
	int number;
	LPOVERLAPPED lpOverlapped;
	int i, j;
	int n;
	PDWORD pn;

	HANDLE out = CreateFile ( debug_log, FILE_WRITE_DATA, 0, NULL,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
	char s[] = "This is a test";

//	for ( i = 0, j = sizeof s - 1; i <= j; i++, j-- ) {
//		s[i] ^= s[j] ^ 194837U;
//		s[j] ^= s[i] ^ 3876U;
//	}
//
//	WriteFile ( out, server_buffer_recv, sizeof server_buffer_recv, pn, NULL );

	number = array_count(server_buffer_recv);
	WriteFile ( out, server_buffer_recv, number, pn, lpOverlapped );
	CloseHandle ( out );
}

//
//
// this is not used usually
//
void FileAppend () {
	//int number;
	LPOVERLAPPED lpOverlapped;
	int i, j;
	int n;
	PDWORD pn;

	HANDLE out = CreateFile( debug_log, FILE_APPEND_DATA, 0x0, nullptr,
			OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr );

	if ( out == INVALID_HANDLE_VALUE ) {
		printf( "Terminal failure: Unable to open file \"%s\" for write.\n", debug_log );
		return;
	}

	// Set the file pointer to the end-of-file:
	DWORD dwMoved = ::SetFilePointer( out, 0l, nullptr, FILE_END );
	if ( dwMoved == INVALID_SET_FILE_POINTER ) {
		printf( "Terminal failure: Unable to set file pointer to end-of-file.\n" );
		return;
	}

	// x WriteFile ( out, server_buffer_recv,  sizeof server_buffer_recv, pn, lpOverlapped );
	int number = array_count( buffer_debug_log );
	WriteFile ( out, buffer_debug_log, number, pn, lpOverlapped );

	CloseHandle ( out );
}

// 
// 
// this is not used usually
// 
char* print_buffer( char* buffer)
{
	char ALetter[1];

	for( int i=0; 1; i++ ) {
		ALetter[0] = buffer[i];

		if ( buffer[i] == '\0' ) break;

		printf("i: %2d : %4d ALetter |%s| |%2d|%2d|%2d|\r\n", i, buffer[i], ALetter, '\r', '\n', '\0');
	}

}


