#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "array_counter.h"

int array_count( char *ary );
char* concat( char *head, char *tail );
char* set_array(char *arry, int n, char c);
void print_string( char *head );
int m_compare ( char* tkn, char* m );

char* m_print_buffer( char* buffer);

//int main ( int argc, char *argv[] ) {
//
//	int ac = array_count((char *)"abcdefg");
//
//	printf("count=%d\n", ac );
//
//	return 0;
//}

static char* dummy_allocation;

char* m_print_buffer( char* buffer)
{
	char ALetter[1];

	for( int i=0; 1; i++ ) {
		ALetter[0] = buffer[i];

		if ( buffer[i] == '\0' ) break;

		printf("i: %2d : %4d ALetter |%s| |%2d|%2d|%2d|\r\n", i, buffer[i], ALetter, '\r', '\n', '\0');
	}

}

int array_count( char *ary )
{
	char c;
	if ( ary == nullptr ) return 0;

	int count = 0;
	for ( ;; ) {
		c = *ary;
		if ( c == '\0' ) {
			break;
		}
		ary++;
		count++;
	}

	return count;
}

int m_compare ( char* tkn, char* m ) {

	int count_t = array_count( m );
	int count_m = array_count( m );

	if ( count_t != count_m ) return -1;

	// match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) return -1;
	}

	return 1;
}

char* m_concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
//	char ch, ct;
	char* c_head;

	nh = array_count( head );
	nt = array_count( tail );
	// o if ( nh + nt == 6 ) exit(-1);
	//	printf("array_count: %d %d\n", nh, nt);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		}
		break;
	}

//	printf("alloc=%d\n", alloc);

	if ( alloc == 0 ) {
		alloc = 1;
		dummy_allocation = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
//		printf("allocation blocks( array_count( dummy_allocation ) ) = %d\n", array_count(dummy_allocation) );
		alloc = 0;
	}

	for( int i=0; i< nh; i++ )
		*( dummy_allocation + i ) = *(head + i);

	for( int i=0; i< nt; i++ )
		*( dummy_allocation + nh + i ) = *(tail + i);

	*( dummy_allocation + nh + nt ) = '\0';

//	print_string(dummy_allocation);
	return dummy_allocation;
}


void print_string( char *head )
{
	int nh;
	char a[1];

	nh = array_count( head );
	for( int i=0; i<nh; i++ ) {
		a[0] = *(head + i);
		printf( "|%s|%3d|\n", a, a[0] );
	}
}

// do not use realloc in under sublootin.
// better solution usually by use of macro of realloc in C.
//
// use global value for allocation.
char* concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
	char ch, ct;
	char* c_head;

	nh = array_count( head );
	nt = array_count( tail );
	// o if ( nh + nt == 6 ) exit(-1);

	printf("array_count: %d %d\n", nh, nt);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		}
		break;
	}

	printf("alloc=%d\n", alloc);

	if ( alloc == 0 ) {
		alloc = 1;
//		c_head = (char *) realloc( head , sizeof( char ) * ( nh + nt + 1) );
		c_head = (char *) realloc( head , 100 );

		dummy_allocation = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
//		dummy_allocation = (char *) malloc( sizeof(char *) * ( nh + nt + 1 ) );
//		dummy_allocation = (char *) malloc( 100 * ( nh + nt + 1 ) );

//		*( head + nh + nt) = '\0';
		// x *(head) = 0;
		// o head = tail;
		printf("allocation blocks(head)=%d\n", sizeof( head ) );
		printf("allocation blocks(*head)=%d\n", sizeof( *head ) );
//		printf("allocation blocks(array_count(head))=%d\n", array_count(head) );

		printf("allocation blocks(c_head)=%d\n", sizeof( c_head ) );
		printf("allocation blocks(tail)=%d\n", sizeof( tail ) );

		// x *(head + 3 ) = ' ';
		//set_array( head, 3, ' ');
		printf("allocation blocks(array_count(head))=%d\n", array_count(head) );


//		*( dummy_allocation + nh + nt ) = '\0';
		*( dummy_allocation + 1 ) = '\0';
		printf("allocation blocks( dummy_allocation )=%d\n", sizeof( dummy_allocation ) );
		printf("allocation blocks( array_count( dummy_allocation ) ) = %d\n", array_count(dummy_allocation) );

		alloc = 0;
	}

	

// o	head = tail;
// x	*head = *tail;
// o	ch = *head;
//	exit(-1);

	head += nh;
	for( int i=0; i<nt; i++ ) {
		// x head[ nh + i ] = tail[ i ];
		// x head[ 0 ] = tail[ i ];
		// x *(head + nt + i) = *( tail + i);
		// x *(head + nt + i) = *( tail);
		// x *(head + nt + i) = 0;
		// o head = tail;
		// x *head = *tail;
		// x *head = 0;
		// x *(head) = 0;

		ch = *head;
		ct = *tail;

		// o *(head + 3) = ct;
		// x *( head + nh + i ) = ct;
		// x *head = ct;

		head = tail;

		tail++;
		head++;
	}

//	exit(-1);

	return head;
}

char* set_array(char *arry, int n, char c) {

	static char *returnable;

	returnable = arry;
	arry++;
	*arry = c;
	////arry = c;
	//arry = returnable;

	return returnable;
}


