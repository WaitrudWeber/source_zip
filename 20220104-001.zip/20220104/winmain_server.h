#ifndef WINMAIN_SERVER_H
#define WINMAIN_SERVER_H

char *server_buffer;
extern int update_thread = 0;

extern void SetText ( HWND hWnd ) ;

#endif

