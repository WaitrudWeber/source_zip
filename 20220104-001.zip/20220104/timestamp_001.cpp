/* timestamp example */
#include <stdio.h>      /* printf */
#include <time.h>       /* time_t, time (for timestamp in second) */
#include <sys/timeb.h>  /* ftime, timeb (for timestamp in millisecond) */
#include <sys/time.h>   /* gettimeofday, timeval (for timestamp in microsecond) */

char* get_datetime_info () ;
char* takeout_line_end ( char* a );

//
//
//
//
//
char* get_datetime_info () {

	time_t rtime;
	char * chrtime;
	time_t timestamp_sec; /* timestamp in second */

	rtime = time(&timestamp_sec);  /* get current time; same as: timestamp_sec = time(NULL)  */
	chrtime = ctime( &rtime );
	// printf( "chrtime=%s" , chrtime );

	chrtime = takeout_line_end ( chrtime );

	return chrtime;
}

//
//
//
//
//
char* takeout_line_end ( char* a ) {
	int index = 0;
	int flag = 0;

	// if ( a == NULL ) return a;

	for ( ;; ) {

		if ( index > 1000 ) break;

		printf( "a: %s index %d\r\n", a , index );
		if ( a == "\0" ) {
			while ( index > 0) {
				index--;
				a--;
				printf( "a: %s index %d\r\n", a , index );

				if ( a == "\n" ) {

					flag++;
				} else if ( flag == 1 && a == "\r" ) {

					a = "\0";
					break;
				} else if ( flag == 1 ) {
					a++;
					a = "\0";
					// it does not work for TAB.
				}
			}
			break;
		}
		a++;
		index++;
	}
}

