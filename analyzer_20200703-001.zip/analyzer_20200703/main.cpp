#include <stdio.h>
#include <windows.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

int filesize( FILE *fp ) ;

int main () {
	FILE *fp;
	int i;
	char dummy[256];
	char* filename = ".\\alphabet-001.txt";
	char* filename_split = ".\\001-split-001.txt";
	char spit_line[10];
	char lines[10][10];
	char basic[2];

	fp = fopen(filename_split, "rb");
	int file_end = filesize ( fp );


	int start = 0;
	int j = 0;
	// first, we are going to find "spit_line".
	// each block should be stored as block name eve like "001-block---001.txt".
	// and we care following orders.
	//
	for ( i =0; i<file_end; i++ ) {
		printf("loop start i: %d: j: %d: \r\n", i, j );
		fread ( dummy, 1, 1, fp);

		dummy[1] = '\0';
		basic[1] = dummy[0];

		// find line end.
		if ( m_compare( (char*)dummy, (char*)"\r\n" ) == 1 ) {
			if ( i > 1 ) lines[j][i-2] = '\0';
			else lines[j][0] = '\0';
			j++;
			start = i;
		} else {
			lines[j][ i - start ] = dummy[0];
			lines[j][ i - start + 1 ] = '\0';
		}

		basic[0] = basic[1];
		printf("loop   end i: %d: %s j:%d|%s|\r\n", i, dummy, j, lines[j]);
	}

	printf("split_line: %s\r\n", spit_line);
	fclose(fp);

	for ( i =0; i<10; i++ ) {
		printf("lines[%d]|%s|\r\n", i, lines[i]);
	}


	/*fp = fopen(filename, "rb");
	file_end = filesize ( fp );
	for ( i =0; i<file_end; i++ ) {
		fread ( dummy, 1, 1, fp);
		dummy[1] = '\0';
		printf("%d: %s\r\n", i, dummy);
	}

	close(fp);*/
	return 0;
}

int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}