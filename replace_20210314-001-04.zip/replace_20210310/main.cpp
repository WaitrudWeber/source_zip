#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"

int main () {

	char* a_001 = (char*)"aaabbb\r\nccc";
	a_001 = m_replace ( a_001, (char*)"cc", (char*)"dd" );
	printf("a_001 |%s|\r\n", a_001);

//	int a = read_csv(".\\001-csv-20210210-001\.txt");
//	int b = replace_csv ( ".\\001-form-20210211-001\.txt");

	return 0;
}
