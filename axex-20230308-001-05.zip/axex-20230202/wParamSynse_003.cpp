
#include "wParamSynse_003.h"

wParamSynse_003::wParamSynse_003 () {
}
