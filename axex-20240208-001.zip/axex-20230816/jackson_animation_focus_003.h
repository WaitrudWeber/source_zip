#ifndef _JACSON_ANIMATION_FOCUS__003_
#define _JACSON_ANIMATION_FOCUS__003_

struct struct_rgbt {
	unsigned char r;
	unsigned char g;
	unsigned char b;
	unsigned char t;
} ;

struct struct_animation_focus {
	int start_x;
	int start_y;
	int width;
	int height;
};

struct struct_read_ppm {
	struct_rgbt** ppm_canvas = NULL;
	struct_animation_focus focus;

	int thread_initialize ();
	int thread_process ();
	int thread_pose ();
	int thread_outbyend ();
	int thread_close ();

};

struct struct_animation_fonts_frame {
	int** fonts_sheet = NULL;
	struct_animation_focus focus;
	int thread_initialize ();
	int thread_process ();
	int thread_pose ();
	int thread_outbyend ();
	int thread_close ();

};

struct struct_animation_focus_frame {
	int (*draw_number)();
	int (*draw_effects)();
	int (*draw_model_frame)();
	int (*draw_grid)();
	int (*initialize_parameters_all)();
	int **canvas;
	int thread_sleep_real_animation = 33;
	int thread_animation_times = 60;
	int initialized = 0;
	struct_animation_focus focus;
	struct_animation_focus fonts_focus[10];

	// basic
	int (*call_draw_fucus_canvas_buffer_only) () ;
	int (*call_draw_canvas_all) ();

	int thread_initialize ();
	int thread_process ();
	int thread_pose ();
	int thread_outbyend ();
	int thread_close ();

};

typedef struct_animation_focus_frame ANIMATION_FOCUS_FRAME;
typedef struct_animation_focus ANIMATION_FOCUS;
typedef struct_read_ppm READ_PPM;
typedef struct_animation_fonts_frame ANIMATION_FONTS;
typedef struct_rgbt RGBT;


extern int brunch_functions_all ();

extern int initialize_ppm_fonts () ;
extern int read_ppm (char* filename, READ_PPM* read_ppm) ;
extern int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) ;
extern int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) ;
extern int char_ppm_width_height ( char* print_dummy, int num, int* width, int* height ) ;
extern ANIMATION_FOCUS_FRAME* get_jackson_pointer_animation_thread ();
extern DWORD WINAPI Animation_5times_thread_canvas_focus_validate ( LPVOID hdc ) ;

extern int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y );
extern int sub_fonts_number_focus_set_param_sheet_basic () ;


// debug
extern int initialize_parameters_all () ;

extern int set_log_001_jackson_animation (Logging* llog) ;
//20240208
extern int caribration_grid () ;
extern int caribration_grid_01_03 () ;


#endif