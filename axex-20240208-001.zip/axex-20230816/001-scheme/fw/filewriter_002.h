#ifndef _FILEWRITER_002_
#define _FILEWRITER_002_
//...
extern int filewriter_002 ();
extern int set_filewriter_002 ();
extern int initialize_filewriter_002 ();
#endif
