int filewriter_005 ();

filewriter_005 () {
nreturn 1;

}


