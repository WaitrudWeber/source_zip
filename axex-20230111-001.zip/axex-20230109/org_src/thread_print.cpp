// Special thanls to https://docs.microsoft.com/ja-jp/windows/desktop/ProcThread/creating-threads

#include <windows.h>
#include <tchar.h>
#include <strsafe.h>

#include "array_counter.h"
// #include "server.h"

#define MAX_THREADS 1
#define BUF_SIZE 255

#include "thread_print.h"

typedef struct MyData {
    int val1;
    int val2;
} MYDATA, *PMYDATA;

int thread_dispose = 0;
const char* debug_log = "debug.log";

const char* line_end = "\r\n";
static char* mythread_allocation;

int written_line = 0;

DWORD WINAPI MyThreadFunction( LPVOID lpParam ) ;

char* WriteTheOneLineFromTop( char* server_buffer_recv );
char* WriteTheOneLine( char* server_line, int number );

void RefreshServerBuffer ();
void wErrorHandler(TCHAR tchar) ;
void wErrorHandler(const char* c_char) ;

//int multithread () ;
int multithread_print ();
int writetext () ;

char* print_buffer( char* buffer);

// it does not use on the following:
void FileWriter();
void FileAppend();

DWORD WINAPI MyThreadFunction( LPVOID lpParam ) 
{
    HANDLE hStdout;
    PMYDATA pDataArray;

    TCHAR msgBuf[BUF_SIZE];
    size_t cchStringSize;
    DWORD dwChars;

    // Make sure there is a console to receive output results. 
    hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
    if( hStdout == INVALID_HANDLE_VALUE )
        return 1;

	//show_garbage_collection ();
	// show_garbage_collectionA ();

    // Cast the parameter to the correct data type.
    // The pointer is known to be valid because 
    // it was checked for NULL before the thread was created.

    pDataArray = (PMYDATA)lpParam;

    // Print the parameter values using thread-safe functions.
/*
    StringCchPrintf(msgBuf, BUF_SIZE, TEXT( "Parameters = %d, %d\n" ), 
        pDataArray->val1, pDataArray->val2);

    StringCchLength(msgBuf, BUF_SIZE, &cchStringSize);
    WriteConsole( hStdout, msgBuf, (DWORD)cchStringSize, &dwChars, NULL );

	boot_console_server ();
*/
    return 0;
}

void ErrorHandler(LPTSTR lpszFunction) 
{ 
    // Retrieve the system error message for the last-error code.

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
    DWORD dw = GetLastError(); 

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message.

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCTSTR) lpMsgBuf) + lstrlen((LPCTSTR) lpszFunction) + 40) * sizeof(TCHAR)); 
    StringCchPrintf((LPTSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf) / sizeof(TCHAR),
        TEXT("%s failed with error %d: %s"), 
        lpszFunction, dw, lpMsgBuf); 
    MessageBox(NULL, (LPCTSTR) lpDisplayBuf, TEXT("Error"), MB_OK); 

    // Free error-handling buffer allocations.

    LocalFree( lpMsgBuf );
    LocalFree( lpDisplayBuf );
}

int create_thread () {
}

int multithread_print ()
{
    PMYDATA pDataArray[MAX_THREADS];
    DWORD   dwThreadIdArray[MAX_THREADS];
    HANDLE  hThreadArray[MAX_THREADS]; 

    // Create MAX_THREADS worker threads.

    for( int i=0; i<MAX_THREADS; i++ )
    {
        // Allocate memory for thread data.

        pDataArray[i] = (PMYDATA) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
                sizeof(MYDATA));

        if( pDataArray[i] == NULL )
        {
           // If the array allocation fails, the system is out of memory
           // so there is no point in trying to print an error message.
           // Just terminate execution.
            ExitProcess(2);
        }

        // Generate unique data for each thread to work with.

        pDataArray[i]->val1 = i;
        pDataArray[i]->val2 = i+100;

        // Create the thread to begin execution on its own.

        hThreadArray[i] = CreateThread( 
            NULL,                   // default security attributes
            0,                      // use default stack size  
            MyThreadFunction,       // thread function name
            pDataArray[i],          // argument to thread function 
            0,                      // use default creation flags 
            &dwThreadIdArray[i]);   // returns the thread identifier 


        // Check the return value for success.
        // If CreateThread fails, terminate execution. 
        // This will automatically clean up threads and memory. 

        if (hThreadArray[i] == NULL) 
        {
           wErrorHandler(TEXT("CreateThread"));
           ExitProcess(3);
        }
    } // End of main thread creation loop.

	if ( thread_dispose == 1 ) {

	    // Wait until all threads have terminated.
	    WaitForMultipleObjects(MAX_THREADS, hThreadArray, TRUE, INFINITE);

		// Block2;
    	// Close all thread handles and free memory allocations.

		for(int i=0; i<MAX_THREADS; i++)
		{
			CloseHandle(hThreadArray[i]);
			if(pDataArray[i] != NULL)
			{
				HeapFree( GetProcessHeap(), 0, pDataArray[i] );
				pDataArray[i] = NULL;    // Ensure address will not be used angain.
			}
		}
    }

    return 0;
}

//
//
// tchar: ARRAY
void wErrorHandler(TCHAR tchar[]) {

//	TCHAR szAppName[] = TEXT( "TestApp" );
//	LPSTR lpString= "TestApp";
//	LPCSTR lpcString= "TestApp";

	LPSTR lpString = (LPSTR) tchar;
// x LPCSTR lpcString = (LPCSTR) tchar;

    ErrorHandler( lpString );
}

//
//
// c_char: const char*
//
void wErrorHandler( const char* c_char) {

//	TCHAR szAppName[] = TEXT( "TestApp" );
//	LPSTR lpString= "TestApp";
//	LPCSTR lpcString= "TestApp";
	LPSTR lpString = (LPSTR) c_char;
//	lpcString = (LPCSTR) c_char;

    ErrorHandler( lpString );
}

//
//
//
//

/*
//
// Thanks to
// https://stackoverflow.com/questions/18933283/how-to-append-text-to-a-file-in-windows
// this is not used usually
//
void FileWriter() {
	int number;
	LPOVERLAPPED lpOverlapped;
	int i, j;
	int n;
	PDWORD pn;

	HANDLE out = CreateFile ( debug_log, FILE_WRITE_DATA, 0, NULL,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
	char s[] = "This is a test";

//	for ( i = 0, j = sizeof s - 1; i <= j; i++, j-- ) {
//		s[i] ^= s[j] ^ 194837U;
//		s[j] ^= s[i] ^ 3876U;
//	}
//
//	WriteFile ( out, server_buffer_recv, sizeof server_buffer_recv, pn, NULL );

	//number = array_count(server_buffer_recv);
	//WriteFile ( out, server_buffer_recv, number, pn, lpOverlapped );
	CloseHandle ( out );
}

//
//
// this is not used usually
//
void FileAppend () {
	//int number;
	LPOVERLAPPED lpOverlapped;
	int i, j;
	int n;
	PDWORD pn;

	HANDLE out = CreateFile( debug_log, FILE_APPEND_DATA, 0x0, nullptr,
			OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr );

	if ( out == INVALID_HANDLE_VALUE ) {
		printf( "Terminal failure: Unable to open file \"%s\" for write.\n", debug_log );
		return;
	}

	// Set the file pointer to the end-of-file:
	DWORD dwMoved = ::SetFilePointer( out, 0l, nullptr, FILE_END );
	if ( dwMoved == INVALID_SET_FILE_POINTER ) {
		printf( "Terminal failure: Unable to set file pointer to end-of-file.\n" );
		return;
	}

	// x WriteFile ( out, server_buffer_recv,  sizeof server_buffer_recv, pn, lpOverlapped );
	int number = array_count( buffer_debug_log );
	WriteFile ( out, buffer_debug_log, number, pn, lpOverlapped );

	CloseHandle ( out );
}

// 
// 
// this is not used usually
// 
char* print_buffer( char* buffer)
{
	char ALetter[1];

	for( int i=0; 1; i++ ) {
		ALetter[0] = buffer[i];

		if ( buffer[i] == '\0' ) break;

		printf("i: %2d : %4d ALetter |%s| |%2d|%2d|%2d|\r\n", i, buffer[i], ALetter, '\r', '\n', '\0');
	}

}
*/

