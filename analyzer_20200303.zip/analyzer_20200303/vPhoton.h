#ifndef _VPHOTON_H_
#define _VPHOTON_H_
class vPhoton {
	public :
		vPoint *photon1, *photon2; // Place amd Normal, which is Refrection on the face.
		char *c1, *c2;

	public:
		vPhoton ();
		void setPlace(vPoint* place);
		void setNormal(vPoint* normal);
		void print () ;

};

#endif
