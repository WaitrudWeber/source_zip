#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdlib.h>
#include <math.h>

#include "Print.h"
#include "array_counter.h"
//#include "aToken.h"
//#include "wC_structure.h"
//#include "analyzer_C.h"

//#include "wTextarea.h"
//#include "clipboard.h"
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
//#include "vBox.h"

#include "vCalculation.h"
#include "vCurveCalculation.h"

#include "vIntersection.h"
#include "vIntersection_001.h"

#include "vScreen.h"
#include "vScreenCG.h"

//#include "vLine.h"
//#include "vCircle.h"

#include "vPointStructure.h"
#include "vPointLinear.h"
//#include "vRailCurtain.h"

#include "vAxex_2D.h"
#include "creation_of_axex.h"

#include "display_threeD.h"

#include "vAxex_2D.h"
#include "vBox.h"

#include "vDisplayController.h"
#include "v3dCalculation.h"

vCalculation calc;

// void vCalculation::Print_Point_Memories () {
//
int v3dCalculation::calculation_thread () {
	printf("v3dCalculation:: calculation_threed () starts.\r\n");
/*	calc.Print_Point_Memories ();

	display_threeD_screen_initialize_OnRails () ;

	calc.Print_Point_Memories (); */
	printf("v3dCalculation:: calculation_threed () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_002 () {
/*	printf("v3dCalculation:: calculation_thread_002 () starts.\r\n");
	calc.Print_Point_Memories ();

	rails_initialization () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_002 () ends.\r\n"); */
	return 1;
}

int v3dCalculation::calculation_thread_003 () {
	printf("v3dCalculation:: calculation_thread_003 () starts.\r\n");
/*	calc.Print_Point_Memories ();

	memorizevpoint_tests () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_003 () ends.\r\n");*/
	return 1;
}

int v3dCalculation::calculation_thread_004 () {
	printf("v3dCalculation:: calculation_thread_004 () starts.\r\n");
	calc.Print_Point_Memories ();

	curve_initialization () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_004 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_005 () {
	printf("v3dCalculation:: calculation_thread_005 () starts.\r\n");
/*	calc.Print_Point_Memories ();

	subtract_loop ();

	calc.Print_Point_Memories ();*/
	printf("v3dCalculation:: calculation_thread_005 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_006 () {
	printf("v3dCalculation:: calculation_thread_006 () starts.\r\n");
/*	calc.Print_Point_Memories ();

	memorize_print ();

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_006 () ends.\r\n");*/
	return 1;
}

int v3dCalculation::calculation_thread_007 () {
	printf("v3dCalculation:: calculation_thread_007 () starts.\r\n");
/*	calc.Print_Point_Memories ();

	add_loop ();

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_007 () ends.\r\n");*/
	return 1;
}

int v3dCalculation::calculation_thread_008() {
	printf("v3dCalculation:: calculation_thread_008 () starts.\r\n");
/*	calc.Print_Point_Memories();

	// Recognision: 20200508: inside display_threeD_screen_initialize_OnRails:
	//rails_initialization(); inside display_threeD_screen_initialize_OnRails:
	int a001 = display_threeD_screen_initialize_OnRails();

	calc.Print_Point_Memories();
	printf("v3dCalculation:: calculation_thread_008 () ends.\r\n");
	*/
	return 1;
}

int v3dCalculation::calculation_thread_009() {
	printf("v3dCalculation:: calculation_thread_009 () starts.\r\n");
	/*calc.Print_Point_Memories();

	// Recognision: 20200508: inside display_threeD_screen_initialize_OnRails:
	//rails_initialization(); inside display_threeD_screen_initialize_OnRails:
	int a001 = display_threeD_screen_initialize_OnRails();
	int a002 = getCreatedLines();

	calc.Print_Point_Memories();
	printf("v3dCalculation:: calculation_thread_009 () ends.\r\n");
	*/
	return 1;
}

int v3dCalculation::calculation_thread_010() {
	printf("v3dCalculation:: calculation_thread_010 () starts.\r\n");
/*	HWND hWnd;
	HDC hDC;
	PAINTSTRUCT* ps = nullptr;
	hWnd = 0;
	hDC = 0;

	calc.Print_Point_Memories();

	// Recognision: 20200508: inside display_threeD_screen_initialize_OnRails:
	//rails_initialization(); inside display_threeD_screen_initialize_OnRails:
	int a001 = display_threeD_screen_initialize_OnRails();
	int a002 = dDisplayControls_wmpaint_display_threeD_proc( hWnd, hDC, ps, 0, 0, 0 );
	//	int a002 = dDisplayControls_wmpaint_display_threeD_proc(HWND hWnd, HDC hDC, PAINTSTRUCT * ps, UINT uMsg, WPARAM wParam, LPARAM lParam);

	calc.Print_Point_Memories();
	printf("v3dCalculation:: calculation_thread_010 () ends.\r\n");
*/	return 1;
}

int v3dCalculation::calculation_thread_011() {
	printf("v3dCalculation:: calculation_thread_011 () starts.\r\n");

	vLine* d3dline = new vLine( memorizevPoint( 0.0, 0.0, 200.0 ), memorizevPoint( 600.0, 600.0, -250.0 ) );
	vLine* d2dline = to_screen_line(d3dline);

	printf("print the 3dline:\r\n");
	d3dline->print();

	printf("print the line on the screen:\r\n");
	d2dline->print();

	printf("print Screen:\r\n");
	int a = print_screen ();

	printf("v3dCalculation:: calculation_thread_011 () ends.\r\n");
	return 1;
}

//
//
//
//
//
int v3dCalculation::calculation_thread_012() {
	printf("v3dCalculation:: calculation_thread_012 () starts.\r\n");

	// ID: 001001012
	if ( lines == nullptr ) {
		lines = (vLine**) malloc ( sizeof ( vLine* ) * 3 );
	}
	if ( lines_2D == nullptr ) {
		lines_2D = (vLine**) malloc ( sizeof ( vLine* ) * 3 );
	}

	lines[0] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
	lines[1] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
	lines[2] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );

	for ( int i = 0; i<3; i++ ) {
		printf("i:%d loop block starts.\r\n", i );
		lines_2D[i] = (vLine*) to_screen_line ( lines[i] ) ;
		printf("i:%d loop block starts.\r\n", i );
	}
	// ID: 001001012

	int a = print_screen ();

	printf("v3dCalculation:: calculation_thread_012 () ends.\r\n");
	return 1;
}

//
//
//
//
//
int v3dCalculation::calculation_thread_013() {
	printf("v3dCalculation:: calculation_thread_013 () starts.\r\n");

	// ID: 001001013
	if ( lines == nullptr ) {
		lines = (vLine**) malloc ( sizeof ( vLine* ) * 3 );
		lines_2D = (vLine**) malloc ( sizeof ( vLine* ) * 3 );
	}

	lines[0] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
	lines[1] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
	lines[2] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );

	lines_2D[0] = (vLine*) to_screen_line ( lines[0] ) ;

	int a = print_screen ();

	printf("v3dCalculation:: calculation_thread_013 () ends.\r\n");
	return 1;
}

//
//
//
//
//
int v3dCalculation::calculation_thread_014() {
	vCalculation calc;
	int i;

	printf("v3dCalculation:: calculation_thread_014 () starts.\r\n");

	vPoint* o = memorizevPoint( 0.0f, 0.0f, 0.0f) ;
	vPoint* p = memorizevPoint( 0.0f, 0.0f, 0.0f) ;
	vPoint* a = memorizevPoint ( 50.0f, 10.0f, 45.0f );
	vPoint* up = memorizevPoint ( 0.0f, 1.0f, 0.0f );
	vPoint* right = memorizevPoint ( 1.0f, 0.0f, 0.0f );

	calc.cross ( up, a, right );
	printf("right is going to print:\r\n");
	right->print();

	for ( i =0; i<5; i++ ) {
		printf("additional p calculation is going to print: i = %d\r\n", i );
		p->print();
		calc.add( o, calc.scalize ( right, (float) i ), p );
		p->print();
	}


	printf("v3dCalculation:: calculation_thread_014 () ends.\r\n");
	return 1;
}

//
int v3dCalculation::calculation_thread_015() {
	vCalculation calc;
	int i, line_index;

	printf("v3dCalculation:: calculation_thread_015 () starts.\r\n");

	// ID: 001001015
	if ( lines == nullptr ) {
		lines = (vLine**) malloc ( sizeof ( vLine* ) * MAX_LINE );
	}
	if ( lines_2D == nullptr ) {
		lines_2D = (vLine**) malloc ( sizeof ( vLine* ) * MAX_LINE );
	}

	lines[0] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
	lines[1] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
	lines[2] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );

	// ID: 001001015
	line_index = 3;
	int a = create_model_lines( lines, &line_index, MAX_LINE );
	printf("line_index = %d\ returned from create_model_lines.\r\n", line_index);
	int b = convert_model_lines( lines, lines_2D, 0, line_index );
	printf("line_index = %d\ returned from create_model_lines.\r\n", line_index);

	for( i = 0; i<line_index; i++ ) {
		if (lines[i] == nullptr ) {
			printf("lines[ %d ] is not allocated.\r\n", i);
			exit(-1);
		}
		printf("lines[ %d ] ", i);
		lines[i]->print();
		printf("lines_2D[ %d ] ", i);
		lines_2D[i]->print();
	}

	printf("v3dCalculation:: calculation_thread_015 () ends.\r\n");
	return 1;
}

//
int v3dCalculation::calculation_thread_016() {
	printf("v3dCalculation:: calculation_thread_016 () starts.\r\n");
	int a = create_vaxex_test () ;
	printf("v3dCalculation:: calculation_thread_016 () ends.\r\n");
	return 1;
}

//
int v3dCalculation::calculation_thread_017() {
	int a;
	static vPoint center( 50.0f, 50.0f, 50.0f );

	err_msg_001("v3dCalculation:: calculation_thread_017 () starts.\r\n");

	a = initialize_vAxex_2D_003();

	AXEX_2D_002[0].center->print();
	AXEX_2D_002[1].center->print();
	AXEX_2D_002[2].center->print();

//	a = Approach_vAxex_2D ( &center ) ;

//	AXEX_2D_002[0].center->print();
//	AXEX_2D_002[1].center->print();
//	AXEX_2D_002[2].center->print();

	err_msg_001("v3dCalculation:: calculation_thread_017 () ends.\r\n");
	return 1;
}

//
int v3dCalculation::calculation_thread_018() {
	int a;
	static vPoint center( 50.0f, 50.0f, 50.0f );

	printf("v3dCalculation:: calculation_thread_018 () starts.\r\n");

	a = convert_AXEX_2D();

	printf("v3dCalculation:: calculation_thread_018 () ends.\r\n");
	return 1;
}

//
int v3dCalculation::calculation_thread_019() {
	int a;
	float x, y;
	static vPoint p1( 50.0f, 50.0f, -50.0f );

	printf("v3dCalculation:: calculation_thread_019 () starts.\r\n");

	a = display_threeD_screen_initialize ();
	a = get_cooordinate_on_screen ( p1, &x, &y );

	printf(" x, y = %f, %f a is other side %d\r\n", x, y, a );

	printf("v3dCalculation:: calculation_thread_019 () ends.\r\n");
	return 1;
}

//
int v3dCalculation::calculation_thread_020() {
	int a;
	float x, y;
	static vPoint p1( 0.0f, 0.0f, -100.0f );

	printf("v3dCalculation:: calculation_thread_020 () starts.\r\n");

	a = display_threeD_screen_initialize ();
	a = get_cooordinate_on_screen ( p1, &x, &y );

	printf(" x, y = %f, %f a is other side %d\r\n", x, y, a );

	printf("v3dCalculation:: calculation_thread_020 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_021() {
	int a;
	float x, y;
	static vPoint p1( 0.0f, 0.0f, -100.0f );

	printf("v3dCalculation:: calculation_thread_021 () starts.\r\n");

	a = display_threeD_screen_initialize_004 ();
	a = get_cooordinate_on_screen ( p1, &x, &y );

	printf(" x, y = %f, %f a is other side %d\r\n", x, y, a );

	printf("v3dCalculation:: calculation_thread_021 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_022() {
	int a;
	float x, y;
	static vPoint p1( 0.0f, 0.0f, -100.0f );

	printf("v3dCalculation:: calculation_thread_022 () starts.\r\n");

	a = display_threeD_screen_initialize_005 ();
	a = get_cooordinate_on_screen ( p1, &x, &y );

	printf(" x, y = %f, %f a is other side %d\r\n", x, y, a );

	printf("v3dCalculation:: calculation_thread_022 () ends.\r\n");
	return 1;
}


int v3dCalculation::calculation_thread_023() {
	vPoint* eye = nullptr;

	printf("v3dCalculation:: calculation_thread_023 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_004.put_U ( *U );
	screen_004.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_004.put_Up ( *up );

	screen_004.setWidth ( 640 );
	screen_004.setHeight ( 480 );
	screen_004.setEye ( *eye );
	screen_004.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_004.Set_HowFarFrmEye ( 320.0f );

	printf("screen_004.HowFarFromEye=%f\r\n", screen_004.HowFarFromEye);

	screen_004.calculation_up_UV();

	printf("v3dCalculation:: calculation_thread_023 () ends.\r\n");
}

int v3dCalculation::calculation_thread_024() {
	vPoint* eye = nullptr;

	printf("v3dCalculation:: calculation_thread_024 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_005.put_U ( *U );
	screen_005.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_005.put_Up ( *up );

	screen_005.setWidth ( 640 );
	screen_005.setHeight ( 480 );
	screen_005.setEye ( *eye );
	screen_005.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_005.Set_HowFarFromEye ( 320.0f );
	screen_005.printParams();

	printf("screen_005.HowFarFromEye=%f\r\n", screen_005.HowFarFromEye);

	screen_005.calculation_up_UV();

	printf("v3dCalculation:: calculation_thread_024 () ends.\r\n");
}

int v3dCalculation::calculation_thread_025() {
	vPoint* eye = nullptr;

	printf("v3dCalculation:: calculation_thread_025 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_005.put_U ( *U );
	screen_005.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_005.put_Up ( *up );

	screen_005.setWidth ( 640 );
	screen_005.setHeight ( 480 );
	screen_005.setEye ( *eye );
	screen_005.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_005.Set_HowFarFromEye ( 320.0f );
	screen_005.printParams();

	printf("screen_005.HowFarFromEye=%f\r\n", screen_005.HowFarFromEye);

	screen_005.calculation_up_UV();

	screen_005.printParams();
	screen_005.calculation_up_UV();

	printf("v3dCalculation:: calculation_thread_025 () ends.\r\n");
}


int v3dCalculation::calculation_thread_026() {
	vPoint* eye = nullptr;

	printf("v3dCalculation:: calculation_thread_025 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_005.put_U ( *U );
	screen_005.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_005.put_Up ( *up );

	screen_005.setWidth ( 640 );
	screen_005.setHeight ( 480 );
	screen_005.setEye ( *eye );
	screen_005.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_005.Set_HowFarFromEye ( 320.0f );
	screen_005.printParams();

	printf("screen_005.HowFarFromEye=%f\r\n", screen_005.HowFarFromEye);

	screen_005.calculation_up_UV_001();

	printf("v3dCalculation:: calculation_thread_026 () ends.\r\n");
}


int v3dCalculation::calculation_thread_027() {
	vBox* box2 = nullptr;
	vBox box( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);

	printf("v3dCalculation:: calculation_thread_027 () starts.\r\n");
	box2 = new vBox( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);
	box.Print();
	printf("v3dCalculation:: calculation_thread_027 () ends.\r\n");
}

int v3dCalculation::calculation_thread_028() {
	float x, y;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint* eye = nullptr;
	vBox box( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);

	printf("v3dCalculation:: calculation_thread_028 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_005.put_U ( *U );
	screen_005.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_005.put_Up ( *up );

	screen_005.setWidth ( 640 );
	screen_005.setHeight ( 480 );
	screen_005.setEye ( *eye );
	screen_005.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_005.Set_HowFarFromEye ( 320.0f );
	screen_005.printParams();

	printf("screen_005.HowFarFromEye=%f\r\n", screen_005.HowFarFromEye);

	screen_005.calculation_up_UV();


	int a = screen_005.get_cooordinate_on_screen ( p1, &x, &y );


	printf("v3dCalculation:: calculation_thread_028 () ends.\r\n");
}

int v3dCalculation::calculation_thread_029() {
	float x, y;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint* eye = nullptr;
	vBox box( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);

	printf("v3dCalculation:: calculation_thread_029 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_005.put_U ( *U );
	screen_005.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_005.put_Up ( *up );

	screen_005.setWidth ( 640 );
	screen_005.setHeight ( 480 );
	screen_005.setEye ( *eye );
	screen_005.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_005.Set_HowFarFromEye ( 320.0f );
	screen_005.printParams();

	printf("screen_005.HowFarFromEye=%f\r\n", screen_005.HowFarFromEye);

	screen_005.calculation_up_UV();


	int a = screen_005.get_cooordinate_on_screen ( p1, &x, &y );


	printf("v3dCalculation:: calculation_thread_029 () ends.\r\n");
}

int v3dCalculation::calculation_thread_030() {
	float x, y;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint* eye = nullptr;
	vBox box( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);

	printf("v3dCalculation:: calculation_thread_030 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_005.put_U ( *U );
	screen_005.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_005.put_Up ( *up );

	screen_005.setWidth ( 640 );
	screen_005.setHeight ( 480 );
	screen_005.setEye ( *eye );
	screen_005.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_005.Set_HowFarFromEye ( 320.0f );
	screen_005.printParams();

	printf("screen_005.HowFarFromEye=%f\r\n", screen_005.HowFarFromEye);

	screen_005.calculation_up_UV();

	for ( int i=8; i<8; i++ ) {
		int a = screen_005.get_cooordinate_on_screen ( *(box.p[i]), &x, &y );
	}

	box.Print();

	printf("v3dCalculation:: calculation_thread_030 () ends.\r\n");
}


int v3dCalculation::calculation_thread_031() {
	printf("v3dCalculation:: calculation_thread_031 () starts.\r\n");

	display_001.DisplaytheBox();

	printf("v3dCalculation:: calculation_thread_031 () ends.\r\n");
}

int v3dCalculation::calculation_thread_032() {
	float x, y;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint* eye = nullptr;
	vBox box( 0.0f, 0.0f, 0.0f, 100.0f, 100.0f, 100.0f);

	printf("v3dCalculation:: calculation_thread_030 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_005.put_U ( *U );
	screen_005.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_005.put_Up ( *up );

	screen_005.setWidth ( 640 );
	screen_005.setHeight ( 480 );
	screen_005.setEye ( *eye );
	screen_005.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_005.Set_HowFarFromEye ( 320.0f );
	screen_005.printParams();

	printf("screen_005.HowFarFromEye=%f\r\n", screen_005.HowFarFromEye);

	screen_005.calculation_up_UV();

	for ( int i=0; i<8; i++ ) {
		printf("code block set loop %d starts.\r\n", i);
		int a = screen_005.get_cooordinate_on_screen ( *(box.p[i]), &x, &y );
		printf("code block set loop %d ends.\r\n", i);
	}

	box.Print();

	printf("v3dCalculation:: calculation_thread_030 () ends.\r\n");
}

//
int v3dCalculation::calculation_thread_033() {
	int i, j, k;
	char* tab = "		";
	char* tab_002 = "			";
	float x, y, z;
	double theta, r;
	double m_pi = 3.1415926535;
	double xx, yy;
	vCalculation Calc;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint u1( 45.0f, 50.0f, 50.0f );
	vPoint v1( 50.0f, 45.0f, 0.0f );
	vPoint n1( 50.0f, 50.0f, 50.0f );
	vPoint vx( 50.0f, 50.0f, 50.0f );
	vPoint vy( 50.0f, 50.0f, 50.0f );
	vPoint pa( 50.0f, 50.0f, 50.0f );
	FILE *fp;

	printf("v3dCalculation:: calculation_thread_033 () starts.\r\n");

	fp = (FILE*)fopen ("001-switch-case-20220622-001.txt", "w");

	//
	Calc.normal(&u1);
	Calc.normal(&v1);
	Calc.cross(&u1, &v1, &n1);
	Calc.normal(&n1);
	Calc.cross(&n1, &u1, &v1);

	u1.print();
	v1.print();
	n1.print();

	j = 0;
	r = 1000.0;

	for ( i = 'A'; i<='Z'; i++ ) {
		theta =  ( m_pi * j )/ 16.0;
		xx = r * sin(theta);
		yy = r * cos(theta);
		printf("%scase %d:\r\n", tab, i );
		printf("%sbreak;\r\n", tab_002 );
		printf("xx %f yy %f\r\n", xx, yy);
		Calc.scale (&u1, xx, &vx );
		Calc.scale (&v1, yy, &vy );

		Calc.add (&vx, &vy, &pa );
		pa.print();
		// display_004.SetEye ( 1000.0f, -1000.0f, -1000.0f) ;
		//exit(-1);

		fprintf(fp, "%scase %d: //%c\r\n", tab, i, i );
		fprintf(fp, "%sdisplay_004.SetEye ( %f, %f, %f );\r\n", tab_002, pa.x, pa.y, pa.z);
		fprintf(fp, "%sp_evt->main_mode = 29;\r\n", tab_002 );
		fprintf(fp, "%sbreak;\r\n", tab_002 );
		j++;
	}

	fclose (fp);
	printf("v3dCalculation:: calculation_thread_033 () ends.\r\n");
}

//
int v3dCalculation::calculation_thread_034() {
	int i, j, k;
	char* tab = "			";
	char* tab_002 = "				";
	float x, y, z;
	double theta, r;
	double m_pi = 3.1415926535;
	double xx, yy;
	vCalculation Calc;
	vPoint p1( 50.0f, 50.0f, 50.0f );
	vPoint u1( 45.0f, 50.0f, 50.0f );
	vPoint v1( 50.0f, 45.0f, 0.0f );
	vPoint n1( 50.0f, 50.0f, 50.0f );
	vPoint vx( 50.0f, 50.0f, 50.0f );
	vPoint vy( 50.0f, 50.0f, 50.0f );
	vPoint pa( 50.0f, 50.0f, 50.0f );
	FILE *fp;

	printf("v3dCalculation:: calculation_thread_033 () starts.\r\n");

	fp = (FILE*)fopen ("001-switch-case-20220622-002.txt", "w");

	//
	Calc.normal(&u1);
	Calc.normal(&v1);
	Calc.cross(&u1, &v1, &n1);
	Calc.normal(&n1);
	Calc.cross(&n1, &u1, &v1);

	u1.print();
	v1.print();
	n1.print();

	j = 0;
	r = 1000.0;

//	for ( i = 'A'; i<'z'; i++ ) {
	for ( i = 'A'; i<='Z'; i++ ) {
		theta =  ( m_pi * j )/ 16.0;
		xx = r * sin(theta);
		yy = r * cos(theta);
		printf("%scase %d:\r\n", tab, i );
		printf("%sbreak;\r\n", tab_002 );
		printf("xx %f yy %f\r\n", xx, yy);
		Calc.scale (&u1, xx, &vx );
		Calc.scale (&v1, yy, &vy );

		Calc.add (&vx, &vy, &pa );
		pa.print();
		// display_004.SetEye ( 1000.0f, -1000.0f, -1000.0f) ;
		//exit(-1);

		fprintf(fp, "%scase %d: //%c\r\n", tab, i, i );
		fprintf(fp, "%sdisplay_004.SetEye ( %f, %f, %f );\r\n", tab_002, pa.x, pa.y, pa.z);
//		fprintf(fp, "%sp_evt->main_mode = 29;\r\n", tab_002 );
		fprintf(fp, "%sbreak;\r\n", tab_002 );
		j++;
	}

	fclose (fp);
	printf("v3dCalculation:: calculation_thread_033 () ends.\r\n");
}

