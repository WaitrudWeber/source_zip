#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_001.h"

extern char* filename_read_csv_000a_001_ = (char*)"read_csv_000a_001.txt";

int read_csv_000a_001 ();
int set_read_csv_000a_001 (char** argv, int argc);
int initialize_read_csv_000a_001 (char** argv, int argc);

int read_csv_000a_001 () {
	return 1;

}


int read_csv_000a_set_001 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_001 (char** argv, int argc) {
 	return 1;
 
}

