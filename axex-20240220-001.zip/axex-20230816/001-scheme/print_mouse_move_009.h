#ifndef _PRINT_MOUSE_009_
#define _PRINT_MOUSE_009_
int print_mouse_move_009 () ;
#endif
