
extern int drawButton( HDC hdc, char *button_name, RECT *rect );




