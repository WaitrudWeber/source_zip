#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "Print.h"

int initialize_print_param_001 () ;
int set_no_print_socket_msg_001 () ;

//
int initialize_print_param_001 () {

	int a = set_no_print_socket_msg_001 ();
	return 0;
}

int set_no_print_socket_msg_001 () {
	printf("set_no_print_socket_msg starts.\r\n");

	print_socket_msg = 0;
	printf ("set print_socket_msg = %d\r\n", print_socket_msg);
	printf ("High_Level_Error_MSG = %d\r\n", High_Level_Error_MSG);
	printf ("Low_Level_Error_MSG = %d\r\n", Low_Level_Error_MSG);

	printf("set_no_print_socket_msg ends.\r\n");
	return 0;
}



