#include "wKickEvent.h"

void wKickEvent::setId (int id ) {
	this->id_p = id;
}


void wKickEvent::Execute () {

}


//
//
//
//
//
void wKickEvent::Prefectured () {
}

//
//
//
//
//
void wKickEvent::PreProcessor () {
}

void wKickEvent::Processor () {
}


