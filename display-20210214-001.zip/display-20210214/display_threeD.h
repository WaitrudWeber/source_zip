#ifndef _DISPLAY_THREED_INITIALIZE_
#define _DISPLAY_THREED_INITIALIZE_

extern int display_threeD_initialize () ;
extern int display_threeD_screen_initialize () ;
extern int getchar_display_threeD_proc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern int get_cooordinate_on_screen ( vPoint lp, float* lx, float* ly );
extern int wmpaint_display_threeD_proc_org ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern int wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam );
extern int wmpaint_display_patches ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
extern int curve_initialization () ;
extern int eDisplayControls_wmpaint_display_threeD_proc( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;

#endif
