#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include <stdlib.h>
#include <time.h>


#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"
#include "replace_main.h"

typedef struct html_struct {
	int a;
	int b;
	char* tagname =NULL;
	char* between =NULL;
	char* inside =NULL;
	html_struct* next =NULL;
	html_struct* prev =NULL;
} HTMLTAG;

int replace_main (int argc, char** argv ) ;
int copyof_test () ;
int initialize_parse_test () ;
int read_sourcecode (char* filename ) ;

int main_002_test (int argc, char** argv ) ;
int main_006 (int argc, char** argv );
int main_007 (int argc, char** argv );
int main_008 (int argc, char** argv );
int main_009 (int argc, char** argv );
int main_010 (int argc, char** argv );
int main_011 (int argc, char** argv );
int main_012 (int argc, char** argv );
int main_013 (int argc, char** argv );
int main_014 (int argc, char** argv );

int read_html (char* filename ) ;
int read_html_001 (char* filename ) ;
int read_source_cpp (char* filename ) ;
int read_source_cpp_001 (char* filename ) ;
int read_source_cpp_002 (char* filename ) ;
int read_source_cpp_003 (char* filename ) ;
int read_source_cpp_004 (char* filename ) ;

char* allocation = NULL;

char* html_tag[255];

int print_function_001 ( int i ) ;
int print_function_002 ( int i ) ;
int print_function_cpp ( int i ) ;

// 20200407
int fileallsize ( char* filename ) ;
int read_html_tag(char* filename ) ;
int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) ;

// 20220408
int analyze_html_inside( char* inside, HTMLTAG* html ) ;

// 20220410
int analyze_html_between ( char* between, HTMLTAG* html, STRUCT_FILE* structure_fp ) ;


int main ( int argc, char** argv ) {
	int a = read_html_tag(".\\001-20220407-002.txt");
	return 0;
}

int main_015 ( int argc, char** argv ) {
	int a = fileallsize(".\\001-20220407-001.txt");
	return 0;
}

int read_html_tag(char* filename ) {
	STRUCT_FILE structure_fp;
	int file_end;
	FILE* fp;
	char* p_dummy;
	int i;
	int result;
	char key_buffer[255];
	HTMLTAG* html=NULL;

	printf("int read_html_tag(char* filename ) starts.\r\n");

	fp = fopen(filename, "rb");
	printf("1 fp|%d|\r\n", fp);
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	printf("file_size:%d\r\n", file_end);
	printf("2 fp|%d|\r\n", fp);

	for ( i =0; i<file_end; i++ ) {
		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';
		if ( m_start_with ( (char*)p_dummy, "<" ) == 1 ) {
			printf("We found the |<| index %d fp|%d|.\r\n", i, fp );
			result = get_inside( key_buffer, 255, ">", &structure_fp );
			printf("key_buffer |%s|\r\n", key_buffer );

			html = (HTMLTAG*) malloc ( sizeof(HTMLTAG) );
			if ( html == NULL ) {
				printf("it cannot allocate the memory for the html(HTMLTAG).\r\n");
				exit(-1);
			}
			html->inside = (char*)copyof( (char*) key_buffer);
			analyze_html_inside( html->inside, html );

			printf("Next is going to be the between <%s> and </%s>\r\n", html->tagname, html->tagname);
			analyze_html_between( html->between, html, &structure_fp );
			printf("tag |%s| between |%s|\r\n", html->tagname, html->between );
		}
	}

	printf("int read_html_tag(char* filename ) ends.\r\n");
	return 0;
}

int analyze_html_between ( char* between, HTMLTAG* html, STRUCT_FILE* structure_fp ) {
	int i;
	char* p_dummy;
	printf("int analyze_html_between ( char* between, HTMLTAG* html ) starts.\r\n");

	for ( i =structure_fp->index; i<structure_fp->file_end_index; i++ ) {
		printf("i %d\r\n" , i);
		structure_fp->index++;
		p_dummy = get_string( *structure_fp , 5);
		p_dummy[5] = '\0';

		if ( m_start_with ( (char*)p_dummy, "<" ) == 1 ) {
			printf("tag name |%s| between |%s| p_dummy |%s|\r\n", html->tagname, between, p_dummy );
			exit(-1);
		}
	}

	printf("int analyze_html_between ( char* between, HTMLTAG* html ) ends.\r\n");
	exit(-1);
	return 0;
}

int analyze_html_inside( char* inside, HTMLTAG* html ) {
	char key_buffer[255];
	int break_index = 0;
	printf("int analyze_html_inside( char* inside, HTMLTAG* html ) starts.\r\n");
	int ac = array_count ( inside );
	printf("ac(array count) %d\r\n", ac);
	for ( int i=0; i<ac; i++ ) {
		if (inside[i] == ' ' ) {
			key_buffer[i] = '\0';
			break_index = i; // copy
			break;
		}
		key_buffer[i] = inside[i];
		key_buffer[i+1] = '\0';
	}
	html->tagname = (char*) copyof(key_buffer);
	printf("tag=|%s|\r\n", html->tagname );

	if ( break_index!= 0 && break_index < ac ) {
		printf("inside string has still remained.\r\n");
		exit(-1);
	}

	printf("int analyze_html_inside( char* inside, HTMLTAG* html ) ends.\r\n");
	return 0;
}


int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) {
	int index;
	char* p_dummy;
	printf("int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) starts.\r\n");

	for(int i=0; i<max_buffer; i++ ) {
		sfp->index++;
		p_dummy = get_string( *sfp , 5);
		if ( m_start_with ( (char*)p_dummy, ">" ) == 1 ) {
			key_buffer[i] ='\0';
			printf("We found the |>| index %d fp|%d|.\r\n", sfp->index, sfp->fp );
			printf("key_buffer |%s|\r\n", key_buffer );
			printf("int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) returns 1.\r\n");
			return 1;
		}
		key_buffer[i] = p_dummy[0];
	}

	printf("int get_inside( char* key_buffer, int max_buffer, char* end_string, STRUCT_FILE* sfp ) ends.\r\n");
	return 0;
}

int fileallsize ( char* filename ) {
	STRUCT_FILE structure_fp;
	int file_end;
	FILE* fp;

	fp = fopen(filename, "rb");
	err_msg_001("1 fp|%d|\r\n", fp);
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	err_msg_001("file_size:%d\r\n", file_end);
	err_msg_001("2 fp|%d|\r\n", fp);

	return 0;
}

int main_014 ( int argc, char** argv ) {

	char* bstring = (char*)"aaabbcccc";
	char* bfrom = (char*)"bb";
	char* bto = (char*)"dddd";

	char* cfrom = (char*)"ccc";
	char* cto = (char*)"eeee";

	for ( int i = 0; i<1000; i++ ) {
		char* a = m_replace((char*)bstring, (char*)bfrom, (char*)bto);
		printf("%d: string:%s bstring:%s from:%s to:%s\r\n", i, a, bstring, bfrom, bto);
		a = (char*)m_replace((char*)bstring, (char*)cfrom, (char*)cto);
		printf("%d: string:%s bstring:%s from:%s to:%s\r\n", i, a, bstring, cfrom, cto);
	}
	return 0;
}

int main_013 ( int argc, char** argv ) {

	// main_001.cpp
//	int a = read_source_cpp_001 ("main_001.cpp") ; 
//	int a = read_source_cpp_002 ("main_001.cpp") ; 
	int a = read_source_cpp_004 ("main_001.cpp") ; 

	return 0;
}

int main_012 ( int argc, char** argv ) {

	// 001-form-20210317-001.html
	int a = read_source_cpp ("001-form-20210317-001.html") ; 

	return 0;
}

int read_source_cpp_004 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_cpp[5] = { "int", "void", "char*", "float", "double" };
	int mode = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;
		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';

		printf("dummy %s\r\n", p_dummy);

		switch ( mode ) {
		case 0:
			break;
		default:
			printf("any other if the mode = 0.\r\n");
			exit(-1);
		}
		for ( int j = 0; j<5; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_cpp[j] ) == 1 ) {
				printf("We found the primitive of the return values %s in cpp source code %s at %s index: %d line %d raw %d\r\n", match_cpp[j], filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}

int read_source_cpp_003 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_cpp[5] = { "int", "void", "char*", "float", "double" };
	int mode = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1; i++ ) {
		raw++;
		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';

		printf("dummy %s\r\n", p_dummy);

		switch ( mode ) {
		case 0:
			break;
		default:
			printf("any other if the mode = 0.\r\n");
			exit(-1);
		}
		for ( int j = 0; j<5; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_cpp[j] ) == 1 ) {
				printf("We found the primitive of the return values %s in cpp source code %s at %s index: %d line %d raw %d\r\n", match_cpp[j], filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}


int read_source_cpp_002 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_cpp[5] = { "int", "void", "char*", "float", "double" };
	int mode = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;
		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';

		switch ( mode ) {
		case 0:
			break;
		default:
			printf("any other if the mode = 0.\r\n");
			exit(-1);
		}
		for ( int j = 0; j<5; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_cpp[j] ) == 1 ) {
				printf("We found the primitive of the return values %s in cpp source code %s at %s index: %d line %d raw %d\r\n", match_cpp[j], filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}

int read_source_cpp_001 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_cpp[5] = { "int", "void", "char*", "float", "double" };
	int mode = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;
		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 5);
		p_dummy[5] = '\0';

		switch ( mode ) {
		case 0:
			break;
		default:
			printf("any other if the mode = 0.\r\n");
			exit(-1);
		}
		for ( int j = 0; j<5; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_cpp[j] ) == 1 ) {
				printf("We found the primitive of the return values %s in cpp source code %s at %s index: %d line %d raw %d\r\n", match_cpp[j], filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}


int read_source_cpp (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_html[2] = { "<", ">" };

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		for ( int j = 0; j<2; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_html[j] ) == 1 ) {
				printf("We found the primitive of the all tags in html at %s index: %d line %d raw %d\r\n", filename, i, line, raw );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

//		if ( canread == 2 )
//			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	return 0;
}

int read_html_001 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 1;
	int raw = 0;
	char* match_html[2] = { "<", ">" };

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {
		raw++;

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		for ( int j = 0; j<2; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_html[j] ) == 1 ) {
				printf("We found the primitive of the all tags in html at %s index: %d line %d raw %d\r\n", filename, i, line, raw );
				m_thread_sleep ();
			}


		}
/*
		if ( m_start_with ( (char*)p_dummy, match_html[0] ) == 1) {
			printf("We found the primitive '<' in html at %s index: %d line %d\r\n", filename, i, line );
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread = 2;
		} else if ( m_start_with ( (char*)p_dummy, match_html[1] ) == 1 ) {
			printf("We found the primitive '>' in html at %s index: %d line %d\r\n", filename, i, line );
			printf("tag_line: %s\r\n", p_dummy_token );
			html_tag[k] = copyof (p_dummy_token);
			k++;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread = 1;
		}
*/
		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
			raw=0;
		}

		if ( canread == 2 )
			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	for ( i=0; i<k; i++ ) {
		printf("html_tag[%d]=%s\r\n", i, html_tag[i] );
	}

	return 0;
}


int main_011 ( int argc, char** argv ) {
	for( int i = 0; i<=10; i++) {
		print_function_002 ( i );
		print_function_cpp ( i );
	}
	return 0;
}

int print_function_cpp ( int i ) {
	char* ifndef_buffer = "WORK";
	char print_ifndef_start_buffer[255]; 
	char print_ifndef_end_buffer[255]; 
	FILE *fp;
	char filename[255];
	int ii, iip;

	printf("int print_function_cpp ( int i ) starts.\r\n");

	iip = ( i + 1 ) % 10;
	ii = i;

	sprintf( filename, "%s_%03d.cpp", ifndef_buffer, ii );
	fp = fopen( filename, "wb");

	// ii include
	sprintf(print_ifndef_start_buffer, "#include \"%s_%03d.h\"\r\n", ifndef_buffer, ii );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);

	// iip include
	sprintf(print_ifndef_start_buffer, "#include \"%s_%03d.h\"\r\n", ifndef_buffer, iip );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);


	sprintf(print_ifndef_start_buffer, "void %s_%03d::Set%s_%03d( %s%03d *l%s%03d ){ \r\n\r\n", ifndef_buffer, ii, ifndef_buffer, iip, ifndef_buffer, iip,  ifndef_buffer, iip  );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "}\r\n" );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);

	fclose(fp);

	printf("int print_function_cpp ( int i ) ends.\r\n");
	return 0;
}


//
//
//
//
int print_function_002 ( int i ) {
	char* ifndef_buffer = "WORK";
	char print_ifndef_start_buffer[255]; 
	char print_ifndef_end_buffer[255]; 
	FILE *fp;
	char filename[255];
	int ii, iip;

	printf("int print_function_002 ( int i ) starts.\r\n");

	iip = ( i + 1 ) % 10;
	ii = i;

	sprintf( filename, "%s_%03d.h", ifndef_buffer, ii );
	fp = fopen( filename, "wb");

	sprintf(print_ifndef_start_buffer, "#ifndef _%s_%03d_H_\r\n#define _%s_%03d_H_\r\n", ifndef_buffer, ii, ifndef_buffer, ii );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp, "%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "class %s_%03d { \r\n	public:\r\n		%s_%03d *i%s_%03d=nullptr;\r\n\r\n", ifndef_buffer, ii, ifndef_buffer, iip, ifndef_buffer, ii   );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp, "%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "	public:\r\n		Set%s_%03d( %s%03d *l%s%03d ); \r\n\r\n", ifndef_buffer, iip, ifndef_buffer, iip,  ifndef_buffer, iip  );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp,"%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "};\r\n", ifndef_buffer, ii  );
	printf("%s", print_ifndef_start_buffer);
	fprintf( fp, "%s", print_ifndef_start_buffer);

	sprintf(print_ifndef_end_buffer, "#endif\r\n" );
	printf("%s", print_ifndef_end_buffer);
	fprintf( fp, "%s", print_ifndef_end_buffer);

	fclose(fp);

	printf("int print_function_002 ( int i ) ends.\r\n");
	return 0;
}

//
//
//
//
//
int print_function_001 ( int i ) {
	char* ifndef_buffer = "WORK";
	char print_ifndef_start_buffer[255]; 
	char print_ifndef_end_buffer[255]; 

	printf("int print_function_001 ( int i ) starts.\r\n");

	sprintf(print_ifndef_start_buffer, "#ifndef _%s_%03d_H_\r\n#define _%s_%03d_H_\r\n", ifndef_buffer, i, ifndef_buffer, i );
	printf("print_ifndef_start_buffer: %s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "class %s_%03d{ \r\n	public:\r\n	%s_%03d *i%s_%03d=nullptr;\r\n", ifndef_buffer, i, ifndef_buffer, i + 1, ifndef_buffer, i   );
	printf("print_ifndef_start_buffer: %s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "public:\r\n	Set%s_%03d( %s%03d *l%s%03d ); \r\n", ifndef_buffer, i + 1, ifndef_buffer, i + 1,  ifndef_buffer, i + 1  );
	printf("print_ifndef_start_buffer: %s", print_ifndef_start_buffer);

	sprintf(print_ifndef_start_buffer, "}\r\n", ifndef_buffer, i  );
	printf("print_ifndef_start_buffer: %s", print_ifndef_start_buffer);

	sprintf(print_ifndef_end_buffer, "#endif\r\n" );
	printf("print_ifndef_end_buffer: %s", print_ifndef_end_buffer);

	printf("int print_function_001 ( int i ) ends.\r\n");
	return 0;
}




int main_010 ( int argc, char** argv ) {
//	int a = initialize_parse_test ();
//	print_memories();


	if ( argc < 1 ) {
		printf("argc %d\r\n", argc );
		return 0;
	}

	printf(" argc[i] filename = %s\r\n", (char*)argv[1]);
	int a = read_html ( argv[1] );


	print_memories ();
}

int main_009 ( int argc, char** argv ) {
//	int a = initialize_parse_test ();
//	print_memories();


	if ( argc < 1 ) {
		printf("argc %d\r\n", argc );
		return 0;
	}

	printf(" argc[i] filename = %s\r\n", (char*)argv[1]);
	int a = read_csv_010 ( argv[1] );

	int b = print_csv ();

// 1: char** csv
// 2: char* form_file
// int b = replace_csv ( argv[2], argv[3] );


	print_memories ();
}


int read_html (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j, k;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	char w_filename[255];
	int line = 0;
	char* match_html[2] = { "<", ">" };

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		for ( int j = 0; j<2; j++ ) {
			if ( m_start_with ( (char*)p_dummy, match_html[j] ) == 1 ) {
				printf("We found the primitive of the all tags in html at %s index: %d line %d\r\n", filename, i, line );
				m_thread_sleep ();
			}


		}

		if ( m_start_with ( (char*)p_dummy, match_html[0] ) == 1) {
			printf("We found the primitive '<' in html at %s index: %d line %d\r\n", filename, i, line );
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread = 2;
		} else if ( m_start_with ( (char*)p_dummy, match_html[1] ) == 1 ) {
			printf("We found the primitive '>' in html at %s index: %d line %d\r\n", filename, i, line );
			printf("tag_line: %s\r\n", p_dummy_token );
			html_tag[k] = copyof (p_dummy_token);
			k++;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread = 1;
		}

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 ) {
			line++;
		}

		if ( canread == 2 )
			p_dummy_token = put_token( p_dummy[0] );
	}

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );

	for ( i=0; i<k; i++ ) {
		printf("html_tag[%d]=%s\r\n", i, html_tag[i] );
	}

	return 0;
}



int main_008  ( int argc, char** argv ) {
	int a = 0;

	printf("main: check if char_string_010 works well or not. : START\r\n");

	print_memories ();

	srand(time(NULL));   // Initialization, should only be called once.
//	int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.

	for ( int i=0; i<100; i++) {
		a = rand() % 256;
		printf("a = %d\r\n", a );
		allocation = char_string_010 ( a );
		put_memories (allocation);
		printf("allocation=|%p| |%s| array count=%d\r\n", allocation, allocation, array_count(allocation));
	}

	print_memories ();

	printf("main: check if char_string_010 works well or not. : END\r\n");
	return 0;
}

int main_007( int argc, char** argv ) {
//	int a = initialize_parse_test ();
//	print_memories();


	if ( argc < 1 ) {
		printf("argc %d\r\n", argc );
		return 0;
	}

	printf(" argc[i] filename = %s\r\n", (char*)argv[1]);
	int a = read_csv( argv[1] );
	print_memories ();
}

int main_006 (int argc, char** argv ) {
	int a = initialize_parse_test ();

//	int b = read_sourcecode(".\main_001.cpp");
//	int b = replace_main ( argc, argv) ;
	print_memories();
//	exit(-1);

	char* string = "<img src=\"\$00\">";
	char* url = "http://img-cdn.jg.jugem.jp/cf3/3928048/20210521_2120204.jpg";
	char* c_replace = m_replace( string, "\$00", url );

	printf("string|%s|\r\n", string);
	printf("url|%s|\r\n", url);
	printf("replaced|%s|\r\n", c_replace);

	print_memories();
	return 0;
}

int main_002_test (int argc, char** argv ) {
	int a = initialize_parse_test ();

//	int b = read_sourcecode(".\main_001.cpp");
//	int b = replace_main ( argc, argv) ;

	char* string = "aaabbcccc";
	char* c_replace = m_replace( string, "bb", "dddd" );

	printf("string|%s|\r\n", string);
	printf("replaced|%s|\r\n", c_replace);

	print_memories();
	return 0;
}


int main_001 (int argc, char** argv ) {
	int a = initialize_parse_test ();
//	int a = copyof_test ();
//	int a = replace_main ( argc, argv);
	print_memories();
	return 0;
}


int initialize_parse_test () {
	printf("copyof_test () starts.\r\n");
	initialize_parse_001 ();
	printf("copyof_test () ends.\r\n");
	return 0;
}

//
int copyof_test () {
	char* p_dummy_alocation_001 = NULL;
	char aa[100];
	char* p_dummy_alocation_002 = NULL;

	printf("copyof_test () starts.\r\n");
	initialize_parse ();
	aa[0] = 'a';
	for ( int j =0; j<10; j++ ) { 
		printf("j=%d\r\n", j);
		for ( int i=0; i<10; i++ ) {
			printf("i=%d\r\n", i);
			p_dummy_alocation_001 = put_token( aa[0] );
		}
		p_dummy_alocation_002 = copyof_001(p_dummy_alocation_001);
		printf("|%p|%p| = ", p_dummy_alocation_001, p_dummy_alocation_002);
		printf("p_dummy_alocation_002=||%p|%s|", p_dummy_alocation_002, p_dummy_alocation_002);
		aFree(p_dummy_alocation_001);
		clear_token();
	}
	printf("copyof_test () ends.\r\n");
	return 0;
}

int replace_main (int argc, char** argv ) {
	printf("replace_main starts.\r\n");

//	char* a_001 = (char*)"a$00<><></>$00bbb\r\ncc$01c";
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$00", (char*)"ee" );
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$01", (char*)"ffff" );
//	printf("a_001 |%s|\r\n", a_001);

	if ( argc != 4 ) {
		printf("csv_replace {input-csv-file} {form-html-file} {output-html-file}\r\n");
	}

//	int a = read_csv(".\\001-csv-20210317-001\.txt");
//	int b = replace_csv ( ".\\001-form-20210317-001\.html", ".\\001-html-20210317-001\.txt");

	printf("input-csv: %s form-html-file: %s output-html-file: %s\r\n", argv[1], argv[2], argv[3]);
	sleep(2);

	int a = read_csv( argv[1] );
	print_memories ();
//	exit ( -1 );

//	int b = replace_csv ( argv[2], argv[3] );

//	char* string_all = read_all ( ".\\001-form-20210317-001\.html" );
//	printf("string_all:%s\r\n", string_all);

	printf("replace_main ends.\r\n");

	return 0;
}
