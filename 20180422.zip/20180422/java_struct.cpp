#include <stdio.h>
#include <stdlib.h>

#include "java_struct.h"

int put_package( char* name_package );
int initialize_java_keywords () ;
JAVA_KEYWORDS java_keywords;
int check_structor ();

// memory check
int check_structor () {

	for( int i = 0; i<100; i++ ) {
		put_package ( (char *) "aaa.aaa.aaa" );
	}

	for( int i = 0; i<100; i++ ) {
		printf ( "java_keywords.package[ %d ] = %s\n", i, java_keywords.package[i] );
	}

	return 1;
}

int put_package ( char* name_package ) {
	java_keywords.package_num++;

	if ( java_keywords.package_num >= java_keywords.package_num_size ) {
		java_keywords.package_num_size = java_keywords.package_num_size * 2;
		printf("%d / %d\n", java_keywords.package_num, java_keywords.package_num_size);
		java_keywords.package = (char **) realloc( java_keywords.package, sizeof ( char** ) * java_keywords.package_num_size );
	}

	java_keywords.package[ java_keywords.package_num - 1 ] = (char*)name_package;

	return 1;
}

int initialize_java_keywords () {

	java_keywords.package_num = 0;
	java_keywords.package_num_size = 8;
	java_keywords.package = (char**) malloc ( sizeof(char**) * java_keywords.package_num_size );

	java_keywords.import_num = 0;
	java_keywords.import_num_size = 8;
	java_keywords.import = (char**) malloc ( sizeof(char**) * java_keywords.import_num_size );

	return 1;
}

