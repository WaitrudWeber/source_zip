#ifndef _V_DISPLAY_cONTROLLER_002_H_
#define _V_DISPLAY_cONTROLLER_002_H_

#include "vBox.h"
#include "wCanvasController.h"

// 1. copy vDisplayController_001.h vDisplayController_001.cpp.
// 2. renumber by use of replace vDisplayController_001 to vDisplayController_002 in them above.
// 3. add Makefile vDisplayController_001.cpp.

class vDisplayController_002 {

	private:
		vPoint bones_001[10];
		int bones_max = 10;
		int bones_max_index = 0;
		wCanvasController* canvas = nullptr;
		vCalculation Calc;
		vScreenCG screen_006;
		vLine** axex_line_3d_002 = nullptr;
		int axex_line_max = 3;

//		vBox box( 0.0f, 0.0f, 100.0f, 100.0f );

	public:

	private:
		int Set_Canvas_Bones () ;
//		int SetCanvasBones_002 () :
//		int SetCanvasBones () :


	public:
		int SetCanvas ( wCanvasController *l_canvas ) ;
		int PrintBones () ;
		int PrintBones_001 () ;
		int DisplayBones_002 () ;
		int DisplayBonesGear () ;
		int MoveSelectedPoint_002 () ;
		int MoveSelectedPoint_003 () ;
		int MoveSelectedPoint_004 (int number) ; // 1:up 2:right: depth
		int SetBaseAxex () ;
		int DisplayBaseAxex () ;
		int DisplayBaseAxexFixed () ;
		int SetEye (float x, float y, float z) ;
		int write_ppm_002 (char* filename, float*** img, int width, int height, int flag) ;

} ;

#endif

