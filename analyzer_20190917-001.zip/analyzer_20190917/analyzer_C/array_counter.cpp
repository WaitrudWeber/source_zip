#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include <windows.h>

#include "Print.h"
#include "array_counter.h"

//char* char_line_end_001 = (char*) "\r\n";

int array_count( char *ary );
char* concat( char *head, char *tail );
char* set_array(char *arry, int n, char c);
void print_string( char *head );
int m_compare ( char* tkn, char* m );

char* m_print_buffer( char* buffer);

char* front_trim( char* c_str ) ;
char* back_trim( char* c_str ) ;
char* m_trim( char* c_str ) ;
int m_start_with ( char *head, char *tail ) ;
int m_contains ( char* c_str, char* c_ref ) ;

//int main ( int argc, char *argv[] ) {
//
//	int ac = array_count((char *)"abcdefg");
//
//	printf("count=%d\n", ac );
//
//	return 0;
//}

extern char* dummy_allocation;
extern char** dummy_ary;
extern int dummy_ary_index;
extern char* char_line_end;

void print_memories ();
char** put_memories ( char* str );

void slide_to_back ( char *msg, int i, int count ) ;
void place_char ( char *p_char, char c ) ;


//
//
//
// '\r': 13
// '\n': 10
void place_char ( char *p_char, char c ) {
	char* result_001;
	// result_001 = err_msg_001 ( "start of place_char ");
	// o result_001 = err_msg_001 ( "%d %d %d", p_char, 0, c );
	// x result_001 = err_msg_001 ( "%d %c %d", p_char, *p_char, c );
	//   4249052 3 13
	// x result_001 = err_msg_001 ( "%d %c %d", p_char, *p_char, c );
	// print_memories( p_char ) ;
	// result_001 = err_msg_001 ( "%d %d %d %d", p_char, '\n', '\r', c );
	*p_char = (char) c;
	// o *result_001 = (char) c;
	//   *p_char = *result_001;
	// result_001 = err_msg_001 ( "end of place_char ");
}

//
//
//
//
//
void slide_to_back ( char *msg, int start_i, int count ) {
	char *result_001;
	char c;
	char back_c;

	// result_001 = err_msg_001 ( "slide_to_back: start ");
	for( int i = start_i; i<count - 1; i++ ) {
		// result_001 = err_msg_001 ( "slide_to_back: loop satrt i=%d count %d ", i , count);
		// 003
		if ( i == start_i ) {
			c = *( msg + i );
		} else {
			c = back_c;
		}

		back_c = *( msg + i + 1 );
		// result_001 = err_msg_001 ( "|%3d|", c );	// 001
		place_char ( msg + i + 1, c );				// 002
		// exit(-1);
		// place_char ( msg + i + 1, c ); // slide 1 to back and ensured to place.
		// result_001 = err_msg_001 ( "slide_to_back: loop end   i=%d count %d c=%3d c=%c", i , count, c, c );
	}

	//004
	place_char ( msg + count, '\0' );
	// result_001 = err_msg_001 ( "slide_to_back: end ");
}

//
//
//
//
//
char* m_replace ( char* char_string,
 char* from_string, char* to_string ) {
	char c1, c2;
	int count = array_count( char_string );
	int a_f = array_count( from_string );
	int a_t = array_count( to_string );
	int a_c = 0;
	char* char_string_2 = 
	  (char *) malloc ( sizeof (char)*( count + a_t - 1 ) );

	int cnt_replace = 0;
	for ( int i = 0; i<count; i++ ) {
		c1 = *( char_string + i ) ;
		a_c = 0;
		for ( int j=0; j<a_f && j <count; j++ ) {
			c2 = *( from_string + j ) ;
			if ( c1 != c2 ) break;
			a_c++;
		}

		if ( a_c == a_f && cnt_replace == 0) {
			// match
			int to = i + a_t;
			for( int k=0; k<a_t; k++ ) {
				*( char_string_2 + i + k + cnt_replace*(a_t- a_f ) ) = 
				  *( to_string + k );
			}
			i += a_f - 1 ;
			cnt_replace++;
		} else {
			*( char_string_2 + i + cnt_replace*(a_t- a_f ) ) = c1;
		}
	}
	*( char_string_2 + count + cnt_replace*( a_t - a_f ) ) = '\0';
	put_memories ( char_string_2 );

	return char_string_2;
}

//
//
//
//
//
char** put_memories ( char* str ) {

	if ( dummy_ary_index == 0 ) {
		dummy_ary = (char **) malloc( sizeof(char*) );
		dummy_ary_index = 1;
		dummy_ary[ 0 ] = str;
	} else {
		dummy_ary_index++;
		dummy_ary = (char **) realloc( dummy_ary, sizeof(char*)*dummy_ary_index );
		dummy_ary[ dummy_ary_index - 1 ] = str;
	}

	return dummy_ary;
}

//
//
//
//
//
void print_memories () {

	for ( int i=0; i<dummy_ary_index; i++) {
		printf("dummy_ary[%d]=%s\r\n", i, dummy_ary[i] );
	}
}

//
//
//
//
//
//
char* m_print_buffer( char* buffer)
{
	char ALetter[1];

	for( int i=0; 1; i++ ) {
		ALetter[0] = buffer[i];

		if ( buffer[i] == '\0' ) break;

		printf("i: %2d : %4d ALetter |%s| |%2d|%2d|%2d|\r\n", i, buffer[i], ALetter, '\r', '\n', '\0');
	}
}

//
//
//
//
//
//
int array_count( char *ary )
{
	char c;
	if ( ary == nullptr ) return 0;

	int count = 0;
	for ( ;; ) {
		c = *ary;
		if ( c == '\0' ) {
			break;
		}
		ary++;
		count++;
	}

	return count;
}

//
//
//
//
//
//
int m_compare ( char* tkn, char* m ) {

	int count_t = array_count( tkn );
	int count_m = array_count( m );

//	printf(" %d | %d | %s | %s \r\n", count_t, count_m, tkn, m );

	if ( count_t != count_m ) return -1;

	// match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) return -1;
	}

	return 1;
}

//
//
//
//
//
int m_start_with ( char *head, char *tail ) {
	int nh, nt, min;
	char c1, c2;

	nh = array_count( head );
	nt = array_count( tail );
	min = nh;
	if ( min > nt ) {
		min = nt;
	}

	for ( int i=0; i<min; i++ ) {
		c1 = *(head + i ) ;
		c2 = *(tail + i ) ;
		if ( c1 != c2 ) {
			return 0;
		}
	}

	return 1;
}

//
//
//
//
//
//
char* m_concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
//	char ch, ct;
	char* c_head;

	nh = array_count( head );
	nt = array_count( tail );
	// o if ( nh + nt == 6 ) exit(-1);
	//printf("array_count: %d %d | %s %s \r\n", nh, nt, head, tail);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		} else {
			break;
		}
	}

	//printf("alloc=%d\n", alloc);
	if ( alloc == 0 ) {
		alloc = 1;
		for ( int i=0; i<100; i++) {
			dummy_allocation = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
			if ( dummy_allocation != 0 ) break;

			sleep(1);
			char* d_a = (char *) malloc( 1 );
			free(d_a);
		}
		//dummy_allocation[ nh + nt ] = '\0';
		//printf("allocation blocks( array_count( dummy_allocation ) ) = %d| %d\n", array_count(dummy_allocation), dummy_allocation);
		alloc = 0;
	}

	for( int i=0; i< nh; i++ ) {
		// printf("i %d\r\n", i);
		*( dummy_allocation + i ) = *(head + i);
	}

	for( int i=0; i< nt; i++ ) {
		// printf("i %d\r\n", i);
		*( dummy_allocation + nh + i ) = *(tail + i);
	}

	*( dummy_allocation + nh + nt ) = '\0';

//	put_memories(dummy_allocation);
//	print_string(dummy_allocation);

	return dummy_allocation;
}

//
//
//
//
//
//
void print_string( char *head )
{
	int nh;
	char a[] = { '\0', '\0' };

	nh = array_count( head );
	for( int i=0; i<nh; i++ ) {
		a[0] = *(head + i);
		printf( "|%s|%3d|\n", (char*)a, a[0] );
	}
}

//
// do not use realloc in under sublootin.
// better solution usually by use of macro of realloc in C.
//
// use global value for allocation.
char* concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
	char ch, ct;
	char* c_head;

	nh = array_count( head );
	nt = array_count( tail );
	// o if ( nh + nt == 6 ) exit(-1);
	printf("array_count: %d %d\n", nh, nt);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		}
		break;
	}
	printf("alloc=%d\n", alloc);

	if ( alloc == 0 ) {
		alloc = 1;
//		c_head = (char *) realloc( head , sizeof( char ) * ( nh + nt + 1) );
		c_head = (char *) realloc( head , 100 );

		dummy_allocation = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
//		dummy_allocation = (char *) malloc( sizeof(char *) * ( nh + nt + 1 ) );
//		dummy_allocation = (char *) malloc( 100 * ( nh + nt + 1 ) );

//		*( head + nh + nt) = '\0';
		// x *(head) = 0;
		// o head = tail;
		printf("allocation blocks(head)=%d\n", sizeof( head ) );
		printf("allocation blocks(*head)=%d\n", sizeof( *head ) );
//		printf("allocation blocks(array_count(head))=%d\n", array_count(head) );

		printf("allocation blocks(c_head)=%d\n", sizeof( c_head ) );
		printf("allocation blocks(tail)=%d\n", sizeof( tail ) );

		// x *(head + 3 ) = ' ';
		//set_array( head, 3, ' ');
		printf("allocation blocks(array_count(head))=%d\n", array_count(head) );


//		*( dummy_allocation + nh + nt ) = '\0';
		*( dummy_allocation + 1 ) = '\0';
		printf("allocation blocks( dummy_allocation )=%d\n", sizeof( dummy_allocation ) );
		printf("allocation blocks( array_count( dummy_allocation ) ) = %d\n", array_count(dummy_allocation) );

		alloc = 0;
	}

// o	head = tail;
// x	*head = *tail;
// o	ch = *head;
//	exit(-1);

	head += nh;
	for( int i=0; i<nt; i++ ) {
		// x head[ nh + i ] = tail[ i ];
		// x head[ 0 ] = tail[ i ];
		// x *(head + nt + i) = *( tail + i);
		// x *(head + nt + i) = *( tail);
		// x *(head + nt + i) = 0;
		// o head = tail;
		// x *head = *tail;
		// x *head = 0;
		// x *(head) = 0;

		ch = *head;
		ct = *tail;

		// o *(head + 3) = ct;
		// x *( head + nh + i ) = ct;
		// x *head = ct;

		head = tail;

		tail++;
		head++;
	}

	return head;
}

//
//
//
//
//
//
char* set_array(char *arry, int n, char c) {

	static char *returnable;

	returnable = arry;
	arry++;
	*arry = c;
	////arry = c;
	//arry = returnable;

	return returnable;
}

// alloc's
//
//
char* char_string ( int num_memories ) {
	char* mem = (char*)malloc( sizeof(char) * num_memories );
	put_memories( mem );

	return mem;
}

// alloc's
//
//
char* copyof ( char* str ) {
	int ac = array_count(str);
	char* mem = (char*)malloc( sizeof(char) * (ac + 1) );
	put_memories( mem );

	for ( int i=0; i<ac; i++) {
		mem[i] = str[i];
	}

	mem[ac] = '\0';

	return mem;
}

//
//
//
//
//
char* m_trim( char* c_str ) {

	char* result = "\0";
	char* return_result = "\0";
	result = front_trim ( c_str );
	// return_result = back_trim ( result );

	return result;

	//free( result );
	//return return_result;
}


//
//
//
//
//
char* back_trim( char* c_str ) {

	int skip = 0;
	int f_continue = 0;
	char* result = "\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	for ( int i=length -1; i >= 0; i-- ) {
		c = c_str[i];
		switch ( c ) {
		case ' ':
			if ( skip == 0 ) break; // means continue until it finds another letter except space.
			if ( skip == 1 ) return result;
			break;
		default:
			skip = 1;
			dummy[0] = c;
			result = m_concat ( (char *)dummy, (char *)result );
			break;
		}
	}

	return result;
}

//
//
//
//
//
char* front_trim( char* c_str ) {

	int skip = 0;
	int f_continue = 0;
	char* result = "\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	for ( int i=0; i< length; i++) {
		c = c_str[i];
		switch ( c ) {
		case ' ':
			if ( skip == 0 ) break; // means continue until it finds another letter except space.
			if ( skip == 1 ) {
				//printf( "result |%s|", result );
				//exit( -1 );
				return result;
			}
			break;
		default:
			skip = 1;
			dummy[0] = c;
			result = m_concat ( (char *)result, (char *)dummy );
			break;
		}
	}

	return result;
}

//
//
//
//
//
int m_contains ( char* c_str, char* c_ref ) {

	int unmatch = 0;
	int ref_length = array_count( c_ref );
	int length = array_count( c_str );
	for ( int i=length -1; i >= 0; i-- ) {
		for ( int j=ref_length -1; j >= 0; j-- ) {
			// sprintf("m_contains:|%d|%d|\r\n", c_str[i] , c_ref[j] );
			if ( c_str[i] != c_ref[ j ] ) {
				unmatch = 1;
			}
		}
		if ( unmatch == 0 ) return 1;
		else unmatch = 0;
	}

	return 0;
}

