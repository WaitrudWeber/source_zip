#ifndef _VINTERSECTION_
#define _VINTERSECTION_

class vIntersection {

	public:
		vIntersection ( );
		vPoint Intersect( vTriangle tri, vPoint eye, vPoint ray );

	private:

};

#endif

