#include <stdarg.h>  // ADD: 20191227
#include <stdio.h>   // ADD: 20191227
#include <windows.h> // ADD: 20191227

#include "array_counter.h"	// ADD: 20191227
#include "sender.h"			// ADD: 20191227
#include "Print.h"			// ADD: 20191227

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"

vIntersection::vIntersection() {
}

vPoint vIntersection::Intersect ( vTriangle tri, vPoint eye, vPoint ray ) {

	vCalculation *cal = nullptr;

	cal = new vCalculation ();

	log_msg_003("eye= ");
	eye.print();
	log_msg_003("ray= ");
	ray.print();

	vPoint n = tri.getNormal ();
	double d = -n.x*tri.p1.x - n.y*tri.p1.y - n.z * tri.p1.z;
	double depth = ( -d - n.x*eye.x - n.y*eye.y - n.z*eye.z ) / ( n.x*ray.x + n.y*ray.y + n.z*ray.z );

	vPoint scale_ray = cal->scale( ray, depth);
	vPoint intersection = cal->add( eye, scale_ray);

	log_msg_003("depth=%f\r\n", depth);

	delete( cal );

	return intersection;
}

// 20190202
// ray( x2, y2, z2 )
// eye( x3, y3, z3 )
// intersection( xi, yi, zi )
// eye + depth * ray = intersection( xi, yi, zi )
// ( x3, y3, z3 ) +  depth*(x2, y2, z2 ) =( xi, yi, zi )
// depth = ( a*x4 -a*x3 + b*y4 - b*y3 + c*z4 -c*z3 ) / (a*x2 + b*y2 + c*z2) 
// P1(x4, y4, z4)
// d = -a*x4 -b*y4 -c*z4

