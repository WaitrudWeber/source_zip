#ifndef _WTEXT_AREA_CONTROLLER_H_
#define _WTEXT_AREA_CONTROLLER_H_

// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.


class wTextareaController {
	public:
		int CursolNumber;

	private:
		int number_textarea;
		int mode;
		wTextarea **AryTextarea;

	public:
		wTextareaController();
		void addTextarea ( wTextarea* t );
		void drawTextareas ( HDC hdc );
		void selectTextarea ( char* btn_nm );
		void selectTextarea ( );

		//void setButton( int xx, int yy, int h, int w);
		//int wdrawButton( HDC hdc, char *button_name, RECT rect );
		//int aaa();
		//int drawButton( HDC hdc );
		//void setMode ( int m );

};

#endif


