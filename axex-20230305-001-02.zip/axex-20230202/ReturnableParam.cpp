#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "ReturnableParam.h"

void ReturnableParam::SetPointNum (int pn ) {
	this->point_num = pn;
}
