
class wC_structure {

	public:
		int x, y, width, height;
		char* function_name;
		char** function_block;
		char* function_block_start, function_block_end; // filename:line:raw;


	public:
		wC_structure ();

	private:
		void analyze_block();

};

