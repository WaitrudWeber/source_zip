#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "aToken.h"
#include "wC_structure.h"
#include "analyzer_C.h"

#include "wTextarea.h"
#include "clipboard.h"
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
//#include "vLine.h"
#include "vCircle.h"

#include "vPointStructure.h"
#include "vPointLinear.h"
#include "display_threeD.h"

#include "v3dCalculation.h"

vCalculation calc;

// void vCalculation::Print_Point_Memories () {
//
int v3dCalculation::calculation_thread () {
	printf("v3dCalculation:: calculation_threed () starts.\r\n");
	calc.Print_Point_Memories ();

	display_threeD_screen_initialize_OnRails () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_threed () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_002 () {
	printf("v3dCalculation:: calculation_thread_002 () starts.\r\n");
	calc.Print_Point_Memories ();

	rails_initialization () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_002 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_003 () {
	printf("v3dCalculation:: calculation_thread_003 () starts.\r\n");
	calc.Print_Point_Memories ();

	memorizevpoint_tests () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_003 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_004 () {
	printf("v3dCalculation:: calculation_thread_004 () starts.\r\n");
	calc.Print_Point_Memories ();

	curve_initialization () ;

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_004 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_005 () {
	printf("v3dCalculation:: calculation_thread_005 () starts.\r\n");
	calc.Print_Point_Memories ();

	subtract_loop ();

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_005 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_006 () {
	printf("v3dCalculation:: calculation_thread_006 () starts.\r\n");
	calc.Print_Point_Memories ();

	memorize_print ();

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_006 () ends.\r\n");
	return 1;
}

int v3dCalculation::calculation_thread_007 () {
	printf("v3dCalculation:: calculation_thread_007 () starts.\r\n");
	calc.Print_Point_Memories ();

	add_loop ();

	calc.Print_Point_Memories ();
	printf("v3dCalculation:: calculation_thread_007 () ends.\r\n");
	return 1;
}
