#include <stdio.h>
#include <windows.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

int filesize( FILE *fp ) ;

char lines[10][10];
char dummy[256];

int analyze_main () ;
int retrieve (char* filename) ;
int found_enter (char* filename) ;


int main () {
	char* filename = ".\\001-specification-003.txt";

	int result = found_enter (filename);

	return 0;
}

//
//
//
//
//
int found_enter (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;

	fp = fopen(filename, "rb");

	for ( i =0; i<file_end; i++ ) {
		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];
		for '( j=0; j<255; j++ ) {
			b_dummy[ j + 1 ] = dummy[ j ];
		}

		if ( m_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
			printf("We found Eenter %s\r\n", b_dummy);
			exit( -1 );
		}
	
	}

	return 0;
}

int analyze_main () {
	FILE *fp;
	int i;
	char dummy[256];
	char* filename = ".\\alphabet-001.txt";
	char* filename_split = ".\\001-split-001.txt";
//	char spit_line[10];
	char basic[3];

	basic[2] = '\0';

	fp = fopen(filename_split, "rb");
	int file_end = filesize ( fp );

	int start = 0;
	int j = 0;
	// first, we are going to find "spit_line".
	// each block should be stored as block name eve like "001-block---001.txt".
	// and we care following orders.
	//
	for ( i =0; i<file_end; i++ ) {
		printf("loop start i: %d: j: %d: \r\n", i, j );
		fread ( dummy, 1, 1, fp);

		dummy[1] = '\0';
		basic[1] = dummy[0];

		// find line end and space.
		if ( m_compare( (char*)basic, (char*)"\r\n" ) == 1 ) {
			lines[j][i- start - 1 ] = '\0'; //---\r\n if i= 4
			j++;
			start = i + 1;
			//printf("i %d j %d temporary end.\r\n");
			//exit(-1);
		} else {
			lines[j][ i - start ] = dummy[0];
			lines[j][ i - start + 1 ] = '\0';
		}

		printf("loop   end i: %d: |%s| j:%d|%s| basic|%s| start:%d\r\n", i, dummy, j, lines[j], basic, start);
		basic[0] = basic[1];
	}

//	printf("split_line: %s\r\n", spit_line);
	fclose(fp);

	for ( i =0; i<10; i++ ) {
		printf("lines[%d]|%s|\r\n", i, lines[i]);
	}


	/*fp = fopen(filename, "rb");
	file_end = filesize ( fp );
	for ( i =0; i<file_end; i++ ) {
		fread ( dummy, 1, 1, fp);
		dummy[1] = '\0';
		printf("%d: %s\r\n", i, dummy);
	}

	close(fp);*/
	return 0;
}

// 202007710
// START as character
// EOF
int retrieve (char* filename) {
	FILE *fp;
	int i;
	char dummy[256];
	char basic[3];

	printf("retrieve: %s starts.\r\n", filename);

	fp = fopen(filename, "rb");
	int file_end = filesize ( fp );
	int start = 0;
	int j = 0;
	int line_count = 0;
	// first, we are going to find "spit_line".
	// each block should be stored as block name eve like "001-block---001.txt".
	// and we care following orders.
	//
	printf("file_end %d\r\n", file_end );
	for ( i = 0; i<file_end && i<<100; i++ ) {
		printf("loop start i: %d: file_end %d: \r\n", i, file_end  );
		fread ( dummy, 1, 1, fp);

		dummy[1] = '\0';
		basic[1] = dummy[0];

		// find line end.
		if ( m_compare( (char*)basic, (char*)"\r\n" ) == 1 && line_count!= 0 ) {
			lines[j][i- start - 1 ] = '\0'; //---\r\n if i= 4

			char* a = (char*)lines[j];
			if ( i - start - 1 == 0 ) {
				printf("no word\r\n");
				exit(-1);
			} else {
				line_count++;
				//printf("line_count %d\r\n" line_count);
				exit(-1);
			}
			j++;
			start = i + 1;
		} else {
			lines[j][ i - start ] = dummy[0];
			lines[j][ i - start + 1 ] = '\0';
		}

		printf("loop ends i: %d: dummy: |%s| basic: |%s|\r\n", i, dummy, basic );
		basic[0] = basic[1];
	}

	printf("retrieve: %s ends.\r\n", filename);
	return 1;
}



int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

