#ifndef _WORK_006_H_
#define _WORK_006_H_
class WORK_006 { 
	public:
		WORK_007 *iWORK_006=nullptr;

	public:
		SetWORK_007( WORK007 *lWORK007 ); 

};
#endif
