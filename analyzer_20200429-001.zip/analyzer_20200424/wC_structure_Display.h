
class wC_structure_Display {

	public:
		wC_structure** array_wC_structure;
		wC_structure* select_wC_structure;

	public:
		wC_structure_Display();
		void display_array_wC_structure();
		int display_select_wC_structure(HDC hdc);

};

