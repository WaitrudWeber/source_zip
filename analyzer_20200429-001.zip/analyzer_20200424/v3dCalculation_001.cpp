#include <stdio.h>

#include "v3dCalculation_001.h"

int v3dCalculation_001::calculation_threed () {
	printf("v3dCalculation:: calculation_threed () starts.\r\n");


	printf("v3dCalculation:: calculation_threed () ends.\r\n");
	return 1;
}


