#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "Print.h"
#include "array_counter.h"
#include "list_directory.h"

#include "wEvent.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"



#include "vCalculation.h"
#include "vIntersection.h"



#include "vScreen.h"
#include "vScreenCG.h"
#include "something_word.h"

#include "vPointStructure.h"
#include "vPointLinear.h"

#include "vAxex_2D.h"
#include "creation_of_axex.h"

#include "display_threeD.h"

#include "vDisplayController.h"
#include "wDisplayController.h"

#include "wJavaStructure.h"
#include "wCanvasController.h"


//
//
//
//
wCanvasController::wCanvasController() {
	// 20220321
	Initialize_Axex();
//	Initialize_Buffer();
}

void wCanvasController::CheckMSG(HDC hDC) {
	RECT msg_clip;

	SetRect ( &msg_clip, 300, 0, 400, 50);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 50, 400, 100);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 100, 400, 150);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 150, 400, 200);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 200, 400, 250);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 250, 400, 300);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 300, 400, 350);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
}

//	002
int wCanvasController::SetPixelCanvas (int start_x, int start_y, int blk_x, int blk_y ) {
	this->buf_start_x = start_x;
	this->buf_start_y = start_y;
	this->block_x = blk_x;
	this->block_y = blk_y;

	return 0;
}

//	003
int wCanvasController::Draw_Pixel_Buffer ( ) {
	int buf_x = 0;
	int buf_y = 0;
	int ii = 0;
	int jj = 0;
	int i = 0;
	int j = 0;
	int error = 0;

	if ( buffer == NULL ) error = this->Initialize_Buffer_001 ();

	for ( jj = 0; jj<screen_height; jj++ ) 
	for ( ii = 0; ii<screen_width; ii++ ) {

		buf_x = buf_start_x + block_x * ii;
		buf_y = buf_start_y + block_y * jj;

		for( j=buf_y; j<buf_y + block_y - 1; j++ ) {
			for( i=buf_x; i<buf_x + block_x - 1; i++ ) {
				if ( buf_x < 0 || buf_y < 0 || buf_x >= this->width || buf_y >= this->height ) continue;
					SetPixel(event->hDc, i, j, RGB( buffer[ii][jj][0], buffer[ii][jj][1], buffer[ii][jj][2]));
			}
		}

	}

	printf("int wCanvasController::Draw_Pixel_Buffer ( ) ii %d, jj %d i %d j %d ends.\r\n", ii, jj, i, j );

	return 0;
}

//	004
int wCanvasController::Line_Slope (int x1, int y1, int x2, int y2) {
	int i = 0;
	int j = 0;
	double a = 0.0;
	double y = 0.0;
	int error = 0;

	if ( buffer == NULL ) error = this->Initialize_Buffer_001 ();

	a = (double)( y2 -y1 )/ (double)( x2 - x1 );

	y = y1;
	for ( i =0; i<screen_width; i++ ) {
		y += a;
		for ( j=y; j>=0; j-- ) {
			if ( i < 0 || j < 0 || i >= screen_width || j >= screen_height ) continue;
				buffer[ i ][ j ][0] = 255;
		}
	}

	printf("i %d, j %d\r\n", i, j );

	return 0;
}

//	005-01
int wCanvasController::Line_Slope (int x1, int y1, int x2, int y2, int color_num) {
	int i = 0;
	int j = 0;
	double a = 0.0;
	double y = 0.0;
	int error = 0;
	int inclement = 1;
	int start_x = 0;
	int end_x = 0;
	int flg_y = 0;

	if ( buffer == NULL ) error = this->Initialize_Buffer_001 ();
	if ( color_num > 3 ) return -1;

	a = (double)( y2 -y1 )/ (double)( x2 - x1 );

	if ( x1 < x2 ) {
		y = y1;
		start_x = x1;
		end_x = x2;
	} else {
		y = y2;
		start_x = x2;
		end_x = x1;
		flg_y = 1;
	}

	if ( flg_y && y1 <= y2 ) inclement = -1;
	if ( flg_y && y1 > y2 ) inclement = -1;

//	if ( abs(a) < 0.5 ) inclement = -1; 

	printf("a=%f y=%f start_x %d inclement=%d flg_y %d y1 %d y2 %d\r\n", a, y, start_x, inclement, flg_y, y1, y2 );
//	exit(-1);

	for ( i =start_x; i<end_x; i++ ) {
		y += a;
		for ( j=y; j>=0; j += inclement ) {
			printf("i , j = %d, %d\r\n", i, j);
			if ( i < 0 || j < 0 || i >= screen_width || j >= screen_height ) break;

			if ( inclement == -1 && y1 <=  y2 && j < y1 ) break;
			if ( inclement == -1 && y1 >   y2 && j < y2 ) break;

			if ( inclement == 1  && y1 <=  y2 && j > y2 ) break;
			if ( inclement == 1  && y1 >   y2 && j > y1 ) break;

			buffer[ i ][ j ][color_num] = 255;
		}
	}

	printf("i %d, j %d color_num %d\r\n", i, j, color_num  );

	return 0;
}

void wCanvasController::SetWaveValue( int wavevalue ) {
	int abs_value = abs ( wavevalue );
	this->Blued = abs_value;
	this->Greened = 128 - abs_value;
}

int wCanvasController::Initialize_Buffer_001 () {
	printf("int wCanvasController::Initialize_Buffer_001 () stars.\r\n");
	for ( int j=0; j<screen_height; j++ )
		for ( int i=0; i<screen_width; i++ ) {
			printf("i %03d/%03d j %03d/%03d block starts.\r\n", i, screen_width, j, screen_height );
			printf("0|%p| 1|%p| 2|%p|\r\n", &buffer[i][j][0], &buffer[i][j][1], &buffer[i][j][2]);
			buffer[i][j][0] = (unsigned char)0;
//			buffer[i][j][1] = (unsigned char)0;
//			buffer[i][j][2] = (unsigned char)255; // Blue
			printf("i %03d/%03d j %03d/%03d block ends.\r\n", i, screen_width, j, screen_height );
		}

	printf("int wCanvasController::Initialize_Buffer_001 () ends.\r\n");
	return 0;
}

//
void wCanvasController::Initialize_Buffer() {
	for ( int j=0; j<screen_height; j++ )
		for ( int i=0; i<screen_width; i++ ) {
			printf("i %03d/%03d j %03d/%03d %d/%d/%d/%d block starts.\r\n", i, screen_width, j, screen_height, buffer[i][j][0], buffer[i][j][1], buffer[i][j][2], buffer[i][j][3] );
			buffer[i][j][0] = 0;
			buffer[i][j][1] = 0;
			buffer[i][j][2] = 0; // Blue
			buffer[i][j][3] = 0; // Blue
			printf("i %03d/%03d j %03d/%03d %d/%d/%d/%d block ends.\r\n", i, screen_width, j, screen_height, buffer[i][j][0], buffer[i][j][1], buffer[i][j][2], buffer[i][j][3]  );
		}
}

// 010
int wCanvasController::draw_line_001  ( int x1, int y1, int x2, int y2, unsigned char num, unsigned char col ) {
	double step, cur, end;	
	int xy_flg, base, dec_flg, opp_flg;

	printf("int wCanvasController::draw_line_001  ( int x1, int y1, int x2, int y2, unsigned char num, unsigned char col ) starts.\r\n");

	step = (double)(y2 - y1) / (double)(x2 - x1) + 0.0000000001;

	printf("x1 %d y1 %d x2 %d y2 %d\r\n", x1, y1, x2, y2);

	// https://www.ibm.com/docs/ja/zos/2.2.0?topic=lf-fabs-fabsf-fabsl-calculate-floating-point-absolute-value
	if ( fabs ( step ) < 1.0 ) xy_flg = 1;
	else xy_flg = 0;

	if ( xy_flg ) base = x1;
	else base = y1;

	if ( xy_flg ) cur = y1;
	else cur = x1;

	if ( xy_flg ) end = y2;
	else end = x2;

	if ( xy_flg && x1 <= x2 ) dec_flg = 1;
	if ( xy_flg && x1 > x2 ) dec_flg = -1;
	if ( xy_flg == 0 && y1 <= y2 ) dec_flg = 1;
	if ( xy_flg == 0 && y1 > y2 ) dec_flg = -1;

	step *= dec_flg;
	opp_flg = 0;
	if ( cur > end ) opp_flg = 1;

	printf("base %d cur %f end %f step %f xy_flg %d dec_flg %d opp_flg %d\r\n", base, cur, end, step, xy_flg, dec_flg, opp_flg );
//	exit(-1);
	while ( ( opp_flg ==0 && cur <= end ) || ( opp_flg && cur >= end ) ) {
		step_cursol_001 ( cur, base, xy_flg, 0, col );
		cur += step; 
		base += dec_flg;
		printf("base %d cur %f end %f step %f xy_flg %d dec_flg %d\r\n", base, cur, end, step, xy_flg, dec_flg );
//		exit(-1);
	}

	printf("int wCanvasController::draw_line_001  ( int x1, int y1, int x2, int y2, unsigned char num, unsigned char col ) ends.\r\n");
}

// 009
void wCanvasController::step_cursol  ( unsigned char ***img, double cur, int base, int xy_flg, unsigned char num, unsigned char col )  {
	printf("void wCanvasController::step_cursol  ( unsigned char ***img, double cur, int base, int xy_flg, unsigned char num, unsigned char col ) starts.\r\n");
	printf("cur %f, base %d xy_flg %d img |%p| num %d col %d\r\n", cur, base, xy_flg, img, num, col);
/*	if ( xy_flg )
		img[base][(int)cur][num] = col;
	else
		img[(int)cur][base][num] = col;*/
	printf("void wCanvasController::step_cursol  ( unsigned char ***img, double cur, int base, int xy_flg, unsigned char num, unsigned char col ) ends.\r\n");
}

// void step_cursol_001  ( double cur, int base, int xy_flg, unsigned char num, unsigned char col )  ;
// 009-01
void wCanvasController::step_cursol_001  ( double cur, int base, int xy_flg, unsigned char num, unsigned char col )  {
	printf("void wCanvasController::step_cursol_001  ( double cur, int base, int xy_flg, unsigned char num, unsigned char col ) starts.\r\n");
	printf("cur %f, base %d xy_flg %d num %d col %d\r\n", cur, base, xy_flg, num, col);
	if ( xy_flg )
		this->buffer[base][(int)cur][num] = col;
	else
		this->buffer[(int)cur][base][num] = col;
	printf("void wCanvasController::step_cursol_001  ( double cur, int base, int xy_flg, unsigned char num, unsigned char col ) ends.\r\n");
}

void wCanvasController::set_color_001  ( )  {
	for ( int i=0; i<10; i++ ) 
	for ( int j=0; j<10; j++ ) {
		printf("a %d %d", 1, this->buffer[0][0][0]);
//		this->buffer[i][j][0] = 255;
		this->set_color_001( i, j, 1, 255 );
	}
}

void wCanvasController::set_color_001  ( int i, int j, unsigned char num, unsigned char col )  {
	this->buffer[i][j][num] = col;
}

//
void wCanvasController::step_cursol_test_001 ( ) {
	printf("buffer|%p|\r\n", &buffer[0][0][0]);
	step_cursol_test((unsigned char ***)&buffer[0][0][0]);
}


// void step_cursol_test  ( unsigned char ***img );
void wCanvasController::step_cursol_test  ( unsigned char ***img ) {
	printf("img |%p|\r\n", img);
	printf("img[0][0][0] |%p|\r\n", &img[0][0][0]);
}

//
//
//
//
//void wCanvasController::Print_struct(wJavaStructure top ) {
//
//
//}

//
//
//
//
void wCanvasController::setEvent( wEvent* evt ) {

	this->event = evt;

}

//
//
//
//
void wCanvasController::kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

}

//
//
//
//
void wCanvasController::Process () {

	Processed = 0;
//	switch ( *( this->event->uMsg ) ) {
	switch ( this->event->Type ) {
	case WM_PAINT:
		ProcessWmPaint ();
		Processed = 1;
		break;
	case WM_CHAR:
//		ProcessWmChar ();
		Processed = 1;
	case WM_KEYUP:
		printf("wCanvasController::WM_KEYUP: %d\r\n", WM_KEYUP);
		// Passed at 20190406
		ProcessWmKeyup ();
		Processed = 1;
		ProcessedKeyup = 1;
		break;
	}

}

//
void wCanvasController::Set_Axex_Line( int x1, int y1, int x2, int y2 ) {
	printf("void wCanvasController::Set_Axex_Line( int x1, int y1, int x2, int y2 ) starts.");
	axline[this->AXEX_2D_LINE_Index]->p1->x = x1;
	axline[this->AXEX_2D_LINE_Index]->p1->y = y1;
	axline[this->AXEX_2D_LINE_Index]->p2->x = x2;
	axline[this->AXEX_2D_LINE_Index]->p2->y = y2;
	this->AXEX_2D_LINE_Index++; 
	printf("void wCanvasController::Set_Axex_Line( int x1, int y1, int x2, int y2 ) ends.");
}


void wCanvasController::ProcessWmKeyup () {
	printf("void wCanvasController::ProcessWmKeyup () starts.\r\n");

	if ( this->event->wParam < 999 && this->event->wParam >= 0 )
		this->key_wParam_Keyup = this->event->wParam;
	else {
		printf("void wButtonController::ProcessWmKeyup () ends as skipping.\r\n");
		return;
	}

	int m_mode = this->event->main_mode;
	this->event->wParam_Keyup = this->key_wParam_Keyup;

	//  8 Backspace
	// 17 Ctl
	// 13 Enter
	// 27 ESC
	// 37 LEFT
	// 38 UP
	// 38 RIGHT
	// 40 DOWN
	switch ( this->key_wParam_Keyup ) {
	case 13:
		call_once_key = 1;
		break;
	case 17:
		break;
	case 27:
		//escape_action( m_mode );
		//m_mode = -1; // means f
		// screen.
		call_once_key = 1;
		break;
	case 37:
		printf("case 37\r\n");
		exit(-1);
		break;
	case 38:
//		this->CursolNumber--;
//		this->selectButton( );
		call_once_key = 1;
		break;
	case 39:
		break;
	case 40:
//		this->CursolNumber++;
//		this->selectButton( );
		call_once_key = 1;
		break;
	}

	if ( m_mode == 8 &&  this->key_wParam_Keyup == 65 ) {
		AXEX_2D_002_Index_Selected++;
		if ( AXEX_2D_002_Index_Selected >= AXEX_2D_002_Index ) {  //a
			AXEX_2D_002_Index_Selected = 0;
		}
		printf("AXEX_2D_002_Index_Selected %d / AXEX_2D_002_Index %d %f %f - %f %f\r\n", AXEX_2D_002_Index_Selected, AXEX_2D_002_Index, lines_2D_001[AXEX_2D_002_Index_Selected].p1->x, lines_2D_001[AXEX_2D_002_Index_Selected].p1->y, lines_2D_001[AXEX_2D_002_Index_Selected].p2->x, lines_2D_001[AXEX_2D_002_Index_Selected].p2->y );
		call_once_key == 1;
	} else if ( m_mode == 8 &&  this->key_wParam_Keyup == 66 ) { //b
		int a = convert_AXEX_2D();
		this->AXEX_2D_002_Index = 0;
		for ( int i = 3; i<line_index; i++ ) {
			this->Set_vAxex_2D( lines_2D_001[i].p1->x, lines_2D_001[i].p1->y ); 
			this->Set_vAxex_2D( lines_2D_001[i].p2->x, lines_2D_001[i].p2->y ); 
		}
		call_once_key == 1;
	}

	this->event->main_mode = m_mode;

	printf("wCanvasController:: this->key_wParam_Keyup=%d\r\n", this->key_wParam_Keyup );
	printf("void wCanvasController::ProcessWmKeyup () ends.\r\n");
}

//
//
//
//
void wCanvasController::ProcessWmChar () {
	switch ( this->event->main_mode ) {
	case 2:
		//something_word
		//getchar_display_threeD_proc ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		//exit(-1);
		break;
	case 8:
		//getchar_display_threeD_proc ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		break;
	}
}

void wCanvasController::ProcessEllipseWmPaint () {
	int	R = 20;
	int a = 0;

	printf("void wCanvasController::ProcessEllipseWmPaint () starts.\r\n");
	for ( int i=0; i<AXEX_2D_002_Index - 1; i++ ) {
		if ( AXEX_2D_002_Index_Selected == i ) {
    	    //    Set the DC Brush to Red
			//    The RGB macro is declared in "Windowsx.h"
			SetDCBrushColor(event->hDc, RGB( 255, 0, 0));
			//    Set the event->hDc to Blue
			SetDCPenColor(event->hDc, RGB( 0, 0, 255));
			printf("Selected %d/ %d\r\n", AXEX_2D_002_Index_Selected, AXEX_2D_002_Index);
		} else {
			SetDCBrushColor(event->hDc, RGB( 255, 255, 255));
			SetDCPenColor(event->hDc, RGB( 0, 0, 0));
		}
		a = Ellipse( event->hDc, vAxex_2D_002[i].x - R, vAxex_2D_002[i].y - R, vAxex_2D_002[i].x + R, vAxex_2D_002[i].y + R );
	}

	printf("void wCanvasController::ProcessEllipseWmPaint () ends.\r\n");
}

void wCanvasController::ProcessLinesWmPaint () {
	int	R = 20;
	int a = 0;

	printf("void wCanvasController::ProcessLinesWmPaint () starts.\r\n");
	// OK: ROOT
	for ( int i=0; i<AXEX_2D_002_Index - 1; i++ ) {
		if ( AXEX_2D_002_Index_Selected == i ) {
    	    //    Set the DC Brush to Red
			//    The RGB macro is declared in "Windowsx.h"
			SetDCBrushColor(event->hDc, RGB( 255, 0, 0));
			//    Set the event->hDc to Blue
			SetDCPenColor(event->hDc, RGB( 0, 0, 255));
			printf("Selected %d/ %d\r\n", AXEX_2D_002_Index_Selected, AXEX_2D_002_Index);
//				exit(-1);
		} else {
			SetDCBrushColor(event->hDc, RGB( 255, 255, 255));
			SetDCPenColor(event->hDc, RGB( 0, 0, 0));
		}
//		a = Ellipse( event->hDc, vAxex_2D_002[i].x - R, vAxex_2D_002[i].y - R, vAxex_2D_002[i].x + R, vAxex_2D_002[i].y + R );
		MoveToEx( event->hDc, vAxex_2D_002[i].x, vAxex_2D_002[i].y, NULL);
		LineTo  ( event->hDc, vAxex_2D_002[i + 1].y, vAxex_2D_002[i + 1].y );
		// exit(-1); OK: ROOT
	}

	printf("void wCanvasController::ProcessLinesWmPaint () ends.\r\n");
}

void wCanvasController::ProcessAxexWmPaint () {
	int a = 0;

	printf("void wCanvasController::ProcessAxexWmPaint () starts.\r\n");
	// Draw axex
	if ( axline != nullptr )
		for ( int i=0; i<3; i++ ) {
			if ( axline[i] != nullptr ) {
				MoveToEx( event->hDc, (int)axline[i]->p1->x, (int)axline[i]->p1->y, NULL);
				LineTo  ( event->hDc, (int)axline[i]->p2->x, (int)axline[i]->p2->y );
				printf("line to: ax;ine\r\n");
			}
		}
	printf("axline|%p|\r\n", axline);

	printf("void wCanvasController::ProcessAxexWmPaint () ends.\r\n");
}

//
//
//
//
void wCanvasController::ProcessWmPaint () {

	static 	RECT rect;
	int	R = 20;
	int a = 0;

	printf("void wCanvasController::ProcessWmPaint () starts.\r\n");

    SetRect(&rect, 300, 460, 600, 480 );
	SetTextColor( event->hDc, RGB( 0 , 0,  0 ) );

	this->CheckMSG (event->hDc);

	Rectangle( event->hDc, 300, 460, 600, 480  );
	DrawText( event->hDc, TEXT( "Canvas 20210901" ), -1, &rect, DT_NOCLIP);

	SelectObject(event->hDc, GetStockObject(DC_PEN));
	SelectObject(event->hDc, GetStockObject(DC_BRUSH));

	SetDCBrushColor(event->hDc, RGB( 255, 0, 0));
	SetDCPenColor(event->hDc, RGB( 0, 0, 255));
	Ellipse( event->hDc, 50 - R,  50 - R, 50 + R, 50 + R );

	//
	//if ( vAxex_2D_002[0].x == 0) exit(-1);

	switch ( this->event->main_mode ) {
	case 2:
		//something_word
//		wmpaint_somtehing_word_proc ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
		break;
	case 6:
		//this->Initialize_Buffer ();
		//printf("this->Initialize_Buffer ();\r\n");
//		a = this->Initialize_Buffer_001 ();
//		printf("a = this->Initialize_Buffer_001 ();\r\n");
//		exit(-1);
		break;
	case 7:
//		a = this->Draw_Buffer_002 ();
//		printf("a = this->Draw_Buffer_002 ();\r\n");
		a = Draw_Pixel_Buffer ();
		printf("a = this->Draw_Pixel_Buffer ();\r\n");
//		a = this->Draw_Buffer ();
//		printf("a = this->Draw_Buffer ();\r\n");
//		exit(-1);
		break;
	case 29:
		// OK: ROOT
		for ( int i=0; i<AXEX_2D_002_Index; i++ ) {
			if ( AXEX_2D_002_Index_Selected == i ) {
	    	    //    Set the DC Brush to Red
				//    The RGB macro is declared in "Windowsx.h"
				SetDCBrushColor(event->hDc, RGB( 255, 0, 0));
				//    Set the event->hDc to Blue
				SetDCPenColor(event->hDc, RGB( 0, 0, 255));
				printf("Selected %d/ %d\r\n", AXEX_2D_002_Index_Selected, AXEX_2D_002_Index);
//				exit(-1);
			} else {
				SetDCBrushColor(event->hDc, RGB( 255, 255, 255));
				SetDCPenColor(event->hDc, RGB( 0, 0, 0));
			}
			a = Ellipse( event->hDc, vAxex_2D_002[i].x - R, vAxex_2D_002[i].y - R, vAxex_2D_002[i].x + R, vAxex_2D_002[i].y + R );
			// exit(-1); OK: ROOT
		}
		// 20220321
		// Draw axex
		if ( axline != nullptr )
			for ( int i=0; i<3; i++ ) {
				if ( axline[i] != nullptr ) {
					MoveToEx( event->hDc, (int)axline[i]->p1->x, (int)axline[i]->p1->y, NULL);
					LineTo  ( event->hDc, (int)axline[i]->p2->x, (int)axline[i]->p2->y );
					printf("line to: ax;ine\r\n");
				}
			}
		printf("axline|%p|\r\n", axline);
		break;
	case 30:
		this->ProcessLinesWmPaint ();
		this->ProcessAxexWmPaint ();
		break;
	}

	printf("this->event->main_mode %d\r\n", this->event->main_mode);

	printf("void wCanvasController::ProcessWmPaint () ends.\r\n");
//	exit(-1);
}

//
int wCanvasController::Set_Buffer (int xx, int yy, int col, unsigned char vv ) {
	err_msg_001("int wCanvasController::Set_Buffer (int xx, int yy, int col, unsigned char vv ) ; starts.\r\n");

	if ( xx >= 0 && yy >=0 && xx < screen_width && yy < screen_height )
		buffer[xx][yy][col] = vv;

	err_msg_001("int wCanvasController::Set_Buffer (int xx, int yy, int col, unsigned char vv ) ; ends.\r\n");
}

//
int wCanvasController::Draw_Buffer ( ) {
	int i, j;
	printf("int wCanvasController::Draw_Buffer ( ) starts.\r\n");
	for( j=0; j<screen_height; j++ ) {
		for( i=0; i<screen_width; i++ ) {
			SetPixel(event->hDc, i + screen_x, j + screen_y, RGB( buffer[i][j][0], buffer[i][j][1], buffer[i][j][2]));
		}
	}
	printf("int wCanvasController::Draw_Buffer ( ) ends.\r\n");
	return 0;
}
//
int wCanvasController::Draw_Buffer_001 ( ) {
	int i, j;
	printf("int wCanvasController::Draw_Buffer ( ) starts.\r\n");

	printf("screen_x %03d screen_y %03d screen_width %03d screen_height %03d\r\n", screen_x, screen_y, screen_width, screen_height);

	SetDCBrushColor(event->hDc, RGB( 255, 255, 255));
	SetDCPenColor(event->hDc, RGB( 0, 0, 255));

	// buffer[i][j][0], buffer[i][j][1], buffer[i][j][2] 
	for( j=0; j<screen_height; j++ )
		for( i=0; i<screen_width; i++ ) {
			printf("i %03d/%03d i %03d/%03d draw block starts.\r\n", i+ screen_x, screen_width, j+ screen_y, screen_height);
			// x SetDCBrushColor(event->hDc, RGB( buffer[i][j][0], buffer[i][j][1], buffer[i][j][2] ));
			// x SetDCBrushColor(event->hDc, RGB( 255, 255, 255));
			// x SetDCPenColor(event->hDc, RGB( buffer[i][j][0], buffer[i][j][1], buffer[i][j][2] ));
			MoveToEx( event->hDc, i + screen_x, j + screen_y, NULL);
			LineTo  ( event->hDc, i + screen_x, j + screen_y );
			printf("i %03d/%03d/%03d j %03d/%03d/%03d %d %d %d draw block ends.\r\n", i+ screen_x, i, screen_width, j+ screen_y, j, screen_height, buffer[i][j][0], buffer[i][j][1], buffer[i][j][2]);
		}

	// Dummy
	SetDCBrushColor(event->hDc, RGB( 255, 255, 255));
	SetDCPenColor(event->hDc, RGB( 0, 0, 0));
	MoveToEx( event->hDc, 300, 300, NULL);
	LineTo  ( event->hDc, 500, 400 );

	// Dummy
	SetDCBrushColor(event->hDc, RGB( 255, 255, 255));
	SetDCPenColor(event->hDc, RGB( 0, 0, 255));
	MoveToEx( event->hDc, 298, 298, NULL);
	LineTo  ( event->hDc, 298, 298 );
	MoveToEx( event->hDc, 297, 298, NULL);
	LineTo  ( event->hDc, 297, 298 );
	MoveToEx( event->hDc, 296, 298, NULL);
	LineTo  ( event->hDc, 296, 298 );
	MoveToEx( event->hDc, 295, 298, NULL);
	LineTo  ( event->hDc, 294, 0 );

	// x Dummy
	MoveToEx( event->hDc, 108, 298, NULL);
	LineTo  ( event->hDc, 108, 298 );
	MoveToEx( event->hDc, 107, 298, NULL);
	LineTo  ( event->hDc, 107, 298 );
	MoveToEx( event->hDc, 106, 298, NULL);
	LineTo  ( event->hDc, 106, 298 );
	MoveToEx( event->hDc, 105, 298, NULL);
	LineTo  ( event->hDc, 104, 0 );

	//  Dummy
	MoveToEx( event->hDc, 208, 298, NULL);
	LineTo  ( event->hDc, 208, 298 );
	MoveToEx( event->hDc, 207, 298, NULL);
	LineTo  ( event->hDc, 207, 298 );
	MoveToEx( event->hDc, 206, 298, NULL);
	LineTo  ( event->hDc, 206, 298 );
	MoveToEx( event->hDc, 205, 298, NULL);
	LineTo  ( event->hDc, 204, 0 );

	for ( int ii = 100; ii<200; ii++ ) {
		for ( int jj = 100; jj<200; jj++ ) {
			printf("ii %d jj %d\r\n", ii, jj );
			MoveToEx( event->hDc, ii, jj, NULL);
			LineTo  ( event->hDc, ii, jj );
		}
	}

	unsigned char red_001 = 255;
	for ( int ii = 300; ii<400; ii++ ) {
		for ( int jj = 300; jj<400; jj++ ) {
			printf("ii %d jj %d\r\n", ii, jj );
			SetPixel(event->hDc, ii, jj, RGB(0, 0, buffer[0][0][2]));
		}
	}

	printf("0, 0, buffer[0][0][2] = %d\r\n", buffer[0][0][2]);



	printf("i %d j %d 2:blue %d\r\n", i, j, buffer[i][j][2]);
	printf("int wCanvasController::Draw_Buffer ( ) ends. i %d/%d j %d/%d\r\n", i, screen_width, j, screen_height );
	return 0;
}

//
int wCanvasController::Draw_Buffer_002 ( ) {
	int i, j;
	int ii, jj;

	printf("int wCanvasController::Draw_Buffer_002 ( ) starts.\r\n");
	for( j=0; j<screen_height; j+=4 ) {
		for( i=0; i<screen_width; i+=4 ) {
			for ( jj = j; jj<j+3; jj++ ) 
				for ( ii = i; ii<i+3; ii++ ) 
					SetPixel(event->hDc, ii + screen_x, jj + screen_y, RGB( buffer[i][j][0], buffer[i][j][1], buffer[i][j][2]));
			for ( jj = j+3; jj<j+4; jj++ ) 
				for ( ii = i+3; ii<i+4; ii++ )  
					SetPixel(event->hDc, ii + screen_x, jj + screen_y, RGB( 255, 255, 255));

			printf(" i, j = %d , %d\r\n", i, j);
		}
	}

	printf("int wCanvasController::Draw_Buffer_002 ( ) ends. i %d/%d j %d/%d\r\n", i, screen_width, j, screen_height );
	return 0;
}

// 20220321
void wCanvasController::Initialize_Axex ( ) {
		if ( axline == nullptr )
			axline = (vLine**)malloc(sizeof(vLine*)*3);

		// On the 2D
		if ( axline != nullptr ) {
			axline[0] = memorizevLine( memorizevPoint( width/2.0f + 0.0f, height/2.0f + 0.0f, 0.0f), memorizevPoint( width/2.0f + 200.0f, height/2.0f + 0.0f, 0.0f) );
			axline[1] = memorizevLine( memorizevPoint( width/2.0f + 0.0f, height/2.0f + 0.0f, 0.0f), memorizevPoint( width/2.0f +   0.0f, height/2.0f + 200.0f, 0.0f) );
			axline[2] = memorizevLine( memorizevPoint( width/2.0f + 0.0f, height/2.0f + 0.0f, 0.0f), memorizevPoint( width/2.0f + 100.0f, height/2.0f + 100.0f, 0.0f) );
		}
}

int wCanvasController::get_pixel_buffer( int i, int j, unsigned char* rgbt ) {

	rgbt[0] = this->buffer[i][j][0];
	rgbt[1] = this->buffer[i][j][1];
	rgbt[2] = this->buffer[i][j][2];
	rgbt[3] = this->buffer[i][j][3];

	return 0;
}

int wCanvasController::put_pixel_buffer( int i, int j, unsigned char rgbt[4] ) {

	this->buffer[i][j][0] = rgbt[0];
	this->buffer[i][j][1] = rgbt[1];
	this->buffer[i][j][2] = rgbt[2];
	this->buffer[i][j][3] = rgbt[3];

	printf("put|%d|%d|%d|%d|\r\n", rgbt[0], rgbt[1], rgbt[2], rgbt[3] );
	printf("buf|%d|%d|%d|%d|\r\n", this->buffer[0], this->buffer[1], this->buffer[2], this->buffer[3] );

	return 0;
}

void wCanvasController::Set_vAxex_2D ( float x, float y ) {
	vAxex_2D_002[AXEX_2D_002_Index].x = x;
	vAxex_2D_002[AXEX_2D_002_Index].y = y;
	AXEX_2D_002_Index++;
	if ( AXEX_2D_002_Max <= AXEX_2D_002_Index ) AXEX_2D_002_Index = 0;
}

//
int wCanvasController::Get_vAxex_2D ( int num, float *x, float *y ) {
	*x = vAxex_2D_002[num].x;
	*y = vAxex_2D_002[num].y;

	return 0;
}

int wCanvasController::GetSelected ( ) {

	return AXEX_2D_002_Index_Selected;
}
