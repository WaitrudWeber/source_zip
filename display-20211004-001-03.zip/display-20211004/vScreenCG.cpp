#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"

#include "vScreenCG.h"


vScreenCG::vScreenCG ( ) {

	//Point U = new Point();
	//Point V = new Point();

	this_calc = new vCalculation ();
}

int vScreenCG::getWidth() {
	return this->width;
}
int vScreenCG::getHeight() {
	return this->height;
}

int vScreenCG::OntheScreen ( vPoint lp, vPoint* result ) {

	// Screen( x, y );

	return 0;
}

// All qualified at 20190627:
//
//
//
//
int vScreenCG::OntheScreen ( vPoint lp, float* x, float* y ) {
	vCalculation calc;
	vPoint result;

	//printf("lp= ");
	//lp.print ();

	// Screen( x, y )
	// lp is surely on the screen.
	calc.subtract( &(lp) , &(this->C), &result );

	printf("lp = ");
	lp.print();

	printf("C = ");
	this->C.print();


	printf("result_001 = ");
	result.print();

//	*x = calc.dot( result, this->U ); // right
//	*y = calc.dot( result, this->V ); // up
	*x = calc.dot( result, this->u ); // right
	*y = calc.dot( result, this->up ); // up

	printf("up= ");
	this->up.print();
	printf("right= ");
	this->u.print();


	printf("001 x, y = %f , %f\r\n", *x, *y);

//	*x /= (double)this->width;
//	*y /= (double)this->height;

/*	printf("002 x, y = %f , %f\r\n", *x, *y);

	*y = -*y + this->height;

	printf("003 x, y = %f , %f height %f\r\n", *x, *y, this->height);*/

/*	result_x = calc.cross ( result, this->u ) ;
	result_y = calc.cross ( result, this->up ) ;

	// double -> float
	*x = (float) this_calc->length( result_x );
	*y = this->height - (float) this_calc->length( result_y );

	*x = *x + this->width / 2.0f;
	*y = ( -*y + this->height )  + this->height/2.0f; */

	return 0;
}

void vScreenCG::OntheScreen ( float* x, float* y ) {
	vPoint px;
	vPoint py;

	OntheScreen( &px, &py );
	*x = px.x;
	*y = px.y;
}

void vScreenCG::OntheScreen ( vPoint* x, vPoint* y) {
	vPoint px, py;
	subtract ( X, C, &px );
	subtract ( Y, C, &py );
}

void vScreenCG::LookAt ( vPoint lookat ) {
	this->lookat = lookat;
}

void vScreenCG::put_U ( vPoint a ) {
	U = a;
}

void vScreenCG::put_Up ( vPoint up ) {
	vCalculation calc;
	
	calc.normal( &(up), &(this->up) );
}

void vScreenCG::put_V ( vPoint b) {
	V = b;
}

void vScreenCG::put_C ( vPoint c) {
	C = c;
}

void vScreenCG::calculation () {
	calculation_uv_up();
}

void vScreenCG::calculation_uv_up () {

	vCalculation calc;

	calc.normal ( &(this->U), &(this->u) ) ;
	calc.normal ( &(this->V), &(this->v)  ) ;
	calc.cross ( &(this->u), &(this->v), &(this->up) ) ;

}

void vScreenCG::Set_HowFarFromEye (float howfarfrmeye) {
	printf("void vScreenCG::Set_HowFarFromEye (float howfarfrmeye) starts.\r\n");

	this->HowFarFromEye = howfarfrmeye;
	printf("this->HowFarFromEye=%f\r\n", this->HowFarFromEye);
	printf("void vScreenCG::Set_HowFarFromEye (float howfarfrmeye) ends.\r\n");
}

void vScreenCG::calculation_up_UV () {
	vCalculation calc_this;
	vPoint howfar, harfU, harfV;

	printf("void vScreenCG::calculation_up_UV () starts.\r\n");

	printf("this->eye= ");
	this->eye.print();
	printf("lookat= ");
	this->lookat.print();
	printf("this->HowFarFromEye=%d\r\n", this->HowFarFromEye);

	calc_this.subtract ( &(this->lookat), &(this->eye), &howfar );
	calc_this.normal( &howfar );
	printf("normal howfar= ");
	howfar.print();

	calc_this.scale( &howfar, this->HowFarFromEye );

	printf("this->HowFarFromEye=%f\r\n", this->HowFarFromEye);

	printf("howfar= ");
	howfar.print();

	calc_this.add( &(this->eye), &howfar, &(this->C) );

	normal ( &(this->up) ) ;
	printf("normal up= ");
	up.print();

	u = cross( howfar, up );		//right , -left
	calc_this.normal ( &u ) ;
	printf("normal u= ");

	up = cross( u, howfar );		//up
	depth = cross( up, u );				// depth
	calc_this.normal ( &depth ) ;
	calc_this.normal ( &up ) ;

	printf("right u= "); // u is right
	u.print();
	printf("depth= ");
	depth.print();

	v = cross( u, depth );		//up = v
	printf("up v= ");
	v.print();

	printf("this->height=%f\r\n", this->height);
	printf("up = ");
	this->up.print();

	calc_this.scale( &u, this->width, &U );
	calc_this.scale( &(this->up), this->height, &V ); // V means UP, v means depth direction

	printf("u= ");
	u.print();
	printf("U= ");
	U.print();
	printf("V= ");
	V.print();

	calc_this.scale( &(u), -this->width/2.0f, &harfU );
	calc_this.scale( &(this->up), -this->height/2.0f, &harfV );

	calc_this.add( &(this->C), &(harfU), &(this->C) );
	calc_this.add( &(this->C), &(harfV), &(this->C) );

	printf("this->C= ");
	this->C.print();

	calc_this.add( &(this->C), &(this->U), &(this->LeftTop) );
	calc_this.add( &(this->C), &(this->V), &(this->RightBottom) );

	printf("this->LeftTop= ");
	this->LeftTop.print();
	printf("this->RightBottom= ");
	this->RightBottom.print();

	printf("void vScreenCG::calculation_up_UV () ends.\r\n");

}

vPoint vScreenCG::getRight() {
	//right also -left is this->u.
	return this->u;
}


void vScreenCG::normal( vPoint *a) {
	this_calc->normal ( a ) ;
}

void vScreenCG::subtract( vPoint a, vPoint b, vPoint *result) {

	result = this_calc->subtract ( a, b ) ;
}

vPoint vScreenCG::cross( vPoint a, vPoint b) {
	vPoint result;

	this_calc->cross ( &a, &b, &result ) ;
	return result;
}

//
//
//
void vScreenCG::setWidth( int w ) {
	this->width = w;
}

//
//
//
void vScreenCG::setHeight( int h ) {
	this->height = h;
}

//
//
//
void  vScreenCG::setEye ( vPoint leye ) {
	this->eye.x = leye.x;
	this->eye.y = leye.y;
	this->eye.z = leye.z;
}

void  vScreenCG::printParams () {
	printf("void  vScreenCG::printParams() starts.\r\n");
	printf("HowFarFromEye=%f\r\n", this->HowFarFromEye);
	printf("void  vScreenCG::printParams() ends.\r\n");
}

void  vScreenCG::calculation_up_UV_001 () {
	vCalculation calc_this;
	vPoint howfar, harfU, harfV;

	printf("void vScreenCG::calculation_up_UV_001 () starts.\r\n");

	printf("HowFarFromEye=%f\r\n", this->HowFarFromEye);

	printf("this->eye= ");
	this->eye.print();
	printf("this->lookat= ");
	this->lookat.print();
	printf("this->HowFarFromEye=%f\r\n", this->HowFarFromEye);

	calc_this.subtract ( &(this->lookat), &(this->eye), &howfar );
	calc_this.normal( &howfar );
	printf("normal howfar= ");
	howfar.print();

	calc_this.scale( &howfar, this->HowFarFromEye );

	printf("howfar= ");
	howfar.print();

	printf("void  vScreenCG::calculation_up_UV_001() ends.\r\n");
}

//
int vScreenCG::get_cooordinate_on_screen ( vPoint lp, float* lx, float* ly ) {
	vCalculation calc;
	vPoint ray_001;
	vTriangle screen_tri;

	printf("get_cooordinate_on_screen starts.\r\n");

	calc.subtract( &lp, &(this->eye), &ray_001);
	calc.normal( &ray_001 );

	screen_tri.p1.setPoint(this->C.x, this->C.y, this->C.z );
	screen_tri.p2.setPoint(this->LeftTop.x, this->LeftTop.y, this->LeftTop.z );
	screen_tri.p3.setPoint(this->RightBottom.x, this->RightBottom.y, this->RightBottom.z );

	screen_tri.print();

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	vPoint* point_intersection = intersection->Intersect( screen_tri, this->eye, ray_001 );

	printf("intersection_001 = ");
	point_intersection->print();

	int result = this->OntheScreen( *point_intersection, lx, ly );
	printf("get_cooordinate_on_screen ends. 001\r\n");

	delete ( point_intersection );

	printf("get_cooordinate_on_screen ends. 002 OtherSide=%d\r\n", intersection->OtherSide);

	if ( intersection->OtherSide == 1) return 1;

	return 0;
}
