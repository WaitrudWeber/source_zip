

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vDisplayController.h"

#include "wEvent.h"
#include "wButton.h"
#include "wButtonController.h"

void vDisplayController::Set_Lines (vLine** l ) {
	lines = l;
}

void vDisplayController::Set_Lines_2D (vLine** l_2D ) {
	lines_2D = l_2D;
}

//
int vDisplayController::Approach_vAxex_2D( vPoint* ap ) {
	printf("002: int Approach_vAxex_2D( vPoint* ap ) starts.\r\n");

	vPoint* to_vector = Calc.subtract( ap, AXEX_2D_002[0].center ) ;
	double distance = Calc.length ( to_vector );

	if ( distance >= 1.0 ) {
		Calc.normal(to_vector);
		vPoint* progress =  Calc.scalize( to_vector, 5.0f );
		vPoint* next_p = Calc.add ( AXEX_2D_002[0].center, progress);
		AXEX_2D_002[0].SetCenter( next_p->x, next_p->y, next_p->z );
		AXEX_2D_002[0].SetDepth ( next_p->x, next_p->y, next_p->z );
		AXEX_2D_002[0].Calculation_Axex_002 ( );
		free_point( progress );
		free_point( next_p );
	}
	free_point( to_vector );

	AXEX_2D_002[0].CheckAxex();

	vPoint* to_vector_001 = Calc.subtract( ap, AXEX_2D_002[1].center ) ;
	distance = Calc.length ( to_vector );
	if ( distance >= 1.0 ) {
		Calc.normal(to_vector_001);
		vPoint* progress_001 =  Calc.scalize( to_vector_001, 5.0f );
		vPoint* next_p_001 = Calc.add ( AXEX_2D_002[1].center, progress_001);
		AXEX_2D_002[1].SetCenter( next_p_001->x, next_p_001->y, next_p_001->z );
		AXEX_2D_002[1].SetDepth ( next_p_001->x, next_p_001->y, next_p_001->z );
		AXEX_2D_002[1].Calculation_Axex_002 ( );
		free_point( progress_001 );
		free_point( next_p_001 );
	}
	free_point( to_vector_001 );

	AXEX_2D_002[1].CheckAxex();

	vPoint* to_vector_002 = Calc.subtract( ap, AXEX_2D_002[2].center ) ;
	distance = Calc.length ( to_vector );
	if ( distance >= 1.0 ) {
		Calc.normal(to_vector_002);
		vPoint* progress_002 =  Calc.scalize( to_vector_002, 5.0f );
		vPoint* next_p_002 = Calc.add ( AXEX_2D_002[2].center, progress_002);
		AXEX_2D_002[2].SetCenter( next_p_002->x, next_p_002->y, next_p_002->z );
		AXEX_2D_002[2].SetDepth ( next_p_002->x, next_p_002->y, next_p_002->z );
		AXEX_2D_002[2].Calculation_Axex_002 ( );
		free_point( progress_002 );
		free_point( to_vector_002 );
		free_point( next_p_002 );
	}
	free_point( to_vector_002 );

	AXEX_2D_002[2].CheckAxex();

	printf("002: int Approach_vAxex_2D( vPoint* ap ) ends.\r\n");
	return 0;
}


