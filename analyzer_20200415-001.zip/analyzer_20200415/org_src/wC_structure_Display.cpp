#include <stdio.h>

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include "array_counter.h"
#include "wC_structure.h"
#include "wC_structure_Display.h"
#include "analyzer_C.h"

wC_structure_Display::wC_structure_Display() {
}

//
//
//
//
//
void wC_structure_Display::display_array_wC_structure() {

	char** char_params = (char**)malloc( sizeof(char*) * 1 ) ;
	Analyzer* anl = new Analyzer();

//	char_params[0] = copyof( "C:\\Users\\soresore\ soreda\\source\\sourcevisualizer\\analyzer_20190915\\xvcut.c" );
	char_params[0] = copyof( ".\\xvcut.c" );
	anl->analyze_C( 1, char_params);
	exit(-1);
}

//
//
//
//
//
int wC_structure_Display::display_select_wC_structure(HDC hdc) {
	RECT rect;

	if ( this->select_wC_structure == nullptr ) {
		this->select_wC_structure = new wC_structure ();
	}

	// Calculation of right and bottom
	int right = this->select_wC_structure->x + this->select_wC_structure->width;
	int bottom = this->select_wC_structure->y + this->select_wC_structure->height;

    SetRect(&rect, this->select_wC_structure->x, this->select_wC_structure->y, right, bottom);
//    SetRect(&rect, 400, 0, 500, bottom);

	Rectangle( hdc, rect.left, rect.top, rect.right, rect.bottom );
	DrawText( hdc, TEXT( this->select_wC_structure->function_name ), -1, &rect, DT_NOCLIP);


    SetRect(&rect, 400, 0, 500, 100);
	Rectangle( hdc, rect.left, rect.top, rect.right, rect.bottom );
	DrawText( hdc, TEXT( "default_scope:" ), -1, &rect, DT_NOCLIP);

	return 1;
}

