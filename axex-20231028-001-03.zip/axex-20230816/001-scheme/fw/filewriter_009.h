#ifndef _FILEWRITER_009_
#define _FILEWRITER_009_
//...
extern int filewriter_009 ();
extern int set_filewriter_009 ();
extern int initialize_filewriter_009 ();
#endif
