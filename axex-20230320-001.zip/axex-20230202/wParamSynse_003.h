#ifndef _WPARAM_SYNSE_003_H_
#define _WPARAM_SYNSE_003_H_

class wParamSynse_003 {

	public:
		wParamSynse_003();

	private:
		int Initialize_001 ();

} ;

#endif
