#ifndef _FILEWRITER_008_
#define _FILEWRITER_008_
//...
extern int filewriter_008 ();
extern int set_filewriter_008 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_filewriter_008 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
