#ifndef _READ_CSV__009_
#define _READ_CSV__009_
//...
extern int read_csv_000a_009 ();
extern int set_read_csv_000a_009 (char** argv, int argc);
extern int initialize_read_csv_000a_009 (char** argv, int argc);
#endif
