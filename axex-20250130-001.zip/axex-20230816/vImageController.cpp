#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "vImageController.h"

int vImangeController::Initialize () {
	img_canvas->layer_num = 1;
	img_canvas->width_index = 1;
	img_canvas->height_index = 1;

	this->img_canvas = (IMG_CANVAS*) malloc (sizeof(IMG_CANVAS));
	if (this->img_canvas == NULL) {
		printf("img_canvas is NULL.\r\n");
		exit(-1);
	}

	this->Reallocation_003 ( 0 );

	return 0;
}

int vImangeController::Reallocation () {

	if ( img_canvas->layer_num_max > img_canvas->layer_num_index ) {
		img_canvas->layer_num_max *= 2;
		this->Reallocation_002 ();
	}

	return 0;
}

int vImangeController::Reallocation_001 () {
	unsigned char*** a = NULL;
	a = (unsigned char***) realloc ( a, sizeof(unsigned char**) * 11 ) ;

	return 0;
}


//
int vImangeController::Reallocation_002 () {
	int i;

	img_canvas->img = (RGBT_VAL***) realloc ( img_canvas->img, sizeof(RGBT_VAL**) * img_canvas->layer_num_max ) ;
	if (img_canvas->img == NULL) {
		printf("Reallocation_002 can not reallocate. \r\n");
		exit(-1);
	}

	for ( i =0; i <img_canvas->layer_num_index; i++ ) {
		this->Reallocation_003 ( i );
	}

	return 0;
}

//
//
int vImangeController::Reallocation_003 ( int layer_num ) {
	int i;

	img_canvas->img[layer_num] = (RGBT_VAL**) realloc ( img_canvas->img[layer_num], sizeof(RGBT_VAL*) * img_canvas->width_max ) ;
	if ( img_canvas->img[layer_num] == NULL ) {
		printf("Reallocation_003 can not reallocate as layer num %d. \r\n", layer_num );
		exit(-1);
	}

	for ( i =0; i <img_canvas->height; i++ ) {
		img_canvas->img[layer_num][i] = (RGBT_VAL*) realloc ( img_canvas->img[layer_num], sizeof(RGBT_VAL) * img_canvas->height_max ) ;
		if ( img_canvas->img[layer_num][i] == NULL ) {
			printf("Reallocation_003 can not reallocate as layer num %d and width %d height %d. \r\n", layer_num, i , img_canvas->height_max  );
			exit(-1);
		}
	}

	return 0;
}

