#ifndef _WEVENT_H
#define _WEVENT_H

class wEvent {

	public :
		HWND hWnd = nullptr;
		UINT *uMsg = nullptr;
		WPARAM wParam = 0;
		LPARAM lParam = 0;
		int main_mode = 0; // button number
		HDC hDc = nullptr;
		PAINTSTRUCT* ps = nullptr;
		WPARAM wParam_Keyup = 0;
		int Keep_Keyup = 0;

		// 20190404
		int Type = 0; // the left is nececassary because uMsg changes usually after BeginPaint or maybe when calling of WindowsAPI which has a handle.
};

#endif
