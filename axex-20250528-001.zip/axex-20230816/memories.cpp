#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h> // ADD: 20200125

int wait_sharp_short_time () ;

//
int wait_sharp_short_time () {
	int i;
	for (i=0; i<10; i++ ) {
		printf("#");
		Sleep(66);
	}
	printf("\r\n");
	return 0;
}

