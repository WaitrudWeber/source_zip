#ifndef _JACSON_ANIMATION_FOCUS_003_H_
#define _JACSON_ANIMATION_FOCUS_003_H_

struct struct_rgbt {
	unsigned char r;
	unsigned char g;
	unsigned char b;
	unsigned char t;
} ;

struct struct_float_twod {
	float x;
	float y;
} ;


struct struct_animation_focus {
	int start_x;
	int start_y;
	int width;
	int height;
	int margin_x;
	int margin_y;
};

struct struct_read_ppm {
	struct_rgbt** ppm_canvas = NULL;
	struct_animation_focus focus;

	int thread_initialize ();
	int thread_process ();
	int thread_pose ();
	int thread_outbyend ();
	int thread_close ();

};

struct struct_read_pgm {
	struct_rgbt** pgm_canvas = NULL;
	struct_animation_focus focus;

	int thread_initialize ();
	int thread_process ();
	int thread_pose ();
	int thread_outbyend ();
	int thread_close ();

};

struct struct_animation_fonts_frame {
	int** fonts_sheet = NULL;
	struct_animation_focus focus;
	int thread_initialize ();
	int thread_process ();
	int thread_pose ();
	int thread_outbyend ();
	int thread_close ();

};

struct struct_history_focus {
	struct_animation_focus *child = NULL;
	int history_focus_index = 0;
	int history_focus_last_index = 8;
};

struct struct_history_several_focus {
	struct_animation_focus **child = NULL;
	int history_several_focus_index = 0;
	int history_several_focus_last_index = 32;
};

struct struct_animation_focus_frame {
	int (*draw_number)();
	int (*draw_effects)();
	int (*draw_model_frame)();
	int (*draw_grid)();
	int (*initialize_parameters_all)();
	int **canvas;
	struct_animation_focus canvas_focus;
	int number = 0;
	int font_background = 1;
	struct_rgbt fore_ground_colour;
	struct_rgbt back_ground_colour;
	struct_rgbt grid_colour;
	char* char_str_number = NULL;
	int thread_sleep_real_animation = 33;
	int thread_animation_times = 60;
	int initialized = 0;
	struct_animation_focus focus;
	struct_animation_focus paint_focus[10];
	int focus_num = 10;
	struct_animation_focus small_focus;
	struct_animation_focus number_focus;
	struct_animation_focus fonts_focus[10];
	struct_animation_focus draw_focus;

	double font_rasio = 0.5;

	char** history = NULL;
	int history_last_index = 0;
	int history_index = 0;
	int history_pix_middle_index = 0;

	struct_history_focus *history_focus = NULL;
	int history_focus_index = 0;
	int history_focus_last_index = 8;

	double circle_r = 5.0;
	double circle_center_x = 10.0;
	double circle_center_y = 10.0;

	struct_float_twod	**line_pixel_01 = NULL;
	struct_float_twod	**line_pixel_02 = NULL;
	int line_pixel_01_index = 0;
	int line_pixel_01_max = 0;
	int line_pixel_02_index = 0;
	int line_pixel_02_max = 0;

	int (*Interface_Draw_Jackson) (int* function_name ) ;
	struct_animation_focus log_focus[6];

	int log_msg_flag = 0;
	struct_rgbt log_msg_fore_ground_colour;
	struct_rgbt log_msg_back_ground_colour;
	struct_rgbt log_msg_grid_colour;

	int (*Draw_Jackson_Focus_Circle) () ;
	int (*Draw_Jackson_Focus_Rectangle) () ;
	int	(*Draw_Jackson_Focus_Triangle) () ;

	int (*Full_Box1) ( int x1, int y1, int width, int height) ;
	int (*Full_Box2) ( int x1, int y1, int width, int height) ;

	char* ini_filename_name = (char*)".\\ini\\001-20240816-001\.ini";
	char* asm_filename_name = (char*)".\\asm\\001-20240827-001-01\.ntxt";

	char* menu_filename_name = (char*)".\\Menu\\001-menu-20241007-001\.txt";
	char* menu_stack_print_filename_name = (char*)".\\Menu\\001-menu-20241016-001\.txt";
	char* menu_stack_code_filename_name = (char*)".\\Menu\\001-menu-20241016-code-001\.txt";

	char* font_filename_name = (char*)"..\\resource\\fonts\\vcr_osd_mono0.ppm";

	char* button_ok_cancel = ".\\button\\001-button-001\.txt";
	char* button_ok_cancel_file_print = ".\\button\\001-button-001-w\.txt";

	int menu_num = 0;
	int menu_num_max = 8;
	char** menu_name = NULL;

	int ini_block_index = 0;
	int ini_block_index_max = 8;
	char** ini_block_name = NULL;

	// white campus dialog
	struct_animation_focus campus_window_dialog;

	// 20250329
	struct_animation_focus **rect_focus;
	int rects_focus_index = 0;
	int rects_focus_max = 32;

	// 20250407
	struct_history_several_focus several_focus;

	// 20250522
	int reset_validation_area = 1;
	int black_draw = 1;
	int flag_line_start = 0;

	// basic
	int (*call_draw_fucus_canvas_buffer_only) () ;
	int (*call_draw_canvas_all) ();

	int thread_initialize ();
	int thread_process ();
	int thread_pose ();
	int thread_outbyend ();
	int thread_close ();

};


typedef struct_animation_focus_frame ANIMATION_FOCUS_FRAME;
typedef struct_animation_focus ANIMATION_FOCUS;
typedef struct_read_ppm READ_PPM;
typedef struct_read_pgm READ_PGM;
typedef struct_animation_fonts_frame ANIMATION_FONTS;
typedef struct_rgbt RGBT;
typedef struct struct_float_twod FLOAT_TWOD;

typedef struct struct_history_focus HISTORYFOCUS;
typedef struct struct_history_several_focus HISTORYSEVERALFOCUS;


extern int brunch_functions_all ();

extern int initialize_ppm_fonts () ;
extern int read_ppm (char* filename, READ_PPM* read_ppm) ;
extern int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) ;
extern int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) ;
extern int char_ppm_width_height ( char* print_dummy, int num, int* width, int* height ) ;
extern ANIMATION_FOCUS_FRAME* get_jackson_pointer_animation_thread ();

extern int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y );
extern int sub_fonts_number_focus_set_param_sheet_basic () ;


// debug
extern int initialize_parameters_all () ;

extern int set_log_001_jackson_animation (Logging* llog) ;
//20240208
extern int caribration_grid () ;
extern int caribration_grid_01_03 () ;
extern int print_thumb_number_focus () ;

// 20240212
extern int Random_Work_Param ();
extern int Grid_Work_Param () ;
extern int Stored_Work_Param (char* file_name ) ;
extern int Check_Initialize_Param () ;
// 20240212
extern int Store_Work_Param (char* file_name ) ;
// 20240212
extern int Resque_Initialize_Param ();

extern int Resque_Number_Work_Param () ;
extern int initialize_canvas () ;
extern int set_number ();
extern int caribration_grid () ;
extern int caribration_canvas () ;
extern int sub_fonts_number_focus_set_param_sheet_result () ;

extern int print_number_focus ();
extern int set_focus (int sx, int sy, int width, int height ) ;
extern int set_draw_focus (int sx, int sy, int width, int height ) ;
extern int set_small_focus (int sx, int sy, int width, int height ) ;
extern int Draw_Jackson_Focus_Number ();
extern int set_font_background (int fbk_v) ;
extern int set_font_rasio (double fr_v) ;

extern int set_circle (double cx, double cy, double r) ;


extern int Set_Font_Draw_Left_Top ( int x, int y ) ;
extern int Set_Font_Pix_Scale ( int scale ) ;
extern int Set_Font_Colour ( RGBT rgbt ) ;
extern int Set_Font_Height ( int height ) ;
extern int Set_Font_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) ;

extern int Set_Background_Colour ( RGBT rgbt ) ;
extern int Set_Grid_Colour ( RGBT rgbt ) ;
extern int Set_Grid_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) ;
extern int Set_Background_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) ;
extern int Set_Support_Nuber (int num) ;
extern int Set_Background_Rect (int sx, int sy, int w, int h) ;
extern int Set_Support_Number_001 (int num) ;
extern int Set_Support_Number (int num) ;
extern int Set_Background_Rect (int sx, int sy, int w, int h) ;
extern int Process_and_History (char* p_msg_string ) ;
extern int stack_msg_string (char* p_msg_string ) ;

extern int Set_Fore_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) ;


extern int devide_num_history_focus_box (int num ) ;
extern int initialize_history_focus_box () ;

extern int Draw_Jackson_Focus_Circle () ;
extern int Draw_Jackson_Focus_Rectangle () ;
extern int Draw_Jackson_Focus_Triangle () ;

extern int Interface_Draw_Jackson (int (*function_name () ) ) ;
extern int Line_To (int x1, int y1, int x2, int y2) ;

extern int	Draw_Circle( float x, float y, float r ) ;
// 20240625
extern int Draw_Circle_Line (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;

//20240721
extern int Full_Triangle ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;
extern int Full_Square ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;

//20240725
int Draw_Circle_Line_Fraction (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;
int Full_Square_Fix1 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;
int Full_Square_Fix2 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;
// 20240822
int Full_Square_Fix3 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;


// 20240917
extern int Load_Inifile_Jackson ( ) ;
extern int Read_Inifile_Jackson (char* inifile) ;


// 20240924
extern int Full_Box1 ( int x1, int y1, int width, int height) ;
extern int Full_Box2 ( int x1, int y1, int width, int height) ;
extern int Initialize_Full_Box_Ifnot () ;

// 20240925
extern int File_Print_Function (char* file_name, int* point_func, int num, int max );
extern int File_Print_Function_Full_Box ();

// 20241008
extern int Read_Menufile_Jackson (char* menufile) ;
extern int Load_Menufile_Jackson ( ) ;

// 20241016
extern int file_print_stack_menu (char* file_print) ;
extern int File_Write_Stack_Menu ();
extern int file_code_stack_menu (char* file_code) ;
extern int File_Code_Stack_Menu ();

extern int print_stack_menu ();
extern int set_debug_param_msg_num ( int num);

// 20250108
extern int Background_Points_Sampling ();
extern int Background_Draw_Messages ();
extern int Background_Button_OK_Cancel ();

// 20250128
extern int Organize_Bones (int type);
extern int Initialize_Organize_Bones ();
extern int Release_Organize_Bones ();
// x extern int Draw_Organize_Bones (vPoint* points, int num);
// x extern int Print_Organize_Bones (vPoint* points, int num) ;

extern int Stack_Focus_Rect (ANIMATION_FOCUS* r) ;
extern int Print_Refresh_Focus_Focus_Rects ();
extern ANIMATION_FOCUS* Pop_Focus_Rect ();

extern int Get_Font_Colour ( RGBT *rgbt ) ;
extern int draw_circle_line_to_003_Normal ( double i, double j, float base, int skip, int type ) ;
extern int draw_circle_line_to_003_Normal_05 ( double i, double j, float base, int skip, int type ) ;
extern int draw_circle_line_to_003 ( double i, double j, float base, int skip, int type ) ;
extern int check_break_line_to_003_01 ( double i, double j, int flag, int x2, int y2 ) ;
extern int check_break_line_to_003_02 ( double i, double j, int flag, int cnt, int* skip ) ;
extern int debug_print_msg_param ();

extern Logging log_001;
extern LOG_001* dlog_001;


extern ANIMATION_FOCUS_FRAME *p_jackson;

extern READ_PPM m_read_ppm;
extern READ_PPM m_read_ppm_002;

extern READ_PGM m_read_pgm;
extern READ_PGM m_read_pgm_002;

#endif
