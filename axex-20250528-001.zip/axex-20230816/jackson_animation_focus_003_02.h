#ifndef _JACSON_ANIMATION_FOCUS_003_02_H_
#define _JACSON_ANIMATION_FOCUS_003_02_H_

extern int Draw_Circle_Line_005 (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;
extern int Draw_Line_and_Focus ();
extern int Draw_Line_and_Focus_thin ();
extern int Set_Debug_Sleep_003_02 (int value );
extern int Draw_Line_and_Focus_thin_axex ();


#endif
