// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "something_word.h"

#include "wEvent.h"
#include "wButton.h"
#include "wButtonController.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
#include "display_threeD.h"

// CursolNumber is public.
//
//
//
wButtonController::wButtonController () {

	this->mode = 0;
	this->number_button = 0;
	AryButton = nullptr;
}

//
//
//
//
void wButtonController::selectButton ( ) {

	if( this->CursolNumber < 0 ) {
		this->CursolNumber = this->number_button -1;
		//return;
	}

	if( this->CursolNumber >= this->number_button ) {
		this->CursolNumber = 0;
		//return;
	}

	for ( int i=0; i<this->number_button; i++ )
		AryButton[ i ]->setMode( 0 );

	AryButton[ this->CursolNumber ]->setMode( 1 );

}

//
//
//
//
//
void wButtonController::setEvent ( wEvent* evt ) {

	this->event = evt;
}

// 186: colon
// 187: colon
//
//
//
void wButtonController::Process () {
	printf("wButtonController::Process: %d / %d<-WM_PAINT wParam %d lParam %d this->event->uMsg:%d *(this->event->uMsg)=%d \r\n", *(this->event->uMsg), WM_PAINT, this->event->wParam, this->event->lParam, this->event->uMsg, *(this->event->uMsg) );

	Processed = 0;

// 20190406
//	switch ( *( this->event->uMsg ) ) {
	switch ( this->event->Type ) {
	case WM_CREATE:
		Processed = 1;
		break;
	case WM_CHAR:
		ProcessWmChar ();
		Processed = 1;
		break;
	case WM_CLOSE:
		Processed = 1;
		break;
	case WM_PAINT:
		printf("wButtonController::WM_PAINT:\r\n");
		ProcessWmPaint ();
		Processed = 1;
		break;
	case WM_COMMAND:
		Processed = 1;
		break;
	case WM_KEYUP:
		// Passed at 20190406
		ProcessWmKeyup ();
		Processed = 1;
		break;
	case WM_KEYDOWN:
		Processed = 1;
		break;
	case WM_DESTROY:
		Processed = 1;
		break;
	case WM_ENDSESSION:
		Processed = 1;
		break;
	case WM_LBUTTONDOWN:
		Processed = 1;
		break;
	case WM_LBUTTONDBLCLK:
		Processed = 1;
		break;
	case WM_RBUTTONDBLCLK:
		Processed = 1;
		break;
	case WM_SIZE:
		Processed = 1;
		break;
	default:
		Processed = 2;
		break;
	}

	//exit(-1); // it does work and through :20191112
}

// it doesn't work and throuh here: 20191112
//
//
void wButtonController::initialize( int m ) {

	printf("initialize %d\r\n", this->CursolNumber);
	//exit(-2); // it does work: 20191112 at 8.

	switch( this->CursolNumber ) {
	case 0:
		// list_directory ();
		break;
	case 2:
		//something_word_initialize ();
		display_threeD_screen_initialize_002 ();
		//printf( "display_threeD_screen_initialize_002 ():" );
		//exit(-1);
		break;
	case 3:
		printf( "display_threeD_screen_initialize_003 ():" );
		exit(-1);
		break;
	case 8:
		switch( mode_rails ) {
		case 0:
			display_threeD_screen_initialize ();
			break;
		case 1:
			display_threeD_screen_initialize_OnRails ();
			break;
		}
		break;
	default:
		break;
	}

	printf("initialize %d ends.\r\n", this->CursolNumber);
	//exit(-2); // it does work: 20191112 at 8.
}

//
//
//
//
//
void wButtonController::ProcessWmKeyup () {
	int key_w = this->event->wParam;
	int m_mode = this->event->main_mode;

	printf("wButtonController::ProcessWmKeyup: Starts:");
	switch ( this->event->main_mode ) {
	case -2:
		// modified 20191112
		// keyup_something_word ( hWnd, key_w, &m_mode );
		// keyup_something_word ( this->event->hWnd, key_w, &m_mode );
		// exit(-1); // it does not work here: 20191112
		break;
	default:
		//  8 Backspace
		// 17 Ctl
		// 13 Enter
		// 27 ESC
		switch ( key_w ) {
		case 13:
			m_mode = this->CursolNumber;
			initialize( m_mode );
			call_once_key = 1;
			break;
		case 17: // Changing mode to command mode means select button because it equals expectancy of events, in this case edit command.
			this->selectButton( (char *) "Edit - Ctl -");
			break;
		case 27:
			escape_action( m_mode );
			//m_mode = -1; // means f
			// screen.
			call_once_key = 1;
			break;
		case 37:
			exit(-1);
			break;
		case 38:
			this->CursolNumber--;
			this->selectButton( );
			call_once_key = 1;
			break;
		case 39:
			break;
		case 40:
			this->CursolNumber++;
			this->selectButton( );
			call_once_key = 1;
			break;
		}
		break;
	}

	this->event->main_mode = m_mode;

	printf("wButtonController::ProcessWmKeyup: Ends:");

	// InvalidateRect( this->event->hWnd, NULL, TRUE);
	// exit(-2); // it does work here: 20191112
}

void wButtonController::ProcessWmChar () {

	int key_w = this->event->wParam;

	switch ( this->event->main_mode ) {
	case -2:
		// keyup_something_word ( hWnd, key_w, &m_mode );
		// 20190122
		// keyup_something_word ( this->event->hWnd, key_w, &m_mode );
		// 20190403
		// getchar_something_word_proc( this->event->hWnd, this->event->Type, this->event->wParam, this->event->lParam );
		break;
	default:
		//  8 Backspace
		// 17 Ctl
		// 13 Enter
		// 27 ESC
		switch ( key_w ) {
		case 13:
			this->event->main_mode = this->CursolNumber;
//			initialize( this->event->main_mode );
			this->call_once_key = 1;
			break;
		case 17: // Changing mode to command mode means select button because it equals expectancy of events, in this case edit command.
			this->selectButton( (char *) "Edit - Ctl -");
			break;
		case 27:
			this->escape_action( this->event->main_mode );
			//m_mode = -1; // means 
			// screen.
			this->call_once_key = 1;
			break;;
		case 37: // Left
			exit(-1);
			break;
		case 38:
			this->CursolNumber--;
			this->selectButton( );
			this->call_once_key = 1;
			break;
		case 39:
			break;
		case 40:
			this->CursolNumber++;
			this->selectButton( );
			this->call_once_key = 1;
			break;
		}
		break;
	}

	InvalidateRect( this->event->hWnd, NULL, TRUE);
	printf("Called: InvalidateRect( this->event->hWnd, NULL, TRUE) %d \r\n", this->event->main_mode );

	//exit(-2); // it does work here: 20191112
}


//
//
// 27 ESC
void wButtonController::escape_action( int mode ) {
	//int result;

	/* if ( mode == 2 ) {
		result = something_word_escape ();
		if ( result == 1) {
			// to main window
			this->main_mode = -1;
		}
		return;
	} */

	this->event->main_mode = -1; // means main screen.
}

//
//
//
//
//
void wButtonController::ProcessWmChar_ () {
	int succ;

	//
	//
	// Send wTriger tp ButtonController
	// btc.setTriger( hTriger );


	switch ( this->event->main_mode ) {
	case 0:
		break;
	}

	switch( this->event->wParam ) {
	case 'w':
		break;
	}


/*	switch( m_mode ) {
		case 0:
			break;
		case 1:
			break;
		case 2:
			getchar_something_word_proc( hWnd, uMsg, wParam, lParam );
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		case 8:
			// do not write anything
			break;
		case 9:
			//getchar_display_threeD_proc( hWnd, uMsg, wParam, lParam );
			break;
	}
*/

	// for Edit
	/* if ( btc.CursolNumber == 7 ) {

		switch( key_w ) {
		case 'v':
			//succ_paste = ReadClip ( hWnd, m_pastestr );
			EditPaste();
			m_pastestr = m_concat(m_pastestr, ":did paste");
			break;
		case 'r':
			show_garbage_collection () ;
			m_pastestr = "show_garbage_collection () ;";
			// multithread_print();
			break;
		default:
			break;
		}

		if ( call_once_key == 1 ) {
			call_once_key = 0;
			//break;
		}


		switch( key_w ) {
		case 'o':
			btc.selectButton( (char *) "File Open - o -");
			break;
		case 's':
			btc.selectButton( (char *) "Something Sentence - s -");
			break;
		case 'w':
			btc.selectButton( (char *) "Something Word - w -");
			break;
		case 'd':
			btc.selectButton( (char *) "Dictionary Link - d -");
			break;
		case 'l':
			btc.selectButton( (char *) "Web Link - l -");
			break;
		case 'p':
			btc.selectButton( (char *) "Print Html - p -");
			break;
		case 'e':
			btc.selectButton( (char *) "Exit - e -");
			break;
		case '3':
			btc.selectButton( (char *) "Display 3D - 3 -");
			break;
		}


	} */
}

//
//
//
//
//



//
//
//
//
//
void wButtonController::ProcessWmPaint () {
	static char ex_str[2048];
	static char str[2048];
	static char num_str[2048];
	static char pastestr[1024];

	//PAINTSTRUCT ps;
	RECT msg_key, msg_clip, msg_replace;
	FILE * pFile;
	RECT msg;
	int succ;

	//HDC hdc = BeginPaint(this->event->hWnd, &ps);
	HDC hdc = this->event->hDc;
	HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );

	int key_w = this->event->wParam;
	int key_l = this->event->lParam;

	itoa(key_w, num_str, 10);
	strcpy( str, "b key param: ");
	strcat( str, num_str );

	itoa(key_l, num_str, 10);
	strcat( str, ":" );
	strcat( str, num_str );

	itoa(this->key_state, num_str, 10);
	strcat( str, ":" );
	strcat( str, num_str );

	itoa( this->CursolNumber, num_str, 10);
	strcat( str, ":" );
	strcat( str, num_str );

	printf("this->event->main_mode = %d\r\n", this->event->main_mode);

	switch ( this->event->main_mode ) {
	case -2:
		break;
	default:
		printf("default:\r\n");
		SelectObject(hdc, hPen);

		// 100
		SetRect( &msg_key, 300, 100, 400, 250 );
		DrawText( hdc, TEXT( str ), -1, &msg_key, DT_NOCLIP );

		// 200
		SetRect(&msg_clip, 300, 200, 400, 250);
		DrawText( hdc, TEXT( this->main_pastestr ), -1, &msg_clip, DT_NOCLIP);

		// 300
		SetRect(&msg_replace, 300, 300, 400, 350);
		DrawText( hdc, TEXT( this->main_replace_selection ), -1, &msg_replace, DT_NOCLIP);

		// message
		SetRect( &msg, 300, 400, 400, 450);
		if ( succ == -1 ) {

			DrawText( hdc, TEXT( "Could not read clipboard" ), -1, &msg, DT_NOCLIP);
		} else {

			ex_str[0] = '\0';
			itoa( this->CursolNumber, num_str, 10);
			strcat( num_str, ":" );
			strcat( ex_str, num_str );
			itoa( this->succ_paste, num_str, 10);
			strcat( ex_str, num_str );
			DrawText( hdc, TEXT( ex_str ), -1, &msg, DT_NOCLIP);
		}

		this->drawButtons( hdc );
		//EndPaint(this->event->hWnd, &ps);
		break;
	}

	//EndPaint( this->event->hWnd, &ps);
}

//
//
//
//
//
void wButtonController::setTriger ( int h_triger ) {
	hTriger = h_triger;
}

//
//
//
//
//
void wButtonController::selectButton ( char* btn_nm ) {
	int ret;

	for ( int i=0; i<this->number_button; i++ ) {
		
		ret = strcmp( AryButton[ i ]->button_name, btn_nm );
		if ( ret == 0 ) {
			CursolNumber = i;
			AryButton[ i ]->setMode( 1 );
		} else
			AryButton[ i ]->setMode( 0 );
	}
}

//
//
//
//
//
void wButtonController::addButton ( wButton* b ) {
	if ( this->number_button ==0 || AryButton == nullptr ) {
		AryButton = ( wButton** ) malloc ( sizeof( wButton* ) * 1 );
		AryButton[ this->number_button ] = b;
		this->number_button = 1;
		return;
	}

	this->number_button++;
	AryButton = (wButton **) realloc( AryButton, this->number_button * sizeof(wButton *) );
	AryButton[ this->number_button - 1] = b;

}

//
//
//
//
//
void wButtonController::drawButtons ( HDC hdc ) {

	printf("void wButtonController::drawButtons ( HDC hdc ): Starts \r\n");

	for ( int i=0; i<this->number_button; i++ ) {
		AryButton[ i ]->drawButton( hdc );
		printf("AryButton %d = %d \r\n", i, AryButton[ i ]->getMode() );
	}

	printf("void wButtonController::drawButtons ( HDC hdc ): Ends\r\n");
	//exit(-2);

}

//( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
//
//
// added 20190118
//
void wButtonController::kickEveentButtons ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	for ( int i=0; i<this->number_button; i++ ) {
		AryButton[ i ]->kickEveentButton( hWnd, uMsg, wParam, lParam );
	}

}

// void
