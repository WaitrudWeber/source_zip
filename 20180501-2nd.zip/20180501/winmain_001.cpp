//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <Windows.h>
#include <windowsx.h>

#include "array_counter.h"
#include "button.h"

//------------------------------------------------
// Macro for switch
//------------------------------------------------
#define CASE        break;case
#define DEFAULT     break;default

//------------------------------------------------
// Constant for Screen
//------------------------------------------------
#define SCREEN_STYLE        (WS_OVERLAPPEDWINDOW ^ (WS_THICKFRAME|WS_MAXIMIZEBOX))
#define SCREEN_WIDTH        (640)       // Screen Width (32dot x 20)
#define SCREEN_HEIGHT       (480)       // Screen Height (32dot x 15)

//------------------------------------------------
// Define Error message
//------------------------------------------------
#define ERRMSG_TITLE        TEXT("WinMain Function")
#define ERRMSG_WINREG       TEXT("Window Class can not be set.")
#define ERRMSG_CREATE       TEXT("Window can not be created.")

//------------------------------------------------
// Window Procedure
//------------------------------------------------
static LRESULT CALLBACK mainWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch ( uMsg ){
        CASE WM_CREATE:
            /*
            initialization
            */
        CASE WM_CLOSE:
            /*
            Deposition
            */
            DestroyWindow( hWnd );
        CASE WM_DESTROY:
            PostQuitMessage( 0 );
        CASE WM_PAINT:
        {
			//PAINTSTRUCT     ps;
			//HDC             hDC;
            
			//hDC = BeginPaint( hWnd, &ps );
			//HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);SelectObject(hDC, hPen);

			// drawing rectangle // 20180430
			// Parameters
			//hdc [in]
			//A handle to the device context.
			//nLeftRect [in]
			//The x-coordinate, in logical coordinates, of the upper-left corner of the rectangle.
			//nTopRect [in]
			//The y-coordinate, in logical coordinates, of the upper-left corner of the rectangle.
			//nRightRect [in]
			//The x-coordinate, in logical coordinates, of the lower-right corner of the rectangle.
			//nBottomRect [in]
			//The y-coordinate, in logical coordinates, of the lower-right corner of the rectangle.
			//Rectangle( hDC, 100, 100, 100, 100 );
			//EndPaint( hWnd, &ps );

            PAINTSTRUCT ps;
//            HFONT hFont;
//            RECT rect;
            RECT rect_2;

			HDC hdc = BeginPaint(hWnd, &ps);
			HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);
			SelectObject(hdc, hPen);
//			Ellipse(hdc, 100, 200, 400, 400);
//			Ellipse(hdc, 300, 300, 500, 510);
//			Rectangle( hdc, 100, 100, 200, 200 );
//			DeleteObject(hPen);


            //The font face name will be Impact.
//            hFont = CreateFont(48,0,0,0,FW_DONTCARE,FALSE,TRUE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
//                CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY, VARIABLE_PITCH,TEXT("Impact"));
//            SelectObject(hdc, hFont);
//            //Sets the coordinates for the rectangle in which the text is to be formatted.
//           SetRect(&rect, 100,100,700,200);
//            SetTextColor(hdc, RGB(255,0,0));
//            DrawText(hdc, TEXT("Drawing Text with Impact"), -1, &rect, DT_NOCLIP);

            SetRect(&rect_2, 300, 300, 400, 350);
			drawButton ( hdc, (char *)"File Open", &rect_2 );

			EndPaint(hWnd, &ps);
        }
        CASE WM_ENDSESSION:         PostMessage( hWnd, WM_CLOSE, 0, 0 );
        CASE WM_LBUTTONDOWN:        SendMessage( hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
        CASE WM_LBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_TOPMOST,   0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
        CASE WM_RBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
        DEFAULT:                    return DefWindowProc( hWnd, uMsg, wParam, lParam );
    }
    return 0;
}


//------------------------------------------------
// Set Window Procedure
//------------------------------------------------
static ATOM funcWindowClass( HINSTANCE hInstance, LPCTSTR lpClassName )
{
    WNDCLASSEX wcex = { 0 };
    
    wcex.cbSize         = sizeof(WNDCLASSEX);
    wcex.style          = CS_DBLCLKS;
    wcex.lpfnWndProc    = mainWindowProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon( NULL, IDI_APPLICATION );
    wcex.hIconSm        = LoadIcon( NULL, IDI_APPLICATION );
    wcex.hCursor        = LoadCursor( NULL, IDC_ARROW );
    wcex.hbrBackground  = (HBRUSH)GetStockObject( WHITE_BRUSH );
    wcex.lpszMenuName   = NULL;
    wcex.lpszClassName  = lpClassName;
    return RegisterClassEx( &wcex );
}

//------------------------------------------------
// Set Window Size
//------------------------------------------------
static VOID funcSetClientSize( HWND hWnd, LONG sx, LONG sy )
{
    RECT rc1;
    RECT rc2;
    
    GetWindowRect( hWnd, &rc1 );
    GetClientRect( hWnd, &rc2 );
    sx += ((rc1.right - rc1.left) - (rc2.right - rc2.left));
    sy += ((rc1.bottom - rc1.top) - (rc2.bottom - rc2.top));
    SetWindowPos( hWnd, NULL, 0, 0, sx, sy, (SWP_NOZORDER|SWP_NOOWNERZORDER|SWP_NOMOVE) );
}

//------------------------------------------------
// Creation of Window
//------------------------------------------------
static HWND funcCreateWindow( HINSTANCE hInstance, LPCTSTR lpClassName, LPCTSTR lpTitleName, int nCmdShow )
{
    HWND hWnd = CreateWindowEx(
        0,                  // Expandation of Window Style
        lpClassName,        // Window Class Name
        lpTitleName,        // Window Title
        SCREEN_STYLE,       // Window Style
        CW_USEDEFAULT,      // Horizental window position
        CW_USEDEFAULT,      // Vertical window position
        CW_USEDEFAULT,      // Window width
        CW_USEDEFAULT,      // Window height
        NULL,               // Parent window handle
        NULL,               // handle of Menu bar
        hInstance,          // handle of Instance
        NULL );             // Put parameter Creation of window
    
    if ( hWnd != NULL ){
        funcSetClientSize( hWnd, SCREEN_WIDTH, SCREEN_HEIGHT );
        ShowWindow( hWnd, nCmdShow );
        UpdateWindow( hWnd );
    }
    return hWnd;
}

//------------------------------------------------
// Main Function
//------------------------------------------------
extern int WINAPI _tWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow )
{
    LPCTSTR lpClassName = TEXT("Lesson5WndClass");
    LPCTSTR lpTitleName = TEXT("Drawing Shapes");
    MSG Msg;
    
    // Set Window Class
    if ( funcWindowClass(hInstance,lpClassName) == 0 ){
        MessageBox( NULL, ERRMSG_WINREG, ERRMSG_TITLE, (MB_OK|MB_ICONERROR) );
        return -1;
    }
    // Creation of Window
    if ( funcCreateWindow(hInstance,lpClassName,lpTitleName,nCmdShow) == NULL ){
        MessageBox( NULL, ERRMSG_CREATE, ERRMSG_TITLE, (MB_OK|MB_ICONWARNING) );
        return -2;
    }
    // Message Loop
    while ( GetMessage(&Msg,NULL,0,0) > 0 ){
        TranslateMessage( &Msg );
        DispatchMessage( &Msg );
    }
    UNREFERENCED_PARAMETER( hPrevInstance );
    UNREFERENCED_PARAMETER( lpCmdLine );
    return Msg.wParam;
}

//------------------------------------------------------------------------------
// End of Lesson5.cpp
//------------------------------------------------------------------------------

//------------------------------------------------
// Window Procedeure
//------------------------------------------------
// static LRESULT CALLBACK mainWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
// {
//     switch ( uMsg ){
//         CASE WM_CREATE:
//             /*
//             Initialization
//             */
//         CASE WM_CLOSE:
//             /*
//             Deposition
//             */
//             DestroyWindow( hWnd );
//         CASE WM_DESTROY:
//             PostQuitMessage( 0 );
//         CASE WM_PAINT:
//         {
//             PAINTSTRUCT     ps;
//             HDC             hDC;
//             
//             hDC = BeginPaint( hWnd, &ps );
//             /*
//             Drawing
//             */
//             EndPaint( hWnd, &ps );
//         }
//         CASE WM_ENDSESSION:         PostMessage( hWnd, WM_CLOSE, 0, 0 );
//         CASE WM_LBUTTONDOWN:        SendMessage( hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
//         CASE WM_LBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_TOPMOST,   0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
//         CASE WM_RBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
//         DEFAULT:                    return DefWindowProc( hWnd, uMsg, wParam, lParam );
//     }
//     return 0;
// }




