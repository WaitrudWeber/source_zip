#include <windows.h>
#include <math.h>
#include <iostream>
#include <mmsystem.h>
//#include <amstream.h>
//#include <mmstream.h>

#include "sounds-011.h"

//#pragma comment(lib, "Winmm.lib")

using namespace std;
//dummy
HWAVEOUT am_waveOut; // Handle to sound card output
WAVEFORMATEX am_waveFormat; // The sound format
WAVEHDR am_waveHeader; // WAVE header for our sound data
HANDLE am_done; // Event Handle that tells us the sound has finished being played.


int sbuffer[11025 * 2];

//dummy
void play_001();

// Very Thanks to https://stackoverflow.com/questions/19894384/simple-sounds-in-c?newreg=f9687df41b574a8f8f34db83b5c4a16a
// > mingw32-g++.exe main.o .\sounds-011.o -o winmain_011.exe
int main() {
//	IMultiMediaStream *pMMStream;

//	SoundEffect* sound_011 = new SoundEffect ();
	SoundEffect* sound_011 = new SoundEffect ( sbuffer, 11025 * 2 );
	sound_011->Play();

	return 0;
}


void play_001()
{
	if (waveOutOpen(&am_waveOut, 0, &am_waveFormat, (DWORD) am_done, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) 
	{
		 cout << "Sound card cannot be opened." << endl;
		return;
	}
}

//https://docs.microsoft.com/en-us/previous-versions/windows/desktop/api/mmstream/nn-mmstream-imultimediastream
//https://docs.microsoft.com/en-us/windows/win32/directshow/audio-streaming-sample-code
//https://www.exefiles.com/en/h/amstream-h/
//https://www.exefiles.com/en/h/mmstream-h/
/*HRESULT RenderStreamToDevice(IMultiMediaStream *pMMStream)
{
    WAVEFORMATEX wfx;
    #define DATA_SIZE 5000

    IMediaStream        *pStream = NULL;
    IAudioStreamSample  *pSample = NULL;
    IAudioMediaStream   *pAudioStream = NULL;
    IAudioData          *pAudioData = NULL;

    HRESULT hr = pMMStream->GetMediaStream(MSPID_PrimaryAudio, &pStream);
    if (FAILED(hr))
    {
        return hr;
    }

	return S_OK;
}*/
