// button controler needs the function which changes button cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.


class wButtonController {
	public:
		int CursolNumber;
		int number_button;

	private:
		int mode;
		wButton **AryButton;

	public:
		wButtonController();
		void addButton ( wButton* b );
		void drawButtons ( HDC hdc );
		void selectButton ( char* btn_nm );

		//void setButton( int xx, int yy, int h, int w);
		//int wdrawButton( HDC hdc, char *button_name, RECT rect );
		//int aaa();
		//int drawButton( HDC hdc );
		//void setMode ( int m );

};



