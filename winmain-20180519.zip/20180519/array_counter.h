

extern int array_count( char *ary );
extern char* concat( char *head, char *tail );
