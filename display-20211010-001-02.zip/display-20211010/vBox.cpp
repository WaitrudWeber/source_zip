#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "vBox.h"
#include "vCalculation.h"

vBox::vBox ( float xx1, float yy1, float zz1, float xx2, float yy2, float zz2 ) {

	this->x1 = xx1;
	this->y1 = yy1;
	this->z1 = zz1;

	this->x2 = xx2;
	this->y2 = yy2;
	this->z2 = zz2;

	for (int i = 0; i < 8; i++) {
		this->p[i] = memorizevPoint( 0.0f, 0.0f, 0.0f );
	}

	printf("Val:%f %f %f - %f %f %f\r\n", xx1, yy1, zz1, xx2, yy2, zz2 );
	printf("Set:%f %f %f - %f %f %f\r\n", this->x1, this->y1, this->z1, this->x2, this->y2, this->z2 );

	this->Calculation ();
}

void vBox::Calculation () {
	this->p[0]->setPoint ( this->x1, this->y1, this->z1 );
	this->p[1]->setPoint ( this->x1, this->y1, this->z2 );
	this->p[2]->setPoint ( this->x2, this->y1, this->z1 );
	this->p[3]->setPoint ( this->x2, this->y1, this->z2 );
	this->p[4]->setPoint ( this->x1, this->y2, this->z1 );
	this->p[5]->setPoint ( this->x1, this->y2, this->z2 );
	this->p[6]->setPoint ( this->x2, this->y2, this->z1 );
	this->p[7]->setPoint ( this->x2, this->y2, this->z2 );
}

void vBox::Print () {

	for (int i = 0; i < 8; i++) {
		printf("i:%d ", i );
		this->p[i]->print();
	}

}
