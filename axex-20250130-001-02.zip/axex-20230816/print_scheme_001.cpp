#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "wTextarea.h"
#include "clipboard.h"
#include "Print.h"	//ADD: 20191228

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"
#include "vCurveCalculation.h"

#include "vIntersection_001.h"
#include "vIntersection.h"

#include "vScreenCG.h"
#include "vScreen.h"
//#include "vLine.h"
//#include "vCircle.h"

#include "vCalculation.h"

#include "vAxex_2D.h"
#include "vDisplayController.h"


#include "vPointStructure.h"
#include "vPointLinear.h"
#include "display_threeD.h"

#include "v3dCalculation.h"

#include "vReturnableParam.h"

#include "print_scheme_001.h"


int function_001_01 ():

//
int function_001_01 ()
{
	FILE *fp;

	fp = fopen( "001-filename-001\.txt","wb");
	char* func_key = (char*)"wButton button_o";
	fprintf("	%s_%0d () {\r\n//($code_block)}\r\n", func_key, i );

	return 0;
}
