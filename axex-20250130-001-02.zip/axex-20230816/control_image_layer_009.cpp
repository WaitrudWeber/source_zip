#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

//#include <realloc_001.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"


#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"

#include "read_csv_004.h"
#include "read_csv_005.h"

#include "control_image_layer_009.h"

GRID_MATRIX_004* im_grid_matrix_009 = NULL;

static Logging* log_001;
static LOG_001* dlog_001 = NULL;


int putthegray_009 ( int ii, int jj, char* word ) ;
int	initialize_im_grid_matrix_009 () ;
int putthegray_009_01 ( int ii, int jj, char* word ) ;
int putthegray_009_02 ( int ii, int jj, char* word ) ;
int putthegray_009_03 ( int ii, int jj, char* word ) ;

char*** putthegray_009_03_height ( char*** img, int start_i, int width, int height ) ;


int Set_Logging_Control_Image_Layer_009 (Logging* logg) ;
int Caribration_Control_Image_Layer_009 () ;

GRID_MATRIX_004* get_im_grid_matrix_009 () ;
int putthegray_009_04 ( int ii, int jj, char* word ) ;

int Set_Img_Width_Height (char*** img, int width, int height ) ;
int Free_Img_Width_Height () ;


char* temp_literature = (char*)"-";

char* log_alloc = (char*)"001-log-allallocation-001\.ntxt";

int delay_time_009 = 250;

//
GRID_MATRIX_004* get_im_grid_matrix_009 () {

	return im_grid_matrix_009;
}

int Free_Img_Width_Height () {
	int i, j;

	if ( im_grid_matrix_009 == NULL ) {
		return -1;
	}

	for ( i = 0; i< im_grid_matrix_009->width_index_num_max; i++ ) {
		if ( im_grid_matrix_009->grid_matrix[i] != NULL )
			free( (char*)im_grid_matrix_009->grid_matrix[i] );
	}

	free(im_grid_matrix_009->grid_matrix);
	return 0;
}

int Set_Img_Width_Height (char*** img, int width, int height ) {

	if ( im_grid_matrix_009 == NULL ) {
		im_grid_matrix_009 = (GRID_MATRIX_004*) malloc ( sizeof (GRID_MATRIX_004) );
		if ( im_grid_matrix_009 == NULL ) {
			exit(-1);
		}
	}

	im_grid_matrix_009->width_index_num_max = width;
	im_grid_matrix_009->height_index_num_max = height;
	im_grid_matrix_009->grid_matrix = (char***)img;

	return 0;
}


// control_image_layer_010.cpp
// size of word is 4.
//
int putthegray_009 ( int ii, int jj, char* word ) {
	int a, i, rmode, ri;
	char msg[255];

	printf("int putthegray_009 ( int ii, int jj, char* word ) starts.\r\n");
	printf("im_grid_matrix_009 |%p| ii %d log_001|%p|\r\n", im_grid_matrix_009, ii, log_001 );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_009 ( int ii, int jj, char* word ) starts." );

	if ( im_grid_matrix_009 == NULL ) {
		a = initialize_im_grid_matrix_009 ();
	}

	printf("int putthegray_009 ( int ii, int jj, char* word ) block 001.\r\n");
	printf("im_grid_matrix_009 |%p| ii %d\r\n", im_grid_matrix_009, ii );
	printf("im_grid_matrix_009->width_index_num_max %d ii %d\r\n", im_grid_matrix_009->width_index_num_max, ii );

	rmode = 0;
	if (im_grid_matrix_009->width_index_num_max <= ii ) {
		rmode = 1;
		ri = im_grid_matrix_009->width_index_num_max;
		for ( i= 0; ii >= im_grid_matrix_009->width_index_num_max; i++ ) {
			im_grid_matrix_009->width_index_num_max *= 2;
		}
		printf("out1 i %d jj %d width_index_num_max %d\r\n", i, jj, im_grid_matrix_009->width_index_num_max );
		im_grid_matrix_009->grid_matrix = (char***)realloc ( im_grid_matrix_009->grid_matrix , sizeof(char**) * im_grid_matrix_009->width_index_num_max );
		for ( i = ri; i< im_grid_matrix_009->width_index_num_max; i++ ) {
			printf("out9-1 i %d / %d matrix|%p| -> ", i, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->grid_matrix[i] );
			im_grid_matrix_009->grid_matrix[i] = (char**)malloc ( sizeof(char*) * im_grid_matrix_009->height_index_num_max );
			printf(" matrix|%p| \r\n", i, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->grid_matrix[i] );
		}
	}

	printf("int putthegray_009 ( int %d, int %d, char* word ) block 002.\r\n", ii, jj);

	if (im_grid_matrix_009->height_index_num_max <=jj ) {
		rmode = 2;
		printf("in i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
		for ( i= 0; jj >= im_grid_matrix_009->height_index_num_max; i++ ) {
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
			im_grid_matrix_009->height_index_num_max *= 2;
		}
		printf("out2 i %d jj %d width_index_num_max %d height_index_num_max %d \r\n", i, jj, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max );
		for ( i = 0; i< im_grid_matrix_009->width_index_num_max; i++ ) {
			im_grid_matrix_009->grid_matrix[i] = (char**)realloc ( im_grid_matrix_009->grid_matrix[i], sizeof(char*) * im_grid_matrix_009->height_index_num_max );
			printf("out2-1 im_grid_matrix_009->grid_matrix[%d]|%p|size %d\r\n", i, im_grid_matrix_009->grid_matrix[i], im_grid_matrix_009->height_index_num_max );
		}
	}

	printf("int putthegray_009 ( int %d, int %d, char* word ) block 003.\r\n", ii, jj);

	sprintf( msg, "putthegray_009 %d %d grid matrix %s", ii, jj, (char*) im_grid_matrix_009->grid_matrix[ii][jj]  );
	dlog_001 = log_001->update_log ( (char*) msg );

	csvafree_005(im_grid_matrix_009->grid_matrix[ii][jj]);
	im_grid_matrix_009->grid_matrix[ii][jj] = (char*) csvcopyof_005 ( word );


	printf("int putthegray_009 ( int %d, int %d, char* word ) block 004.\r\n", ii, jj);

	sprintf( msg, "putthegray_009 %d %d word %s", ii, jj, word  );
	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_009 ( int ii, int jj, char* word ) end." );

	printf("int putthegray_009 ( int ii, int jj, char* word ) ends.\r\n");
	return 0;
}

//
int	initialize_im_grid_matrix_009 () {
	int i, j;
	char msg[255];
	Log_Add ( log_alloc, "int	initialize_im_grid_matrix_009 () starts.", 0);

	im_grid_matrix_009 = (GRID_MATRIX_004*) malloc ( sizeof (GRID_MATRIX_004) );
	if ( im_grid_matrix_009 == NULL ) {
		exit(-1);
	}

	im_grid_matrix_009->width_index_num_max = 8;
	im_grid_matrix_009->height_index_num_max = 8;

	im_grid_matrix_009->grid_matrix = (char***)malloc ( sizeof(char**) * im_grid_matrix_009->width_index_num_max );

	sprintf( msg, "im_grid_matrix_009->grid_matrix |%p| im_grid_matrix_009->width_index_num_max=%d", im_grid_matrix_009->grid_matrix, im_grid_matrix_009->width_index_num_max );
	dlog_001 = log_001->update_log ( (char*) msg );

	sprintf( msg, "im_grid_matrix_009->grid_matrix |%p| im_grid_matrix_009->height_index_num_max=%d", im_grid_matrix_009->grid_matrix, im_grid_matrix_009->height_index_num_max );
	dlog_001 = log_001->update_log ( (char*) msg );

	for ( i = 0; i< im_grid_matrix_009->width_index_num_max; i++ ) {
		im_grid_matrix_009->grid_matrix[i] = (char**)malloc ( sizeof(char*) * im_grid_matrix_009->height_index_num_max );
		if ( im_grid_matrix_009->grid_matrix[i] == NULL ) {
			exit(-1);
		}
		for ( j = 0; j< im_grid_matrix_009->height_index_num_max; j++ ) {
			im_grid_matrix_009->grid_matrix[i][j] = (char*)csvcopyof_005 ("g");
		}
	}

	Log_Add ( log_alloc, "int	initialize_im_grid_matrix_009 () ends.", 1);

	return  0;
}


int putthegray_009_01 ( int ii, int jj, char* word ) {
	int a, i, rmode, ri;
	int j;
	char msg[255];

	printf("int putthegray_009_01 ( int ii, int jj, char* word ) starts.\r\n");
	printf("im_grid_matrix_009 |%p| ii %d log_001|%p|\r\n", im_grid_matrix_009, ii, log_001 );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_009_01 ( int ii, int jj, char* word ) starts." );

	if ( im_grid_matrix_009 == NULL ) {
		dlog_001 = log_001->update_log ( (char*)"im_grid_matrix_009 is NULL, so, ..." );
		a = initialize_im_grid_matrix_009 ();
	}

	printf("int putthegray_009_01 ( int ii, int jj, char* word ) block 001.\r\n");
	printf("im_grid_matrix_009 |%p| ii %d\r\n", im_grid_matrix_009, ii );
	printf("im_grid_matrix_009->width_index_num_max %d ii %d\r\n", im_grid_matrix_009->width_index_num_max, ii );

	rmode = 0;
	if (im_grid_matrix_009->width_index_num_max <= ii ) {
		rmode = 1;
		ri = im_grid_matrix_009->width_index_num_max;
		for ( i= 0; ii >= im_grid_matrix_009->width_index_num_max; i++ ) {
			printf("i %d ii %d width_index_num_max %d\r\n", i, ii, im_grid_matrix_009->width_index_num_max );
			im_grid_matrix_009->width_index_num_max *= 2;
			printf("i %d ii %d width_index_num_max %d\r\n", i, ii, im_grid_matrix_009->width_index_num_max );
		}
		printf("out9: i %d ii %d width_index_num_max %d\r\n", i, ii, im_grid_matrix_009->width_index_num_max );
		im_grid_matrix_009->grid_matrix = (char***)realloc ( im_grid_matrix_009->grid_matrix , sizeof(char**) * im_grid_matrix_009->width_index_num_max );
		for ( i = ri; i< im_grid_matrix_009->width_index_num_max; i++ ) {
			printf("out9-1 i %d / %d matrix|%p| -> ", i, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->grid_matrix[i] );
			im_grid_matrix_009->grid_matrix[i] = (char**)malloc ( sizeof(char*) * im_grid_matrix_009->height_index_num_max );
			printf(" [%d]/ %d height %d matrix|%p| \r\n", i, im_grid_matrix_009->width_index_num_max,im_grid_matrix_009->height_index_num_max, im_grid_matrix_009->grid_matrix[i] );
			// print
			if ( im_grid_matrix_009->grid_matrix[i] == NULL ) {
				printf("im_grid_matrix_009->grid_matrix[i] == NULL\r\n");
				exit(-1);
			}

			// set default o
			for ( i = ri; i< im_grid_matrix_009->width_index_num_max; i++ ) {
				for ( j = 0; j< im_grid_matrix_009->height_index_num_max; j++ ) {
					printf("( i %3d, j %3d) ->", i, j);
					im_grid_matrix_009->grid_matrix[i][j] = (char*)"-";
					printf( "|%p|%p|%s| as null|%p|\r\n", &(im_grid_matrix_009->grid_matrix[i][j]), im_grid_matrix_009->grid_matrix[i][j], im_grid_matrix_009->grid_matrix[i][j], NULL );
				}
			}

		}
	}

	printf("int putthegray_009_01 ( int %d, int %d, char* word ) block 002.\r\n", ii, jj, im_grid_matrix_009->grid_matrix[0] );
	printf("im_grid_matrix_009->height_index_num_max %d jj %d im_grid_matrix_009->grid_matrix[0]|%p|\r\n", im_grid_matrix_009->height_index_num_max, jj );

	if (im_grid_matrix_009->height_index_num_max <=jj ) {
		rmode = 2;
		printf("in i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
		for ( i= 0; jj >= im_grid_matrix_009->height_index_num_max; i++ ) {
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
			im_grid_matrix_009->height_index_num_max *= 2;
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
		}
		printf("out2 i %d jj %d width_index_num_max %d height_index_num_max %d \r\n", i, jj, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max );
		for ( i = 0; i< im_grid_matrix_009->width_index_num_max; i++ ) {
			im_grid_matrix_009->grid_matrix[i] = (char**)realloc ( im_grid_matrix_009->grid_matrix[i], sizeof(char*) * im_grid_matrix_009->height_index_num_max );
			printf("out2-1 im_grid_matrix_009->grid_matrix[%d]|%p|size %d\r\n", i, im_grid_matrix_009->grid_matrix[i], im_grid_matrix_009->height_index_num_max );
			// print
			if ( im_grid_matrix_009->grid_matrix[i] == NULL ) {
				printf("im_grid_matrix_009->grid_matrix[i] == NULL\r\n");
				exit(-1);
			}

			// set default o
			for ( i = 0; i< im_grid_matrix_009->width_index_num_max; i++ ) {
				for ( j = 0; j< im_grid_matrix_009->height_index_num_max; j++ ) {
					printf("( i %3d, j %3d) ->", i, j);
					im_grid_matrix_009->grid_matrix[i][j] = (char*)"-";
					printf( "|%p|%p|%s| as null|%p|\r\n", &(im_grid_matrix_009->grid_matrix[i][j]), im_grid_matrix_009->grid_matrix[i][j], im_grid_matrix_009->grid_matrix[i][j], NULL );
				}
			}

		}
	}

	printf("int putthegray_009_01 ( int %d, int %d, char* word ) block 003.\r\n", ii, jj);
	printf("msg|%p| log_001|%p| im_grid_matrix_009->grid_matrix[0][0]|%p| ( %d, %d ) max ( %d, %d )\r\n", (char*)msg, log_001, &(im_grid_matrix_009->grid_matrix[0][0]), ii, jj, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max );
	printf ( "im_grid_matrix_009->grid_matrix[%d][%d]=|%p|-> ", ii, jj, &(im_grid_matrix_009->grid_matrix[ii][jj]) );
	printf ( "|%s|\r\n", ii, jj, im_grid_matrix_009->grid_matrix[ii][jj] );

	sprintf( msg, "putthegray_009_01 %d %d grid matrix %s\0", ii, jj, (char*) im_grid_matrix_009->grid_matrix[ii][jj]  );
	printf("msg:%s\r\n", (char*)msg);
// x	dlog_001 = log_001->update_log ( (char*) msg );


	csvafree_005(im_grid_matrix_009->grid_matrix[ii][jj]);
	im_grid_matrix_009->grid_matrix[ii][jj] = (char*) csvcopyof_005 ( word );


	printf("int putthegray_009_01 ( int %d, int %d, char* word ) block 004.\r\n", ii, jj);

	sprintf( msg, "putthegray_009_01 %d %d word %s", ii, jj, word  );
	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_009_01 ( int ii, int jj, char* word ) end." );

	printf("int putthegray_009_01 ( int ii, int jj, char* word ) ends.\r\n");
	return 0;
}

int Set_Logging_Control_Image_Layer_009 (Logging* logg) {

	log_001 = logg;
	return 0;
}

//
int Caribration_Control_Image_Layer_009 () {
	int a;

	a = putthegray_009_01 ( 14, 16, (char*) "b" ) ;
	a = putthegray_009_01 ( 16, 17, (char*) "b" ) ;

	return 0;
}



int putthegray_009_02 ( int ii, int jj, char* word ) {
	int a, i, rmode, ri;
	int j;
	char msg[255];

	Log_Add ( log_alloc, "int putthegray_009_02 ( int ii, int jj, char* word ) starts.", 0);
	printf("int putthegray_009_02 ( int ii, int jj, char* word ) starts.\r\n");
	printf("im_grid_matrix_009 |%p| ii %d log_001|%p|\r\n", im_grid_matrix_009, ii, log_001 );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_009_02 ( int ii, int jj, char* word ) starts." );

	if ( im_grid_matrix_009 == NULL ) {
		dlog_001 = log_001->update_log ( (char*)"im_grid_matrix_009 is NULL, so, ..." );
		a = initialize_im_grid_matrix_009 ();
	}

	printf("int putthegray_009_02 ( int ii, int jj, char* word ) block 001.\r\n");
	printf("im_grid_matrix_009 |%p| ii %d\r\n", im_grid_matrix_009, ii );
	printf("im_grid_matrix_009->width_index_num_max %d ii %d\r\n", im_grid_matrix_009->width_index_num_max, ii );

	rmode = 0;
	if (im_grid_matrix_009->width_index_num_max <= ii ) {
		rmode = 1;
		ri = im_grid_matrix_009->width_index_num_max;
		for ( i= 0; ii >= im_grid_matrix_009->width_index_num_max; i++ ) {
			printf("i %d ii %d width_index_num_max %d\r\n", i, ii, im_grid_matrix_009->width_index_num_max );
			im_grid_matrix_009->width_index_num_max *= 2;
			printf("i %d ii %d width_index_num_max %d\r\n", i, ii, im_grid_matrix_009->width_index_num_max );
		}
		printf("out9: i %d ii %d ri %d width_index_num_max %d (char***)\r\n", i, ii, ri, im_grid_matrix_009->width_index_num_max );
		im_grid_matrix_009->grid_matrix = (char***) realloc_char_003_01_013 ( im_grid_matrix_009->grid_matrix, im_grid_matrix_009->width_index_num_max );
		for ( i = ri; i< im_grid_matrix_009->width_index_num_max; i++ ) {
			// log
			sprintf( logmsg, "out9-1 i %d / %d matrix|%p| -> ", i, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->grid_matrix[i] );
			Log_Add ( log_alloc, logmsg, 1);
			im_grid_matrix_009->grid_matrix[i] = (char**) realloc_char_002_01_013 ( im_grid_matrix_009->grid_matrix[i], im_grid_matrix_009->height_index_num_max );
			sprintf( logmsg, " [%d]/ %d height %d matrix|%p| \r\n", i, im_grid_matrix_009->width_index_num_max,im_grid_matrix_009->height_index_num_max, im_grid_matrix_009->grid_matrix[i] );
			Log_Add ( log_alloc, logmsg, 1);
			// print
			if ( im_grid_matrix_009->grid_matrix[i] == NULL ) {
				printf("im_grid_matrix_009->grid_matrix[i] == NULL\r\n");
				exit(-1);
			}

			// set default o
			for ( i = ri; i< im_grid_matrix_009->width_index_num_max; i++ ) {
				for ( j = 0; j< im_grid_matrix_009->height_index_num_max; j++ ) {
					sprintf( logmsg, "( i %3d, j %3d) ->", i, j);
					Log_Add ( log_alloc, logmsg, 1);
					im_grid_matrix_009->grid_matrix[i][j] = (char*)temp_literature;
					sprintf( logmsg,  "|%p|%p|%s| as null|%p|\r\n", &(im_grid_matrix_009->grid_matrix[i][j]), im_grid_matrix_009->grid_matrix[i][j], im_grid_matrix_009->grid_matrix[i][j], NULL );
					Log_Add ( log_alloc, logmsg, 1);
				}
			}

		}
	}

	printf("int putthegray_009_02 ( int %d, int %d, char* word ) block 002.\r\n", ii, jj, im_grid_matrix_009->grid_matrix[0] );
	printf("im_grid_matrix_009->height_index_num_max %d jj %d im_grid_matrix_009->grid_matrix[0]|%p|\r\n", im_grid_matrix_009->height_index_num_max, jj );

	if (im_grid_matrix_009->height_index_num_max <=jj ) {
		rmode = 2;
		printf("in i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
		for ( i= 0; jj >= im_grid_matrix_009->height_index_num_max; i++ ) {
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
			im_grid_matrix_009->height_index_num_max *= 2;
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
		}
		printf("out2 i %d jj %d width_index_num_max %d height_index_num_max %d \r\n", i, jj, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max );
		for ( i = 0; i< im_grid_matrix_009->width_index_num_max; i++ ) {
			// log
			sprintf( logmsg, "out9-1 i %d / %d matrix|%p| -> ", i, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->grid_matrix[i] );
			Log_Add ( log_alloc, logmsg, 1);
			im_grid_matrix_009->grid_matrix[i] = (char**) realloc_char_002_01_013 ( im_grid_matrix_009->grid_matrix[i], im_grid_matrix_009->height_index_num_max );
			sprintf( logmsg, " [%d]/ %d height %d matrix|%p| \r\n", i, im_grid_matrix_009->width_index_num_max,im_grid_matrix_009->height_index_num_max, im_grid_matrix_009->grid_matrix[i] );
			Log_Add ( log_alloc, logmsg, 1);

			
			// print
			if ( im_grid_matrix_009->grid_matrix[i] == NULL ) {
				printf("im_grid_matrix_009->grid_matrix[i] == NULL\r\n");
				exit(-1);
			}

			// set default o
			for ( i = 0; i< im_grid_matrix_009->width_index_num_max; i++ ) {
				for ( j = 0; j< im_grid_matrix_009->height_index_num_max; j++ ) {
					sprintf( logmsg,"( i %3d, j %3d) ->", i, j);
					Log_Add ( log_alloc, logmsg, 1);
					im_grid_matrix_009->grid_matrix[i][j] = (char*)temp_literature;
					sprintf( logmsg, "|%p|%p|%s| as null|%p|\r\n", &(im_grid_matrix_009->grid_matrix[i][j]), im_grid_matrix_009->grid_matrix[i][j], im_grid_matrix_009->grid_matrix[i][j], NULL );
					Log_Add ( log_alloc, logmsg, 1);
				}
			}

		}
	}

	printf("int putthegray_009_02 ( int %d, int %d, char* word ) block 003.\r\n", ii, jj);
	printf("msg|%p| log_001|%p| im_grid_matrix_009->grid_matrix[0][0]|%p| ( %d, %d ) max ( %d, %d )\r\n", (char*)msg, log_001, &(im_grid_matrix_009->grid_matrix[0][0]), ii, jj, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max );
	printf ( "im_grid_matrix_009->grid_matrix[%d][%d]=|%p|-> ", ii, jj, &(im_grid_matrix_009->grid_matrix[ii][jj]) );
	printf ( "|%s|\r\n", ii, jj, im_grid_matrix_009->grid_matrix[ii][jj] );

	sprintf( logmsg, "putthegray_009_02 %d %d grid matrix %s\0", ii, jj, (char*) im_grid_matrix_009->grid_matrix[ii][jj]  );
	Log_Add ( log_alloc, logmsg, 1);
// x	dlog_001 = log_001->update_log ( (char*) msg );


	csvafree_005(im_grid_matrix_009->grid_matrix[ii][jj]);
	im_grid_matrix_009->grid_matrix[ii][jj] = (char*) csvcopyof_005 ( word );


	printf("int putthegray_009_02 ( int %d, int %d, char* word ) block 004.\r\n", ii, jj);

	sprintf( msg, "putthegray_009_02 %d %d word %s", ii, jj, word  );
	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_009_02 ( int ii, int jj, char* word ) end." );

	printf("int putthegray_009_02 ( int ii, int jj, char* word ) ends.\r\n");
	Log_Add ( log_alloc, "int putthegray_009_02 ( int ii, int jj, char* word ) ends.", 1);
	return 0;
}



int putthegray_009_03 ( int ii, int jj, char* word ) {
	int a, i, rmode, ri;
	int j;
	char msg[255];

	Log_Add ( log_alloc, "int putthegray_009_03 ( int ii, int jj, char* word ) starts.", 0);
	printf("int putthegray_009_03 ( int ii, int jj, char* word ) starts.\r\n");
	printf("im_grid_matrix_009 |%p| ii %d log_001|%p|\r\n", im_grid_matrix_009, ii, log_001 );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_009_03 ( int ii, int jj, char* word ) starts." );


	set_realloc_char_delay (100);

	if ( im_grid_matrix_009 == NULL ) {
		dlog_001 = log_001->update_log ( (char*)"im_grid_matrix_009 is NULL, so, ..." );
		a = initialize_im_grid_matrix_009 ();
	}

	printf("int putthegray_009_03 ( int ii, int jj, char* word ) block 001.\r\n");
	printf("im_grid_matrix_009 |%p| ii %d\r\n", im_grid_matrix_009, ii );
	printf("im_grid_matrix_009->width_index_num_max %d ii %d\r\n", im_grid_matrix_009->width_index_num_max, ii );

	rmode = 0;
	if (im_grid_matrix_009->width_index_num_max <= ii ) {
		rmode = 1;
		ri = im_grid_matrix_009->width_index_num_max;
		for ( i= 0; ii >= im_grid_matrix_009->width_index_num_max; i++ ) {
			printf("i %d ii %d width_index_num_max %d\r\n", i, ii, im_grid_matrix_009->width_index_num_max );
			im_grid_matrix_009->width_index_num_max *= 2;
			printf("i %d ii %d width_index_num_max %d\r\n", i, ii, im_grid_matrix_009->width_index_num_max );
		}

		printf("out9:: i %d ii %d ri %d width_index_num_max %d (char***)", i, ii, ri, im_grid_matrix_009->width_index_num_max );
		Sleep(delay_time_009);
		printf("---> height %d\r\n", im_grid_matrix_009->height_index_num_max );
		Sleep(delay_time_009);
		printf("---> height %d\r\n", im_grid_matrix_009->height_index_num_max );

		a = memories_width ( ri, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max, im_grid_matrix_009->grid_matrix );
	}

	printf("int putthegray_009_03 ( int %d, int %d, char* word ) block 002.\r\n", ii, jj, im_grid_matrix_009->grid_matrix[0] );
	printf("im_grid_matrix_009->height_index_num_max %d jj %d im_grid_matrix_009->grid_matrix[0]|%p|\r\n", im_grid_matrix_009->height_index_num_max, jj );

	if (im_grid_matrix_009->height_index_num_max <=jj ) {
		rmode = 2;
		printf("for height in i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
		for ( i= 0; jj >= im_grid_matrix_009->height_index_num_max; i++ ) {
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
			im_grid_matrix_009->height_index_num_max *= 2;
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, im_grid_matrix_009->height_index_num_max );
		}
		printf("out2 i %d jj %d width_index_num_max %d height_index_num_max %d \r\n", i, jj, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max );
		Sleep(delay_time_009);
		printf("---> height %d\r\n", im_grid_matrix_009->height_index_num_max );
		Sleep(delay_time_009);
		a = memories_height( im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max, im_grid_matrix_009->grid_matrix );
	}

	printf("int putthegray_009_03 ( int %d, int %d, char* word ) block 003.\r\n", ii, jj);
	printf("msg|%p| log_001|%p| im_grid_matrix_009->grid_matrix[0][0]|%p| ( %d, %d ) max ( %d, %d )\r\n", (char*)msg, log_001, &(im_grid_matrix_009->grid_matrix[0][0]), ii, jj, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max );
	printf ( "im_grid_matrix_009->grid_matrix[%d][%d]=|%p|--> ", ii, jj, &(im_grid_matrix_009->grid_matrix[ii][jj]) );
	printf ( "(%d,%d)\r\n", ii, jj );

	sprintf( logmsg, "putthegray_009_03 %d %d grid matrix %s\0", ii, jj, (char*) im_grid_matrix_009->grid_matrix[ii][jj]  );
	Log_Add ( log_alloc, logmsg, 1);
// x	dlog_001 = log_001->update_log ( (char*) msg );


	csvafree_005(im_grid_matrix_009->grid_matrix[ii][jj]);
	im_grid_matrix_009->grid_matrix[ii][jj] = (char*) csvcopyof_005 ( word );


	printf("int putthegray_009_03 ( int %d, int %d, char* word ) block 004.\r\n", ii, jj);

	sprintf( msg, "putthegray_009_03 %d %d word %s", ii, jj, word  );
	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int putthegray_009_03 ( int ii, int jj, char* word ) end." );

	printf("int putthegray_009_03 ( int ii, int jj, char* word ) ends.\r\n");
	Log_Add ( log_alloc, "int putthegray_009_03 ( int ii, int jj, char* word ) ends.", 1);
	return 0;
}

//
int putthegray_009_04 ( int ii, int jj, char* word ) {
	int i, ri, a;
	Log_Add ( log_alloc, "int putthegray_009_04 ( int ii, int jj, char* word ) starts.", 1);

	if ( im_grid_matrix_009 == NULL ) {
		a = initialize_im_grid_matrix_009 ();
	}

	sprintf( logmsg, "( %d, %d ) word %s --> ( %d, %d ) \0", ii, jj, word, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max );
	Log_Add ( log_alloc, (char*)logmsg, 1);

	if (im_grid_matrix_009->width_index_num_max <= ii ) {
		ri = im_grid_matrix_009->width_index_num_max;
		for ( i= 0; ii >= im_grid_matrix_009->width_index_num_max; i++ ) 
			im_grid_matrix_009->width_index_num_max *= 2;

		a = memories_width ( ri, im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max, im_grid_matrix_009->grid_matrix );
	}

	if (im_grid_matrix_009->height_index_num_max <= jj ) {
		for ( i= 0; jj >= im_grid_matrix_009->height_index_num_max; i++ ) 
			im_grid_matrix_009->height_index_num_max *= 2;

		a = memories_height( im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max, im_grid_matrix_009->grid_matrix );
	}

	sprintf( logmsg, "max( %d, %d ) \0", im_grid_matrix_009->width_index_num_max, im_grid_matrix_009->height_index_num_max  );
	Log_Add ( log_alloc, (char*)logmsg, 1);

	Log_Add ( log_alloc, "int putthegray_009_04 ( int ii, int jj, char* word ) ends.", 1);
	return 0;
}

//
char*** putthegray_009_03_height ( char*** img, int start_i, int width, int height ) {
	int i, a;

	Log_Add ( log_alloc, "char*** putthegray_009_03_height ( char*** img, int start_i, int width, int height ) starts.", 1);

	for ( i = start_i; i< width; i++ ) {
		sprintf( logmsg, "i %d img |%p| as width %d\0", i, img[i], width );
		Log_Add ( log_alloc, logmsg, 1);
//		img[i] = (char**) reallocation_001_02 ( img[i], height);
//		img[i] = (char**)realloc_char_002_01_013 ( img[i], height);
		Sleep ( delay_time_009 );
	}

	Log_Add ( log_alloc, "char*** putthegray_009_03_height ( char*** img, int start_i, int width, int height ) ends.", 1);
	return img;
}


