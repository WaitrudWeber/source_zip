#ifndef _VBOX_H_
#define _VBOX_H_

class vBox {

	public:
		vPoint*	p[8];
		float x1, x2, y1, y2, z1, z2;
		vLine*	line[12];
		vPoint Center;
		vLine* line_on_screen[12];

	public:
		vBox ();
		vBox ( float xx1, float yy, float zz1, float xx2, float yy2, float zz2 ) ;
		void Calculation () ;
		void Print () ;
		void SetBox ( float xx1, float yy1, float zz1, float xx2, float yy2, float zz2 ) ;

};

#endif

