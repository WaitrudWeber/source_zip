#ifndef _WAVESOUND_H_
#define _WAVESOUND_H_

extern int multithread();
extern int no_playsound_multithread_002();

#endif