// https://github.com/WaitrudWeber/source_zip/blob/master/winmain-20190109.zip
// https://docs.microsoft.com/en-us/windows/desktop/dataxchg/using-the-clipboard


//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-hProcess-in-mingw-what-to-use-instead
// #include <strsafe.h>

//#include <mmdeviceapi.h>

#include "resource.h"

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"

#include "clipboard.h"

#include "button.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "display_threeD.h"
#include "vPointStructure.h"


#include "vSoundBuffer_001.h"


#include "wEvent.h"
#include "wEventListener.h"

#include "wJavaStructure.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

#include "wTextarea.h"
#include "wTextareaController.h"

#include "something_word.h"
#include "thread_print.h"


#include "wDisplayController.h"
//#include "wParamSynse_003.h"
#include "wCanvasController.h"

#include "cg_schema.h"


#include "ReturnableParam.h"

#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "winmainthread_001.h"

#define _DRAW_PARAM_00000000000000000000000000000001_ 1
#define _DRAW_PARAM_00000000000000000000000000000010_ 2
#define _DRAW_PARAM_00000000000000000000000000000100_ 4
#define _DRAW_PARAM_00000000000000000000000000001000_ 8
#define _DRAW_PARAM_00000000000000000000000000010000_ 16
#define _DRAW_PARAM_00000000000000000000000000100000_ 32
#define _DRAW_PARAM_00000000000000000000000001000000_ 64
#define _DRAW_PARAM_00000000000000000000000010000000_ 128
#define _DRAW_PARAM_00000000000000000000000100000000_ 256
#define _DRAW_PARAM_00000000000000000000001000000000_ 512
#define _DRAW_PARAM_00000000000000000000010000000000_ 1024
#define _DRAW_PARAM_00000000000000000000100000000000_ 2048
#define _DRAW_PARAM_00000000000000000001000000000000_ 4096
#define _DRAW_PARAM_00000000000000000010000000000000_ 8192
#define _DRAW_PARAM_00000000000000000100000000000000_ 16384
#define _DRAW_PARAM_00000000000000001000000000000000_ 32768
#define _DRAW_PARAM_00000000000000010000000000000000_ 65536
#define _DRAW_PARAM_00000000000000100000000000000000_ 131072
#define _DRAW_PARAM_00000000000001000000000000000000_ 262144
#define _DRAW_PARAM_00000000000010000000000000000000_ 524288

DWORD ThreadId;
HANDLE ThreadHandle;

static RECT RefreshRect;
static int param_int[20];
static char value_text[20][4];
static RECT rect_xy[20];

static char	soundwave[255];
static char	voicewave[255];


DWORD WINAPI Animation_5times_thread_validate_021 ( LPVOID hdc ) ;

//static LRESULT CALLBACK mainWindowProc_021 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
LRESULT CALLBACK mainWindowProc_021 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );


// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
 LRESULT CALLBACK mainWindowProc_021 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = 0;
	static HDC     hDC;
	static PAINTSTRUCT ps_001;
	static char x_b[4];
	static char y_b[4];
	static char c_b[4]; //
	static char d_b[4]; // diff value
	static RECT rect_x, rect_y;
	static HFONT hFont, hFont2;
	static int flg_paint = 0;
	static int DRAW_PARAM = 0;
	double	param[16];
	int i, by;

	if ( p_evt == nullptr ) {
		p_evt = new wEvent ();
	}

	p_evt->hWnd = hWnd;
	p_evt->uMsg = &uMsg;
	p_evt->wParam = wParam;
	p_evt->lParam = lParam;
	p_evt->main_mode = m_mode;
//	wtextareacontroller.setEvent ( p_evt );

	// Code Block 1 - 01:
	p_evt->Type = uMsg;

	switch (uMsg) {
	case WM_CREATE:

//		for ( i=0; i<255; i++ )
//			soundwave[i] = 127;

		for ( i=0; i<255; i++ )
			soundwave[i] = sin( i * 0.1 ) * 127.0;


		SetRect( &rect_xy[0], 10, 10, 60, 60 );//04
		SetRect( &rect_xy[1], 60, 10, 110, 60 );//04
		SetRect( &rect_xy[2], 110, 10, 160, 60 );//04
		SetRect( &rect_xy[3], 160, 10, 210, 60 );//04
		SetRect( &rect_xy[4], 210, 10, 260, 60 );//04
		SetRect( &rect_xy[5], 260, 10, 310, 60 );//04
		SetRect( &rect_xy[6], 310, 10, 360, 60 );//04
		SetRect( &rect_xy[7], 360, 10, 410, 60 );//04
		SetRect( &rect_xy[8], 410, 10, 460, 60 );//04
		SetRect( &rect_xy[9], 460, 10, 510, 60 );//04
		SetRect( &rect_xy[10], 510, 10, 560, 60 );//04
		SetRect( &rect_xy[11], 560, 10, 610, 60 );//04
		SetRect( &rect_xy[12], 10, 60, 60, 110 );//04
		SetRect( &rect_xy[13], 60, 60, 110, 110 );//04
		SetRect( &rect_xy[14], 110, 60, 160, 110 );//04
		SetRect( &rect_xy[15], 160, 60, 210, 110 );//04
		SetRect( &rect_xy[16], 210, 60, 260, 110 );//04
		SetRect( &rect_xy[17], 260, 60, 310, 110 );//04
		SetRect( &rect_xy[18], 310, 60, 360, 110 );//04
		SetRect( &rect_xy[19], 360, 60, 410, 110 );//04
		SetRect( &RefreshRect, 0, 0, 640, 480 );//04
		DRAW_PARAM = 0;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000000001_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000000010_;
		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000000100_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000001000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000100000000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000001000000000000000000_;
		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000010000000000000000000_;
		ThreadHandle = CreateThread( NULL, /* default security attributes */ 0, /* default stack size */    
			Animation_5times_thread_validate_021, /* thread function */ (LPVOID)&(p_evt->hDc), /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId);

//		hFont = CreateFont (20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
//		hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);
//		SetTextColor( hDC, RGB(0 ,0, 255) );

		break;
	case WM_MOUSEMOVE: //512
		param_int[1] = GET_Y_LPARAM ( lParam );
		param_int[3] = param_int[2] - param_int[1]; // diff in a step
		if (param_int[3] < 0) param_int[3] = - param_int[3];

		sprintf( value_text[0], "%04d", GET_X_LPARAM ( lParam ) );
		sprintf( value_text[1], "%04d", param_int[1] );
		sprintf( value_text[3], "%04d", param_int[3] );
		sprintf( value_text[4], "%04d", param_int[4] - param_int[1] );

		param_int[0] = GET_X_LPARAM ( lParam );
		param_int[1] = GET_Y_LPARAM ( lParam );
		param_int[2] = param_int[1];
		param_int[4] += 1;

		SetRect( &rect_xy[11], param_int[3], 400, param_int[3] + 10, 450 );//04
		b_Processed = 1;
//		for ( i =0; i<20; i++ )
//			InvalidateRect( hWnd, &rect_xy[i], FALSE);

//		InvalidateRect( hWnd, &RefreshRect, FALSE);
		InvalidateRect( hWnd, &rect_xy[0], FALSE);
		InvalidateRect( hWnd, &rect_xy[1], FALSE);
		InvalidateRect( hWnd, &rect_xy[2], FALSE);
		InvalidateRect( hWnd, &rect_xy[3], FALSE);
		InvalidateRect( hWnd, &rect_xy[4], FALSE);
		InvalidateRect( hWnd, &rect_xy[5], FALSE);
		InvalidateRect( hWnd, &rect_xy[6], FALSE);

		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d DRAW_PARAM=%d\r\n", WM_MOUSEMOVE, flg_paint, DRAW_PARAM );
		break;
	case WM_PAINT: //15
		hDC = BeginPaint( hWnd, &ps_001 );
		p_evt->hDc = hDC;
		p_evt->ps = &ps_001;
		param_int[5] = 0;

		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000000001_ ) {
//$00000000000000000000000000000001
//			SelectObject( hDC, GetStockObject(GRAY_BRUSH)); 
//			Ellipse( hDC, RefreshRect.left, RefreshRect.top, RefreshRect.right, RefreshRect.bottom);
			SelectObject( hDC, GetStockObject(WHITE_BRUSH)); 
			Rectangle( hDC, RefreshRect.left, RefreshRect.top, RefreshRect.right, RefreshRect.bottom);
			printf("00000000000000000000000000000001\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000000010_ ) {
//$00000000000000000000000000000010
			param[0] = 1.0; // margin x;
			param[1] = 1.0; // margin y;
			param[2] = 10.0; // step x;
			param[3] = param[2] * 0.5 * sqrt( 3.0 ); // step y;
			param[4] = 640.0; // screen width
			param[5] = 480.0; // screen height
			param[6] = param[1]; // current x
			param[7] = param[2]; // current y
			param[8] = param[0] + 0.5 * param[2];
			param[9] = param[0];  // start of odd

			while ( param[7] < param[5] ) {

				SetPixel( p_evt->hDc, param[6], param[7], RGB( 0, 0, 255 ) );
				// inclement of cursol and turn
				if ( (param[6] += param[2] ) >= param[4]  ) {
					param[7] += param[3];

					if ( param[9] == param[0] ) param[6] = param[8];
					else param[6] = param[0];
					param[9] = param[6];
				}
			}

			printf("00000000000000000000000000000010\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000000100_ ) {
//$00000000000000000000000000000100
			// Graph 001:
			// on SetRect( &rect_xy[17], 10, 300, 630, 350 );//04
			// 10 + cursol
			// 325 + value
//			SetPixel( p_evt->hDc, 10 + param_int[17], 325 + param_int[15], RGB( 255, 0, 0 ) );

			for ( i = 10; i<638; i++ ) {
				SetPixel( p_evt->hDc, i, 325 + 127 * 0.2, RGB( 0, 0, 255 ) );
				SetPixel( p_evt->hDc, i, 325 - 127 * 0.2, RGB( 0, 0, 255 ) );
				SetPixel( p_evt->hDc, i, 325 + soundwave[(i-10)%255] * 0.2, RGB( 0, 0, 255 ) );
				param_int[5]+=3;
			}
//				SetPixel( p_evt->hDc, i, 127 + soundwave[ ( i - 10 ) % 255 ], RGB( 0, 0, 255 ) );

			sprintf( value_text[5], "%04d", param_int[5] );
			sprintf( value_text[6], "%04d", 0 );
			printf("00000000000000000000000000000100\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000001000_ ) {
//$00000000000000000000000000001000
			for ( i =0; i<20; i++ ) {
				Rectangle(  (HDC) hDC, rect_xy[i].left, rect_xy[i].top, rect_xy[i].right, rect_xy[i].bottom );
			}

			SelectObject( hDC, GetStockObject(GRAY_BRUSH)); 
			Rectangle(  (HDC) hDC, rect_xy[15].left, rect_xy[15].top, rect_xy[15].right, rect_xy[15].bottom );
			printf("00000000000000000000000000001000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000010000_ ) {
//$00000000000000000000000000010000
			printf("00000000000000000000000000010000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000100000_ ) {
//$00000000000000000000000000100000
			printf("00000000000000000000000000100000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000001000000_ ) {
//$00000000000000000000000001000000
			printf("00000000000000000000000001000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000010000000_ ) {
//$00000000000000000000000010000000
			printf("00000000000000000000000010000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000100000000_ ) {
//$00000000000000000000000100000000
			printf("00000000000000000000000100000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000001000000000_ ) {
//$00000000000000000000001000000000
			printf("00000000000000000000001000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000010000000000_ ) {
//$00000000000000000000010000000000
			printf("00000000000000000000010000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000100000000000_ ) {
//$00000000000000000000100000000000
			printf("00000000000000000000100000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000001000000000000_ ) {
//$00000000000000000001000000000000
			printf("00000000000000000001000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000010000000000000_ ) {
//$00000000000000000010000000000000
			printf("00000000000000000010000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000100000000000000_ ) {
//$00000000000000000100000000000000
			printf("00000000000000000100000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000001000000000000000_ ) {
//$00000000000000001000000000000000
			printf("00000000000000001000000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000010000000000000000_ ) {
//$00000000000000010000000000000000
			printf("00000000000000010000000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000100000000000000000_ ) {
//$00000000000000100000000000000000
			param[0] = 0.0; // cursol soundwave
			param[1] = 0.0; // cursol voicewave
			param[2] = 20.0; // margin x;
			param[3] = 20.0; // margin y;
			param[4] = 150.0; // graph height;
			param[5] = 300.0; // graph length;
			param[6] = 0.5 * param[5] + param[4]; // graph o;
			param[7] = param[2]; 			// cursol for drawing sound and voice waves x
			param[8] = param[7] + param[5];	// cursol for drawing sound and voice waves x max
			param[9] = param[5] / 255.0; // step x;
			param[10] = param[5] / 255.0; // rasio height;

			param[11] = 1.0;   // array index step 1.0
			param[12] = 255.0; // buffer_size
			param[13] = 0.0;   // array index cursol
			param[14] = 3.1415926535; // pi
			param[15] = param[14] * 0.1; // number of wave
			param[16] = 128.0;

			// soundwave set
			// voicewave set
			while ( param[13] < param[12] ) {
				soundwave[(int)param[13]] = sin( param[13] ) * param[16];
				voicewave[(int)param[13]] = cos( param[13] ) * param[16];
				param[13] += param[11];
				printf("soundwave[%d] %d = sin(%f) %f %f\r\n", (int)param[13], soundwave[(int)param[13]], param[13], param[13] );
			}
//			exit(-1);
			printf("00000000000000100000000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000001000000000000000000_ ) {
//$00000000000001000000000000000000
			param[0] = 0.0; // cursol soundwave
			param[1] = 0.0; // cursol voicewave
			param[2] = 20.0; // margin x;
			param[3] = 20.0; // margin y;
			param[4] = 150.0; // graph height;
			param[5] = 300.0; // graph length;
			param[6] = 0.5 * param[5] + param[4]; // graph o;
			param[7] = param[2]; 			// cursol for drawing sound and voice waves x
			param[8] = param[7] + param[5];	// cursol for drawing sound and voice waves x max
			param[9] = param[5] / 255.0; // step x;
			param[10] = param[5] / 255.0; // rasio height;

			param[11] = 1.0;   // array index step 1.0
			param[12] = 255.0; // buffer_size
			param[13] = 0.0;   // array index cursol
			param[14] = 3.1415926535; // pi
			param[15] = param[14] * 0.1; // number of wave
			param[16] = 128.0;

			// soundwave set
			// voicewave set
			while ( param[13] < param[12] ) {
				soundwave[(int)param[13]] = sin( param[14] * param[13] ) * param[16];
				voicewave[(int)param[13]] = cos( param[14] * param[13] ) * param[16];
				param[13] += param[11];
				printf("soundwave[%d] %d = sin(%f) %f %f\r\n", (int)param[13], soundwave[(int)param[13]], param[14] * param[13], param[14], param[13] );
			}
			exit(-1);
			printf ("condition %f < %f\r\n", param[7], param[8] );
			// Dot
			while( param[7] < param[8] ) {

				param[10] = soundwave[ (int)param[7] ] + param[6]; // height * value + graph o

				SetPixel( p_evt->hDc, param[7], param[10], RGB( 0, 0, 255 ) );

				param[7] += param[9];
				printf ("param (%f,%f) %f %d\r\n", param[7], param[10], param[10], soundwave[ (int)param[7] ] );
			}
			printf("00000000000001000000000000000000 & DRAW_PARAM %d\r\n", DRAW_PARAM);
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000010000000000000000000_ ) {
//$00000000000010000000000000000000

			TextOutA( (HDC) hDC, rect_xy[0].left, rect_xy[0].top, value_text[0], 4);
			TextOutA( (HDC) hDC, rect_xy[1].left, rect_xy[1].top, value_text[1], 4);
			TextOutA( (HDC) hDC, rect_xy[3].left, rect_xy[3].top, value_text[3], 4);
			TextOutA( (HDC) hDC, rect_xy[4].left, rect_xy[4].top, value_text[4], 4);
			TextOutA( (HDC) hDC, rect_xy[5].left, rect_xy[5].top, value_text[5], 4);
			TextOutA( (HDC) hDC, rect_xy[6].left, rect_xy[6].top, value_text[6], 4);
//			TextOutA( (HDC) hDC, rect_xy[15].left, rect_xy[15].top, value_text[15], 4);
			TextOutA( (HDC) hDC, rect_xy[16].left, rect_xy[16].top, value_text[16], 4);
			TextOutA( (HDC) hDC, rect_xy[17].left, rect_xy[17].top, value_text[17], 4);
			TextOutA( (HDC) hDC, rect_xy[18].left, rect_xy[18].top, value_text[18], 4);
			TextOutA( (HDC) hDC, rect_xy[19].left, rect_xy[19].top, value_text[19], 4);

//			DrawText( (HDC) hDC, TEXT( value_text[0] ), -1, &rect_xy[0], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[1] ), -1, &rect_xy[1], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[3] ), -1, &rect_xy[3], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[4] ), -1, &rect_xy[4], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[18] ), -1, &rect_xy[18], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[19] ), -1, &rect_xy[19], DT_NOCLIP );

			printf("00000000000010000000000000000000\r\n");
		} 
		b_Processed = 2;
		flg_paint = 1;
		printf("WM_PAINT=uMsg=%d flg_paint=%d hDC %d DRAW_PARAM %d\r\n", WM_PAINT, flg_paint, hDC, DRAW_PARAM );
		break;
	case WM_KEYUP:
		InvalidateRect( hWnd, &RefreshRect, TRUE);
		InvalidateRect( hWnd, &rect_x, FALSE);
		b_Processed = 1;
		printf("WM_KEYUP=uMsg=%d flg_paint=%d\r\n", WM_KEYUP, flg_paint );
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		printf("WM_KEYDOWN=uMsg=%d flg_paint=%d\r\n", WM_KEYDOWN, flg_paint );
		break;
	}

	switch (uMsg) {
	case WM_PAINT: //15
		SelectObject((HDC)(hDC), hFont2);
		DeleteObject(hFont);
		EndPaint( hWnd, &ps_001 );	
//		wtextareacontroller.stack_number_free ();
		break;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

//
DWORD WINAPI Animation_5times_thread_validate_021 ( LPVOID hdc ) {
	printf("Animation_5times_thread_validate_021 starts.\r\n");
	DWORD hdc_011 = *(DWORD*)hdc;
	for ( param_int[19] = 0; param_int[19]<255; param_int[19]++ ) {
		param_int[18] = param_int[19] - 1;

		// Cursol
		param_int[17] = param_int[19];
		param_int[16] = soundwave[ param_int[17] ];
		param_int[15] = (int)( (double)param_int[16] * 0.1 );
	
		sprintf( value_text[15], "%04d", param_int[15] ); //128 soundwave * 0.2
		sprintf( value_text[16], "%04d", soundwave[ param_int[16] ] ); //128 soundwave
		sprintf( value_text[17], "%04d", soundwave[ param_int[17] ] ); //128 soundwave

		sprintf( value_text[18], "%04d", param_int[18] );
		sprintf( value_text[19], "%04d", param_int[19] );

		// Graph 001:
		SetRect( &rect_xy[15], 10 + param_int[17] , 325 + param_int[15], 20 + param_int[17], 335 + param_int[15] );//04

		SetRect( &rect_xy[16], 127 + param_int[16], 250, 127 + param_int[16] + 10, 300 );//04
		SetRect( &rect_xy[17], 10, 300, 630, 350 );//04

		SetRect( &rect_xy[19], param_int[19], 350, param_int[19] + 10, 400 );//04

		InvalidateRect( p_evt->hWnd, &rect_xy[15], FALSE);
		InvalidateRect( p_evt->hWnd, &rect_xy[16], FALSE);
		InvalidateRect( p_evt->hWnd, &rect_xy[17], FALSE);
		InvalidateRect( p_evt->hWnd, &rect_xy[18], FALSE);
		InvalidateRect( p_evt->hWnd, &rect_xy[19], FALSE);
		Sleep(333);
	}
	printf("Animation_5times_thread_validate_021 ends.\r\n");
	return 0;
}
