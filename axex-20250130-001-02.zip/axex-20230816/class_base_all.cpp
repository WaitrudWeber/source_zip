#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "class_base_all.h"

//class_base_all.cpp
//
int class_base_all::Initialize_param_all () {
	return 0;
}

int class_base_all::Sub_Initialize_param_all () {
	return 0;
}



