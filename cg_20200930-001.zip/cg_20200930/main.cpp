#include <stdio.h>
#include <stdlib.h>

#include "print_line.h"

int main () {
	int x = 320;
	int y = 180;

	allocation_canvas( x, y );

	/*for ( int j=0; j<10; j++ ) {
		for ( int i=0; i<10; i++ ) {
			printf("x %3d y %3d %3d \r\n", canvas[y][x] );
		}
	}*/

	return  0;
}
