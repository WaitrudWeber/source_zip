#include <stdio.h>
#include <stdlib.h>

#include "print_line.h"

int** canvas = NULL;
int allocation_canvas ( int x, int y ) ;

int allocation_canvas ( int x, int y ) {

	canvas = (int**) malloc (sizeof(int*) * x );

	for ( int i=0; i<x; i++ ) {
		canvas[x] = (int*) malloc ( sizeof(int) * y );
	}

	for ( int j=0; j<y; j++ ) {
		for ( int i=0; i<y; i++ ) {
			printf("x = %d y = %d i %d j %d \r\n", x, y, i, j );
			canvas[x][y] = 0;
		}
	}

	return 0;
}

