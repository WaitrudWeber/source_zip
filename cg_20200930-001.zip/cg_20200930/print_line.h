extern int allocation_canvas ( int x, int y ) ;
extern int** canvas;
