#ifndef WCANVASCONTROLLER_H
#define WCANVASCONTROLLER_H

class wCanvasController {

	public:
		int Processed = 0;

	private:
		wEvent* event;

	public:
		wCanvasController ();
		void kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
		void Process ();
		void ProcessWmPaint ();
		void ProcessWmChar();
		void setEvent( wEvent* evt );
		void Print_struct(wJavaStructure top ) ;
		void setKickEvent_001 ( int num, wKickEvent* kick_event) { }

};


#endif
