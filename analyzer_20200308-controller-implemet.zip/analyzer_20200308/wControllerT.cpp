#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include "wJavaStructure.h"

#include "wEvent.h"
#include "wKickEvent.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wCanvasController.h"


#include "wControllerT.h"

void wControllerT::setKickEvent_001 ( int num, wKickEvent* kick_event) {
	m_btc->setKickEvent_001( num, kick_event);
	m_canvas->setKickEvent_001( num, kick_event);
}

void wControllerT::setButtonController ( wButtonController* btc ) {
	m_btc = btc;
}

void wControllerT::setCanvasController ( wCanvasController* canvas ) {
	m_canvas = canvas;
}


