#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <stdio.h>

#include "array_counter.h"
#include "wEvent.h"
#include "wKickEvent.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
#include "something_word.h"

#include "vPointStructure.h"
#include "vPointLinear.h"

#include "display_threeD.h"

#include "wJavaStructure.h"
#include "wCanvasController.h"

#include "wC_structure.h"
#include "wC_structure_Display.h"


wC_structure_Display* c_literal = nullptr;

//
//
//
//
wCanvasController::wCanvasController() {
}

//
//
//
//
void wCanvasController::Print_struct(wJavaStructure top ) {


}

//
//
//
//
void wCanvasController::setEvent( wEvent* evt ) {

	this->event = evt;

}

//
//
//
//
void wCanvasController::kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

}

//
//
//
//
void wCanvasController::Process () {

	Processed = 0;
//	switch ( *( this->event->uMsg ) ) {
	switch ( this->event->Type ) {
	case WM_PAINT:
		ProcessWmPaint ();
		Processed = 1;
		break;
	case WM_CHAR:
		ProcessWmChar ();
		Processed = 1;
		break;
	}

}

//
//
//
//
void wCanvasController::ProcessWmChar () {
	switch ( this->event->main_mode ) {
	case 2:
		getchar_display_threeD_proc_002 ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		break;
	case 8:
		getchar_display_threeD_proc ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		break;
	}

	printf("void wCanvasController::ProcessWmChar (): %d \r\n", this->event->main_mode );
	// exit(-2); // it does work: 20191112
}

//
//
//
//
void wCanvasController::ProcessWmPaint () {

	switch ( this->event->main_mode ) {
	case 1:
		break;
	case 2:
		//something_word -> drawing circles
		wmpaint_display_threeD_proc_002 ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
		//exit(-2); // it does work here: 20191112
		break;
	case 3:
		// wmpaint_display_patches ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
		if ( c_literal == nullptr ) {
			c_literal = new wC_structure_Display ();
		}
		c_literal->display_select_wC_structure ( event->hDc );
		c_literal->display_array_wC_structure();
		break;
	case 8:
		wmpaint_display_threeD_proc ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
		break;
	}

}

