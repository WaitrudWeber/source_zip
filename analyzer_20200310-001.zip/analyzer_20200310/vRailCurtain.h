#ifndef _VRAILcURTAIN_H_
#define _VRAILcURTAIN_H_

class vRailCurtain {

	int RailWidth = 1000;
	int Width = 500;

	vPoint*** points = nullptr;

	void Calculation ();
	void Initialization ();

};

#endif