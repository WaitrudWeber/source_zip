extern vPoint** getPoints () ;
static vPoint** allocation = nullptr;
