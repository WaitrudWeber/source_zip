#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"

#include "allocation.h"
#include "main.h"

int** controls = NULL;

int main () {

//	controls = (int**) malloc ( sizeof(int*) * 3 );
	allocation = (vPoint**) malloc ( sizeof(vPoint*) * 3 );

	printf("we could allocate the static memories |%p|\r\n", allocation );

	return 0;
}

