#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "allocation.h"


static vPoint** allocation = nullptr;
vPoint** getPoints () ;

vPoint** getPoints () {
	return allocation;
}

