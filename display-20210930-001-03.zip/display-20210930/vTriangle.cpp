#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"

vTriangle::vTriangle() {
}

vPoint* vTriangle::getNormal() {

	vPoint *nrml;
	vPoint *ap, *bp;
	vCalculation *cal = nullptr;

	cal = new vCalculation ();
	ap = cal->subtract( p2 , p1 );
	bp = cal->subtract( p3 , p1 );

	nrml = cal->cross( ap, bp );
	cal->normal( nrml );

	this->normal = nrml;

//	printf("ap = ");
//	ap->print();
//	printf("bp = ");
//	bp->print();

	delete( cal );
	free_point (ap);
	free_point (bp);

	return nrml;
}


