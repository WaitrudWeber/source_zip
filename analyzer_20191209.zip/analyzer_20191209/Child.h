#ifndef _CHILD_H_
#define _CHILD_H_

// Sub class inheriting from Base Class(Parent) 
class Child : public Parent 
{ 
    public: 
      int id_c; 

	private:
		int pid;

	public:
		void setPid ( int id ) ;
};

#endif
