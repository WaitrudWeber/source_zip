#include "Parent.h"
#include "Child.h"

void Child::setPid ( int id ) {
	this->pid =id;
}