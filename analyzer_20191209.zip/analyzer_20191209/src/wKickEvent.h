#ifndef _W_KICK_EVENT_H_
#define _W_KICK_EVENT_H_

class wKickEnven {

	private:
		int pa=0;

	public:
		int p=0;

	private:


	public:
		wKickEnven ();

};

#endif
