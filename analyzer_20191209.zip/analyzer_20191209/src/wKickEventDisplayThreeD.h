#ifndef _W_KICK_EVENT_DISPLAY_THREED_H_
#define _W_KICK_EVENT_DISPLAY_THREED_H_

// https://www.tutorialspoint.com/cplusplus/cpp_inheritance.htm
class wKickEventDisplayThreeD : public wKickEvent {

	private:
		int pa=0;

	public:
		int p=0;

	private:


	public:
		wKickEventDisplayThreeD ();

};

#endif
