#include "wKickEvent.h"


wKickEnven:: wKickEnven () {
}

