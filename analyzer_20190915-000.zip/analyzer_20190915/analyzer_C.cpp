#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "aToken.h"

#include "analyzer_C.h"

// argv[0] : file name
//
//
//
//
int Analyzer::analyze_C (int argc, char** argv ) {

	this->parse(argv[0]);

	return 0;
}

//
//
//
//
//
int Analyzer::parse ( char* filename ) {
	FILE *fp;
	aToken *iToken = nullptr;
	char *parse_token;
	int previous_index = 0;

	iToken = new aToken();
	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end && i<100; i++ ) {
		// DEBUG
		previous_index = i;

		// the below has problem at 20190913.
		parse_token = iToken->getToken( fp, &i, &file_end );
		printf("parse_token: |%s|\r\n", parse_token );
		// this cannot scope the below function, but sucope it in aDebug.cpp at 20190303
		// DEBUG_SUB( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// DEBUG ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// o debug_msg_001 ();
		// DEBUG_002 ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// printf("msg: |%s|\r\n", msg );
		// err_msg_001 ( "parse_token: |%s|", parse_token ) ;

		if ( m_compare( parse_token, (char *) "void" ) == 1 ) {
			printf("void\r\n");
			exit( -1);
		} else if ( m_compare( parse_token, (char *) "/*" ) == 1 ) {

			printf("comment out: i %d raw %d line %d\r\n", i, iToken->getRaw(), iToken->getLine() );
			exit(-1);

		} else {
//			m_free_token( parse_token );
//			free_main_token (); //scope
			iToken->free_main_token ();
//			free( parse_token );
//			token = (char*)"\0";
		}

		// DEBUG
		if ( previous_index > i ) {
			printf("previous_index > i\r\n");
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		} else if ( previous_index == i ) {
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		}

	}

	fclose(fp);
	return 1;
}

//
//
//
//
//
int Analyzer::filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

