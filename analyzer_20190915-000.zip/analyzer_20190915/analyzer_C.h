#ifndef _ANALYZE_H_
#define _ANALYZE_H_

class Analyzer {

	public:
		int analyze_C (int argc, char** argv ) ;
		int filesize( FILE *fp ) ;
		int parse ( char* filename ) ;

};

#endif
