//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdlib.h>
#include <stdio.h>

#include "resource.h"

#include "array_counter.h"
#include "button.h"

#include "wButton.h"

//------------------------------------------------
// Macro for switch
//------------------------------------------------
#define CASE        break;case
#define DEFAULT     break;default

//------------------------------------------------
// Constant for Screen
//------------------------------------------------
#define SCREEN_STYLE        (WS_OVERLAPPEDWINDOW ^ (WS_THICKFRAME|WS_MAXIMIZEBOX))
#define SCREEN_WIDTH        (640)       // Screen Width (32dot x 20)
#define SCREEN_HEIGHT       (480)       // Screen Height (32dot x 15)

//------------------------------------------------
// Define Error message
//------------------------------------------------
#define ERRMSG_TITLE        TEXT("WinMain Function")
#define ERRMSG_WINREG       TEXT("Window Class can not be set.")
#define ERRMSG_CREATE       TEXT("Window can not be created.")

wButton button1((char *)"File Open");
wButton button2((char *)"Something Sentence");
wButton button3((char *)"Something Word");
wButton button4((char *)"Dictionary Link");
wButton button5((char *)"Web Link");
wButton button6((char *)"Print Html");
wButton button7((char *)"Exit");

char* m_button_select;
int m_button_number_select;
HHOOK hMyHook;

void ButtonSelectDown ();
void ButtonSelectUp ();
// light = 0 means non-select
// light = 1 means select
void ButtonLight( int light, int bn );


void MyHookStart(HWND hWnd) ;
void MyHookEnd(HWND hWnd) ;
LRESULT CALLBACK MyHookProc(int nCode, WPARAM wp, LPARAM lp) ;

char m_string[256];
int once_hook = 0;


//------------------------------------------------
// Window Procedure
//------------------------------------------------
static LRESULT CALLBACK mainWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch ( uMsg ){
        CASE WM_CREATE:
            /*
            initialization
            */
        {
			button1.setButton ( 0, 0,    200, 50 );
			button2.setButton ( 0, 50,   200, 50 );
			button3.setButton ( 0, 100,  200, 50 );
			button4.setButton ( 0, 150,  200, 50 );
			button5.setButton ( 0, 200,  200, 50 );
			button6.setButton ( 0, 250,  200, 50 );
			button7.setButton ( 0, 300,  200, 50 );

			// Failure in WM_Create.
//			if ( once_hook == 0 ) {
//
//				once_hook = 1;
//				MyHookStart ( hWnd );
//
//			}

			sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
        }
        CASE WM_CLOSE:
            /*
            Deposition
            */
            DestroyWindow( hWnd );
        CASE WM_DESTROY:
            PostQuitMessage( 0 );
        CASE WM_PAINT:
        {

//			if ( once_hook == 0 ) {

//				once_hook = 1;
//				MyHookStart ( hWnd );

//			}

			//PAINTSTRUCT     ps;
			//HDC             hDC;
			//hDC = BeginPaint( hWnd, &ps );
			//HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);SelectObject(hDC, hPen);

			// drawing rectangle // 20180430
			// Parameters
			//hdc [in]
			//A handle to the device context.
			//nLeftRect [in]
			//The x-coordinate, in logical coordinates, of the upper-left corner of the rectangle.
			//nTopRect [in]
			//The y-coordinate, in logical coordinates, of the upper-left corner of the rectangle.
			//nRightRect [in]
			//The x-coordinate, in logical coordinates, of the lower-right corner of the rectangle.
			//nBottomRect [in]
			//The y-coordinate, in logical coordinates, of the lower-right corner of the rectangle.
			//Rectangle( hDC, 100, 100, 100, 100 );
			//EndPaint( hWnd, &ps );

            PAINTSTRUCT ps;
//            HFONT hFont;
//            RECT rect;
            RECT rect_2;

			HDC hdc = BeginPaint(hWnd, &ps);
			HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);
			SelectObject(hdc, hPen);
//			Ellipse(hdc, 100, 200, 400, 400);
//			Ellipse(hdc, 300, 300, 500, 510);
//			Rectangle( hdc, 100, 100, 200, 200 );
//			DeleteObject(hPen);


            //The font face name will be Impact.
//            hFont = CreateFont(48,0,0,0,FW_DONTCARE,FALSE,TRUE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
//                CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY, VARIABLE_PITCH,TEXT("Impact"));
//            SelectObject(hdc, hFont);
//            //Sets the coordinates for the rectangle in which the text is to be formatted.
//           SetRect(&rect, 100,100,700,200);
//            SetTextColor(hdc, RGB(255,0,0));
//            DrawText(hdc, TEXT("Drawing Text with Impact"), -1, &rect, DT_NOCLIP);
//

            SetRect(&rect_2, 300, 300, 400, 350);
			SetTextColor(hdc, RGB( 0, 0, 0));
			DrawText( hdc, TEXT( m_string ), -1, &rect_2, DT_NOCLIP);

			button1.drawButton ( hdc );
			button2.drawButton ( hdc );
			button3.drawButton ( hdc );
			button4.drawButton ( hdc );
			button5.drawButton ( hdc );
			button6.drawButton ( hdc );
			button7.drawButton ( hdc );

			EndPaint(hWnd, &ps);

        }
        //CASE WH_KEYBOARD:
        //{
		//	ButtonSelectDown () ;
		//}
        CASE WM_COMMAND:
        {
			if ( once_hook == 0 ) {

				sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
				once_hook = 1;
		        MessageBox(hWnd, "WM_COMMAND", "Inside", MB_OK);
				MyHookStart ( hWnd );

			}

            switch(LOWORD(wParam)) {
				case IDR_MYMENU:
					// SendMessage(hWnd, WM_CLOSE, 0, 0L);
					break;
				case ID_FILE_EXIT:
					break;
				case ID_STUFF_GO:
					break;
            }
        }
//        CASE WM_SYSCOMMAND:
//        {
//			if ( once_hook == 0 ) {
//
//		        MessageBox(hWnd, "WM_SYSCOMMAND", "Inside", MB_OK);
//				sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
//				once_hook = 1;
//				MyHookStart ( hWnd );
//
//			}
//
//        }
//        CASE WM_KEYUP:
//        {
//			ButtonSelectUp () ;
//		}
//        CASE WM_KEYDOWN:
//        {
//			ButtonSelectDown () ;
//		}
        CASE WM_ENDSESSION:         PostMessage( hWnd, WM_CLOSE, 0, 0 );
        CASE WM_LBUTTONDOWN:
        {
			SendMessage( hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
        }
        CASE WM_LBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_TOPMOST,   0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
        CASE WM_RBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
        DEFAULT:                    return DefWindowProc( hWnd, uMsg, wParam, lParam );
    }
    return 0;
}




void ButtonSelectDown () {
	ButtonLight( 0, m_button_number_select );
	m_button_number_select++;
	ButtonLight( 1, m_button_number_select );
}

void ButtonSelectUp () {
	ButtonLight( 0, m_button_number_select );
	m_button_number_select--;
	ButtonLight( 1, m_button_number_select );
}


// light = 0 means non-select
// light = 1 means select
void ButtonLight( int light, int bn ) {

	switch ( m_button_number_select ) {
	case 1:
		button1.setMode( light );
		break;
	case 2:
		button1.setMode( light );
		break;
	case 3:
		button1.setMode( light );
		break;
	case 4:
		button1.setMode( light );
		break;
	case 5:
		button1.setMode( light );
		break;
	case 6:
		button1.setMode( light );
		break;
	case 7:
		button1.setMode( light );
		break;
	}

}

//------------------------------------------------
// Set Window Procedure
//------------------------------------------------
static ATOM funcWindowClass( HINSTANCE hInstance, LPCTSTR lpClassName )
{
    WNDCLASSEX wcex = { 0 };
    wcex.cbSize         = sizeof(WNDCLASSEX);
    wcex.style          = CS_DBLCLKS;
    wcex.lpfnWndProc    = mainWindowProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon( NULL, IDI_APPLICATION );
    wcex.hIconSm        = LoadIcon( NULL, IDI_APPLICATION );
    wcex.hCursor        = LoadCursor( NULL, IDC_ARROW );
    wcex.hbrBackground  = (HBRUSH)GetStockObject( WHITE_BRUSH );
    wcex.lpszMenuName   = "IDR_MYMENU";
    wcex.lpszClassName  = lpClassName;
    return RegisterClassEx( &wcex );
}

//------------------------------------------------
// Set Window Size
//------------------------------------------------
static VOID funcSetClientSize( HWND hWnd, LONG sx, LONG sy )
{
    RECT rc1;
    RECT rc2;
    
    GetWindowRect( hWnd, &rc1 );
    GetClientRect( hWnd, &rc2 );
    sx += ((rc1.right - rc1.left) - (rc2.right - rc2.left));
    sy += ((rc1.bottom - rc1.top) - (rc2.bottom - rc2.top));
    SetWindowPos( hWnd, NULL, 0, 0, sx, sy, (SWP_NOZORDER|SWP_NOOWNERZORDER|SWP_NOMOVE) );
}

//------------------------------------------------
// Creation of Window
//------------------------------------------------
static HWND funcCreateWindow( HINSTANCE hInstance, LPCTSTR lpClassName, LPCTSTR lpTitleName, int nCmdShow )
{
    HWND hWnd = CreateWindowEx(
        0,                  // Expandation of Window Style
        lpClassName,        // Window Class Name
        lpTitleName,        // Window Title
        SCREEN_STYLE,       // Window Style
        CW_USEDEFAULT,      // Horizental window position
        CW_USEDEFAULT,      // Vertical window position
        CW_USEDEFAULT,      // Window width
        CW_USEDEFAULT,      // Window height
        NULL,               // Parent window handle
        NULL,               // handle of Menu bar
        hInstance,          // handle of Instance
        NULL );             // Put parameter Creation of window
    
    if ( hWnd != NULL ){
        funcSetClientSize( hWnd, SCREEN_WIDTH, SCREEN_HEIGHT );
        ShowWindow( hWnd, nCmdShow );
        UpdateWindow( hWnd );
    }
    return hWnd;
}

//------------------------------------------------
// Main Function
//------------------------------------------------
extern int WINAPI _tWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow )
{
    LPCTSTR lpClassName = TEXT("Lesson5WndClass");
    LPCTSTR lpTitleName = TEXT("Drawing Shapes");
    MSG Msg;
    
    // Set Window Class
    if ( funcWindowClass(hInstance,lpClassName) == 0 ){
        MessageBox( NULL, ERRMSG_WINREG, ERRMSG_TITLE, (MB_OK|MB_ICONERROR) );
        return -1;
    }
    // Creation of Window
    if ( funcCreateWindow(hInstance,lpClassName,lpTitleName,nCmdShow) == NULL ){
        MessageBox( NULL, ERRMSG_CREATE, ERRMSG_TITLE, (MB_OK|MB_ICONWARNING) );
        return -2;
    }
    // Message Loop
    while ( GetMessage(&Msg,NULL,0,0) > 0 ){
        TranslateMessage( &Msg );
        DispatchMessage( &Msg );
    }
    UNREFERENCED_PARAMETER( hPrevInstance );
    UNREFERENCED_PARAMETER( lpCmdLine );
    return Msg.wParam;
}

//------------------------------------------------------------------------------
// End of Lesson5.cpp
//------------------------------------------------------------------------------

void MyHookStart(HWND hWnd)
{
    HINSTANCE hInst;

    hInst = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);
    hMyHook = SetWindowsHookEx(WH_KEYBOARD,
        (HOOKPROC)MyHookProc,
        hInst,
        0);
    if (hMyHook == NULL)
        MessageBox(hWnd, "Failed to hook", "Error", MB_OK);

    return;
}

LRESULT CALLBACK MyHookProc(int nCode, WPARAM wp, LPARAM lp)
{

	sprintf( m_string, "nCode:%d wp:%d\n", nCode, wp );

    if (nCode < 0)
        return CallNextHookEx(hMyHook, nCode, wp, lp);
    if (wp >= 0x30 && wp <=0x39)
        return CallNextHookEx(hMyHook, nCode, wp, lp);

    MessageBeep(MB_OK);
    return TRUE;
}

void MyHookEnd(HWND hWnd)
{
    if (UnhookWindowsHookEx(hMyHook) != 0)
        MessageBox(hWnd, "Delete hook.", "OK", MB_OK);
    else
        MessageBox(hWnd, "Fail to delete hook", "Error", MB_OK);
    return;
}

/**
 *
 *  wParam, one of the: WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, or WM_SYSKEYUP
    lParam: pointer to a KBDLLHOOKSTRUCT structure

    (*) "The hook procedure should process a message in less time than the
    data entry specified in the LowLevelHooksTimeout value in the following registry key: 
    HKEY_CURRENT_USER\Control Panel\Desktop 

    The value is in milliseconds. If the hook procedure does not 
    return during this interval, the system will pass the message to the next hook."

 *
 */

/*
LRESULT CALLBACK
hook_proc( int code, WPARAM wParam, LPARAM lParam )
{
  static long ctrl_cnt = 0;
  static bool mmode = false;
  static DWORD time;

  KBDLLHOOKSTRUCT*  kbd = (KBDLLHOOKSTRUCT*)lParam;

  if (  code < 0
  ||   (kbd->flags & 0x10) // ignore injected events
     ) return CallNextHookEx( thehook, code, wParam, lParam );

  long ret = 1; // by default I swallow the keys
  if (  mmode  ) { // macro mode is ON
    if (  WM_KEYDOWN == wParam  )
      PostMessage(mainwnd, WM_MCR_ACCUM, kbd->vkCode, 0);

    if (  WM_KEYUP == wParam  )
      switch (kbd->vkCode) {
        case VK_ESCAPE:
          mmode = false;
          keys.removeall();
          PostMessage(mainwnd, WM_MCR_HIDE, 0, 0);
          break;

        case VK_RETURN:
          PostMessage(mainwnd, WM_MCR_EXEC, 0, 0);
          break;

        case VK_LCONTROL:
          mmode = false;
          PostMessage(mainwnd, WM_MCR_HIDE, 0, 0);
          PostMessage(mainwnd, WM_MCR_EXEC, 0, 0);
          break;
      }

    // Which non printable keys allow passing?
    switch( kbd->vkCode ) {
      case VK_LCONTROL:
      case VK_CAPITAL:
      case VK_LSHIFT:
      case VK_RSHIFT:
        ret = CallNextHookEx( thehook, code, wParam, lParam );
    }
  }
  else { // macro mode is OFF
    // Ctrl pressed 
    if (  kbd->vkCode == VK_LCONTROL && WM_KEYDOWN == wParam  ) {
      ctrl_cnt = 1;
      time = kbd->time;
    }

    // Prevent ctrl combinations to activate macro mode 
    if (  kbd->vkCode != VK_LCONTROL  )
      ctrl_cnt = 0;

    // Ctrl released 
    if (  ctrl_cnt == 1 && WM_KEYUP == wParam  ) {
      if (  kbd->time - time > 40  ) {
        mmode = true;
        PostMessage(mainwnd, WM_MCR_SHOW, 0, 0);
      }
    }

    ret = CallNextHookEx( thehook, code, wParam, lParam ); // let it pass
  }

  return ret;
}
*/

void SetNumLock( BOOL bState )
   {
      BYTE keyState[256];

      GetKeyboardState((LPBYTE)&keyState);
      if( (bState && !(keyState[VK_NUMLOCK] & 1)) ||
          (!bState && (keyState[VK_NUMLOCK] & 1)) )
      {
      // Simulate a key press
         keybd_event( VK_NUMLOCK,
                      0x45,
                      KEYEVENTF_EXTENDEDKEY | 0,
                      0 );

      // Simulate a key release
         keybd_event( VK_NUMLOCK,
                      0x45,
                      KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP,
                      0);
      }
   }

//------------------------------------------------
// Window Procedeure
//------------------------------------------------
// static LRESULT CALLBACK mainWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
// {
//     switch ( uMsg ){
//         CASE WM_CREATE:
//             /*
//             Initialization
//             */
//         CASE WM_CLOSE:
//             /*
//             Deposition
//             */
//             DestroyWindow( hWnd );
//         CASE WM_DESTROY:
//             PostQuitMessage( 0 );
//         CASE WM_PAINT:
//         {
//             PAINTSTRUCT     ps;
//             HDC             hDC;
//             
//             hDC = BeginPaint( hWnd, &ps );
//             /*
//             Drawing
//             */
//             EndPaint( hWnd, &ps );
//         }
//         CASE WM_ENDSESSION:         PostMessage( hWnd, WM_CLOSE, 0, 0 );
//         CASE WM_LBUTTONDOWN:        SendMessage( hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
//         CASE WM_LBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_TOPMOST,   0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
//         CASE WM_RBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
//         DEFAULT:                    return DefWindowProc( hWnd, uMsg, wParam, lParam );
//     }
//     return 0;
// }




