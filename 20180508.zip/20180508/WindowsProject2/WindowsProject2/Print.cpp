//#include "SDL.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//#include <iostream>
#include <cstdio>

#include "stdafx.h"
#include "Print.h"

//#define __cdecl	1
#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NON_CONFORMING_SWPRINTFS

//int __cdecl system(const char *);

extern "C" {
	void PrintError(const char* fmt, ...);
	wchar_t* vformat(const char* fmt, va_list args);
	wchar_t* _toChars(char * m_string);
	char* toChars(LPSTR str);

}

void error(const char* fmt, ...) {
	//	using namespace N;
	va_list ap;
	va_start(ap, fmt);

	// printf("%s", vformat(fmt, ap) );
	// printf("%s", vformat(fmt, ap));
	// _tprintf( _toChars("aaa") );
	// _tprintf(L"aaaa");
	// _tprintf( _toChars( (char *)"aaaa" ) );
	// _tprintf(_toChars( fmt));
	// int a = ppp( L"aaa" );
	// toChars( L"aaa" );
	// printf("aaa");
	// std::printf("aaa");
	// printf_s("aaa");

	// write memories
	// x printf("%s", vformat(fmt, ap) );
	char strx[2000];
	wsprintf((LPWSTR)strx, (LPCWSTR)"%s", vformat(fmt, ap));


	va_end(ap);
	//	exit(1);
}


int ppp (LPSTR a) {
	return 0;
}

/*
namespace N {
	class C {
		friend void FriendFunc() {
		}
		friend void AnotherFriendFunc(C* c) {}
	};
}
*/

void PrintError(const char* fmt, ...) {

	return;
}

char* toChars(wchar_t* str)
{
	char* cptc = (char*)str;
//	char* ptc = const_cast<(char*)>( str );

	return cptc;
}

wchar_t* _toChars(char* m_string )
{
	// LPSTR lpstr = const_cast<LPSTR>(m_string);
	// x LPCWSTR lpcwstr = const_cast<LPCWSTR>(m_string);
	// LPCWSTR lpcwstr = (LPCWSTR)lpstr;
	// T2A(L"aaa");
	// char *pc = (char*) TEXT( "aaa" );

	wchar_t* wp = (wchar_t*)m_string;

	return wp;
}

wchar_t* vformat(const char* fmt, va_list args) {
	char buf[2000];
	wchar_t* abuf;

	abuf = (wchar_t*) L"aaa";

	// x vswprintf(buf, _toChars((char*)fmt), args);
	// o vswprintf( abuf, L"aaa", args);
	// vswprintf( abuf, _toChars( (char*)fmt ), args);
	// o vswprintf(abuf, _toChars((char*)fmt), args);

	// char *str_org = (char *)"left=%d top=%d right=%d bottom=%d";
	char strx[2000];

	// o wsprintf( (LPWSTR)strx, (LPCWSTR)str_org, 10, 10, 10, 10);
	// o wsprintf( (LPWSTR)strx, (LPCWSTR)str_org, args);
	wsprintf((LPWSTR)strx, (LPCWSTR)fmt, args);

	// vsprintf(buf, 2000, _toChars((char*)fmt, args);
	// vswprintf(buf, fmt, args);
	// char* result = toChars( abuf );

	return abuf;
}

/*
std::string vformat(std::string fmt, va_list args) {
	char buf[2000];
	vsprintf(buf, fmt.c_str(), args);
	return std::string(buf);
}
*/

/*
void PrintErrorMsg(const char* fmt, ...);

void PrintErrorMsg(const char* fmt, ...) {

}*/
