#pragma once


//#include "Print.h"

extern void PrintErrorMsg(const char* fmt, ...);

