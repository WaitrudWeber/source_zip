#ifndef _WORK_007_H_
#define _WORK_007_H_
class WORK_007 { 
	public:
		WORK_008 *iWORK_007=nullptr;

	public:
		SetWORK_008( WORK008 *lWORK008 ); 

};
#endif
