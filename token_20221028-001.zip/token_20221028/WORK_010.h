#ifndef _WORK_010_H_
#define _WORK_010_H_
class WORK_010 { 
	public:
		WORK_001 *iWORK_010=nullptr;

	public:
		SetWORK_001( WORK001 *lWORK001 ); 

};
#endif
