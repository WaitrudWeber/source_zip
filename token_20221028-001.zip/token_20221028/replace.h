#ifndef _SENDER_H_
#define _SENDER_H_

typedef struct {
	FILE *fp;
	FILE *file_start;
	int index;
	int file_end_index;
} STRUCT_FILE;

extern int read_csv (char* filename ) ;
extern int read_csv_010 (char* filename ) ;
extern int replace_csv ( char* form_file, char* write_file ) ;
extern char* read_all (char* filename ) ;
extern char* read_all_002 (char* filename ) ;
extern char* read_all_003 (char* filename ) ;
extern int m_thread_sleep ();
extern char get_char ( STRUCT_FILE structure_fp) ;
extern char* get_string ( STRUCT_FILE structure_fp, int num ) ;
extern char* get_string_001 ( STRUCT_FILE structure_fp, int num ) ;
extern int filesize( FILE *fp ) ;
extern int print_csv () ;

#endif
