#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

typedef struct {
	FILE *fp;
	FILE *file_start;
	int index;
	int file_end_index;
} STRUCT_FILE;


int filesize( FILE *fp ) ;

char lines[10][10];
char dummy[256];
char g_dummy[255];
char*** csv = NULL;



int analyze_main () ;
int retrieve (char* filename) ;
int found_enter (char* filename) ;


int found_level1 (char* filename) ;
int a_compare (char* s1, char* s2 ) ;

int found_enter_002 (char* filename) ;
int found_enter_001 (char* filename) ;
int found_enter_003 (char* filename) ; // find "moov"
int found_enter_004 (char* filename) ; // find "---" and "\r\n"
int found_enter_006 (char* filename ) ;


int found_level_001 (int index, int file_end, FILE *fp ) ;
int found_level_002 (int index, int file_end, FILE *fp ) ;
int found_start (char* filename) ;
char* read_to ( char* to, int index, int file_end, FILE *fp ) ;
int start_readline (char* filename ) ;

char get_char ( STRUCT_FILE structure_fp) ;
char* get_string ( STRUCT_FILE structure_fp, int num ) ;

int write_block( char* w_filename, char* c_string ) ;
int replace_csv (char*** csv, char* form_file ) ;
char* read_all (char* filename ) ;

int found_enter_007 (char* filename );
//int typeofprimitive ( STRUCT_FILE* structure_fp, char* p_dummy_001 ) ;
int typeofprimitive ( STRUCT_FILE* structure_fp, char* p_dummy );



int main () {

	int ini = initialize_parse ();

	//int a = found_enter_003(".\\SANY0208\.MP4");
	//int a = found_enter_004(".\\001-20210114-004-C-001\.txt");
	int a = found_enter_007(".\\001-main.cpp");
//	int b = replace_csv ( csv,  ".\\001-form-20210211-001\.txt");

	// we can use found_007 as c analyzer.//20210629

	return 0;
}

//
// : https://www.cprogrammingbasics.com/itoa-function-in-c/
int replace_csv (char*** csv, char* form_file ) {
	char str_num[10];
	char* string;
	printf("replace_csv starts.\r\n");

	string = read_all(form_file);

	for( int i =0; i<10; i++ ) {
		for( int j =0; j<10; j++ ) {
			sprintf( str_num, "$%d%d", i, j );
			string = m_replace ( string, str_num, csv[i][j] );
			printf("replace: %d %d |%s|%s|:\r\n|%s|", i, j, str_num, csv[i][j], string);
			sleep(1);
		}
	}

	write_block( ".\\001-html-20210211-001\.txt", string );
	printf("replace_csv ends.\r\n");
	return -1;
}

//
char* read_all (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;

	printf("read_all starts.\r\n");

	if ( csv == NULL ) {
		csv = (char***) malloc( sizeof(char**) * 10 );
	}

	for( int i = 0; i<10; i++ ) {
		csv[i] = (char**) malloc ( sizeof(char**) * 10  );
	}

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 1);
		p_dummy[1] = '\0';

		p_dummy_token = put_token( p_dummy[0] );
	}


	return p_dummy_token;

	printf("read_all ends.\r\n");
}


//
int typeofprimitive ( STRUCT_FILE* structure_fp, char* p_dummy /*p_dummy_001*/ ) {
	int canread = 1;
//	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int col = 0;
	int index = 0;
	int i;

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<structure_fp->file_end_index && i <1000; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp->fp );

		structure_fp->index = i;
		p_dummy = get_string( (*structure_fp) , 8);
//		p_dummy[4] = '\0';

		if ( m_start_with ( (char*)p_dummy, "int" ) == 1 && canread == 1 ) {
			printf("we could find int.\r\n");
			canread = 2;
//			clear_token();
			sleep(2);
		} else if ( m_start_with ( (char*)p_dummy, "char" ) == 1 && canread == 1  ) {
			printf("we could find char.\r\n");
			canread = 2;
//			clear_token();
			sleep(2);
		} else if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 0  ) {
			printf("we could find line-end as unread.\r\n");
			canread = 2;
			clear_token();
			sleep(2);
		} else if ( m_start_with ( (char*)p_dummy, "double" ) == 1 && canread == 1 ) {
			printf("we could find double.\r\n");
			canread = 2;
//			clear_token();
			sleep(2);
		} else if ( m_start_with ( (char*)p_dummy, "float" ) == 1 && canread == 1 ) {
			printf("we could find float.\r\n");
			canread = 2;
			sleep(2);
		}
		p_dummy_token = put_token( p_dummy[0] );

		printf("typeofprimitive canread %d\r\n", canread);

		if ( canread == 2 ) return 1;
	}

	return 0;
}


int found_enter_007 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;

	printf("found_enter_007: starts.\r\n");

	if ( csv == NULL ) {
		csv = (char***) malloc( sizeof(char**) * 10 );
	}

	for( int i = 0; i<10; i++ ) {
		csv[i] = (char**) malloc ( sizeof(char**) * 10  );
	}

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();


	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 8);
//		p_dummy[4] = '\0';

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 1 ) {
			printf("we could find line end.\r\n");
			clear_token();
			i++;
			sleep(2);
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "#define" ) == 1 && canread == 1  ) {
			printf("we could find #define.\r\n");
			clear_token();
			sleep(2);
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 0  ) {
			printf("we could find line-end as unread.\r\n");
			canread = 1;
			clear_token();
			sleep(2);
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "#include" ) == 1 && canread == 1 ) {
			printf("we could find #include.\r\n");
			canread = 1;
			clear_token();
			sleep(2);
		} else if ( m_start_with ( (char*)p_dummy, "typedef" ) == 1 && canread == 1 ) {
			printf("we could find typedef.\r\n");
			canread = 1;
			sleep(2);
			exit(-1);
		} else if ( typeofprimitive ( &structure_fp, (char*)p_dummy ) == 1 && canread == 1 ) {
			printf(" we could find type.\r\n");
//			clear_token();
			canread = 2;
			i++;
			sleep(2);
//			exit(-1);
		} else if ( m_start_with ( (char*)p_dummy, ";" ) == 1 && canread == 2 ) {
			printf("Error: we could find semi-coon of line end.\r\n");
			printf("p_dummy_token %s p_dummy %s", p_dummy_token, p_dummy );
			sleep(2);
			exit(-1);
		}

		p_dummy_token = put_token( p_dummy[0] );
	}

	printf("found_enter_007: ends.\r\n");
	return 0;
}

int found_enter_006 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;

	printf("found_enter_006: starts.\r\n");

	if ( csv == NULL ) {
		csv = (char***) malloc( sizeof(char**) * 10 );
	}

	for( int i = 0; i<10; i++ ) {
		csv[i] = (char**) malloc ( sizeof(char**) * 10  );
	}

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();


	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 1 ) {
			printf("we could find line end.\r\n");
			csv[index][col] = (char*) copyof(p_dummy_token);
			printf("set csv[%d][%d] = |%s|.\r\n", index, col, csv[index][col] );
			clear_token();
			index++;
			col = 0;
			i++;
			sleep(2);
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "," ) == 1 && canread == 1  ) {
			printf("we could find comma.\r\n");
			csv[index][col] = (char*) copyof(p_dummy_token);
			printf("set csv[%d][%d] = |%s|.\r\n", index, col, csv[index][col] );
			col++;
			clear_token();
			sleep(2);
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && canread == 1 ) {
			printf("we could find double quoate start.\r\n");
			canread = 0;
			clear_token();
			sleep(2);
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && canread == 0 ) {
			printf("we could find double quoate end.\r\n");
			canread = 1;
			sleep(2);
		} else if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 0 ) {
			printf("Error: we could find enter before finding double quoate end.\r\n");
			csv[index][col] = (char*) copyof(p_dummy_token);

			clear_token();
			i++;
			sleep(2);
			exit(-1);
		}

		p_dummy_token = put_token( p_dummy[0] );
	}

	printf("found_enter_006: ends.\r\n");
	return 0;
}

//
//
//
//
//
int found_enter_004 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];

	printf("found_enter_004: starts.\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 0;

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 0 ) {
			printf("we could find line end.\r\n");
			canread = 1;
//			exit(-1);
		} else if ( m_start_with ( (char*)p_dummy, "---" ) == 1  && canread == 1 ) {
			printf("we could find canread=%d.\r\n", canread);
			canread = 2; // skip
			//block_string = copyof ( p_dummy_token ); //20210118
			sprintf(w_filename, "block-%04d-001-01.txt", b_index );
			printf("block %d %s |%s|\r\n", b_index, w_filename, block_string);
			b_index++;
//			exit(-1);
		} else if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1  && canread == 2 ) {

			printf("block %s |%s|\r\n", w_filename, p_dummy_token); //20210118
			write_block( w_filename, p_dummy_token);
			printf("write_block: %s\r\n", w_filename);
			canread = 1;
			int ini = initialize_parse ();
			sleep(3);
			//exit(-1);
		}

		p_dummy_token = put_token( p_dummy[0] );

		printf("block %s |%s|\r\n", w_filename, p_dummy_token); //20210118
		write_block( w_filename, p_dummy_token);
		printf("write_block: %s\r\n", w_filename);

		printf("bi:%d canread=%d i: %d: |%s| |%s|\r\n", b_index, canread, i, p_dummy, p_dummy_token );
	}

	printf("found_enter_004: ends.\r\n");
	return 0;
}


//
//
//
int write_block( char* w_filename, char* c_string ) {
	FILE *wfp;
	int ac;

	printf("write_block starts.\r\n");

	wfp = fopen( w_filename, "wb");

	ac = array_count ( c_string );

	fwrite( c_string, sizeof(char), ac, wfp);
	printf("cstring:\r\n|%s|\r\n", c_string);

	fclose(wfp);

	printf("write_block ends.\r\n");
}

//
//
//
//
//
int found_enter_003 (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;

	printf("found_enter_003: starts\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <100; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		if ( m_compare( (char*)p_dummy, "moov" ) == 1 ) {
			printf("we could find moov.\r\n");
			exit(-1);
		}

		p_dummy_token = put_token(p_dummy[0]);

		printf("i: %d: |%s| |%s|\r\n", i, p_dummy, p_dummy_token );
	}

	printf("found_enter_003: ends\r\n");
	return 0;
}



//
//
//
//
//
int start_readline (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	char* a_line = NULL;

	printf("start_readline: starts: filename %s\r\n", filename);

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i = 0; i<file_end && i<100; i++ ) {
		a_line = read_to ( "\r\n", i, file_end, fp );
		printf("a_line %s\r\n", a_line);
	}

	printf("start_readline: ends\r\n");
}

//
//
//
//
//
char* read_to ( char* to, int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;
	int count = 0;

	printf("read_to starts to |%s|.\r\n", (char*) to);

	tfp = fp;
	for ( j=0; j<256; j++ ) {
		b_dummy[j] = '\0';
	}

	for ( i =index; i<file_end && count<100; i++ ) {
		printf("i: %d loop starts.\r\n", i );

		for ( j=254; j>=0; j-- ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		/*if ( a_compare( (char*)b_dummy, to ) == 1 ) {
			printf("We found |%s| as |%s| index %d i %d tfp %d fp %d\ return 2r\n", to, b_dummy, index, i, tfp, fp);
			//return NULL;
			exit(-1);
		}*/

		count++;
		printf("i: %d loop ends.\r\n", i );
	}
	printf("read_to ends.\r\n");

	return NULL;
}


// From Head :
// 
// int index    :
// int file_end :
// FILE*     fp :
int found_level_001 (int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;
	char keyword[2][5] = { "#", "/*" };
//	char* keyword[2] = { "---", "/*" };
	int count = 0;

	printf("found_level_001 starts.\r\n");

	tfp = fp;
	for ( j=0; j<256; j++ ) {
		b_dummy[j] = '\0';
	}

	for ( i =index; i<file_end && count<100; i++ ) {
		printf("i: %d loop starts.\r\n", i );

		for ( j=254; j>=0; j-- ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( a_compare( (char*)b_dummy, (char *)keyword[0] ) == 1 ) {
			printf("We found |%s| as |%s| index %d i %d tfp %d fp %d\ return 2r\n", keyword[0], b_dummy, index, i, tfp, fp);
			return 2;
		}

		count++;
		printf("i: %d loop ends.\r\n", i );
	}

	printf("found_level_001 ends.\r\n");
}

/*

// From Head :
// 
// int index    :
// int file_end :
// FILE*     fp :
int found_level_001 (int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;
//	char keyword[2][5] = { "#", "/*" };
	char* keyword[2] = { "#", "/*" };

	tfp = fp;
	for ( j=0; j<256; j++ ) {
		b_dummy[j] = '\0';
	}

	for ( i =index; i<file_end; i++ ) {
		printf("i: %d loop starts.\r\n", i );

		for ( j=254; j>=0; j-- ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

//		if ( a_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
		if ( a_compare( (char*)b_dummy, (char*)keyword[0] ) == 1 ) {
			printf("We found Sharp |%s| index %d i %d tfp %d fp�@%d\r\n", b_dummy, index, i, tfp, fp);
			found_level_002 ( i + 1, file_end, fp );
			exit( -1 );
		}

		printf("i: %d loop ends.\r\n", i );
	}
}
*/
// From Head :
// 
// int index    :
// int file_end :
// FILE*     fp :
int found_level_002 (int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;
//	char keyword[2][5] = { "#", "/*" };
	char* keyword[2] = { "\r\n", "/*" };
	int count = 0;

	printf("found_level_002 starts.\r\n");

	tfp = fp;
	for ( j=0; j<256; j++ ) {
		b_dummy[j] = '\0';
	}

	for ( i =index; i<file_end && count < 100; i++ ) {
		printf("i: %d loop starts.\r\n", i );

		for ( j=254; j>=0; j-- ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = (char) dummy[0];

		// put_tokene is still useful if you don't like b_dummy.
		if ( a_compare( (char*)b_dummy, (char*)keyword[0] ) == 1 ) {
			printf("We found Enter |%s|%s| index %d i %d tfp %d fp�@%d count %d\r\n", b_dummy, keyword[0], index, i, tfp, fp, count);
			exit( -1 );
		}

		count++;
		printf("i: %d loop ends. |%s| next |%d| end|%d| count %d level_002\r\n", i,  b_dummy, b_dummy[1], b_dummy[count],  count );
	}

	for ( i =0; i<count; i++ ) {
		printf("i %d |%d| |%s| in level_002\r\n", i, b_dummy[i], b_dummy  );
	}

	printf("found_level_002 ends.\r\n");
}

//
//
//
//
int found_start (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	int a;

	printf("found_start: starts: filename %s\r\n", filename);

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i = 0; i<file_end && i<100; i++ ) {
		a = found_level_001 ( i, file_end, fp );

		switch ( a ) {
		case 1:
			a = found_level_001 ( i, file_end, fp );
			break;
		case 2:
			a = found_level_002 ( i, file_end, fp );
			break;
		}
	}

	printf("found_start: ends\r\n");
}

//
//
//
//
int found_level1 (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;

	printf("found_enter: starts\r\n");

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i =0; i<file_end; i++ ) {

		printf("i: %d loop starts.\r\n", i );

		for ( j=0; j<255; j++ ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( a_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
			printf("We found Eenter %s\r\n", b_dummy);
			exit( -1 );
		} else if ( a_compare( (char*)b_dummy, (char*)":" ) == 1 ) {
			printf("We found colon |%s|\r\n", b_dummy);
			exit( -1 );
		}

		printf("i: %d: |%d|%d|%d|%d| loop ends.\r\n", i, b_dummy[0], b_dummy[1], '\r', '\n' );

		// We could find flip side:
		//
		//
		if ( b_dummy[0] == 13 && b_dummy[1] == 10 ) {
			b_dummy[2] = '\0';
			printf("We found Eenter opposite side: |%s|\r\n", b_dummy);
			exit(-1);
		}
	}

	printf("found_enter: ends\r\n");
	return 0;
}

//
//
//
int a_compare (char* s1, char* s2 ) {
	int c, c1, c2;
	int i;
	char r1, r2;
	int result;
	int sep;

	c1 = array_count(s1);
	c2 = array_count(s2);

	if ( c1 < c2 ) {
		c = c1;
		r2 = s2[c1];	
		s2[c1] = '\0';	
		sep = 0;
	} if ( c1 == c2 ) {
		c = c1;
		sep = 1;
	} else {
		c = c2;
		r1 = s1[c2];	
		s1[c2] = '\0';	
		sep = 2;
	}

	printf("a_compare|%s||%s| 003\r\n", s1, s2);

	result = m_compare( s1, s2 );



	switch ( sep ) {
	case 0:
		printf("case sep=0\n");
		s2[c] = r1;
		break;
	case 1:
		printf("case sep=1\n");
		break;
	case 2:
		printf("case sep=2\n");
		s1[c] = r2;
		break;
	default:
		break;
	}

	printf("a_compare ends : result = %d\r\n", result);
	return result;
}

//
//
//
//
//
int found_enter_001 (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;

	printf("found_enter_001: starts\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;
	
	for ( i =0; i<file_end && i < 10; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		dummy[0] = get_char( structure_fp );
		dummy[1] = '\0';


		printf("i: %d: |%s| \r\n", i, dummy);

	}

	// Lootn check if we set 100 to the text file.
	for ( i =100; i<file_end && i >90; i-- ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		dummy[0] = get_char( structure_fp );
		dummy[1] = '\0';


		printf("i: %d: |%s| \r\n", i, dummy);

	}


	printf("found_enter_001: ends\r\n");
	return 0;
}

//
//
//
//
//
int found_enter_002 (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;

	printf("found_enter_002: starts\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;
	
	for ( i =0; i<file_end && i < 10; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		dummy[0] = get_char( structure_fp );
		dummy[1] = '\0';


		printf("i: %d: |%s| \r\n", i, dummy);

	}

	// Lootn check if we set 100 to the text file.
	for ( i =100; i<file_end && i >90; i-- ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 1);
		p_dummy[1] = '\0';

		printf("i: %d: |%s| \r\n", i, p_dummy);
	}


	printf("found_enter_002: ends\r\n");
	return 0;
}

//
//
//
char* get_string ( STRUCT_FILE structure_fp, int num ) {
	long diff;
	char c;

	printf("get_char starts.\r\n");

	diff = (long)structure_fp.fp - (long)structure_fp.file_start;

	// set
	//(long)structure_fp.file_start + (long)structure_fp.index;
	//	fseek(fp,0,SEEK_END);
	//	fseek(fp,0,SEEK_CUR);

	printf("struct_fp.fp |%d| struct_fp.index |%d|\r\n", structure_fp.fp , structure_fp.index);

	fseek( structure_fp.fp, structure_fp.index, SEEK_SET);
	fread ( g_dummy, 1, num, structure_fp.fp );

	printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

	printf("get_char ends.\r\n");

	return g_dummy;
}

// https://bituse.info/c_func/48
//
//
char get_char ( STRUCT_FILE structure_fp) {
	long diff;
	char c;
	char dummy[255];

	printf("get_char starts.\r\n");

	diff = (long)structure_fp.fp - (long)structure_fp.file_start;

	// set
	//(long)structure_fp.file_start + (long)structure_fp.index;
	//	fseek(fp,0,SEEK_END);
	//	fseek(fp,0,SEEK_CUR);

	printf("struct_fp.fp |%d| struct_fp.index |%d|\r\n", structure_fp.fp , structure_fp.index);

	fseek( structure_fp.fp, structure_fp.index, SEEK_SET);
	fread ( dummy, 1, 1, structure_fp.fp );

	printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

	printf("get_char ends.\r\n");

	return dummy[0];
}

//
//
//
//
//
int found_enter (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;

	printf("found_enter: starts\r\n");

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i =0; i<file_end; i++ ) {

		printf("i: %d loop starts.\r\n", i );

		for ( j=0; j<255; j++ ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( m_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
			printf("We found Eenter %s\r\n", b_dummy);
			exit( -1 );
		}

		printf("i: %d: |%d|%d|%d|%d| loop ends.\r\n", i, b_dummy[0], b_dummy[1], '\r', '\n' );

		// We could find flip side:
		//
		//
		if ( b_dummy[0] == 13 && b_dummy[1] == 10 ) {
			b_dummy[2] = '\0';
			printf("We found Eenter opposite side: |%s|\r\n", b_dummy);
			exit(-1);
		}
	}

	printf("found_enter: ends\r\n");
	return 0;
}

int analyze_main () {
	FILE *fp;
	int i;
	char dummy[256];
	char* filename = ".\\alphabet-001.txt";
	char* filename_split = ".\\001-split-001.txt";
//	char spit_line[10];
	char basic[3];

	basic[2] = '\0';

	fp = fopen(filename_split, "rb");
	int file_end = filesize ( fp );

	int start = 0;
	int j = 0;
	// first, we are going to find "spit_line".
	// each block should be stored as block name eve like "001-block---001.txt".
	// and we care following orders.
	//
	for ( i =0; i<file_end; i++ ) {
		printf("loop start i: %d: j: %d: \r\n", i, j );
		fread ( dummy, 1, 1, fp);

		dummy[1] = '\0';
		basic[1] = dummy[0];

		// find line end and space.
		if ( m_compare( (char*)basic, (char*)"\r\n" ) == 1 ) {
			lines[j][i- start - 1 ] = '\0'; //---\r\n if i= 4
			j++;
			start = i + 1;
			//printf("i %d j %d temporary end.\r\n");
			//exit(-1);
		} else {
			lines[j][ i - start ] = dummy[0];
			lines[j][ i - start + 1 ] = '\0';
		}

		printf("loop   end i: %d: |%s| j:%d|%s| basic|%s| start:%d\r\n", i, dummy, j, lines[j], basic, start);
		basic[0] = basic[1];
	}

//	printf("split_line: %s\r\n", spit_line);
	fclose(fp);

	for ( i =0; i<10; i++ ) {
		printf("lines[%d]|%s|\r\n", i, lines[i]);
	}


	/*fp = fopen(filename, "rb");
	file_end = filesize ( fp );
	for ( i =0; i<file_end; i++ ) {
		fread ( dummy, 1, 1, fp);
		dummy[1] = '\0';
		printf("%d: %s\r\n", i, dummy);
	}

	close(fp);*/
	return 0;
}

// 202007710
// START as character
// EOF
int retrieve (char* filename) {
	FILE *fp;
	int i;
	char dummy[256];
	char basic[3];

	printf("retrieve: %s starts.\r\n", filename);

	fp = fopen(filename, "rb");
	int file_end = filesize ( fp );
	int start = 0;
	int j = 0;
	int line_count = 0;
	// first, we are going to find "spit_line".
	// each block should be stored as block name eve like "001-block---001.txt".
	// and we care following orders.
	//
	printf("file_end %d\r\n", file_end );
	for ( i = 0; i<file_end && i<100; i++ ) {
		printf("loop start i: %d: file_end %d: \r\n", i, file_end  );
		fread ( dummy, 1, 1, fp);

		dummy[1] = '\0';
		basic[1] = dummy[0];

		// find line end.
		if ( m_compare( (char*)basic, (char*)"\r\n" ) == 1 && line_count!= 0 ) {
			lines[j][i- start - 1 ] = '\0'; //---\r\n if i= 4

			char* a = (char*)lines[j];
			if ( i - start - 1 == 0 ) {
				printf("no word\r\n");
				exit(-1);
			} else {
				line_count++;
				//printf("line_count %d\r\n" line_count);
				exit(-1);
			}
			j++;
			start = i + 1;
		} else {
			lines[j][ i - start ] = dummy[0];
			lines[j][ i - start + 1 ] = '\0';
		}

		printf("loop ends i: %d: dummy: |%s| basic: |%s|\r\n", i, dummy, basic );
		basic[0] = basic[1];
	}

	printf("retrieve: %s ends.\r\n", filename);
	return 1;
}



int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

