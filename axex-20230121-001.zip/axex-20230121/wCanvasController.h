#ifndef WCANVASCONTROLLER_H
#define WCANVASCONTROLLER_H

#include "wEvent.h"

class wCanvasController {

	public:
		int key_wParam_Keyup = 0;
		int Processed = 0;
		int ProcessedKeyup = 0;
		int AXEX_2D_002_Max  = 30;
		int AXEX_2D_002_Index  = 0;
		int AXEX_2D_002_Index_Selected  = 0;
		int AXEX_2D_LINE_Index = 0;
		int Blued = 0;   // 128 -> 256 : 
		int Greened = 0; //   0 -> 128 : 
		int Draw_Pixel_Buffer_001 = 0;
		int Init_Pixel_Buffer_001 = 0;

	private:
		int call_once_key = 0;
		vLine** axline = nullptr;
		int width = 640;
		int height = 480;
		int screen_x = 0;
		int screen_y = 0;
		int screen_width = 160;
		int screen_height = 90;
		// 001
		int buf_start_x = 0;
		int buf_start_y = 0;
		int block_x  = 5;
		int block_y  = 5;
		vAxex_2D vAxex_2D_002[30];
		unsigned char buffer[160][90][4];
		wEvent* event;
//		vDisplayController vDisp;
//		wDisplayController wDisp;

	public:
		wCanvasController ();
		void kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
		void Process ();
		void ProcessWmPaint ();
		void ProcessWmChar ();
		void ProcessWmKeyup ();
		void setEvent( wEvent* evt );
//		void Print_struct(wJavaStructure top ) ;
		void Set_vAxex_2D ( float x, float y );
		int Get_vAxex_2D ( int num, float *x, float *y );
		int GetSelected ();
		void Initialize_Axex ( ) ;
		void Initialize_Buffer ( ) ;
		void Set_Axex_Line( int x1, int y1, int x2, int y2 );
		int Draw_Buffer ( ) ;
		int Draw_Buffer_001 ( ) ;
		int Draw_Buffer_002 ( ) ;
		int Initialize_Buffer_001 () ;
		int Set_Buffer (int xx, int yy, int col, unsigned char vv ) ;
		void ProcessLinesWmPaint () ;
		void ProcessAxexWmPaint () ;
		void SetWaveValue( int wavevalue );
		void ProcessEllipseWmPaint () ;
		// 001-01
		int SetPixelCanvas (int start_x, int start_y, int blk_x, int blk_y ) ;
		int Draw_Pixel_Buffer ( ) ;
		int Line_Slope (int x1, int y1, int x2, int y2) ;
		int Line_Slope (int x1, int y1, int x2, int y2, int color_num ) ;
		vLine** CreateTriangleLine( vPoint p1, vPoint p2, vPoint p3, int* result_num );	
		int draw_line_001 ( int x1, int y1, int x2, int y2, unsigned char num, unsigned char col ) ;
		void step_cursol_test_001 ( );
		void set_color_001  ( );
		void set_color_001  ( int i, int j, unsigned char num, unsigned char col )  ;
		int get_pixel_buffer( int i, int j, unsigned char* rgbt );
		int put_pixel_buffer( int i, int j, unsigned char rgbt[4] );

	private:
		void step_cursol ( unsigned char ***img, double cur, int base, int xy_flg, unsigned char num, unsigned char col ) ;
		void step_cursol_test  ( unsigned char ***img );
		void step_cursol_001  ( double cur, int base, int xy_flg, unsigned char num, unsigned char col ) ;

};

#endif
