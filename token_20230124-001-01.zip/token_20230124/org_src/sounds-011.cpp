#include "sounds-011.h"


void SoundEffect::dummy_function() {

	return;
}



