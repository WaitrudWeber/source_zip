//SOUNDS_WORK_001
// SOUNDSSOUNDSWORK001
//
#ifndef _SOUNDS_WORK_001_H_
#define _SOUNDS_WORK_001_H_

class SOUNDS_WORK_001 { 
	public:
		SOUNDS_WORK_001 *iSOUNDS_WORK_001=nullptr;
		char* m_buffer;
		int num_buffer = 255;
		double sample = 1.0;

	private:
		HWAVEOUT m_waveOut; // Handle to sound card output
		WAVEFORMATEX m_waveFormat; // The sound format
		WAVEHDR m_waveHeader; // WAVE header for our sound data
		HANDLE m_done;	// Event Handle that tells us the sound has finished being played.
						// This is a very efficient way to put the program to sleep
						// while the sound card is processing the sound buffer
	public:
		void SetWORK_001 (); 
		void Play ();
//		void SetWORK_001( SOUNDS_WORK_001 *lSOUNDSWORK001 ); 



};
#endif