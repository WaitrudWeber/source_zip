#include "WORK_000.h"
#include "WORK_001.h"
void WORK_000::SetWORK_001( WORK001 *lWORK001 ){ 

}
