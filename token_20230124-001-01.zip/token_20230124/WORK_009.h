#ifndef _WORK_009_H_
#define _WORK_009_H_
class WORK_009 { 
	public:
		WORK_000 *iWORK_009=nullptr;

	public:
		SetWORK_000( WORK000 *lWORK000 ); 

};
#endif
