#ifndef _V_MODEL_BUFFER_CONTROLLER_H_
#define _V_MODEL_BUFFER_CONTROLLER_H_

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vScreenCG.h"

// 1. copy vDisplayController_001.h vDisplayController_001.cpp.
// 2. renumber by use of replace vDisplayController_001 to vModelBufferController in them above.
// 3. add Makefile vDisplayController_001.cpp.

class vModelBufferController {

	private:
		vPoint bones_001[10];
		int bones_max = 10;
		int bones_max_index = 0;
		//20250216
		vPoint** bones_006_01 = NULL;
		int bones_index_006_01 = 0;
		int bones_max_006_01 = 0;
		//20250216
		vCalculation Calc;
		vScreenCG screen_006;
		vLine** axex_line_3d_002 = nullptr;
		int axex_line_max = 3;
		vLine** line_2D = nullptr;
		int line_2D_max = 3;
		int create_bones_initialized = -1;

	public:
		int param_print = 0; // 1 is very slow abd exut.
		int debug = 2; // 0: 1: 2:

	private:
		int Set_Canvas_Bones () ;
		vPoint** reallocation_set_point_2d (int num); // 20250216
		int CreateBones () ;
//		int SetCanvasBones_002 () :
//		int SetCanvasBones () :


	public:
		int Organize_Axex_2D (vLine** lines, int num);
		vLine** GetAxex2D(int* num);
		//20250216
		vPoint** GetPoints(int* num);
		int SetPoint2D( float x, float y );
		int CreateBones_call_one_time () ;
		//20250216
		vLine** GetAxex(int* num);
		int SetupScreen ();
		int SetupAxex ();
		// 20250611
		int ConvertionBonesOntheFace ();
		// 20250615
		int SetEye (vPoint p);
		int PrintEye ();
		vPoint** GetPoints3D(int* num);
		int Print3DBones ();
} ;

#endif

