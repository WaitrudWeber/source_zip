#ifndef _MEMORIES_H_
#define _MEMORIES_H_

extern int debug_print_msg;

extern int wait_sharp_short_time () ;
extern int set_wait_sharp_short_time (int num);

extern int set_debug_param_msg_num ( int num);
extern int wait_sharp_short_time () ;
extern int debug_print_msg_sleep ();
extern int set_debug_print_msg_sleep (int sl );

// 20250615
extern int set_debug_param (int dp );
extern int print_debug_param ();


#endif