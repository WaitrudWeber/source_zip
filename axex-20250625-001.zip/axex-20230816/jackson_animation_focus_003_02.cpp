#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"
#include "parse.h"
#include "aToken.h"
#include "memories.h"

#include "vVectorCG.h"

#include "wEvent.h"
#include "cg_schema.h"

#include "log_001.h"

#include "image_layer_001.h"
#include "settle_grid_001.h"

#include "vVectorCG.h"
#include "vModelBufferController.h"

#include "vDisplayController.h"
#include "vDisplayController_001.h"
#include "vModelBufferController.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "jackson_animation_focus_003.h"
#include "jackson_animation_focus_003_01.h"
#include "jackson_animation_focus_003_02.h"

int debug_sleep_003_02 = 1;

int draw_circle_line_to_fix1_02 ( double i, double j, float base, int skip, int type );
int line_to_005 (float x1, float y1, float x2, float y2, double a, float base, int type, int first_type) ;
int Draw_Circle_Line_005 (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;
int Draw_Line_and_Focus ();
int Draw_Line_and_Focus_thin ();
int Draw_Line_and_Focus_thin_axex ();

int draw_circle_line_to_005 ( double i, double j, float base, int skip, int type ) ;
int draw_circle_line_to_005_Normal ( double i, double j, float base, int skip, int type ) ;
int draw_circle_line_to_005_Normal_05 ( double i, double j, float base, int skip, int type ) ;

int Draw_Circle_focus( float x, float y, float r );
int Set_Debug_Sleep_003_02 (int value );

int Organize_Axex (int type);
int Print_Organize_Axex (vLine** lines, int num);
int Draw_Organize_Axex (vLine** lines, int num);

// 20250530
int Organize_Axex_Bones (int type );
int Draw_Organize_Bones_Line_005 (vPoint** points, int num);
// 20250611
int Change_Eye_thin_axex_bones ();
// 20250615
int Print_Focuses ();

// 			1: Sleep
// any other�F Skip
int Set_Debug_Sleep_003_02 (int value ) {

	debug_sleep_003_02 = value;

	return 0;
}

// 20250615
int Print_Focuses () {
	int a;
	printf("int Print_Focuses () starts.\r\n");

	a =  print_set_focus ();
	a = print_set_draw_focus ();
	a = display_006_01.PrintEye ();
	a = display_006_01.Print3DBones ();

	printf("int Print_Focuses () ends.\r\n");
	return 0;
}


// 20250425
int Draw_Circle_focus( float x, float y, float r ) {
	int a;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_focus( %0.3f, %0.3f, %0.3f ) starts.\r\n", x, y, r );

	a = set_circle ( x, y, r );
	a = Draw_Jackson_Focus_Circle ();
	//exit(-1);

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_focus( %0.3f, %0.3f, %0.3f ) ends.\r\n", x, y, r );
	return 0;
}

//20240904
int Draw_Circle_Line_005 (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) {
	double a;
	int flip = 0;
	int value;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_005 (float x1, float y1, float x2, float y2, float bold ) starts.\r\n");

	a = (double)( y2 - y1 ) / (double)( x2 - x1 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs(a) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs(a) > 1.0 ) flip = 0;

	if ( debug_print_msg_param () == 1 ) printf("flip %d\ a %f\r\n", flip, a);

	// 20240904
	// diagnal first_type 1
	switch (flip) {
	case 0:
		value = line_to_005 ( x1, y1, x2, y2, a , bold * 2.0, type, first_type );
		break;
	case 1:
		value = line_to_005 ( x2, y2, x1, y1, a, bold * 2.0, type, first_type );
		break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_005 (float x1, float y1, float x2, float y2, float bold ) ends.\r\n");
	return 0;
}

// 20240904
// float input
int line_to_005 (float x1, float y1, float x2, float y2, double a, float base, int type, int first_type) {
	int flag = 0;
	int skip = 0;
	int cnt = 0;
	double i, j;
	int *hh;
	int aa;
	double	da_m_base;
	int ii, jj, p_ii, p_jj;

	if ( debug_print_msg_param () == 1 ) printf("int line_to_005 (int %4d, int %4d, int %4d, int %4d, double %0.3f) starts.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	hh = (int*) &(p_jackson->fore_ground_colour);
	i = (double) x1;
	j = (double) y1;

	ii = (int)( i / base);
	jj = (int)( j / base);
	ii *= base;
	jj *= base;

	// 20240905
	// first step
	// type 1:
//	aa = first_line_to_003 ( (float) x1, (float) y1, (float) x2, (float) y2, (double) a, (float) base, flag, 1, first_type, cnt, (double*) &i, (double*) &j )  ;
//	if ( aa == 1 ) cnt++;

	p_ii = -1;
	p_jj = -1;

	da_m_base = a * base ;
	// step works and their code blocks for easiness
	while(1) {
		if ( debug_print_msg_param () == 1 ) printf("i %0.3f j %0.3f ", i, j );

		aa = check_break_line_to_003_01 ( (double) i, (double) j, (int) flag, (int) x2, (int) y2 ) ;
		if ( aa == 1 ) break;
		aa = check_break_line_to_003_02 ( (double) i, (double) j, (int) flag, (int) cnt, (int*) &skip ) ;
		if ( aa == 1 ) break;

		ii = (int)( i / base);
		jj = (int)( j / base);
		ii *= base;
		jj *= base;

		switch(p_jackson->flag_line_start) {
		case 0:
		case 1:
			break;
		default:
			printf("p_jackson->flag_line_start %d\r\n", p_jackson->flag_line_start);
			exit(-1);
		}

		// 20250523
		switch( cnt ) {
		case 0:
			p_jackson->flag_line_start = 1;
			break;
		case 1:
			p_jackson->flag_line_start = 0;
			break;
		default:
			break;
		}

		// 20240904
		// additional part
		// diagnal: first_type 1:
		// fabs is not necesarry.
		if ( p_ii != -1 && p_jj != -1 && abs(ii - p_ii) >= fabs(base) && abs(ii - p_jj) >= fabs(base) && first_type == 1 ){

			if ( flag == 1 ) {
				aa = draw_circle_line_to_fix1_02 ((double) p_ii, (double) jj, (float) base, skip, type );
			} else {
				aa = draw_circle_line_to_fix1_02 ((double) ii, (double) p_jj, (float) base, skip, type );
			}
		}

		// 20240904
		aa = draw_circle_line_to_fix1_02 ((double) ii, (double) jj, (float) base, skip, type );

		if ( debug_print_msg_param () == 1 ) printf("v %d\r\n", (int)*hh );
		if ( skip == 0 ) cnt++;


		p_ii = ii;
		p_jj = jj;

		if (flag == 1 ) {
			j += base;
			i += da_m_base;
		} else {
			i += base;
			j += da_m_base;
		}
	}

	if ( debug_sleep_003_02 == 1 ) {
		printf( "cnt=%d base %f da_m_base %f \r\n", cnt, base, da_m_base );
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
	}

	if ( debug_print_msg_param () == 1 ) printf("int line_to_005 (int %4d, int %4d, int %4d, int %4d, double %0.3f) ends.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);
	return 0;
}

//
//
//
// type: 5
// type: 4
// type: 3
// type: 2
// type: 1
// type: 0
int draw_circle_line_to_fix1_02 ( double i, double j, float base, int skip, int type )  {
	int aa;
	static int cnt_02 = 0;

	if ( cnt_02 == 0 && debug_sleep_003_02 == 1 ) {
		cnt_02++;
		printf( "(%0.3f,%0.3f) <- ", i, j );
		printf( "cnt_02=%d base %f\r\n", cnt_02, base );
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
	}

	if ( type > 4 )
		aa = draw_circle_line_to_005_Normal_05 ( (double) i, (double) j, (float) base, skip, type  - 4 ) ;
	else if ( type > 2 )
		aa = draw_circle_line_to_005_Normal ( (double) i, (double) j, (float) base, skip, type  - 2 ) ;
	else
		aa = draw_circle_line_to_005 ( (double) i, (double) j, (float) base, skip, type ) ;

	// type: 0
	// type: 1

	// p_jackson->draw_focus
	aa = Stack_Oneof_Several_Focus_Large(( ANIMATION_FOCUS*) &(p_jackson->draw_focus), 3 );

	return 0;
}

// 20240905
// type 1
// type 2 fraction
//
//
//
int draw_circle_line_to_005 ( double i, double j, float base, int skip, int type ) {
	int a_i, a_j;
	int aa;
	double fi, fj;
	double frac;
	RGBT rgbt;
	double radius = 0.0;

	printf("int draw_circle_line_to_005 ( double i, double j, float base, int skip, int type ) starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("skip %d type %d \r\n", skip, type);

	if ( base <= 1.0 ) radius = 1.0;
	else radius = base / 2.0;

	if ( type >= 2 ) 
		frac = base / 2.0;
	else
		frac = base * 0.99;

	if ( skip == 0 ) {
		if ( type >= 1 ) {
			if ( type == 2 ) {
				a_i = (i + base / 2.0) / base;
				a_j = (j + base / 2.0) / base;
			} else {
				a_i = i / base;
				a_j = j / base;
			}
			a_i *= base;
			a_j *= base;
			fi = i - a_i;
			fj = j - a_j;
			if ( debug_print_msg_param () == 1 ) printf("a(i,j) =(%d,%d) f(%0.3f,%0.3f) base %0.3f frac %0.3f\r\n", a_i, a_j, fi, fj, base, frac );
			if ( fi >= frac || fj >= frac ) {
				aa = Get_Font_Colour ( &rgbt );
				aa = Set_Font_Colour_Rgb ( 0, 0, 255 );
				aa = Draw_Circle( (float) i, (float) j, radius ); //r
				aa = Set_Font_Colour_Rgb ( rgbt.r, rgbt.g, rgbt.b );
			} else
				aa = Draw_Circle( (float) a_i, (float) a_j, radius ); //r
		} else aa = Draw_Circle( i, j, radius ); //r
	}

	printf("int draw_circle_line_to_005 ( double i, double j, float base, int skip, int type ) ends.\r\n");
	return 0;
}



// type 1
// type 2 fraction
//
//
//
int draw_circle_line_to_005_Normal ( double i, double j, float base, int skip, int type ) {
	int a_i, a_j;
	int aa;
	double fi, fj;
	double frac;
	RGBT rgbt;
	double radius = 0.0;

	printf("int draw_circle_line_to_005_Normal ( double i, double j, float base, int skip, int type ) starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("skip %d type %d \r\n", skip, type);

	if ( base <= 1.0 ) radius = 1.0;
	else radius = base / 2.0;

	if ( type >= 2 ) 
		frac = base / 2.0;
	else
		frac = base * 0.99;

	if ( skip == 0 ) {
		if ( type >= 1 ) {
			if ( type == 2 ) {
				a_i = (i + base / 2.0) / base;
				a_j = (j + base / 2.0) / base;
			} else {
				a_i = i / base;
				a_j = j / base;
			}
			a_i *= base;
			a_j *= base;
			fi = i - a_i;
			fj = j - a_j;
			if ( debug_print_msg_param () == 1 ) printf("a(i,j) =(%d,%d) f(%0.3f,%0.3f) base %0.3f frac %0.3f\r\n", a_i, a_j, fi, fj, base, frac );
			if ( fi >= frac ) { 
				aa = Get_Font_Colour ( &rgbt );
				aa = Set_Font_Colour_Rgb ( 0, 128, 0 );
				aa = Draw_Circle( (float) a_i + base,  (float) a_j, radius ); //r
				aa = Set_Font_Colour_Rgb ( rgbt.r, rgbt.g, rgbt.b );
			} else if ( fj >= frac ) {
				aa = Get_Font_Colour ( &rgbt );
				aa = Set_Font_Colour_Rgb ( 0, 128, 0 );
				aa = Draw_Circle( (float) a_i, (float) a_j + base, radius ); //r
				aa = Set_Font_Colour_Rgb ( rgbt.r, rgbt.g, rgbt.b );
			} else {
				aa = Draw_Circle( (float) a_i, (float) a_j, radius ); //r
			}
		} else aa = Draw_Circle( i, j, radius ); //r
	}

	printf("int draw_circle_line_to_005_Normal ( double i, double j, float base, int skip, int type )endts.\r\n");
	return 0;
}


// 5 -> 1
// 6 -> 1
// type 1
// type 2 fraction
//
//
//
int draw_circle_line_to_005_Normal_05 ( double i, double j, float base, int skip, int type ) {
	int a_i, a_j;
	int aa;
	double fi, fj;
	double frac;
	RGBT rgbt;
	double radius = 0.0;

	printf("nt draw_circle_line_to_005_Normal_05 ( double i, double j, float base, int skip, int type ) starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("skip %d type %d \r\n", skip, type);

	if ( base <= 1.0 ) radius = 1.0;
	else radius = base / 2.0;

	if ( type >= 2 ) 
		frac = base / 2.0;
	else
		frac = base * 0.99;

	if ( skip == 0 ) {
		if ( type >= 1 ) {
			if ( type == 2 ) {
				a_i = (i + base / 2.0) / base;
				a_j = (j + base / 2.0) / base;
			} else {
				a_i = i / base;
				a_j = j / base;
			}
			a_i *= base;
			a_j *= base;
			fi = i - a_i;
			fj = j - a_j;
			if ( debug_print_msg_param () == 1 ) printf("a(i,j) =(%d,%d) f(%0.3f,%0.3f) base %0.3f frac %0.3f\r\n", a_i, a_j, fi, fj, base, frac );
			if ( fi >= frac ) { 
				aa = Draw_Circle( (float) a_i + base,  (float) a_j, radius ); //r
			} else if ( fj >= frac ) {
				aa = Draw_Circle( (float) a_i, (float) a_j + base, radius ); //r
			} else {
				aa = Draw_Circle( (float) a_i, (float) a_j, radius ); //r
			}
		} else aa = Draw_Circle( i, j, radius ); //r
	}

	printf("nt draw_circle_line_to_005_Normal_05 ( double i, double j, float base, int skip, int type ) ends.\r\n");
	return 0;
}

// 20250528
int Organize_Axex (int type ) {
	int a, num;
	vLine** lines;
	printf("int Organaize_Axex (int type ) starts.\r\n");

	display_006_01.CreateBones_call_one_time ();

	lines = (vLine**)display_006_01.GetAxex2D (&num);
	a = Print_Organize_Axex (lines, num);
	a = Draw_Organize_Axex (lines, num);


	switch ( type ) {
	case 1:
		a = set_focus ( 0, 0, 640, 480);
		break;
	default:
		break;
	}

	printf("int Organaize_Axex (int type ) ends.\r\n");
	return 0;
}


// 20250531
int Draw_Organize_Bones_Line_005 (vPoint** points, int num) {
	int i, a;
	RGBT rgbt;
	printf("int Draw_Organize_Bones_Line_005 (vPoint** points, int num) starts.\r\n");

	rgbt = p_jackson->fore_ground_colour;
	a = Set_Font_Colour_Rgb ( rgbt.r, rgbt.g, rgbt.b );



	for ( i = 1; i<num; i++ ) {
		a =	Draw_Circle_Line_005 ( points[i - 1]->x, points[i - 1]->y, points[i]->x, points[i]->y, 0.5, 0, 0 );
//		a =	Draw_Circle_Line_005 ( points[i - 1]->x, points[i - 1]->y, points[i]->x, points[i]->y, 0.5, 2, 0 );
	}

	printf("int Draw_Organize_Bones_Line_005 (vPoint** points, int num) ends.\r\n");
	return 0;
}


// 20250530
int Organize_Axex_Bones (int type ) {
	int a, num;
	vLine** lines;
	vPoint** points;
	printf("int Organaize_Axex (int type ) starts.\r\n");

	display_006_01.CreateBones_call_one_time ();

	lines = (vLine**)display_006_01.GetAxex (&num);
	a = Print_Organize_Axex (lines, num);

	lines = (vLine**)display_006_01.GetAxex2D (&num);
	a = Print_Organize_Axex (lines, num);
	a = Draw_Organize_Axex (lines, num);

	// Bones
	a = Initialize_Organize_Bones ();

	// get points 3D
	display_006_01.Print3DBones ();
	points = (vPoint**)display_006_01.GetPoints3D (&num);
	a = Print_Organize_Bones (points, num);

	// get points 2D
	points = (vPoint**)display_006_01.GetPoints (&num);
	printf("points|%p| num %d\r\n", points, num );
	// set points -> Draw points
	a = Print_Organize_Bones (points, num);

	// DEBUG
	a = set_debug_param (0);
	a = set_debug_param_msg_num (1000);
	a = print_debug_param ();

	printf("debug_msg set 1000 from this part.\r\n");

	a = Draw_Organize_Bones (points, num);
	printf("Draw_Organize_Bones: points|%p| num %d\r\n", points, num );
//	a = Draw_Organize_Bones_Line_005 (points, num);
//	printf("Draw_Organize_Bones_Line_005: points|%p| num %d\r\n", points, num );

	a = Release_Organize_Bones ();

	switch ( type ) {
	case 1:
		a = set_focus ( 0, 0, 640, 480);
		break;
	default:
		break;
	}

	printf("int Organaize_Axex (int type ) ends.\r\n");
	return 0;
}


// 20250528
int Print_Organize_Axex (vLine** lines, int num) {
	int i, a;
	vPoint* p1;
	vPoint* p2;
	printf("int Print_Organaize_Axex (vLine** lines, int num) starts.\r\n");


	if ( lines == NULL ) {
		printf("lines is NULL.\r\n");
		exit(-1);
	}

	for ( i = 0; i<num; i++ ) {
		p1 = lines[i]->p1;
		p2 = lines[i]->p2;
		printf("line[%d](%0.3f,%0.3f,%0.3f) -> (%0.3f,%0.3f,%0.3f)\r\n", i, p1->x, p1->y, p1->z, p2->x, p2->y, p2->z );
	}

	a = wait_sharp_short_time ();
	printf("int Print_Organaize_Axex (vLine** lines, int num) ends.\r\n");
	if ( debug_print_msg_sleep () == 1 ) Sleep(5000);
	return 0;
}


// 20250528
int Draw_Organize_Axex (vLine** lines, int num) {
	int i;
	vPoint* p1;
	vPoint* p2;
	int a;
	printf("int Draw_Organaize_Axex (vLine** lines, int num) starts.\r\n");


	if ( lines == NULL ) {
		printf("lines is NULL.\r\n");
		exit(-1);
	}

	for ( i = 0; i<num; i++ ) {
		p1 = lines[i]->p1;
		p2 = lines[i]->p2;
		printf("line[%d](%0.3f,%0.3f,%0.3f) -> (%0.3f,%0.3f,%0.3f)\r\n", i, p1->x, p1->y, p1->z, p2->x, p2->y, p2->z );
		a =	Draw_Circle_Line_005 ( p1->x, p1->y, p2->x, p2->y, 0.5, 0, 0 );
	}

	a = Print_Refresh_Several_Focus ();

	printf("int Draw_Organaize_Axex (vLine** lines, int num) ends.\r\n");
	return 0;
}


int Draw_Line_and_Focus () {
	int a;
	printf("int Draw_Line_and_Focus () starts.\r\n");
	a = Set_Font_Colour_Rgb ( 0, 0, 128 );
	a =	Draw_Circle_Line_005 ( 280.0, 150.0, 390.0, 220.0, 5.0, 0, 0 );
	a = Print_Refresh_Several_Focus ();
	printf("int Draw_Line_and_Focus () ends.\r\n");
	return 0;
}

// 390 - 280 = 110
// 220 - 150 = 70
// count 56 = 55 + 1
// multi 3
int Draw_Line_and_Focus_thin_axex_bones () {
	int a;
	printf("int Draw_Line_and_Focus_thin_axex_bones () starts.\r\n");
	a = Set_Font_Colour_Rgb ( 0, 0, 128 );
	p_jackson->flag_line_start = 0;
	switch(p_jackson->flag_line_start) {
	case 0:
	case 1:
		break;
	default:
		printf("p_jackson->flag_line_start %d\r\n", p_jackson->flag_line_start);
		exit(-1);
	}

	//a =	Draw_Circle_Line_005 ( 280.0, 150.0, 390.0, 220.0, 0.5, 0, 0 );
	//a = Print_Refresh_Several_Focus();

	a = Organize_Axex_Bones (1);
	a = Print_Refresh_Several_Focus ();

	printf("int Draw_Line_and_Focus_thin_axex_bones () ends.\r\n");
	return 0;
}


// 20250611
int Change_Eye_thin_axex_bones () {
	vPoint p[4];
	static int index = 0;
	int a;

	p[0].setPoint ( 1000.0f, 1000.0f, -1000.0f);
	p[1].setPoint ( 1000.0f, 1000.0f,  1000.0f);
	p[2].setPoint (-1000.0f, 1000.0f, -1000.0f);
	p[3].setPoint (-1000.0f, 1000.0f,  1000.0f);

	index = index % 4;
	display_006_01.SetEye (p[index]);
	display_006_01.ConvertionBonesOntheFace ();

	a = Organize_Axex_Bones (1);
	a = Print_Refresh_Several_Focus ();

	p[index].print();
	Sleep(5000);

	index++;

	return 0;
}


// 390 - 280 = 110
// 220 - 150 = 70
// count 56 = 55 + 1
// multi 3
int Draw_Line_and_Focus_thin_axex () {
	int a;
	printf("int Draw_Line_and_Focus_thin_axex () starts.\r\n");
	a = Set_Font_Colour_Rgb ( 0, 0, 128 );
	p_jackson->flag_line_start = 0;
	switch(p_jackson->flag_line_start) {
	case 0:
	case 1:
		break;
	default:
		printf("p_jackson->flag_line_start %d\r\n", p_jackson->flag_line_start);
		exit(-1);
	}

	//a =	Draw_Circle_Line_005 ( 280.0, 150.0, 390.0, 220.0, 0.5, 0, 0 );
	//a = Print_Refresh_Several_Focus();

	a = Organize_Axex (1);
	a = Print_Refresh_Several_Focus ();

	printf("int Draw_Line_and_Focus_thin_axex () ends.\r\n");
	return 0;
}

// 390 - 280 = 110
// 220 - 150 = 70
// count 56 = 55 + 1
// multi 3
int Draw_Line_and_Focus_thin () {
	int a;
	printf("int Draw_Line_and_Focus () starts.\r\n");
	a = Set_Font_Colour_Rgb ( 0, 0, 128 );
	p_jackson->flag_line_start = 0;
	switch(p_jackson->flag_line_start) {
	case 0:
	case 1:
		break;
	default:
		printf("p_jackson->flag_line_start %d\r\n", p_jackson->flag_line_start);
		exit(-1);
	}

	a =	Draw_Circle_Line_005 ( 280.0, 150.0, 390.0, 220.0, 0.5, 0, 0 );
	a = Print_Refresh_Several_Focus();
	printf("int Draw_Line_and_Focus () ends.\r\n");
	return 0;
}

// 20250409
int Draw_Line_and_Focus_org () {
	int a;
	printf("press d starts.\r\n");
	a = Set_Font_Colour_Rgb ( 255, 128, 0 );
	a =	Draw_Circle_Line ( 350.0, 200.0, 400.0, 210.0, 5.0, 1, 0 );
	a = Set_Font_Colour_Rgb ( 0, 0, 128 );
	a =	Draw_Circle_Line ( 340.0, 210.0, 390.0, 220.0, 5.0, 1, 1 );
	printf("press d ends.\r\n");
	printf("press e starts.\r\n");
	a = Set_Font_Colour_Rgb ( 255, 128, 0 );
	a =	Draw_Circle_Line ( 350.0, 200.0, 400.0, 210.0, 5.0, 2, 0 );
	a = Set_Font_Colour_Rgb ( 0, 0, 128 );
	a =	Draw_Circle_Line ( 340.0, 210.0, 390.0, 220.0, 5.0, 2, 1 );
	printf("press e ends.\r\n");

// v Draw_Circle_Line_005 is right.
//	a = Draw_Circle_Line_005 ( i, j, cur_x, cur_y,  fabs(base)/2.0, 0, first );
	a = Full_Square_Fix1 ( 350.0, 200.0, 400.0, 210.0, 380.0, 150.0, 5.0 ) ;

	return 0;
}
