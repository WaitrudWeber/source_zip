#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"

#include "vCircle.h"




void vCircle::calculation() {

	vPoint* next = nullptr;
	vPoint* base_xaxis = nullptr;
	vPoint* up = nullptr;
//	vCalculation* calc = nullptr;

	float PI = 3.141592f;
	float exact_length = this->R*PI;
	float length = 0.0f;

//	vCalculation* calc = new vCalculation ();

	// malloc
	for ( int i=0; i<this->max_pixel; i++ ) {
		if ( i < this->max_pixel ) {
			//realloc

			this->max_pixel *= 2;
		}

		// finish the next calculation.
		length += 10000.0f;
		if ( length > exact_length ) { 
			break;
		}

	}

}

