#ifndef _WKINCKEVENTDISPLAYTHREED_H_
#define _WKINCKEVENTDISPLAYTHREED_H_

// Sub class inheriting from Base Class(Parent) 
//
class wKickEventDisplayThreeD : public wKickEvent { 
	public: 
		int id_c; 

	private:
		int pid;

	public:
		void setPid ( int id ) ;
};

#endif
