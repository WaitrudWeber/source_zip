#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "vLine.h"

#include "w3DInfo.h"

//
//
//
//
//
void w3DInfo::SetRay( vPoint* ray ) {

	this->Ray = ray;
}

//
//
//
//
//
void w3DInfo::PutLine( vLine* line ) {

	if ( stack_lines == nullptr ) {
		max_stack_lines = 8;
		stack_lines = (vLine**) malloc ( sizeof (vLine*) * max_stack_lines );
		num_stack_lines = 0;
	} else {
		max_stack_lines *=2;
		stack_lines = (vLine**) realloc ( stack_lines, sizeof (vLine*) * max_stack_lines );
	}

	stack_lines[ num_stack_lines ] = line;
	num_stack_lines++;

}

//
//
//
//
//
vLine* w3DInfo::GetLine( vLine* line ) {

	// this i s only signl not num_stack_lines.
	if ( stack_lines == nullptr )
		return nullptr;

	return stack_lines[ num_stack_lines ];
}



