#ifndef _V_DISPLAY_cONTROLLER_003_H_
#define _V_DISPLAY_cONTROLLER_003_H_

#include "vBox.h"
#include "wCanvasController.h"

// 1. copy vDisplayController_003.h vDisplayController_003.cpp.
// 2. renumber by use of replace vDisplayController_002 to vDisplayController_003 in them above.
// 3. add Makefile vDisplayController_003.cpp.
// 4, change its class name and its inclustion in vDisplayController_003.cpp and winmain_001.cpp

// in winmin_001.cpp
// 1. include for the header file.
// 2. find display_002 like that for the instance.
// 3. find case 80: and like that on the code part.

class vDisplayController_003 {

	private:
		vPoint** bones_002 = nullptr;
		int bones_max = 10;
		int bones_max_index = 0;
		wCanvasController* canvas = nullptr;
		vCalculation Calc;
		vScreenCG screen_006;

//		vBox box( 0.0f, 0.0f, 100.0f, 100.0f );

	public:
		int SetCanvas ( wCanvasController *l_canvas ) ;
		int PrintBones () ;
		int DisplayBones_002 () ;
		int PrintBones ( vPoint** p_bones, int num ) ;

} ;

#endif

