#ifndef _PRINT_MOUSE_007_
#define _PRINT_MOUSE_007_
int print_mouse_move_007 () ;
#endif
