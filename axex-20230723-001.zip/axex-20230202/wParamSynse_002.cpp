
#include "wParamSynse_002.h"

wParamSynse_002::wParamSynse_002 () {
}
