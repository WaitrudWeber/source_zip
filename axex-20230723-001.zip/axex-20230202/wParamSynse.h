#ifndef _WPARAM_SYNSE_H_
#define _WPARAM_SYNSE_H_

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

//
#include "wTextarea.h"
#include "wTextareaController.h"

class wParamSynse {

	public:
		wTextarea** box_param = nullptr;
		int box_param_num = 42;

	private:
		wTextarea textarea1;

	public:
		wParamSynse();

	private:
		int Initialization ();
		int Initialization_001 ();
		int Initialization_002 ();
} ;

#endif

