// https://github.com/WaitrudWeber/source_zip/blob/master/winmain-20190109.zip
// https://docs.microsoft.com/en-us/windows/desktop/dataxchg/using-the-clipboard

//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-hProcess-in-mingw-what-to-use-instead
// #include <strsafe.h>

//#include <mmdeviceapi.h>

#include "resource.h"

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"

#include "clipboard.h"

#include "button.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "display_threeD.h"
#include "vPointStructure.h"


#include "vSoundBuffer_001.h"

#include "image_layer_001.h"

#include "wEvent.h"
#include "wEventListener.h"

#include "wJavaStructure.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

#include "wTextarea.h"
#include "wTextareaController.h"

#include "something_word.h"
#include "thread_print.h"


#include "wDisplayController.h"
//#include "wParamSynse_003.h"
#include "wCanvasController.h"

#include "cg_schema.h"


#include "ReturnableParam.h"

#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "log_001.h"
#include "csv_text_001.h"


#include "winmainthread_001.h"
#include "winmainthread_002.h"

#define _DRAW_PARAM_00000000000000000000000000000001_ 1
#define _DRAW_PARAM_00000000000000000000000000000010_ 2
#define _DRAW_PARAM_00000000000000000000000000000100_ 4
#define _DRAW_PARAM_00000000000000000000000000001000_ 8
#define _DRAW_PARAM_00000000000000000000000000010000_ 16
#define _DRAW_PARAM_00000000000000000000000000100000_ 32
#define _DRAW_PARAM_00000000000000000000000001000000_ 64
#define _DRAW_PARAM_00000000000000000000000010000000_ 128
#define _DRAW_PARAM_00000000000000000000000100000000_ 256
#define _DRAW_PARAM_00000000000000000000001000000000_ 512
#define _DRAW_PARAM_00000000000000000000010000000000_ 1024
#define _DRAW_PARAM_00000000000000000000100000000000_ 2048
#define _DRAW_PARAM_00000000000000000001000000000000_ 4096
#define _DRAW_PARAM_00000000000000000010000000000000_ 8192
#define _DRAW_PARAM_00000000000000000100000000000000_ 16384
#define _DRAW_PARAM_00000000000000001000000000000000_ 32768
#define _DRAW_PARAM_00000000000000010000000000000000_ 65536
#define _DRAW_PARAM_00000000000000100000000000000000_ 131072
#define _DRAW_PARAM_00000000000001000000000000000000_ 262144
#define _DRAW_PARAM_00000000000010000000000000000000_ 524288

DWORD ThreadId_001;
HANDLE ThreadHandle_001;

static CSVTEXT_001 csvtext_001;



static Logging log_001;
static LOG_001* dlog_001 = NULL;

static RECT RefreshRect;
static int param_int[20];
static char value_text[20][4];

static RECT l_rect_xy[96];
static RECT l_rect_xy_head[12];
static char* param_c[12];
static char* param_d[96];

static RECT rect_xy[20];
static RECT rect_xy_head[20];

static RECT rect_log[5];
static RECT rect_log_cursol[5];

static char	soundwave[255];
static char	voicewave[255];


static char* log_a[5];
static char log_cursol[5][4];
static char* param_a[20];
static char* param_b[20];

//char param_csv[5][255];
//int file_end;
//int file_index;
//CSVTEXT_001 csvtext;


static Image_Layer_001 il_001;

void Initialize_firstset_002 ();
void Initialize_firstset_003 ();
void Initialize_firstset_004 ();


DWORD WINAPI Animation_5times_thread_validate_021 ( LPVOID hdc ) ;

//static LRESULT CALLBACK mainWindowProc_021 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
LRESULT CALLBACK mainWindowProc_022 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );


// No validation rect like "ValidateRect( hWnd, &RefreshRect);"
//
//
 LRESULT CALLBACK mainWindowProc_022 ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	int b_Processed = 0;
	static HDC     hDC;
	static PAINTSTRUCT ps_001;
	static char x_b[4];
	static char y_b[4];
	static char c_b[4]; //
	static char d_b[4]; // diff value
	static RECT rect_x, rect_y;
	static HFONT hFont, hFont2;
	static int flg_paint = 0;
	static int DRAW_PARAM = 0;
	double	param[16];
	int i, j, l, by, posx, posy;
	HBRUSH hBrush;
	HRGN bgRgn;
	HPEN hPen;
    RECT clientRect;
    RECT textRect;
	unsigned char* rgbt;

	if ( p_evt == nullptr ) {
		p_evt = new wEvent ();
	}

	p_evt->hWnd = hWnd;
	p_evt->uMsg = &uMsg;
	p_evt->wParam = wParam;
	p_evt->lParam = lParam;
	p_evt->main_mode = m_mode;
//	wtextareacontroller.setEvent ( p_evt );

	// Code Block 1 - 01:
	p_evt->Type = uMsg;

	switch (uMsg) {
	case WM_CREATE:

		Initialize_firstset_002 ();
		Initialize_firstset_003 ();
		Initialize_firstset_004 ();


		param_int[20] = (int) ( (double) 1000.0/27.0 );

//		for ( i=0; i<255; i++ )
//			soundwave[i] = 127;

		for ( i=0; i<255; i++ )
			soundwave[i] = sin( i * 0.1 ) * 127.0;

		SetRect( &rect_xy_head[0], 10, 10, 60, 25 );//04
		SetRect( &rect_xy[0], 10, 25, 60, 60 );//04
		SetRect( &rect_xy_head[1], 60, 10, 110, 25 );//04
		SetRect( &rect_xy[1], 60, 25, 110, 60 );//04
		SetRect( &rect_xy_head[2], 110, 10, 160, 25 );//04
		SetRect( &rect_xy[2], 110, 25, 160, 60 );//04
		SetRect( &rect_xy_head[3], 160, 10, 210, 25 );//04
		SetRect( &rect_xy[3], 160, 25, 210, 60 );//04
		SetRect( &rect_xy_head[4], 210, 10, 260, 25 );//04
		SetRect( &rect_xy[4], 210, 25, 260, 60 );//04
		SetRect( &rect_xy_head[5], 260, 10, 310, 25 );//04
		SetRect( &rect_xy[5], 260, 25, 310, 60 );//04
		SetRect( &rect_xy_head[6], 310, 10, 360, 25 );//04
		SetRect( &rect_xy[6], 310, 25, 360, 60 );//04
		SetRect( &rect_xy_head[7], 360, 10, 410, 25 );//04
		SetRect( &rect_xy[7], 360, 25, 410, 60 );//04
		SetRect( &rect_xy_head[8], 410, 10, 460, 25 );//04
		SetRect( &rect_xy[8], 410, 25, 460, 60 );//04
		SetRect( &rect_xy_head[9], 460, 10, 510, 25 );//04
		SetRect( &rect_xy[9], 460, 25, 510, 60 );//04
		SetRect( &rect_xy_head[10], 510, 10, 560, 25 );//04
		SetRect( &rect_xy[10], 510, 25, 560, 60 );//04
		SetRect( &rect_xy_head[11], 560, 10, 610, 25 );//04
		SetRect( &rect_xy[11], 560, 25, 610, 60 );//04
		SetRect( &rect_xy_head[12], 10, 60, 60, 75 );//04
		SetRect( &rect_xy[12], 10, 75, 60, 110 );//04
		SetRect( &rect_xy_head[13], 60, 60, 110, 75 );//04
		SetRect( &rect_xy[13], 60, 75, 110, 110 );//04
		SetRect( &rect_xy_head[14], 110, 60, 160, 75 );//04
		SetRect( &rect_xy[14], 110, 75, 160, 110 );//04
		SetRect( &rect_xy_head[15], 160, 60, 210, 75 );//04
		SetRect( &rect_xy[15], 160, 75, 210, 110 );//04
		SetRect( &rect_xy_head[16], 210, 60, 260, 75 );//04
		SetRect( &rect_xy[16], 210, 75, 260, 110 );//04
		SetRect( &rect_xy_head[17], 260, 60, 310, 75 );//04
		SetRect( &rect_xy[17], 260, 75, 310, 110 );//04
		SetRect( &rect_xy_head[18], 310, 60, 360, 75 );//04
		SetRect( &rect_xy[18], 310, 75, 360, 110 );//04
		SetRect( &rect_xy_head[19], 360, 60, 410, 75 );//04
		SetRect( &rect_xy[19], 360, 75, 410, 110 );//04

		SetRect( &rect_log_cursol[0], 10, 320, 25, 335 );//04
		SetRect( &rect_log[0], 25, 320, 345, 335 );//04
		SetRect( &rect_log_cursol[1], 10, 335, 25, 350 );//04
		SetRect( &rect_log[1], 25, 335, 345, 350 );//04
		SetRect( &rect_log_cursol[2], 10, 350, 25, 365 );//04
		SetRect( &rect_log[2], 25, 350, 345, 365 );//04
		SetRect( &rect_log_cursol[3], 10, 365, 25, 380 );//04
		SetRect( &rect_log[3], 25, 365, 345, 380 );//04
		SetRect( &rect_log_cursol[4], 10, 380, 25, 395 );//04
		SetRect( &rect_log[4], 25, 380, 345, 395 );//04

		SetRect( &l_rect_xy_head[0], 10, 10, 60, 25 );//04
		SetRect( &l_rect_xy[0], 10, 25, 60, 60 );//04
		SetRect( &l_rect_xy_head[1], 60, 10, 110, 25 );//04
		SetRect( &l_rect_xy[1], 60, 25, 110, 60 );//04
		SetRect( &l_rect_xy_head[2], 110, 10, 160, 25 );//04
		SetRect( &l_rect_xy[2], 110, 25, 160, 60 );//04
		SetRect( &l_rect_xy_head[3], 160, 10, 210, 25 );//04
		SetRect( &l_rect_xy[3], 160, 25, 210, 60 );//04
		SetRect( &l_rect_xy_head[4], 210, 10, 260, 25 );//04
		SetRect( &l_rect_xy[4], 210, 25, 260, 60 );//04
		SetRect( &l_rect_xy_head[5], 260, 10, 310, 25 );//04
		SetRect( &l_rect_xy[5], 260, 25, 310, 60 );//04
		SetRect( &l_rect_xy_head[6], 310, 10, 360, 25 );//04
		SetRect( &l_rect_xy[6], 310, 25, 360, 60 );//04
		SetRect( &l_rect_xy_head[7], 360, 10, 410, 25 );//04
		SetRect( &l_rect_xy[7], 360, 25, 410, 60 );//04
		SetRect( &l_rect_xy_head[8], 410, 10, 460, 25 );//04
		SetRect( &l_rect_xy[8], 410, 25, 460, 60 );//04
		SetRect( &l_rect_xy_head[9], 460, 10, 510, 25 );//04
		SetRect( &l_rect_xy[9], 460, 25, 510, 60 );//04
		SetRect( &l_rect_xy_head[10], 510, 10, 560, 25 );//04
		SetRect( &l_rect_xy[10], 510, 25, 560, 60 );//04
		SetRect( &l_rect_xy_head[11], 560, 10, 610, 25 );//04
		SetRect( &l_rect_xy[11], 560, 25, 610, 60 );//04
		SetRect( &l_rect_xy[12], 10, 60, 60, 110 );//04
		SetRect( &l_rect_xy[13], 60, 60, 110, 110 );//04
		SetRect( &l_rect_xy[14], 110, 60, 160, 110 );//04
		SetRect( &l_rect_xy[15], 160, 60, 210, 110 );//04
		SetRect( &l_rect_xy[16], 210, 60, 260, 110 );//04
		SetRect( &l_rect_xy[17], 260, 60, 310, 110 );//04
		SetRect( &l_rect_xy[18], 310, 60, 360, 110 );//04
		SetRect( &l_rect_xy[19], 360, 60, 410, 110 );//04
		SetRect( &l_rect_xy[20], 410, 60, 460, 110 );//04
		SetRect( &l_rect_xy[21], 460, 60, 510, 110 );//04
		SetRect( &l_rect_xy[22], 510, 60, 560, 110 );//04
		SetRect( &l_rect_xy[23], 560, 60, 610, 110 );//04
		SetRect( &l_rect_xy[24], 10, 110, 60, 160 );//04
		SetRect( &l_rect_xy[25], 60, 110, 110, 160 );//04
		SetRect( &l_rect_xy[26], 110, 110, 160, 160 );//04
		SetRect( &l_rect_xy[27], 160, 110, 210, 160 );//04
		SetRect( &l_rect_xy[28], 210, 110, 260, 160 );//04
		SetRect( &l_rect_xy[29], 260, 110, 310, 160 );//04
		SetRect( &l_rect_xy[30], 310, 110, 360, 160 );//04
		SetRect( &l_rect_xy[31], 360, 110, 410, 160 );//04
		SetRect( &l_rect_xy[32], 410, 110, 460, 160 );//04
		SetRect( &l_rect_xy[33], 460, 110, 510, 160 );//04
		SetRect( &l_rect_xy[34], 510, 110, 560, 160 );//04
		SetRect( &l_rect_xy[35], 560, 110, 610, 160 );//04
		SetRect( &l_rect_xy[36], 10, 160, 60, 210 );//04
		SetRect( &l_rect_xy[37], 60, 160, 110, 210 );//04
		SetRect( &l_rect_xy[38], 110, 160, 160, 210 );//04
		SetRect( &l_rect_xy[39], 160, 160, 210, 210 );//04
		SetRect( &l_rect_xy[40], 210, 160, 260, 210 );//04
		SetRect( &l_rect_xy[41], 260, 160, 310, 210 );//04
		SetRect( &l_rect_xy[42], 310, 160, 360, 210 );//04
		SetRect( &l_rect_xy[43], 360, 160, 410, 210 );//04
		SetRect( &l_rect_xy[44], 410, 160, 460, 210 );//04
		SetRect( &l_rect_xy[45], 460, 160, 510, 210 );//04
		SetRect( &l_rect_xy[46], 510, 160, 560, 210 );//04
		SetRect( &l_rect_xy[47], 560, 160, 610, 210 );//04
		SetRect( &l_rect_xy[48], 10, 210, 60, 260 );//04
		SetRect( &l_rect_xy[49], 60, 210, 110, 260 );//04
		SetRect( &l_rect_xy[50], 110, 210, 160, 260 );//04
		SetRect( &l_rect_xy[51], 160, 210, 210, 260 );//04
		SetRect( &l_rect_xy[52], 210, 210, 260, 260 );//04
		SetRect( &l_rect_xy[53], 260, 210, 310, 260 );//04
		SetRect( &l_rect_xy[54], 310, 210, 360, 260 );//04
		SetRect( &l_rect_xy[55], 360, 210, 410, 260 );//04
		SetRect( &l_rect_xy[56], 410, 210, 460, 260 );//04
		SetRect( &l_rect_xy[57], 460, 210, 510, 260 );//04
		SetRect( &l_rect_xy[58], 510, 210, 560, 260 );//04
		SetRect( &l_rect_xy[59], 560, 210, 610, 260 );//04
		SetRect( &l_rect_xy[60], 10, 260, 60, 310 );//04
		SetRect( &l_rect_xy[61], 60, 260, 110, 310 );//04
		SetRect( &l_rect_xy[62], 110, 260, 160, 310 );//04
		SetRect( &l_rect_xy[63], 160, 260, 210, 310 );//04
		SetRect( &l_rect_xy[64], 210, 260, 260, 310 );//04
		SetRect( &l_rect_xy[65], 260, 260, 310, 310 );//04
		SetRect( &l_rect_xy[66], 310, 260, 360, 310 );//04
		SetRect( &l_rect_xy[67], 360, 260, 410, 310 );//04
		SetRect( &l_rect_xy[68], 410, 260, 460, 310 );//04
		SetRect( &l_rect_xy[69], 460, 260, 510, 310 );//04
		SetRect( &l_rect_xy[70], 510, 260, 560, 310 );//04
		SetRect( &l_rect_xy[71], 560, 260, 610, 310 );//04
		SetRect( &l_rect_xy[72], 10, 310, 60, 360 );//04
		SetRect( &l_rect_xy[73], 60, 310, 110, 360 );//04
		SetRect( &l_rect_xy[74], 110, 310, 160, 360 );//04
		SetRect( &l_rect_xy[75], 160, 310, 210, 360 );//04
		SetRect( &l_rect_xy[76], 210, 310, 260, 360 );//04
		SetRect( &l_rect_xy[77], 260, 310, 310, 360 );//04
		SetRect( &l_rect_xy[78], 310, 310, 360, 360 );//04
		SetRect( &l_rect_xy[79], 360, 310, 410, 360 );//04
		SetRect( &l_rect_xy[80], 410, 310, 460, 360 );//04
		SetRect( &l_rect_xy[81], 460, 310, 510, 360 );//04
		SetRect( &l_rect_xy[82], 510, 310, 560, 360 );//04
		SetRect( &l_rect_xy[83], 560, 310, 610, 360 );//04
		SetRect( &l_rect_xy[84], 10, 360, 60, 410 );//04
		SetRect( &l_rect_xy[85], 60, 360, 110, 410 );//04
		SetRect( &l_rect_xy[86], 110, 360, 160, 410 );//04
		SetRect( &l_rect_xy[87], 160, 360, 210, 410 );//04
		SetRect( &l_rect_xy[88], 210, 360, 260, 410 );//04
		SetRect( &l_rect_xy[89], 260, 360, 310, 410 );//04
		SetRect( &l_rect_xy[90], 310, 360, 360, 410 );//04
		SetRect( &l_rect_xy[91], 360, 360, 410, 410 );//04
		SetRect( &l_rect_xy[92], 410, 360, 460, 410 );//04
		SetRect( &l_rect_xy[93], 460, 360, 510, 410 );//04
		SetRect( &l_rect_xy[94], 510, 360, 560, 410 );//04
		SetRect( &l_rect_xy[95], 560, 360, 610, 410 );//04

		SetRect( &RefreshRect, 0, 0, 640, 480 );//04
		DRAW_PARAM = 0;

//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000000001_;

// BLANK
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000000010_;

//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000000100_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000001000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000010000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000100000_;
		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000010000000000000_;
		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000100000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000001000000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000010000000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000100000000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000001000000000000000000_;
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000010000000000000000000_;

//		ThreadHandle_001 = CreateThread( NULL, /* default security attributes */ 0, /* default stack size */    
//			Animation_5times_thread_validate_021, /* thread function */ (LPVOID)&(p_evt->hDc), /* parameter to thread function */ 0, /* default creation    flags */ &ThreadId_001);

		hFont = CreateFont (20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);
		SetTextColor( hDC, RGB(0 ,0, 255) );

		break;
	case WM_MOUSEMOVE: //512
		param_int[1] = GET_Y_LPARAM ( lParam );
		param_int[3] = param_int[2] - param_int[1]; // diff in a step
		if (param_int[3] < 0) param_int[3] = - param_int[3];

		sprintf( value_text[0], "%04d", GET_X_LPARAM ( lParam ) );
		sprintf( value_text[1], "%04d", param_int[1] );
		sprintf( value_text[3], "%04d", param_int[3] );
		sprintf( value_text[4], "%04d", param_int[4] - param_int[1] );

		param_int[0] = GET_X_LPARAM ( lParam );
		param_int[1] = GET_Y_LPARAM ( lParam );
		param_int[2] = param_int[1];
		param_int[4] += 1;

		SetRect( &rect_xy[11], param_int[3], 400, param_int[3] + 10, 450 );//04

		b_Processed = 1;

//		for ( i =0; i<20; i++ )
//			InvalidateRect( hWnd, &rect_xy[i], FALSE);

//		InvalidateRect( hWnd, &RefreshRect, FALSE);

//		InvalidateRect( hWnd, &rect_xy[0], FALSE);
//		InvalidateRect( hWnd, &rect_xy[1], FALSE);
//		InvalidateRect( hWnd, &rect_xy[2], FALSE);
//		InvalidateRect( hWnd, &rect_xy[3], FALSE);
//		InvalidateRect( hWnd, &rect_xy[4], FALSE);
//		InvalidateRect( hWnd, &rect_xy[5], FALSE);
//		InvalidateRect( hWnd, &rect_xy[6], FALSE);

		printf("WM_MOUSEMOVE=uMsg=%d flg_paint=%d DRAW_PARAM=%d\r\n", WM_MOUSEMOVE, flg_paint, DRAW_PARAM );
		break;
	case WM_PAINT: //15
		hDC = BeginPaint( hWnd, &ps_001 );
		p_evt->hDc = hDC;
		p_evt->ps = &ps_001;
		param_int[5] = 0;

		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000000001_ ) {
//$00000000000000000000000000000001
//			SelectObject( hDC, GetStockObject(GRAY_BRUSH)); 
//			Ellipse( hDC, RefreshRect.left, RefreshRect.top, RefreshRect.right, RefreshRect.bottom);
			SelectObject( hDC, GetStockObject(WHITE_BRUSH)); 
			Rectangle( hDC, RefreshRect.left, RefreshRect.top, RefreshRect.right, RefreshRect.bottom);
			printf("00000000000000000000000000000001\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000000010_ ) {
//$00000000000000000000000000000010

			printf("00000000000000000000000000000010\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000000100_ ) {
//$00000000000000000000000000000100
			param[0] = 1.0; // margin x;
			param[1] = 1.0; // margin y;
			param[2] = 10.0; // step x;
			param[3] = param[2] * 0.5 * sqrt( 3.0 ); // step y;
			param[4] = 640.0; // screen width
			param[5] = 480.0; // screen height
			param[6] = param[1]; // current x
			param[7] = param[2]; // current y
			param[8] = param[0] + 0.5 * param[2];
			param[9] = param[0];  // start of odd

			while ( param[7] < param[5] ) {

				SetPixel( p_evt->hDc, param[6], param[7], RGB( 0, 0, 255 ) );
				// inclement of cursol and turn
				if ( (param[6] += param[2] ) >= param[4]  ) {
					param[7] += param[3];

					if ( param[9] == param[0] ) param[6] = param[8];
					else param[6] = param[0];
					param[9] = param[6];
				}
			}

			printf("00000000000000000000000000000100\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000001000_ ) {
//$00000000000000000000000000001000
			for ( i =0; i<20; i++ ) {
				Rectangle(  (HDC) hDC, rect_xy[i].left, rect_xy[i].top, rect_xy[i].right, rect_xy[i].bottom );
			}

			printf("00000000000000000000000000001000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000010000_ ) {
//$00000000000000000000000000010000

			Rectangle(  (HDC) hDC, rect_xy[17].left, rect_xy[17].top, rect_xy[17].right, rect_xy[17].bottom );
//			DRAW_PARAM -= _DRAW_PARAM_00000000000000000000000000010000_;

			printf("00000000000000000000000000010000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000000100000_ ) {
//$00000000000000000000000000100000

			SelectObject( hDC, GetStockObject(GRAY_BRUSH)); 
			Rectangle(  (HDC) hDC, rect_xy[15].left, rect_xy[15].top, rect_xy[15].right, rect_xy[15].bottom );

			printf("00000000000000000000000000100000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000001000000_ ) {
//$00000000000000000000000001000000
			// Graph 001:
			// on SetRect( &rect_xy[17], 10, 300, 630, 350 );//04
			// 10 + cursol
			// 325 + value
//			SetPixel( p_evt->hDc, 10 + param_int[17], 325 + param_int[15], RGB( 255, 0, 0 ) );

			for ( i = 10; i<638; i++ ) {
				SetPixel( p_evt->hDc, i, 325 + 127 * 0.2, RGB( 0, 0, 255 ) );
				SetPixel( p_evt->hDc, i, 325 - 127 * 0.2, RGB( 0, 0, 255 ) );
				SetPixel( p_evt->hDc, i, 325 + soundwave[(i-10)%255] * 0.2, RGB( 0, 0, 255 ) );
				param_int[5]+=3;
			}
//				SetPixel( p_evt->hDc, i, 127 + soundwave[ ( i - 10 ) % 255 ], RGB( 0, 0, 255 ) );

			sprintf( value_text[5], "%04d", param_int[5] );
			sprintf( value_text[6], "%04d", 0 );

			printf("00000000000000000000000001000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000010000000_ ) {
//$00000000000000000000000010000000
			TextOutA( (HDC) hDC, rect_xy[0].left, rect_xy[0].top, value_text[0], 4);
			TextOutA( (HDC) hDC, rect_xy[1].left, rect_xy[1].top, value_text[1], 4);
			TextOutA( (HDC) hDC, rect_xy[3].left, rect_xy[3].top, value_text[3], 4);
			TextOutA( (HDC) hDC, rect_xy[4].left, rect_xy[4].top, value_text[4], 4);
			TextOutA( (HDC) hDC, rect_xy[5].left, rect_xy[5].top, value_text[5], 4);
			TextOutA( (HDC) hDC, rect_xy[6].left, rect_xy[6].top, value_text[6], 4);
//			TextOutA( (HDC) hDC, rect_xy[15].left, rect_xy[15].top, value_text[15], 4);
			TextOutA( (HDC) hDC, rect_xy[16].left, rect_xy[16].top, value_text[16], 4);
			TextOutA( (HDC) hDC, rect_xy[17].left, rect_xy[17].top, value_text[17], 4);
			TextOutA( (HDC) hDC, rect_xy[18].left, rect_xy[18].top, value_text[18], 4);
			TextOutA( (HDC) hDC, rect_xy[19].left, rect_xy[19].top, value_text[19], 4);

//			DrawText( (HDC) hDC, TEXT( value_text[0] ), -1, &rect_xy[0], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[1] ), -1, &rect_xy[1], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[3] ), -1, &rect_xy[3], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[4] ), -1, &rect_xy[4], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[18] ), -1, &rect_xy[18], DT_NOCLIP );
//			DrawText( (HDC) hDC, TEXT( value_text[19] ), -1, &rect_xy[19], DT_NOCLIP );
			printf("00000000000000000000000010000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000000100000000_ ) {
//$00000000000000000000000100000000
			printf("00000000000000000000000100000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000001000000000_ ) {
//$00000000000000000000001000000000
			printf("00000000000000000000001000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000010000000000_ ) {
//$00000000000000000000010000000000
			printf("00000000000000000000010000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000000100000000000_ ) {
//$00000000000000000000100000000000
			printf("00000000000000000000100000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000001000000000000_ ) {
//$00000000000000000001000000000000
			printf("00000000000000000001000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000010000000000000_ ) {
//$00000000000000000010000000000000
			// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-drawtext
			SelectObject( hDC, GetStockObject(WHITE_BRUSH)); 
			SetBkColor(hDC, RGB(255,255,255));
			for( i = 0; i<96; i++ ) {
				Rectangle( (HDC) hDC, l_rect_xy[i].left, l_rect_xy[i].top, l_rect_xy[i].right, l_rect_xy[i].bottom );
			}

			hFont = CreateFont (20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);
			SetTextColor( hDC, RGB(0 ,0, 255) );

			for( i = 0; i<96; i++ ) {
				DrawText( (HDC) hDC, TEXT( param_d[i] ), -1, &l_rect_xy[i], DT_NOCLIP );
			}

			hPen = CreatePen(PS_DASHDOT,1,RGB(255,0,0));
			SelectObject(hDC, hPen);
			SetBkColor(hDC, RGB(200,255,200));
			SelectObject(hDC,CreateSolidBrush( RGB(200,255,200) ) );


			// https://learn.microsoft.com/en-us/windows/win32/api/gdipluscolor/nf-gdipluscolor-color-getgreen
			// https://learn.microsoft.com/en-us/windows/win32/wcs/rgb-color-spaces
			for( i = 0; i<12; i++ ) {
				Rectangle( (HDC) hDC, l_rect_xy_head[i].left, l_rect_xy_head[i].top, l_rect_xy_head[i].right, l_rect_xy_head[i].bottom );
			}

			hFont = CreateFont (10, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);

//			SetTextColor( hDC, RGB(255 ,255, 255) );
			for( i = 0; i<12; i++ ) {
				DrawText( (HDC) hDC, TEXT( param_c[i] ), -1, &rect_xy_head[i], DT_LEFT );
			}

			// Clean up
			DeleteObject(bgRgn);
			DeleteObject(hBrush);
			DeleteObject(hPen);

			printf("00000000000000000010000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000000100000000000000_ ) {
//$00000000000000000100000000000000
			// 5
			for ( i = 0; i<5; i++ ) {
				log_a[i] = dlog_001->log_list[ i + dlog_001->from ];
			}
			for ( i = 0; i<5; i++ ) {
				sprintf( log_cursol[i], "%d", i + dlog_001->from + 1);
			}

			hPen = CreatePen(PS_DASHDOT,1,RGB( 255, 255, 128));
			SelectObject(p_evt->hDc, hPen);
			SetBkColor(p_evt->hDc, RGB( 0, 128, 0));
			SelectObject(p_evt->hDc, CreateSolidBrush(RGB(0,128,0)));
			for ( i = 0; i<5; i++ ) {
				Rectangle( (HDC) hDC, rect_log[i].left, rect_log[i].top, rect_log[i].right, rect_log[i].bottom );
				Rectangle( (HDC) hDC, rect_log_cursol[i].left, rect_log_cursol[i].top, rect_log_cursol[i].right, rect_log_cursol[i].bottom );
			}

			hFont = CreateFont (13, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);
			SetTextColor( hDC, RGB( 255, 255, 128) );
			for ( i = 0; i<5; i++ ) {
				DrawText( (HDC) hDC, TEXT( log_a[i] ), -1, &rect_log[i], DT_LEFT );
				DrawText( (HDC) hDC, TEXT( log_cursol[i] ), -1, &rect_log_cursol[i], DT_LEFT );
			}
			printf("00000000000000000100000000000000\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000001000000000000000_ ) {
//$00000000000000001000000000000000
			posx = 200;
			posy = 200;
			for( l =0; l<1; l++ ) {
				for( j = posy; j<posy + 100; j++ ) {
					for( i = posx; i<posx +100; i++ ) {
						SetPixel( p_evt->hDc, i, j, RGB( 255, 0, 255 ) );
					}
				}
				posx += 10;
				posy += 10;
			}

			printf("00000000000000001000000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000010000000000000000_ ) {
//$00000000000000010000000000000000
        // Fill the client area with a brush
        GetClientRect(hWnd, &clientRect);
        bgRgn = CreateRectRgnIndirect(&clientRect);
        hBrush = CreateSolidBrush(RGB(200,200,200));
        FillRgn(hDC, bgRgn, hBrush);

        
        hPen = CreatePen(PS_DOT,1,RGB(0,255,0));
        SelectObject(hDC, hPen);
        SetBkColor(hDC, RGB(0,0,0));
        Rectangle(hDC, 10,10,200,200);
        
        // Text caption
        SetBkColor(hDC, RGB(255,255,255));
        SetRect(&textRect, 10, 210, 200,200);
        DrawText(hDC,TEXT("PS_DOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);

        hPen = CreatePen(PS_DASHDOTDOT,1,RGB(0,255,255));
        SelectObject(hDC, hPen);
        SetBkColor(hDC, RGB(255,0,0));
        SelectObject(hDC,CreateSolidBrush(RGB(0,0,0)));
        Rectangle(hDC, 210,10,400,200);
        
        // Text caption
        SetBkColor(hDC, RGB(255,200,200));
        SetRect(&textRect, 210, 210, 400,200);
        DrawText(hDC,TEXT("PS_DASHDOTDOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);

        hPen = CreatePen(PS_DASHDOT,1,RGB(255,0,0));
        SelectObject(hDC, hPen);
        SetBkColor(hDC, RGB(200,255,200));
        SelectObject(hDC,CreateSolidBrush(RGB(200,255,200)) );
        Rectangle(hDC, 410,10,600,200);
        
        // Text caption
        SetBkColor(hDC, RGB(200,255,200));
        SetRect(&textRect, 410, 210, 600,200);
        DrawText(hDC,TEXT("PS_DASHDOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);


			printf("00000000000000010000000000000000\r\n");
		}
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000000100000000000000000_ ) {
//$00000000000000100000000000000000
			for( l =0; l<3; l++ ) {
				for( j = 0; j<il_001.get_height(l); j++ ) {
					for( i = 0; i<il_001.get_width(l); i++ ) {
						rgbt = (unsigned char*) il_001.get_image_layer( l, i, j);
						SetPixel( p_evt->hDc, i + il_001.get_posx(l), j  + il_001.get_posy(l), RGB( rgbt[0], rgbt[1], rgbt[2] ) );
					}
				}
			}
			printf("00000000000000100000000000000000\r\n");
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000001000000000000000000_ ) {
//$00000000000001000000000000000000
			for( l =0; l<3; l++ ) {
				for( j = 0; j<il_001.get_height(l); j++ ) {
					for( i = 0; i<il_001.get_width(l); i++ ) {
						rgbt = (unsigned char*) il_001.get_image_layer_001( l, i, j);
						SetPixel( p_evt->hDc, i + il_001.get_posx(l), j  + il_001.get_posy(l), RGB( rgbt[0], rgbt[1], rgbt[2] ) );
					}
				}
			}
			printf("00000000000001000000000000000000 & DRAW_PARAM %d\r\n", DRAW_PARAM);
		} 
		if ( DRAW_PARAM & _DRAW_PARAM_00000000000010000000000000000000_ ) {
//$00000000000010000000000000000000
			// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-drawtext
			SelectObject( hDC, GetStockObject(WHITE_BRUSH)); 
			SetBkColor(hDC, RGB(255,255,255));
			for( i = 0; i<20; i++ ) {
//				Ellipse( hDC, rect_xy[i].left, rect_xy[i].top, rect_xy[i].right, rect_xy[i].bottom);
				Rectangle( (HDC) hDC, rect_xy[i].left, rect_xy[i].top, rect_xy[i].right, rect_xy[i].bottom );
			}

			// GetClientRect(hwnd, &rect);
			// DrawText (hdc, TEXT ("http://"), -1, &rect,DT_SINGLELINE | DT_LEFT);
			// https://social.msdn.microsoft.com/Forums/en-US/155478d2-f151-4c84-a831-d5d9bd17d3ff/drawtext-amp-use-of-a-background-color?forum=vcgeneral
			// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getclientrect
			hFont = CreateFont (20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);
			SetTextColor( hDC, RGB(0 ,0, 255) );

			for( i = 0; i<20; i++ ) {
				DrawText( (HDC) hDC, TEXT( param_a[i] ), -1, &rect_xy[i], DT_NOCLIP );
			}


			hPen = CreatePen(PS_DASHDOT,1,RGB(255,0,0));
			SelectObject(hDC, hPen);
			SetBkColor(hDC, RGB(200,255,200));
			SelectObject(hDC,CreateSolidBrush( RGB(200,255,200) ) );
//			Rectangle(hDC, 410,10,600,200);

			// Text caption
//			SetBkColor(hDC, RGB(200,255,200));
//			SetRect(&textRect, 410, 210, 600,200);
//			DrawText(hDC,TEXT("PS_DASHDOT"),-1,&textRect, DT_CENTER | DT_NOCLIP);

			// https://learn.microsoft.com/en-us/windows/win32/gdi/creating-colored-pens-and-brushes
			//GetClientRect(hWnd, &clientRect);
			// Fill the client area with a brush
			//GetClientRect(hWnd, &clientRect);
			//bgRgn = CreateRectRgnIndirect(&clientRect);
			//hBrush = CreateSolidBrush(RGB(200,200,200));
			//FillRgn(hdc, bgRgn, hBrush);

			// https://learn.microsoft.com/en-us/windows/win32/api/gdipluscolor/nf-gdipluscolor-color-getgreen
			// https://learn.microsoft.com/en-us/windows/win32/wcs/rgb-color-spaces
			for( i = 0; i<20; i++ ) {
				Rectangle( (HDC) hDC, rect_xy_head[i].left, rect_xy_head[i].top, rect_xy_head[i].right, rect_xy_head[i].bottom );
			}

			hFont = CreateFont (10, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
			hFont2 = (HFONT)SelectObject((HDC)hDC, hFont);

			//SetBkMode(hdc,TRANSPARENT);
			//SetTextColor(hdc,RGB(0,255,0));
			//https://learn.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-setbkmode
//			SetBkMode( hDC, TRANSPARENT);
//			SetTextColor( hDC, RGB(255 ,255, 255) );
			for( i = 0; i<20; i++ ) {
				DrawText( (HDC) hDC, TEXT( param_b[i] ), -1, &rect_xy_head[i], DT_LEFT );
			}

			// Clean up
			DeleteObject(bgRgn);
			DeleteObject(hBrush);
			DeleteObject(hPen);

			printf("00000000000010000000000000000000\r\n");
		} 
		b_Processed = 2;
		flg_paint = 1;
		printf("WM_PAINT=uMsg=%d flg_paint=%d hDC %d DRAW_PARAM %d\r\n", WM_PAINT, flg_paint, hDC, DRAW_PARAM );
		break;
	case WM_KEYUP:
//		DRAW_PARAM = DRAW_PARAM | _DRAW_PARAM_00000000000000000000000000010000_;
//		InvalidateRect( hWnd, &RefreshRect, TRUE);
//		InvalidateRect( p_evt->hWnd, &rect_xy[15], FALSE);
		InvalidateRect( p_evt->hWnd, &rect_xy[17], FALSE);
		switch (wParam) {
		case 65:
			dlog_001 = log_001.update_log ( (char*)"print_log :" );
			dlog_001 = log_001.print_log ();
			exit(-1);
			break;
		case 66:
			// char** param_csv;
			// int file_end;
			// int file_index;
			// CSVTEXT_001 csvtext;
//			csvtext.csv_text_once_006( &file_index, &file_end, (char**)param_csv, 5 ) ;
			break;
		}
		b_Processed = 1;
		printf("WM_KEYUP=uMsg=%d flg_paint=%d wParam %d lParam %d\r\n", WM_KEYUP, flg_paint, wParam, lParam );
		break;
	case WM_KEYDOWN:
		b_Processed = 1;
		printf("WM_KEYDOWN=uMsg=%d flg_paint=%d\r\n", WM_KEYDOWN, flg_paint );
		break;
	}

	switch (uMsg) {
	case WM_PAINT: //15
		SelectObject((HDC)(hDC), hFont2);
		DeleteObject(hFont);
		EndPaint( hWnd, &ps_001 );	
//		wtextareacontroller.stack_number_free ();
		break;
	}

	switch ( b_Processed ) {
	case 0:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	case 1:
		return 0;
	case 2:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;
}

// invalidate:
// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-invalidaterect
//
//
DWORD WINAPI Animation_5times_thread_validate_022 ( LPVOID hdc ) {
	printf("Animation_5times_thread_validate_022 starts.\r\n");
	DWORD hdc_011 = *(DWORD*)hdc;
	for ( param_int[19] = 0; param_int[19]<255 * 100; param_int[19]++ ) {
		param_int[18] = param_int[19] - 1;

		// Cursol
		param_int[17] = (int) ( (double) param_int[19] * 0.01 );
		param_int[16] = soundwave[ param_int[17] ];
		param_int[15] = (int)( (double)param_int[16] * 0.1 );
	
		sprintf( value_text[15], "%04d", param_int[15] ); //128 soundwave * 0.2
		sprintf( value_text[16], "%04d", soundwave[ param_int[16] ] ); //128 soundwave
		sprintf( value_text[17], "%04d", soundwave[ param_int[17] ] ); //128 soundwave

		sprintf( value_text[18], "%04d", param_int[18] );
		sprintf( value_text[19], "%04d", param_int[19] );

		// Graph 001:
		SetRect( &rect_xy[15], 10 + param_int[17] , 325 + param_int[15], 20 + param_int[17], 335 + param_int[15] );//04

		SetRect( &rect_xy[16], 127 + param_int[16], 250, 127 + param_int[16] + 10, 300 );//04
//		SetRect( &rect_xy[17], 10, 300, 630, 350 );//04

		SetRect( &rect_xy[19], param_int[19], 350, param_int[19] + 10, 400 );//04

//		InvalidateRect( p_evt->hWnd, &rect_xy[15], FALSE);
//		InvalidateRect( p_evt->hWnd, &rect_xy[16], FALSE);
		InvalidateRect( p_evt->hWnd, &rect_xy[17], FALSE);
//		InvalidateRect( p_evt->hWnd, &rect_xy[18], FALSE);
//		InvalidateRect( p_evt->hWnd, &rect_xy[19], FALSE);

		if ( param_int[19] == 252 * 100 ) param_int[19] = 0;

		Sleep(param_int[20]);
	}

	printf("Animation_5times_thread_validate_022 ends.\r\n");
	return 0;
}

void Initialize_firstset_004 ()
{
	dlog_001 = log_001.update_log ( (char*)"void Initialize_firstset_004 () starts." );

	dlog_001 = log_001.update_log ( (char*)"1" );
	dlog_001 = log_001.update_log ( (char*)"2" );
	dlog_001 = log_001.update_log ( (char*)"3" );
	dlog_001 = log_001.update_log ( (char*)"4" );

//	csvtext_001.set_read_file_name("001-filename-20230621\.txt" );
//	csvtext_001.csv_index = 3;
//	csvtext_001.csv_read();

	dlog_001 = log_001.update_log ( (char*)"void Initialize_firstset_004 () ends." );
}

void Initialize_firstset_003 ()
{


		param_c[0] = "0";
		param_c[1] = "-";
		param_c[2] = "-";
		param_c[3] = "-";
		param_c[4] = "-";
		param_c[5] = "-";
		param_c[6] = "-";
		param_c[7] = "Very";
		param_c[8] = "thanks";
		param_c[9] = "to";
		param_c[10] = "lotus";
		param_c[11] = "11";

		param_d[0] = "-";
		param_d[1] = "-";
		param_d[2] = "-";
		param_d[3] = "-";
		param_d[4] = "-";
		param_d[5] = "-";
		param_d[6] = "-";
		param_d[7] = "-";
		param_d[8] = "-";
		param_d[9] = "-";
		param_d[10] = "-";
		param_d[11] = "-";
		param_d[12] = "-";
		param_d[13] = "-";
		param_d[14] = "-";
		param_d[15] = "-";
		param_d[16] = "-";
		param_d[17] = "-";
		param_d[18] = "-";
		param_d[19] = "-";
		param_d[20] = "-";
		param_d[21] = "-";
		param_d[22] = "-";
		param_d[23] = "-";
		param_d[24] = "-";
		param_d[25] = "-";
		param_d[26] = "-";
		param_d[27] = "-";
		param_d[28] = "-";
		param_d[29] = "-";
		param_d[30] = "-";
		param_d[31] = "-";
		param_d[32] = "-";
		param_d[33] = "-";
		param_d[34] = "-";
		param_d[35] = "-";
		param_d[36] = "-";
		param_d[37] = "-";
		param_d[38] = "-";
		param_d[39] = "-";
		param_d[40] = "-";
		param_d[41] = "-";
		param_d[42] = "-";
		param_d[43] = "-";
		param_d[44] = "-";
		param_d[45] = "-";
		param_d[46] = "-";
		param_d[47] = "-";
		param_d[48] = "-";
		param_d[49] = "-";
		param_d[50] = "-";
		param_d[51] = "-";
		param_d[52] = "-";
		param_d[53] = "-";
		param_d[54] = "-";
		param_d[55] = "-";
		param_d[56] = "-";
		param_d[57] = "-";
		param_d[58] = "-";
		param_d[59] = "-";
		param_d[60] = "-";
		param_d[61] = "-";
		param_d[62] = "-";
		param_d[63] = "-";
		param_d[64] = "-";
		param_d[65] = "-";
		param_d[66] = "-";
		param_d[67] = "-";
		param_d[68] = "-";
		param_d[69] = "-";
		param_d[70] = "-";
		param_d[71] = "-";
		param_d[72] = "-";
		param_d[73] = "-";
		param_d[74] = "-";
		param_d[75] = "-";
		param_d[76] = "-";
		param_d[77] = "-";
		param_d[78] = "-";
		param_d[79] = "-";
		param_d[80] = "-";
		param_d[81] = "-";
		param_d[82] = "-";
		param_d[83] = "-";
		param_d[84] = "-";
		param_d[85] = "-";
		param_d[86] = "-";
		param_d[87] = "-";
		param_d[88] = "-";
		param_d[89] = "-";
		param_d[90] = "-";
		param_d[91] = "-";
		param_d[92] = "-";
		param_d[93] = "-";
		param_d[94] = "-";
		param_d[95] = "MinGW";

//	csvtext_001.set_log_001	( &log_001 );
//	csvtext_001.csv_save("001-filename-20230621\.txt", (char**)param_d, 12, 8 );

	dlog_001 = log_001.update_log ( (char*)"void Initialize_firstset_003 () ends." );

}

// -> invalid
// -> move
// -> invalid
// -> 
void Initialize_firstset_002 ()
{
	printf("void Initialize_firstset_002 () starts.\r\n");
		param_a[0] = (char*)"0";
		param_a[1] = "0";
		param_a[2] = "9";
		param_a[3] = "27";
		param_a[4] = "3";
		param_a[5] = "true";
		param_a[6] = "true";
		param_a[7] = "0";
		param_a[8] = "242";
		param_a[9] = "37.037037037"; // 37.037037
		param_a[10] = "a";
		param_a[11] = "a";
		param_a[12] = "a";
		param_a[13] = "a";
		param_a[14] = "a";
		param_a[15] = "a";
		param_a[16] = "a";
		param_a[17] = "a";
		param_a[18] = "a";
		param_a[19] = "a";
		param_b[0] = "mouse x";
		param_b[1] = "mouse y";
		param_b[2] = "frequent";
		param_b[3] = "frequent * 3";
		param_b[4] = "frequent / 3";
		param_b[5] = "invalidate1"; //true or not
		param_b[6] = "invalidate2"; //true or not
		param_b[7] = "cursol";
		param_b[8] = "buffer size";
		param_b[9] = "base sleep";
		param_b[10] = "b";
		param_b[11] = "b";
		param_b[12] = "b";
		param_b[13] = "b";
		param_b[14] = "b";
		param_b[15] = "b";
		param_b[16] = "b";
		param_b[17] = "b";
		param_b[18] = "b";
		param_b[19] = "b";

//		il_001.initialize_image_layer();
//		il_001.set_default_image_layer();

		log_001.init_log ();
		log_001.start_log ();
		log_001.Set_Filename( (char*)".\\001-filename-20230710-001\.txt");
		dlog_001 = log_001.update_log ( (char*)"one" );
		dlog_001 = log_001.update_log ( (char*)"two" );
		dlog_001 = log_001.update_log ( (char*)"three" );
		dlog_001 = log_001.update_log ( (char*)"four" );
		dlog_001 = log_001.update_log ( (char*)"five" );
		dlog_001 = log_001.update_log ( (char*)"six" );
		dlog_001 = log_001.update_log ( (char*)"seven" );
		dlog_001 = log_001.update_log ( (char*)"eight" );

	printf("void Initialize_firstset_002 () ends.\r\n");
}

//
