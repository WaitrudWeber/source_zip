#ifndef _VCIRCLE_
#define _VCIRCLE_

class vCircle {

public:
	vPoint** pixels = nullptr;
	int max_pixel = 5;
	int index_pixel = 0;

private:
	float R = 0.0;
	vPoint* Center = nullptr;

public:
	void calculation ( vPoint setup, vPoint right_x );
	void set_center( vPoint* set_c );
	void set_R( float r );
	vLine** getLines() ;

private:

};

#endif

