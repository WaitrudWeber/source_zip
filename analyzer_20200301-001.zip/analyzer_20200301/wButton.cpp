#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include "wEvent.h"
#include "wKickEvent.h"

#include "wButton.h"

wButton::wButton(char* bn) {

	this->button_name = bn;
	this->mode = 0;
}


void wButton::setEvent ( wEvent event) {



}


void wButton::setMode( int m ) {

	this->mode = m;
}

int wButton::getMode( ) {

	return this->mode;
}

void wButton::setButton( int xx, int yy, int w, int h) {

	this->x = xx;
	this->y = yy;
	this->width = w;
	this->height = h;

}

int wButton::aaa( ) {

	return 1;
}

int wButton::drawButton(  HDC hdc ) {

	RECT rect;
	//SetTextColor( hdc, RGB(0 ,0, 255));
	//Rectangle( hdc, rect->left, rect->top, rect->right, rect->bottom );
	//DrawText( hdc, TEXT( button_name ), -1, rect, DT_NOCLIP);

	// Calculation of right and bottom
	int right = this->x + this->width;
	int bottom = this->y + this->height;

    SetRect(&rect, this->x, this->y, right, bottom);

	if ( this->mode == 0 )
		SetTextColor( hdc, RGB( 0 ,0, 255 ) );
	else
		SetTextColor( hdc, RGB( 255 ,0, 0 ) );

	Rectangle( hdc, rect.left, rect.top, rect.right, rect.bottom );
	DrawText( hdc, TEXT( this->button_name ), -1, &rect, DT_NOCLIP);

	return 1;
}



// this function draws a button.
// button has a string.
// button has a rect which is one of shapes in this case.
/*int wButton::wdrawButton( HDC hdc, char *button_name, RECT *rect )
{

	SetTextColor( hdc, RGB(0 ,0, 255));

	Rectangle( hdc, rect->left, rect->top, rect->right, rect->bottom );
	DrawText( hdc, TEXT( button_name ), -1, rect, DT_NOCLIP);

	return 1;
}
*/

//
//( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
//
// added 20190118
//
//
void wButton::kickEveentButton ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	// kick event

}

void wButton::wKickEvent ( wKickEvent* kick_event  ) {

	// kick event

}


