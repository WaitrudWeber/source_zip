#ifndef _WKICKEVENT_H_
#define _WKICKEVENT_H_

//Base class 
class wKickEvent 
{ 
    public: 
      int id_p; 

	public:
		void setId ( int id );
		void setKickEveent ( wKickEvent* kick_event  ) ;

}; 

#endif

