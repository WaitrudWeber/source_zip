#include <stdio.h>

#include "vPoint.h"

vPoint::vPoint ( ) {
}

vPoint::vPoint ( float xx, float yy, float zz) {
	this->x = xx;
	this->y = yy;
	this->z = zz;
}

vPoint::setPoint ( float xx, float yy, float zz) {
	this->x = xx;
	this->y = yy;
	this->z = zz;
}

vPoint vPoint::subtract( vPoint a, vPoint b ) {
	vPoint result;

	return result;
}

void vPoint::print( ) {

	printf("p( %f, %f, %f)\r\n", this->x, this->y, this->z );
}

