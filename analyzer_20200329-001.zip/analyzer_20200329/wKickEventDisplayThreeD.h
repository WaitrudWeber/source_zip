#ifndef _WKINCKEVENTDISPLAYTHREED_H_
#define _WKINCKEVENTDISPLAYTHREED_H_

// Sub class inheriting from Base Class(Parent) 
//
class wKickEventDisplayThreeD : public wKickEvent { 
	public: 
		int id_c; 

	private:
		int pid;

	public:
		void setPid ( int id ) ;
		void Execute_001 () ;
		void Prefectured();
		void PreProcessor () ;
		void Processor () ;
		void Processor_001 ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam );
		void wm_char() { }
		void wm_paint() { }

};

#endif
