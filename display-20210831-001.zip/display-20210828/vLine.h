#ifndef _VLINE_H_
#define _VLINE_H_
class vLine {
	public :
		vPoint *p1, *p2;
		char *c1, *c2;

	public:
		vLine ();
		vLine ( vPoint* ap1, vPoint* ap2 ) ;
		void setLine ( vPoint* ap1, vPoint* ap2 ) ;
		void setLine ( float x1, float y1, float z1, float x2, float y2, float z2 ) ;
		void print () ;

};

#endif