#include "vPoint.h"
#include "vLine.h"

vLine::vLine ( ) {
}

void vLine::setLine ( vPoint ap1, vPoint ap2 ) {

	p1 = ap1;
	p2 = ap2;

}

