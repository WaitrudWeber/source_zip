#include "v3dCalculation.h"

int v3dCalculation:: calculation_threed () {


	return 1;
}


