#ifndef _FILEWRITER_007_
#define _FILEWRITER_007_
//...
extern int filewriter_007 ();
extern int set_filewriter_007 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_filewriter_007 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
