#ifndef _CONTROL_IMG_LAYER_006_
#define _CONTROL_IMG_LAYER_006_
//...
extern int control_img_layer_006 ();
extern int set_control_img_layer_006 (int ii, int jj, char* word);
extern int initialize_control_img_layer_006 (int ii, int jj, char* word);
#endif
