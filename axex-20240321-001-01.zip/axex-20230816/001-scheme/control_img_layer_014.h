#ifndef _CONTROL_IMG_LAYER_014_
#define _CONTROL_IMG_LAYER_014_
//...
extern int control_img_layer_014 ();
extern int set_control_img_layer_014 (int ii, int jj, char* word);
extern int initialize_control_img_layer_014 (int ii, int jj, char* word);
#endif
