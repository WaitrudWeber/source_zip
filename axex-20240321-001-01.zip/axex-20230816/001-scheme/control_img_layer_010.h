#ifndef _CONTROL_IMG_LAYER_010_
#define _CONTROL_IMG_LAYER_010_
//...
extern int control_img_layer_010 ();
extern int set_control_img_layer_010 (int ii, int jj, char* word);
extern int initialize_control_img_layer_010 (int ii, int jj, char* word);
#endif
