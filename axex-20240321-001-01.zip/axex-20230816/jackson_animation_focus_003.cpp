#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"

#include "wEvent.h"
#include "cg_schema.h"

#include "log_001.h"

#include "image_layer_001.h"
#include "settle_grid_001.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_000.h"
#include "winmainthread_005a_001.h"

#include "jackson_animation_focus_003.h"


ANIMATION_FOCUS_FRAME *p_jackson;
ANIMATION_FOCUS_FRAME m_jackson;

READ_PPM m_read_ppm;

int debug_ppm[32];
Logging* logging;

int set_log_001_jackson_animation (Logging* llog) ;

// basic
int call_draw_fucus_canvas_buffer_only () ;
int call_draw_canvas_all ();
ANIMATION_FOCUS_FRAME* get_jackson_pointer_animation_thread ();
DWORD WINAPI Animation_5times_thread_canvas_focus_validate ( LPVOID hdc ) ;
DWORD WINAPI Animation_5times_thread_canvas_focus_validate_01 ( LPVOID hdc ) ;

int draw_number ();
int draw_effects ();
int draw_model_frame ();
int draw_grid ();
int initialize_parameters_all () ;


int brunch_functions_all ();

int initialize_ppm_fonts () ;
int initialize_ppm_fonts_debug () ;

int read_ppm_count (char* filename, READ_PPM* read_ppm, int* count) ;
int draw_canvas () ;
int draw_canvas_number ( char* str_number, READ_PPM* read_ppm ) ;

int initialize_media_tracker () ;

int read_ppm (char* filename, READ_PPM* read_ppm) ;
int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) ;
int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) ;
int char_ppm_width_height ( char* print_dummy, int num, int* width, int* height ) ;

int sub_ppm_number () ;

// 20240128
int sub_fonts_number_focus_sheet ( int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) ;
int sub_set_number_focus () ;

// 20240129
int initialize_fonts_param_sheet ();
int sub_fonts_number_focus_get_param_sheet () ;
int sub_fonts_number_focus_set_param_sheet () ;
int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y );
int sub_fonts_number_focus_set_param_sheet_basic () ;

// 20240207
int check_number_focus ();
int print_number_focus ();
int check_thumb_number_focus ();
int print_thumb_number_focus ();
int logging_thumb_number_focus () ;
int rand_print_thumb_number_focus ();

//20240208
int caribration_grid () ;
int caribration_grid_01_03 () ;

// 20240212
int Random_Work_Param ();
int Grid_Work_Param () ;
int Stored_Work_Param (char* file_name ) ;
int Check_Initialize_Param () ;
// 20240212
int Store_Work_Param (char* file_name ) ;
// 20240212
int set_fonts_param_frm_rect_values (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) ;
// 20240212
int check_animation_focus(ANIMATION_FOCUS* focus) ;
int check_animation_focus_band(ANIMATION_FOCUS* focus) ;
// 20240212
int Resque_Initialize_Param ();

//20240219
int Save_Sound_Wave_Buffer () ;

//20240308
int is_initialized () ;

// 20240319
int sub_fonts_number_focus_set_param_sheet_result () ;
int set_number ();

// 20240321
int initialize_canvas () ;


int caribration_grid () {
	int a;
	char	a_h[1][255];

	printf("int caribration_grid () starts.\r\n");
	a = sub_fonts_number_focus_set_param_sheet_basic () ;

	a = Get_Param_005ah ( "number_height", (char**)&a_h[0][0] );
	a = Get_Param_005ah ( "number_height", (char**)a_h );

	printf("int caribration_grid () ends.\r\n");
	return 0;
}

//
int caribration_grid_01_03 () {
	int a;
	char	a_h[1][255];

	printf("int caribration_grid () starts.\r\n");
	a = sub_fonts_number_focus_set_param_sheet_basic () ;

	Set_Param_index ( 6 );
	a = Get_Param_005a ( 1, 3, (char**)&a_h[0][0] );

	Set_Param_index ( 7 );
	a = Get_Param_005a ( 1, 3, (char**)&a_h[0][0] );

	printf("int caribration_grid () ends.\r\n");
	return 0;
}


// https://www.geeksforgeeks.org/generating-random-number-range-c/
int rand_print_thumb_number_focus () {
	int a;
	srand(time(NULL));   // Initialization, should only be called once.
	int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
	float rand_a = ((double)r) / RAND_MAX;

	if ( rand_a < 1.1f ) {
		a = logging_thumb_number_focus();
	}

	return 0;
}

int check_thumb_number_focus () {
	printf("int check_thumb_number_focus () starts.\r\n");
	if ( p_jackson->focus.start_x < 0 ) return -1;
	if ( p_jackson->focus.start_y < 0 ) return -1;
	if ( p_jackson->focus.width <= 0 ) return -1;
	if ( p_jackson->focus.height <= 0 ) return -1;

	printf("int check_thumb_number_focus () ends.\r\n");
	return 0;
}

int print_thumb_number_focus () {

	printf("start x %d ", p_jackson->focus.start_x);
	printf("start y %d ", p_jackson->focus.start_y);
	printf("font_width %d ", p_jackson->focus.width);
	printf("font_height %d\r\n", p_jackson->focus.height);

	return 0;
}

int logging_thumb_number_focus () {
	char msg[255];
	dlog_001 = logging->update_log ("int logging_thumb_number_focus () starts.\0");

	sprintf(msg,"start x %d\0", p_jackson->focus.start_x);
	dlog_001 = logging->update_log (msg);
	sprintf(msg,"start y %d\0", p_jackson->focus.start_y);
	dlog_001 = logging->update_log (msg);
	sprintf(msg,"font_width %d\0", p_jackson->focus.width);
	dlog_001 = logging->update_log (msg);
	sprintf(msg,"font_height %d\0", p_jackson->focus.height);
	dlog_001 = logging->update_log (msg);

	dlog_001 = logging->update_log ("int logging_thumb_number_focus () ends.\0");
	return 0;
}


int check_number_focus () {
	int i;
	printf("int check_number_focus () starts.\r\n");
	for ( i=0; i<10; i++ ) {
		if ( p_jackson->fonts_focus[i].start_x < 0 ) return -1;
		if ( p_jackson->fonts_focus[i].start_y < 0 ) return -1;
		if ( p_jackson->fonts_focus[i].width <= 0 ) return -1;
		if ( p_jackson->fonts_focus[i].height <= 0 ) return -1;

	}
	printf("int check_number_focus () ends.\r\n");
	return 0;
}

int print_number_focus () {
	int i;
	for ( i=0; i<10; i++ ) {
		printf("i %03d ", i );
		printf("start x %d ", p_jackson->fonts_focus[i].start_x);
		printf("start y %d ", p_jackson->fonts_focus[i].start_y);
		printf("font_width %d ", p_jackson->fonts_focus[i].width);
		printf("font_height %d\r\n", p_jackson->fonts_focus[i].height);
	}
	return 0;
}

ANIMATION_FOCUS_FRAME* get_jackson_pointer_animation_thread () {
	int a;

	if ( p_jackson == NULL ) {
		a = brunch_functions_all ();
	}

	return p_jackson;
}

//
int brunch_functions_all () {
	p_jackson = &m_jackson;
	p_jackson->draw_number = &draw_number;
	p_jackson->draw_effects =&draw_effects;
	p_jackson->draw_model_frame = &draw_model_frame;
	p_jackson->draw_grid = &draw_grid;

	p_jackson->call_draw_fucus_canvas_buffer_only = &call_draw_fucus_canvas_buffer_only;
	p_jackson->call_draw_canvas_all = &call_draw_fucus_canvas_buffer_only;


	p_jackson->initialize_parameters_all= &initialize_parameters_all;

	return 0;
}

//
int initialize_ppm_fonts_debug () {

	debug_ppm[0] = 0;
	debug_ppm[1] = 0;
	debug_ppm[2] = 0;
	debug_ppm[3] = 0;

	debug_ppm[4] = 0;
	debug_ppm[5] = 0;
	debug_ppm[6] = 0;
	debug_ppm[7] = 1;
	debug_ppm[8] = 0;
	debug_ppm[9] = 0;
	debug_ppm[10] = 0;
	debug_ppm[11] = 1;
	debug_ppm[12] = 0;
	debug_ppm[13] = 0;
	debug_ppm[14] = 0;

	debug_ppm[15] = 0;
	debug_ppm[16] = 1;
	debug_ppm[17] = 1;
	debug_ppm[18] = 1;
	debug_ppm[19] = 1;

	return 0;
}

int initialize_ppm_fonts () {
	int a;

	a = initialize_ppm_fonts_debug () ;

	char* str_numbered_ppm = (char*)".\\fonts\\vcr_osd_mono0.ppm";
	a = read_ppm ( (char*) str_numbered_ppm, &m_read_ppm) ;

	return 0;
}

int initialize_canvas () {
	int i, j;
	int a;

	printf("int initialize_canvas () starts.\r\n");
	if ( p_jackson->focus.width < 5 ) return -1;
	if ( p_jackson->focus.height < 5 ) return -1;

	if ( p_jackson->canvas == NULL ) {
		p_jackson->canvas = (int**)malloc (sizeof(int) * p_jackson->focus.width );
		if ( p_jackson->canvas == NULL ) {
			printf("p_jackson->canvas is NULL\r\n.");
			exit(-1);
		}
	}

	for ( i= p_jackson->focus.start_x; i<p_jackson->focus.width; i++ ) {
		p_jackson->canvas[i] = (int*)malloc (sizeof(int) * p_jackson->focus.height);
		if ( p_jackson->canvas[i] == NULL ) {
			printf("p_jackson->canvas[%d]", i );
			if ( debug_ppm[0] == 1) exit(-1);
		}
	}


	for ( j= p_jackson->focus.start_y; j<p_jackson->focus.height; j++ )
	for ( i= p_jackson->focus.start_x; i<p_jackson->focus.width; i++ ) {
		p_jackson->canvas[i][j] = 256*4 -1;
	}

	printf("int initialize_canvas () ends.\r\n");
	return 0;
}

//
int initialize_parameters_all () {
	int i, j;
	int a;

	printf("int initialize_parameters_all () starts.\r\n");


	p_jackson->thread_sleep_real_animation = 33;
	p_jackson->thread_animation_times = 60;

	a = initialize_fonts_param_sheet ();

	a = sub_fonts_number_focus_set_param_sheet_result ();

	a = initialize_canvas ();

	printf("int initialize_parameters_all () ends.\r\n");
//	return (void*);
	return 0;
}


int is_initialized () {
	if ( p_jackson->char_str_number == NULL ) {
		printf("p_jackson->char_str_number is null.\r\n");
		return -1;
	}

	return 1;
}

// change
// m_read_ppm. ->
//
int draw_number () {
	static int i, j, k;
	int a;
	printf("int draw_number () starts.\r\n");

	if ( is_initialized () != 1 ) {
		printf("... is not initialized.\r\n");
		return -1;
	}

	a = rand_print_thumb_number_focus();

	if ( check_thumb_number_focus () < 0 ) {
		a =	print_thumb_number_focus ();
		printf("check_thumb_number_focus is not well for print.\r\n");
		exit(-1);
	}

	if ( check_number_focus () < 0 ) {
		a =	print_number_focus ();
		printf("check_number_focus is not well for print.\r\n");
		exit(-1);
	} 

	k = 2;
	for ( j = p_jackson->fonts_focus[k].start_y; j<p_jackson->fonts_focus[k].height; j++ ) {
		for ( i = p_jackson->fonts_focus[k].start_x; i<p_jackson->fonts_focus[k].width; i++ ) {
			int* h = (int*)&(m_read_ppm.ppm_canvas[i][j]);
			p_jackson->canvas[ p_jackson->focus.start_x + i][ p_jackson->focus.start_y + j] = (int)*h;
		}
	}

	printf("int draw_number () ends.\r\n");
	return 0;
}


int sub_set_number_focus () {
	int i;
	int fonts_width;
	int fonts_height;
	int fonts_start_x;
	int fonts_start_y;

	sub_fonts_number_focus_sheet ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );	

	for ( i=0; i<10; i++ ) {
		p_jackson->fonts_focus[i].start_x =  fonts_start_x;
		p_jackson->fonts_focus[i].start_y =  fonts_start_x;
		p_jackson->fonts_focus[i].width = fonts_width ;
		p_jackson->fonts_focus[i].height = fonts_height ;
		fonts_start_x += fonts_width;
	}
}

//
int sub_ppm_number () {
	static int i, j;
	for ( j = p_jackson->focus.start_y; j<p_jackson->focus.height; j++ ) {
		for ( i = p_jackson->focus.start_x; i<p_jackson->focus.width; i++ ) {
			// x (20240111)
			// x p_jackson->canvas[i][j] = (int)m_read_ppm.ppm_canvas[i][j];
			// x p_jackson->canvas[i][j] = (int)( m_read_ppm.ppm_canvas[i][j] );
			int* h = (int*)&(m_read_ppm.ppm_canvas[i][j]);
			p_jackson->canvas[i][j] = (int)*h;
		}
	}

	return 0;
}

int sub_fonts_number_focus_sheet ( int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) {
	*fonts_width = 0;
	*fonts_height = 0;
	*fonts_start_x = 0;
	*fonts_start_y = 0;
	return 0;
}




int draw_effects () {
	printf("int draw_effects () starts.\r\n");

//	return (void*);
	printf("int draw_effects () ends.\r\n");
}

int draw_model_frame () {
	printf("int draw_model_frame () starts.\r\n");
//	return (void*);
	printf("int draw_model_frame () ends.\r\n");
}

int draw_grid () {
	printf("int draw_grid () starts.\r\n");
//	return (void*);
	printf("int draw_grid () ends.\r\n");
}


//
// Draw to focus canvas buffer only
int call_draw_fucus_canvas_buffer_only () {
	int a;
	static int model_changed = 0;

	printf("int call_draw_fucus_canvas_buffer_only () starts.\r\n");

	model_changed = model_changed  % 4 + 1;

	printf("model_changed %d p_jackson|%p|\r\n", model_changed, p_jackson );

	switch ( model_changed ) {
	case 0:
		break;
	case 1:
		p_jackson->draw_number();
		break;
	case 2:
		p_jackson->draw_effects();
		break;
	case 3:
		p_jackson->draw_model_frame();
		break;
	case 4:
		p_jackson->draw_grid();
		break;
	}

	printf("int call_draw_fucus_canvas_buffer_only () ends.\r\n");
	return 0;
}


//
//
//
int call_draw_canvas_all () {
	int i, j;

/*	for ( j= p_jackson->focus.start_y; j<p_jackson->focus.height; j++ )
	for ( i= p_jackson->focus.start_x; i<p_jackson->focus.width; i++ ) {
		p_jackson->canvas[i][j];
	}
*/
	return 0;
}

//
//
//
DWORD WINAPI Animation_5times_thread_canvas_focus_validate ( LPVOID hdc ) {
	int i, a;

	printf("DWORD WINAPI Animation_5times_thread_canvas_focus_validate ( LPVOID hdc ) starts.\r\n");

	p_jackson = (ANIMATION_FOCUS_FRAME*) get_jackson_pointer_animation_thread ();

	if ( p_jackson->initialized != 1 ) {
		printf("call p_jackson->initialize_parameters_all.\r\n");
		p_jackson->initialize_parameters_all(); 
		p_jackson->initialized = 1;
	}

	printf("DWORD WINAPI Animation_5times_thread_canvas_focus_validate ( LPVOID hdc ) initialized.\r\n");

	printf("p_jackson->thread_animation_times %d\r\n", p_jackson->thread_animation_times);
	printf("p_jackson->thread_sleep_real_animation %d\r\n", p_jackson->thread_sleep_real_animation);

	// for loop
	for ( i = 0; i<p_jackson->thread_animation_times; i++ ) {
		InvalidateRect( p_evt->hWnd, NULL, TRUE);
		a = p_jackson->call_draw_fucus_canvas_buffer_only ();
		a = p_jackson->call_draw_canvas_all ();
		Sleep (p_jackson->thread_sleep_real_animation);
	}

	printf("DWORD WINAPI Animation_5times_thread_canvas_focus_validate ( LPVOID hdc ) ends.\r\n");
}


DWORD WINAPI Animation_5times_thread_canvas_focus_validate_01 ( LPVOID hdc ) {
	int i, a;

	printf("DWORD WINAPI Animation_5times_thread_canvas_focus_validate_01 ( LPVOID hdc ) starts.\r\n");

	p_jackson = (ANIMATION_FOCUS_FRAME*) get_jackson_pointer_animation_thread ();

	if ( p_jackson->initialized != 1 ) {
		printf("call p_jackson->initialize_parameters_all.\r\n");
		p_jackson->initialize_parameters_all(); 
		a = Resque_Initialize_Param () ;
		a = sub_fonts_number_focus_set_param_sheet_result ();
		a = initialize_canvas ();
		p_jackson->initialized = 1;
	}

	printf("DWORD WINAPI Animation_5times_thread_canvas_focus_validate_01 ( LPVOID hdc ) initialized.\r\n");

	printf("p_jackson->thread_animation_times %d\r\n", p_jackson->thread_animation_times);
	printf("p_jackson->thread_sleep_real_animation %d\r\n", p_jackson->thread_sleep_real_animation);

	// for loop
	for ( i = 0; i<p_jackson->thread_animation_times; i++ ) {
		InvalidateRect( p_evt->hWnd, NULL, TRUE);
		p_jackson->number = i;
		a = set_number();
		a = p_jackson->call_draw_fucus_canvas_buffer_only ();
		a = p_jackson->call_draw_canvas_all ();
		Sleep (p_jackson->thread_sleep_real_animation);
	}

	printf("DWORD WINAPI Animation_5times_thread_canvas_focus_validate_01 ( LPVOID hdc ) ends.\r\n");
}

//20240319
int set_number () {
	static char num_str[255];
	printf("int set_number () starts.\r\n");
	p_jackson->char_str_number = itoa( p_jackson->number, num_str, 10 );
	printf("int set_number () ends.\r\n");
	return 0;
}


int initialize_media_tracker () {
	return 0;
}


int read_ppm_thread_initialize (){return 0;}
int read_ppm_thread_process (){return 0;}
int read_ppm_thread_pose (){return 0;}
int read_ppm_thread_outbyend (){return 0;}
int read_ppm_thread_close (){return 0;}


int animation_fonts_frame_thread_initialize (){return 0;}
int animation_fonts_frame_thread_process (){return 0;}
int animation_fonts_frame_thread_pose (){return 0;}
int animation_fonts_frame_thread_outbyend (){return 0;}
int animation_fonts_frame_thread_close (){return 0;}


int animation_focus_frame_thread_initialize (){return 0;}
int animation_focus_frame_thread_process (){return 0;}
int animation_focus_frame_thread_pose (){return 0;}
int animation_focus_frame_thread_outbyend (){return 0;}
int animation_focus_frame_thread_close (){return 0;}


// 20240129
int initialize_fonts_param_sheet () {
	int a;
	printf("int initialize_fonts_param_sheet () starts.\r\n");

	a = sub_fonts_number_focus_get_param_sheet ();

	printf("int initialize_fonts_param_sheet () ends.\r\n");
	return 0;
}

//
int sub_fonts_number_focus_get_param_sheet () {
	int i;
	int fonts_width;
	int fonts_height;
	int fonts_start_x;
	int fonts_start_y;
	int a;

	printf("int sub_fonts_number_focus_get_param_sheet () starts.\r\n");

	a = sub_fonts_number_focus_exist_param_sheet ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );
	if ( a < 0 ) {
		printf ("We are going to set the params for font sets.");
		a = sub_fonts_number_focus_set_param_sheet  ();
	}

	a = sub_fonts_number_focus_exist_param_sheet ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );

	fonts_width = fonts_width / 10;

	for ( i=0; i<10; i++ ) {
		p_jackson->fonts_focus[i].start_x =  fonts_start_x;
		p_jackson->fonts_focus[i].start_y =  fonts_start_x;
		p_jackson->fonts_focus[i].width = fonts_width ;
		p_jackson->fonts_focus[i].height = fonts_height ;
		fonts_start_x += fonts_width;
	}

	p_jackson->focus.start_x =  0;
	p_jackson->focus.start_y =  0;
	p_jackson->focus.width = fonts_width ;
	p_jackson->focus.height = fonts_height ;


	printf("int sub_fonts_number_focus_get_param_sheet () ends.\r\n");
	return 0;
}

int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) {
	int a, b, c, d;
	char a_w[1][255];
	char a_h[1][255];
	char a_x[1][255];
	char a_y[1][255];

	printf("int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) starts.\r\n");

	printf("debug_ppm[15] %d\r\n", debug_ppm[15]);
	if ( debug_ppm[15] == 1 ) exit(-1);

	a = Get_Param_005ah ( "number_start_x", (char**)a_x );
	if ( a < 0 ) {
		printf("sub_fonts_number_focus_exist_param_sheet return -1.\0");
		return -1;
	}

	printf("debug_ppm[16] %d\r\n", debug_ppm[16]);
	if ( debug_ppm[16] == 1 ) exit(-1);
	b = Get_Param_005ah ( "number_start_y", (char**)a_y );
	if ( b < 0 ) {
		printf("sub_fonts_number_focus_exist_param_sheet return -1.\0");
		return -1;
	}

	printf("debug_ppm[17] %d\r\n", debug_ppm[17]);
	if ( debug_ppm[17] == 1 ) exit(-1);
	c = Get_Param_005ah ( "number_width", (char**)a_w );
	if ( c < 0 ) {
		printf("sub_fonts_number_focus_exist_param_sheet return -1.\0");
		return -1;
	}

	printf("debug_ppm[18] %d\r\n", debug_ppm[18]);
	if ( debug_ppm[18] == 1 ) exit(-1);
	d = Get_Param_005ah ( "number_height", (char**)a_h );
	if ( d < 0 ) {
		printf("sub_fonts_number_focus_exist_param_sheet return -1.\0");
		return -1;
	}

	*fonts_width = atoi(a_w[0]);
	*fonts_height = atoi(a_h[0]);
	*fonts_start_x = atoi(a_x[0]);
	*fonts_start_y = atoi(a_y[0]);

	sprintf( a_w[0], " fonts_start_x %d fonts_start_y %d fonts_width %d fonts_height %d\0", *fonts_start_x, *fonts_start_y, *fonts_width, *fonts_height );
	printf( "%s\r\n", (char*)a_w[0] );

	sprintf( a_w[0], "a %d b %d c %d d %d\0", a, b, c, d );
	printf( "%s\r\n", (char*)a_w[0] );

	printf("int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) ends.\0");
	return 0;
}

//
int sub_fonts_number_focus_set_param_sheet () {
	int a;
	printf ( "int sub_fonts_number_focus_set_param_sheet () starts.\0" );

//	char a_w[1][255];
//	char a_h[1][255];
//	char a_x[1][255];
//	char a_y[1][255];

//	strcpy( "50",a_x[0]):
//	strcpy( "500",a_y[0]):
//	strcpy( "600",a_w[0]):
//	strcpy( "100",a_h[0]):
//	a = Set_Param_005ah ( "number_start_x", (char**)a_x );
//	a = Set_Param_005ah ( "number_start_y", (char**)a_y );
//	a = Set_Param_005ah ( "number_width", (char**)a_w );
//	a = Set_Param_005ah ( "number_height", (char**)a_h );

	a = sub_fonts_number_focus_set_param_sheet_basic ();

	printf ( "int sub_fonts_number_focus_set_param_sheet () ends.\0" );

	return 0;
}


int sub_fonts_number_focus_set_param_sheet_basic () {

	dlog_001 = logging->update_log ( (char*)"int sub_fonts_number_focus_set_param_sheet_basic () starts.\0" );

	Set_Param_index ( 6 );
	Set_Param_005a( 0, 3, (char*) "number_start_x"  ) ;
	Set_Param_005a( 1, 3, (char*) "number_start_y"  ) ;
	Set_Param_005a( 2, 3, (char*) "number_width"  ) ;
	Set_Param_005a( 3, 3, (char*) "number_height"  ) ;

	Set_Param_index ( 7 );
	Set_Param_005a( 0, 3, (char*) "0"  ) ;
	Set_Param_005a( 1, 3, (char*) "882"  ) ;
	Set_Param_005a( 2, 3, (char*) "640"  ) ;
	Set_Param_005a( 3, 3, (char*) "55"  ) ;

	dlog_001 = logging->update_log ( (char*)"int sub_fonts_number_focus_set_param_sheet_basic () ends.\0" );
	return 0;
}

// 20240319
int sub_fonts_number_focus_set_param_sheet_result () {
	static char num_str[255];

	dlog_001 = logging->update_log ( (char*)"int sub_fonts_number_focus_set_param_sheet_result () starts.\0" );

	Set_Param_index ( 6 );
	Set_Param_005a( 0, 4, (char*) "focus_start_x"  ) ;
	Set_Param_005a( 1, 4, (char*) "focus_start_y"  ) ;
	Set_Param_005a( 2, 4, (char*) "focus_width"  ) ;
	Set_Param_005a( 3, 4, (char*) "focus_height"  ) ;
	Set_Param_005a( 4, 4, (char*) "draw_param"  ) ;

	if ( p_jackson == NULL) return 1;

	Set_Param_index ( 7 );
	//itoa( i, num_str, 10 )
	Set_Param_005a( 0, 4, (char*) itoa(p_jackson->focus.start_x,(char*)num_str,10)  ) ;
	Set_Param_005a( 1, 4, (char*) itoa(p_jackson->focus.start_y,(char*)num_str,10)  ) ;
	Set_Param_005a( 2, 4, (char*) itoa(p_jackson->focus.width,(char*)num_str,10)  ) ;
	Set_Param_005a( 3, 4, (char*) itoa(p_jackson->focus.height,(char*)num_str,10)  ) ;
	Set_Param_005a( 4, 4, (char*) itoa( DRAW_PARAM ,(char*)num_str,10)  ) ;

	dlog_001 = logging->update_log ( (char*)"int sub_fonts_number_focus_set_param_sheet_result () ends.\0" );
	return 0;
}


int draw_canvas () {
	return 0;
}

// We are going to set
// font width
// fonr height
//
// change
// m_read_ppm. ->
int draw_canvas_number ( char* str_number, READ_PPM* read_ppm ) {
	static int i, j, k;
	int width, height, start_x, start_y;
	int ac;

	width = read_ppm->focus.width;
	height = read_ppm->focus.height;
//	width = ;
//	height = ;

	ac = array_count(str_number);

	for ( k=0; k<ac; k++ ) {
		for ( j = p_jackson->focus.start_y; j<p_jackson->focus.height; j++ ) {
			for ( i = p_jackson->focus.start_x; i<p_jackson->focus.width; i++ ) {
				// x (20240111)
				// x p_jackson->canvas[i][j] = (int)m_read_ppm.ppm_canvas[i][j];
				// x p_jackson->canvas[i][j] = (int)( m_read_ppm.ppm_canvas[i][j] );
				int* h = (int*)&(m_read_ppm.ppm_canvas[i][j]);
				p_jackson->canvas[i][j] = (int)*h;
			}
		}
		start_x += width;
		start_y += height;
	}
}


int read_ppm_count (char* filename, READ_PPM* read_ppm, int* count) {

	return 0;
}

//
int read_ppm (char* filename, READ_PPM* read_ppm) {
	FILE *fp;
	int a, i, j;

	printf("int read_ppm (char* filename, READ_PPM* read_ppm) starts.\r\n");

	read_ppm->ppm_canvas = (RGBT**)NULL;
	read_ppm->focus.start_x = 0;
	read_ppm->focus.start_y = 0;
	read_ppm->focus.width = 0;
	read_ppm->focus.height = 0;

	fp = fopen( filename, "rb");

	printf("|%s| fp %d\r\n", filename, fp);

	a = read_ppm_head ( fp, &read_ppm->focus.start_x, &read_ppm->focus.start_y, &read_ppm->focus.width, &read_ppm->focus.height);
	printf( "x %d y %d w %d h %d debug_ppm[4] %d\r\n",read_ppm->focus.start_x, read_ppm->focus.start_y, read_ppm->focus.width, read_ppm->focus.height, debug_ppm[4]);
	if ( debug_ppm[4] == 1) exit(-1);

	read_ppm->ppm_canvas = (RGBT**)malloc (sizeof(RGBT*) * read_ppm->focus.width);
	if ( read_ppm->ppm_canvas == NULL ) {
		printf("We cannnot allocate read_ppm->ppm_canva as width %d of image\r\n", read_ppm->focus.width );
		exit(-1);
	}

	printf("We could allocate read_ppm->ppm_canva as width %d of image sizeof(RGBT) %d\r\n", read_ppm->focus.width, sizeof(RGBT) );
	if ( debug_ppm[5] == 1) exit(-1);

	// allocation
	for ( i= read_ppm->focus.start_x; i<read_ppm->focus.width; i++ ) {
		read_ppm->ppm_canvas[i] = (RGBT*)malloc ( sizeof(RGBT) * read_ppm->focus.height);
		if ( read_ppm->ppm_canvas[i] == NULL ) {
			printf("read_ppm->ppm_canvas[%d]", i );
			exit(-1);
		}
		if ( debug_ppm[7] == 1 && (i % 100) == 0 ) printf("We could allocate read_ppm->ppm_canva as i %d width %d / height %d\r\n", i, read_ppm->focus.width, read_ppm->focus.height );
	}

	for ( i= read_ppm->focus.start_x; i<read_ppm->focus.width; i++ ) {
		for ( j= read_ppm->focus.start_y; j<read_ppm->focus.height; j++ ) {
			read_ppm->ppm_canvas[i][j].t = 0;
			if ( debug_ppm[6] == 1) printf("i %d j %d canvas %d\r\n", i, j, read_ppm->ppm_canvas[i][j].t);
			if ( debug_ppm[7] == 1 && ( i * read_ppm->focus.width + j ) % 100 == 0 ) printf("i %d j %d canvas %d\r\n", i, j, read_ppm->ppm_canvas[i][j].t);
		}
	}

	printf("We could initialize read_ppm->ppm_canva as width %d and height of  image\r\n", read_ppm->focus.width, read_ppm->focus.height );
	if ( debug_ppm[7] == 1) printf("i - 1 %d j -1  %d canvas %d\r\n", i -1, j -1, read_ppm->ppm_canvas[i -1 ][j -1].t);


	a = read_ppm_image_binary ( fp, &read_ppm->focus.start_x, &read_ppm->focus.start_y, &read_ppm->focus.width, &read_ppm->focus.height, (RGBT**) read_ppm->ppm_canvas);

	fclose(fp);

	printf("int read_ppm (char* filename, READ_PPM* read_ppm) ends.\r\n");
	return 0;
}


// P6
// 255
// 320 180
//
//
int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) {
	char dummy[255], print_dummy[255];
	int i, j, a;
	int count, skip, lootin_continued, get_value;

	printf("int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) starts.\r\n");
	printf("fp %d\r\n", fp);

	count = 0;
	skip = 0;
	j = 0;
	lootin_continued = 0;
	get_value = 0;
	for ( i = 0; i<1000; i++ ) {
		fread( dummy, 1, 1, fp );
		print_dummy[ j % 255 ] = dummy[0];
		print_dummy[ j % 255 + 1 ] = 0;
		printf("count %d i %d j %d |%d|%c|%s|\r\n", count, i, j, dummy[0], dummy[0], print_dummy);
		if ( dummy[0] == '\r' || dummy[0] == '\n' ) {
			if ( skip == 0 ) { count++; j = -1; get_value=1; printf("count %d\r\n", count );}
			else { skip = 0; printf("count %d\r\n", count ); j = 0; continue; }

			if ( get_value == 1 ) {
				switch ( count ) {
				case 1: //P6
					printf( "in case 1 and P6, |%s|\r\n", print_dummy);
					break;
				case 2:
					printf( "in case 2 and like 320 180, |%s|\r\n", print_dummy);
					a = char_ppm_width_height ( print_dummy, 255, (int*)width, (int*)height );
					break;
				case 3:
					printf( "in case 3 and like 255, |%s|\r\n", print_dummy);
					if ( debug_ppm[3] == 1) exit(-1);
					break;
				}
				get_value=0;
			}

		}

		if ( count >= 3 ) break;

		if ( dummy[0] == '#' ) {
			skip = 1;
		}

		j++;
	}

	printf("int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) ends.\r\n");
	return 0;
}


//
// width_line_end
int char_ppm_width_height ( char* print_dummy, int num, int* width, int* height ) {
	int i;
	char c;
	char n_dummy[8];

	for ( i=0; i<num; i++ ) {
		print_dummy[i];
		if ( c == ' ' )
			break;

		n_dummy[i] = print_dummy[i];
	}

	*width = atoi(n_dummy);

	for ( ; i<num; i++ ) {
		print_dummy[i];
		if ( c == '\r' )
			break;

		n_dummy[i] = print_dummy[i];
	}

	*height = atoi(n_dummy);

	return 0;
}

// P6
// 255
// 320 180
//
int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) {
	int i, j;
	unsigned char dummy[4];
	static int count = 0;

	printf("int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) starts.\r\n");

	for ( j = 0; j<*height; j++ ) {
		for ( i = 0; i<*width; i++ ) {
			fread( dummy , 1, 3, fp);
			canvas[i][j].r = dummy[0];
			canvas[i][j].g = dummy[1];
			canvas[i][j].b = dummy[2];
			count++;
			if ( debug_ppm[7] == 1 && ( count % 100 ) == 1 ) printf("canvas i %d j %d / (%d,%d) b%d\r\n", i, j, *width, *height, canvas[i][j].b );
		}
	}


	printf("last i-1 %d j-1 %d b%d\r\n", i -1 , j - 1, canvas[ i -1 ][ j -1 ].b);

	printf("int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) ends.\r\n");
	return 0;
}

//
int set_log_001_jackson_animation (Logging* llog) {

	logging = (Logging*)llog;

	return 1;
}

//
int set_fonts_param_frm_rect_values (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) {
	int fnt_wid = 0;

	printf("int set_fonts_param_frm_rect_values (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) starts.\r\n");

	printf("debug_ppm[12] %d\r\n", debug_ppm[12]);
	if ( debug_ppm[12] == 1) exit(-1);

	printf("pointer set *fonts_start_x %d *fonts_start_y %d *fonts_width %d *fonts_height %d\r\n", *fonts_start_x, *fonts_start_y, (*fonts_width), (*fonts_height));

	fnt_wid = *fonts_width / 10;

	for ( i=0; i<10; i++ ) {
		p_jackson->fonts_focus[i].start_x =  *fonts_start_x;
		p_jackson->fonts_focus[i].start_y =  *fonts_start_x;
		p_jackson->fonts_focus[i].width = fnt_wid ;
		p_jackson->fonts_focus[i].height = *fonts_height ;
		*fonts_start_x += fnt_wid;
	}

	printf("pointer set *fonts_start_x %d *fonts_start_y %d *fonts_width %d *fonts_height %d\r\n", *fonts_start_x, *fonts_start_y, (*fonts_width), (*fonts_height));

	p_jackson->focus.start_x =  0;
	p_jackson->focus.start_y =  0;
	p_jackson->focus.width = (*fonts_width) ;
	p_jackson->focus.height =(*fonts_height) ;

	printf("pointer set *fonts_start_x %d *fonts_start_y %d *fonts_width %d *fonts_height %d\r\n", *fonts_start_x, *fonts_start_y, *fonts_width, *fonts_height);
	Sleep(1000);

	printf("debug_ppm[13] %d\r\n", debug_ppm[13]);
	if ( debug_ppm[13] == 1) exit(-1);

	printf("int set_fonts_param_frm_rect_values (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) ends.\r\n");
	return 1;
}

//
int Random_Work_Param () {
	int fonts_width;
	int fonts_height;
	int fonts_start_x;
	int fonts_start_y;
	int a;

	printf("int Random_Work_Param () starts.\r\n");

	printf("debug_ppm[10] %d\r\n", debug_ppm[10]);
	if ( debug_ppm[10] == 1) exit(-1);


	printf("before set fonts_start_x %d fonts_start_y %d fonts_width %d fonts_height %d\r\n", fonts_start_x, fonts_start_y, fonts_width, fonts_height);
	Sleep(1000);

	// 0,862 + 640, 55
	fonts_start_x = 0;
	fonts_start_y = 882;
	fonts_width = 640;
	fonts_height = 55;

	printf("before set fonts_start_x %d fonts_start_y %d fonts_width %d fonts_height %d\r\n", fonts_start_x, fonts_start_y, fonts_width, fonts_height);
	Sleep(1000);

	a = set_fonts_param_frm_rect_values ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );

	printf("after set fonts_start_x %d fonts_start_y %d fonts_width %d fonts_height %d\r\n", fonts_start_x, fonts_start_y, fonts_width, fonts_height);
	Sleep(1000);

	if ( debug_ppm[11] == 1 ) {
		a = print_thumb_number_focus ();
		a = print_number_focus ();
	}

	printf("int Random_Work_Param () ends.\r\n");
	return 0;
}

//
int Grid_Work_Param () {
	int i;
	int fonts_width;
	int fonts_height;
	int fonts_start_x;
	int fonts_start_y;
	int a;
	printf("int Grid_Work_Param () starts.\r\n");

	printf("debug_ppm[9] %d\r\n", debug_ppm[9]);
	if ( debug_ppm[9] == 1) exit(-1);

	a = sub_fonts_number_focus_exist_param_sheet ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );

	a = set_fonts_param_frm_rect_values ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );

	printf("int Grid_Work_Param () ends.\r\n");
	return 1;
}


//
int Stored_Work_Param (char* file_name ) {
	printf("int Grid_Work_Param () starts.\r\n");
	printf("int Grid_Work_Param () ends.\r\n");
	return 1;
}

//
int Check_Initialize_Param () {
	int a, i;
	printf("int Check_Initialize_Param () starts.\r\n");

	for ( i=0; i<10; i++ ) {
		a = check_animation_focus( &(p_jackson->fonts_focus[i]) );
		if ( a < 0 ) {
			printf("font focus i %d a %d \r\n", i, a );
			printf("int Check_Initialize_Param () return -1.\r\n");
			Sleep(1000);
			return -1;
		}
	}

	a = check_animation_focus_band ( &(p_jackson->focus) );
	if ( a < 0 ) {
		printf("font focus a %d \r\n",  a );
		printf("int Check_Initialize_Param () ends.\r\n");
		Sleep(1000);
		return -1;
	}

	printf("int Check_Initialize_Param () returns as 1.\r\n");
	Sleep(1000);
	printf("debug_ppm[14] %d\r\n", debug_ppm[14]);
	if ( debug_ppm[14] == 1 ) {
		exit(-1);
	}
	return 1;
}

int check_animation_focus(ANIMATION_FOCUS* focus) {
	printf("int Grid_Work_Param () starts.\r\n");

	printf("focus |%p| focus->width %d focus->height %d\r\n", focus, focus->width, focus->height );
	
	if ( focus->width <=0 || focus->height<=0 ) {
		return -1;
	}

	if ( focus->width > 100 || focus->height > 100 ) {
		return -1;
	}

	printf("int Grid_Work_Param () ends.\r\n");
	return 1;
}

int check_animation_focus_band (ANIMATION_FOCUS* focus) {
	printf("int Grid_Work_Param () starts.\r\n");

	printf("focus |%p| focus->width %d focus->height %d\r\n", focus, focus->width, focus->height );
	
	if ( focus->width <=0 || focus->height<=0 ) {
		return -1;
	}

	if ( focus->width > 640 || focus->height > 100 ) {
		return -1;
	}

	printf("int Grid_Work_Param () ends.\r\n");
	return 1;
}



//
int Resque_Initialize_Param () {
	int i, a;
	static int select_param = 0;
	printf("int Resque_Initialize_Param () starts.\r\n");
	printf("debug_ppm[8] %d\r\n", debug_ppm[8]);
	if ( debug_ppm[8] == 1) exit(-1);

	for (i=0; Check_Initialize_Param() <= 0; i++) {
		printf("select_param %d\r\n", select_param);
		Sleep(1000);

		switch( select_param ) {
		case 0:
			a = Grid_Work_Param ();
			break;
		case 1:
			a = Stored_Work_Param(".\\end_p\\001-end-file-process-font-001\.txt");
			break;
		case 2:
			a = Random_Work_Param ();
			break;
		default:
			exit(-1);
			break;
		}

		select_param++;
		select_param %= 3;
	}

	a = print_number_focus();
	printf("int Resque_Initialize_Param () ends.\r\n");
	return 1;
}

//
int Store_Work_Param (char* file_name ) {
	printf("int Store_Work_Param (char* file_name ) starts.\r\n");
	printf("int Store_Work_Param (char* file_name ) ends.\r\n");
	exit(-1);
	return 1;
}


//
int Save_Sound_Wave_Buffer () {
	printf("int Save_Sound_Wave_Buffer () starts.\r\n");
	voicewave[0] = 0;

	printf("int Save_Sound_Wave_Buffer () ends.\r\n");
	return 0;
}


