#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>

#include "wButton.h"

wButton::wButton(char* bn) {

	this->button_name = bn;
	this->mode = 0;
}

void wButton::setMode( int m ) {

	this->mode = m;
}

void wButton::setButton( int xx, int yy, int w, int h) {

	this->x = xx;
	this->y = yy;
	this->width = w;
	this->height = h;

}

int wButton::aaa( ) {

	return 1;
}

int wButton::drawButton(  HDC hdc ) {

	static RECT rect, msg_key;
	static HFONT hFont, hFont2;
	static char ex2_str[2048];
	static char num_str[2048];

	//SetTextColor( hdc, RGB(0 ,0, 255));
	//Rectangle( hdc, rect->left, rect->top, rect->right, rect->bottom );
	//DrawText( hdc, TEXT( button_name ), -1, rect, DT_NOCLIP);

	// Calculation of right and bottom
	int right = this->x + this->width;
	int bottom = this->y + this->height;

    SetRect(&rect, this->x, this->y, right, bottom);

	if ( this->mode == 0 )
		SetTextColor( hdc, RGB(0 ,0, 255) );
	else
		SetTextColor( hdc, RGB(255 ,0, 0) );

	hFont = CreateFont (10, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
	hFont2 = (HFONT) SelectObject(hdc, hFont);

	Rectangle( hdc, rect.left, rect.top, rect.right, rect.bottom );
	DrawText( hdc, TEXT( this->button_name ), -1, &rect, DT_NOCLIP);

	// Draw Button Value: 20211208
	// font size; https://docs.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-createfonta
	// font size: http://www.kumei.ne.jp/c_lang/sdk/sdk_27.htm
	if ( bDisplay == 1 ) {
		ex2_str[0] = 0;
		itoa( this->bValue, num_str, 10 );
		strcat( ex2_str, this->button_name );
		strcat( ex2_str, num_str );
		SetRect( &msg_key, 100, 200, 500, 350 );

		hFont = CreateFont (50, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Arial");
		hFont2 = (HFONT)SelectObject(hdc, hFont);

		DrawText( hdc, TEXT( ex2_str ), -1, &msg_key, DT_NOCLIP );
		SelectObject(hdc, hFont2);
		DeleteObject(hFont);
	}

	return 1;
}




// this function draws a button.
// button has a string.
// button has a rect which is one of shapes in this case.
/*int wButton::wdrawButton( HDC hdc, char *button_name, RECT *rect )
{

	SetTextColor( hdc, RGB(0 ,0, 255));

	Rectangle( hdc, rect->left, rect->top, rect->right, rect->bottom );
	DrawText( hdc, TEXT( button_name ), -1, rect, DT_NOCLIP);

	return 1;
}
*/

//
//( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
//
// added 20190118
//
//
void wButton::paintCanvas ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	// kick event
	printf("void wButton::paintCanvas ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) starts.");

	printf("void wButton::paintCanvas ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ends.");
	//exit(-1);
}



