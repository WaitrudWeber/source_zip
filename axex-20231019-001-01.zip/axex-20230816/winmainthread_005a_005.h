#ifndef _WINMAINTHREAD__005_
#define _WINMAINTHREAD__005_
//...
extern int winmainthread_005a_005 ();
extern int set_winmainthread_005a_005 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_winmainthread_005a_005 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
