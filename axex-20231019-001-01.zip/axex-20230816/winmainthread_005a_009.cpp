//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-hProcess-in-mingw-what-to-use-instead
// #include <strsafe.h>

//#include <mmdeviceapi.h>

#include "resource.h"

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"

#include "clipboard.h"

#include "button.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "display_threeD.h"
#include "vPointStructure.h"


#include "vSoundBuffer_001.h"

#include "image_layer_001.h"

#include "wEvent.h"
#include "wEventListener.h"

#include "wJavaStructure.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

#include "wTextarea.h"
#include "wTextareaController.h"

#include "something_word.h"
#include "thread_print.h"


#include "wDisplayController.h"
//#include "wParamSynse_003.h"
#include "wCanvasController.h"

#include "cg_schema.h"


#include "ReturnableParam.h"

#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "log_001.h"

#include "csv_text_001.h"
#include "settle_grid_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"




#include "winmainthread_005a_009.h"

extern DWORD ThreadId_001;
extern HANDLE ThreadHandle_001;

//CSVTEXT_001 csvtext_001;

//20230816
double param_percent = 0.0;

char* param_d [8][96];
int table_width = 12;
int table_height = 8;
int param_d_index = 0;
int param_d_index_max = 8;
char* param_dcv[8]; //current value
char* param_ecv[1]; //current value

Logging log_001;
LOG_001* dlog_001 = NULL;

RECT RefreshRect;
int param_int[20];
char value_text[20][4];

RECT l_rect_xy[96];
RECT l_rect_xy_head[12];
char* param_c[12];

RECT rect_xy[20];
RECT rect_xy_head[20];

RECT rect_log[5];
RECT rect_log_cursol[5];

char	soundwave[255];
char	voicewave[255];


char* log_a[5];
char log_cursol[5][4];
char* param_a[20];
char* param_b[20];
char log_message[255];

int halt_invalidate = 0;

int index;
int end_index;

Settle_Grid_001 l_settle_grid;
Image_Layer_001 il_001;

int DRAW_PARAM = 0;


  int b_Processed = 0;
  HDC     hDC;
   PAINTSTRUCT ps_001;
   char x_b[4];
   char y_b[4];
   char c_b[4]; //
   char d_b[4]; // diff value
   RECT rect_x, rect_y;
   HFONT hFont, hFont2;
   int flg_paint = 0;
  double	param[16];
  int i, j, l, by, posx, posy;
  HBRUSH hBrush;
  HRGN bgRgn;
  HPEN hPen;
   RECT clientRect;
   RECT textRect;
  unsigned char* rgbt;


extern char* filename_winmainthread_005a_009_ = (char*)"winmainthread_005a_009.txt";

int winmainthread_005a_009 ();
int set_winmainthread_005a_009 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_009 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

int winmainthread_005a_009 () {
	return 1;

}


int winmainthread_005a_set_009 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_009 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

