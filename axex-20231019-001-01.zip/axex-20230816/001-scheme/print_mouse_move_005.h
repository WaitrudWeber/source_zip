#ifndef _PRINT_MOUSE_005_
#define _PRINT_MOUSE_005_
extern int print_mouse_move_005 () ;
#endif
