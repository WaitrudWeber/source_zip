#ifndef _READ_CSV__008_
#define _READ_CSV__008_
//...
extern int read_csv_000a_008 ();
extern int set_read_csv_000a_008 (char** argv, int argc);
extern int initialize_read_csv_000a_008 (char** argv, int argc);
#endif
