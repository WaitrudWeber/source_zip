#ifndef _FILEWRITER_008_
#define _FILEWRITER_008_
//...
extern int filewriter_008 ();
extern int set_filewriter_008 ();
extern int initialize_filewriter_008 ();
#endif
