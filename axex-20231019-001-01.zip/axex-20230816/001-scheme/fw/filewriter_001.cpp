int filewriter_001 ();

filewriter_001 () {
nreturn 1;

}


