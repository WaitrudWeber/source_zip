#ifndef _PRINT_MOUSE_011_
#define _PRINT_MOUSE_011_

extern int print_header_file_011 () ;
//extern int print_mouse_move_011 () ;
extern int set_filename_move_011 (char* lfilename) ;
extern int set_define_block_011 (char* ldefine) ;
extern int set_function_block_011 (char* lfunction) ;
extern int set_function_block_011_01 (char* lfunction) ;
extern int set_function_block_011_02 (char* lfunction) ;
extern int set_makefile_block_011 (char* lmakefile) ;
extern int set_source_file_011 (char* lsourcefile) ;
extern int set_code_block_011 (char* lfunction) ;
extern int set_code_block_011_01 (char* lfunction) ;
extern int set_code_block_011_02 (char* lfunction) ;
extern int set_includion_block_011 (char* lfunction) ;
extern int set_includion_block_011_01 (char* lfunction) ;
extern int set_logfilename_block_011 (char* lfunction) ;

extern int print_makefile_011 ( char** function_name, int num ) ;
extern int print_makefile_011_a ( char** function_name, int num ) ;
extern int print_makefile_011_b ( char** function_name, int num ) ;
extern int print_makefile_011_c ( char* function_name ) ;
extern int print_source_file_011 () ;

#endif
