#ifndef ARRAY_H
#define ARRAY_H

#define PARSE_NUM 3000

//extern static char* dummy_allocation;
extern char** dummy_ary;
extern int dummy_ary_index;
extern int dummy_ary_index_max;

extern void clean_null_array() ;

extern int array_count( char *ary );
extern char* concat( char *head, char *tail );
extern char* m_concat( char *head, char *tail );
extern int m_compare ( char* tkn, char* m );

extern char* m_print_buffer( char* buffer);
extern void print_memories ();
extern void print_memories_002 ();
extern char** put_memories ( char* str ) ;

extern char* front_trim( char* c_str ) ;
extern char* back_trim( char* c_str ) ;
extern char* m_trim( char* c_str ) ;

// Do not use initialization for extern.
// Here, we must use the below at 20190304.
extern char* char_line_end;
//extern char* char_line_end = (char*) "\r\n";
//char* char_line_end_001 = (char*) "\r\n";
extern char* copyof ( char* str ) ;
extern int m_start_with ( char *head, char *tail ) ;
extern int m_contains ( char* c_str, char* c_ref ) ;
extern void slide_to_back ( char *msg, int i, int count ) ;
extern void place_char ( char *p_char, char c ) ;

extern char* m_replace ( char* char_string, char* from_string, char* to_string ) ;
extern char* char_string ( int num_memories ) ;
extern char* char_string_010 ( int num_memories ) ;
extern char* char_string_002 ( int num_memories ) ;
extern char* char_string_012 ( int num_memories ) ;
extern char* m_substring ( char* string, int start, int length );

extern void aFree ( char* str ) ;
extern void aFree_001 ( char* str ) ;
extern void aFree_005 ( char* str ) ;
extern int get_last_index_005() ;

extern char* copyof ( char* str ) ;
extern char* copyof_001 ( char* str ) ;
extern char* copyof_002 ( char* str ) ;
extern char* copyof_010 ( char* str ) ;
extern char* copyof_012 ( char* str ) ;

extern void set_a_sleep_thread_time (int lt);

#endif
