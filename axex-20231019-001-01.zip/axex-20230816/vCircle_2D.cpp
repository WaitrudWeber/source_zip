#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"	// ADD: 20200125
#include "sender.h"			// ADD: 20200125
#include "Print.h"			// ADD: 20200125

#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vCalculation.h"

//
vCircle_2D* vCircle_2D::to_vCircle_2D () {
	return this;
}


