#ifndef _WINMAINTHREAD__001_
#define _WINMAINTHREAD__001_
//...
extern int winmainthread_005a_001 ();
extern int set_winmainthread_005a_001 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_winmainthread_005a_001 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int Set_All_Params () ;
extern int Set_Read_Bar () ;
extern int Return_Read_Bar () ;

#endif
