#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"

#include "vScreen.h"
#include "vUtil.h"

//triangular pyramid, trigonal pyramid
int vUtil::OnSideCones ( vPoint* p, vPoint* eye, vPoint** a, int n) {
	vTriangle tri;
	vIntersection inter;
	vCalculation calc;
	vPoint ray;

	// Create Triangle in Local memories.
	tri.p1.setPoint( a[0]->x, a[0]->y , a[0]->z );
	tri.p2.setPoint( a[1]->x, a[1]->y, a[1]->z );
	tri.p3.setPoint( a[2]->x, a[2]->y, a[2]->z );

	int aa = calc.subtract( p, eye, &ray);

	// vPoint* vIntersection::Intersect ( vTriangle tri, vPoint eye, vPoint ray )
	double depth = inter.Depth( tri, *eye, ray);
	if ( depth < 0.0 ) {
		return -1;
	}

	return 1;
}

//triangular pyramid, trigonal pyramid
int vUtil::InsideCones ( vPoint* p, vPoint* eye, vPoint** a, int n) {
	vTriangle tri;
	vIntersection inter;
	vCalculation calc;
	vPoint ray;
	vPoint* b[3];

	b[0] = eye;
	for ( int i=0; i<4; i++ ) {
		b[1] = a[i];
		b[2] =  a[ ( i + 1 ) % 4] ;
		if ( this->OnSideCones( p, eye, b, 3 ) == -1 ) return -1;
	}

	return 1;
}

//https://stackoverflow.com/questions/13408990/how-to-generate-random-float-number-in-c
//https://www.tutorialspoint.com/how-do-i-generate-random-floats-in-cplusplus#:~:text=In%20C%20or%20C%2B%2B%2C%20we%20cannot%20create%20random,result%20with%20some%20floating%20point%20constant%20like%200.5.
int vUtil::SpreadSeed ( vPoint* from, vPoint* to, vPoint** seed, int* n) {
	float x, y, z;

	if ( *n == 0 ) {
		*n = 10;
	}

	srand((unsigned int)time(NULL));
	float ax = to->x - from->x;
	float ay = to->y - from->y;
	float az = to->z - from->z;

	seed = (vPoint**) malloc ( *n * sizeof(vPoint*) );
	if ( sizeof(seed) != *n ) return -1;

	for ( int i=0; i<*n; i++ ) {
        x = ( ((float)rand()/(float)(RAND_MAX)) * ax);
        y = ( ((float)rand()/(float)(RAND_MAX)) * ay);
        z = ( ((float)rand()/(float)(RAND_MAX)) * az);
		seed[i] = memorizevPoint ( x, y, z );
	}

	return 1;
}

