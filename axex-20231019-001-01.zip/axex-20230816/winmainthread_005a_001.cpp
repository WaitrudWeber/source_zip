#include <tchar.h>
#include <windows.h>
#include <windowsx.h>


#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "csv_text_001.h"
#include "settle_grid_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_001.h"
#include "winmainthread_005a_000.h"

extern char* filename_winmainthread_005a_001_ = (char*)"winmainthread_005a_001.txt";

int winmainthread_005a_001 ();
int set_winmainthread_005a_001 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
int initialize_winmainthread_005a_001 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);

int Set_All_Params () ;
int Set_Read_Bar () ;
int Return_Read_Bar () ;

int winmainthread_005a_001 () {
	return 1;

}


int winmainthread_005a_set_001 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int winmainthread_005a_initialize_001 (char* stored_buffer, char* fnc_name, int i, char* buffer_function) {
 	return 1;
 
}

int Set_All_Params () {
	int i, j;

	dlog_001 = log_001.update_log ( (char*)"int Set_All_Params () starts." ); 

	for  ( j =0; j<table_height; j++ ) {
		for  ( i =0; i<table_width; i++ ) {
			sprintf(log_message, "Set_All_Params: i %d j %d\0", i, j );
			dlog_001 = log_001.update_log ( (char*)log_message ); 
			Set_Param_005a( i, j, (char*) log_message  ) ;

		}
	}

	dlog_001 = log_001.update_log ( (char*)"int Set_All_Params () ends." ); 

	return 1;
}

int Set_Read_Bar () {
	sprintf( log_message, "%04d\0", index);
	Set_Param_005a( 10, 6, (char*) log_message ) ;
	sprintf( log_message, "%04d\0", end_index);
	Set_Param_005a( 10, 7, (char*) log_message ) ;
	return 1;
}

//
int Return_Read_Bar () {
	Set_Param_005a( 10, 6, (char*) gettheword_004( 10, 6 ) ) ;
	Set_Param_005a( 10, 7, (char*) gettheword_004( 10, 7 ) ) ;
	return 1;
}
