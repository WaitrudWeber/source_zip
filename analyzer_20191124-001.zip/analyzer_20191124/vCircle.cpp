#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vCircle.h"


void vCircle::set_center( vPoint* set_c ) {

	this->Center = set_c;
}

//
//
//
//
//
vLine** vCircle::getLines() {
	vLine* line = nullptr;
	vLine** lines = (vLine**) malloc ( sizeof(vLine*) * this->max_pixel );
	for( int i=0; i<this->index_pixel - 1; i++) {
		line = new vLine ();
		line->setLine ( this->pixels[i], this->pixels[ i + 1 ] );
		put_memories( (vPoint*) line );
		lines[ i ] = (vLine*) line;
	}

	return lines;
}

// Q
//
//
//
//
void vCircle::calculation( vPoint set_up, vPoint right_x ) {

	vPoint* next = nullptr;
	vPoint* base_xaxis = nullptr;
	vPoint* up = nullptr;
	vPoint* depth = nullptr;
	vPoint* right = nullptr;
	vPoint* start = nullptr;
	vCalculation* calc = nullptr;

	vPoint* Depth = nullptr;

	float PI = 3.141592f;
	float exact_length = this->R*PI;
	float length = 0.0f;
	const float c_length = 5.0f;

	// set memory indxex.

	this->max_pixel = 5;
	calc = new vCalculation ();

	depth = new vPoint();
	right = new vPoint();
	up = &set_up;
	base_xaxis = &right_x;
	calc->cross( up , base_xaxis, depth );
	calc->cross( depth , up, right );
	calc->normal( up );
	calc->normal( right );
	calc->normal( depth );

	start = new vPoint();
	put_memories( start ); // Book memory-administration.
	calc->scale( depth, this->R, start );

	// malloc
	this->pixels = (vPoint**) malloc( sizeof(vPoint*) * this->max_pixel );
	for ( int i=0; i<this->max_pixel; i++ ) {

		printf("001: i=%d / %d \r\n", i, this->max_pixel );

		if ( i >= this->max_pixel ) {
			//realloc
			this->pixels = (vPoint**) realloc( this->pixels, sizeof(vPoint*) * this->max_pixel );
			this->max_pixel *= 2;
		}
		this->pixels[i] = new vPoint();

		printf("002: i=%d / %d \r\n", i, this->max_pixel );

		// 20191124 debug
		calc->Print_Point_Memories();
		printf("this->Center %p\r\n", this->Center);

		// calculation of next.
		Depth = calc->subtract( start, this->Center );
		printf("003: i=%d / %d \r\n", i, this->max_pixel );

		// 20191124 debug
		calc->Print_Point_Memories();

		calc->cross( Depth, up, next);
		printf("004: i=%d / %d \r\n", i, this->max_pixel );
		calc->normal( next );
		next = calc->scalize ( next, c_length ); // specialized.
		printf("005: i=%d / %d \r\n", i, this->max_pixel );

		this->pixels[i] = (vPoint*) next;

		// finish the next calculation.
		length += c_length;
		if ( length > exact_length ) { 
			index_pixel =i;
			break;
		}

	}

	// flush memories to last indxex.

	printf( "max_pixel= %d index_pixel=%d \r\n", this->max_pixel, this->index_pixel );

	printf(" vCircle::calculation ends\r\n");
}

