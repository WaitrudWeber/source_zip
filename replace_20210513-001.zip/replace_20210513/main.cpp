#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"
#include "replace_main.h"

int replace_main (int argc, char** argv ) ;
int copyof_test () ;
int initialize_parse_test () ;
int read_sourcecode (char* filename ) ;

int main (int argc, char** argv ) {
	int a = initialize_parse_test ();

	int b = read_sourcecode(".\main_001.cpp");

	print_memories();
	return 0;
}

int main_001 (int argc, char** argv ) {
	int a = initialize_parse_test ();
//	int a = copyof_test ();
//	int a = replace_main ( argc, argv);
	print_memories();
	return 0;
}

//
int read_sourcecode (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		printf("i: %d loop starts. ", i );
		printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 1 ) {
			printf("we could find line end.\r\n");
			clear_token();
			index++;
			col = 0;
			i++;
			aFree ( p_dummy_token );
			m_thread_sleep();
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "#" ) == 1 && canread == 1  ) {
			col++;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			canread++;
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && canread == 3 ) {
			printf("we could find double quote at the start.\r\n");
			canread = 4;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && canread == 4 ) {
			printf("we could find double quote at the end.\r\n");
			canread = 1;
			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "include" ) == 1 && canread == 2 ) {
			printf("Error: we could find enter before finding double quote end.\r\n");
			clear_token();
			i++;
			aFree ( p_dummy_token );
			m_thread_sleep();
			exit(-1);
		}

		p_dummy_token = put_token( p_dummy[0] );
	}


	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );
	return 0;
}

int initialize_parse_test () {
	printf("copyof_test () starts.\r\n");
	initialize_parse_001 ();
	printf("copyof_test () ends.\r\n");
	return 0;
}

//
int copyof_test () {
	char* p_dummy_alocation_001 = NULL;
	char aa[100];
	char* p_dummy_alocation_002 = NULL;

	printf("copyof_test () starts.\r\n");
	initialize_parse ();
	aa[0] = 'a';
	for ( int j =0; j<10; j++ ) { 
		printf("j=%d\r\n", j);
		for ( int i=0; i<10; i++ ) {
			printf("i=%d\r\n", i);
			p_dummy_alocation_001 = put_token( aa[0] );
		}
		p_dummy_alocation_002 = copyof_001(p_dummy_alocation_001);
		printf("|%p|%p| = ", p_dummy_alocation_001, p_dummy_alocation_002);
		printf("p_dummy_alocation_002=||%p|%s|", p_dummy_alocation_002, p_dummy_alocation_002);
		aFree(p_dummy_alocation_001);
		clear_token();
	}
	printf("copyof_test () ends.\r\n");
	return 0;
}

int replace_main (int argc, char** argv ) {
	printf("main starts.\r\n");

//	char* a_001 = (char*)"a$00<><></>$00bbb\r\ncc$01c";
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$00", (char*)"ee" );
//	printf("a_001 |%s|\r\n", a_001);
//	a_001 = m_replace ( a_001, (char*)"$01", (char*)"ffff" );
//	printf("a_001 |%s|\r\n", a_001);

	if ( argc != 4 ) {
		printf("csv_replace {input-csv-file} {form-html-file} {output-html-file}\r\n");
	}

//	int a = read_csv(".\\001-csv-20210317-001\.txt");
//	int b = replace_csv ( ".\\001-form-20210317-001\.html", ".\\001-html-20210317-001\.txt");

	printf("input-csv: %s form-html-file: %s output-html-file: %s\r\n", argv[1], argv[2], argv[3]);
	sleep(2);

	int a = read_csv( argv[1] );
	print_memories ();
	exit ( -1 );

//	int b = replace_csv ( argv[2], argv[3] );

//	char* string_all = read_all ( ".\\001-form-20210317-001\.html" );
//	printf("string_all:%s\r\n", string_all);

	printf("main ends.\r\n");

	return 0;
}
