#include <stdio.h>
#include <windows.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

int filesize( FILE *fp ) ;

char lines[10][10];
char dummy[256];

int analyze_main () ;
int retrieve (char* filename) ;
int found_enter (char* filename) ;


int found_level1 (char* filename) ;
int a_compare (char* s1, char* s2 ) ;

int found_level_001 (int index, int file_end, FILE *fp ) ;
int found_level_002 (int index, int file_end, FILE *fp ) ;

int found_start (char* filename) ;


int main () {
	char* filename = ".\\001-specification-003.txt";
//	char b_dummy[256];

	int result = found_start (filename);

	return 0;
}

int found_level_002 (int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;

	tfp = fp;

	for ( i =index; i<file_end; i++ ) {
		printf("i: %d loop starts.\r\n", i );

		for ( j=0; j<255; j++ ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( a_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
			printf("We found Eenter |%s| index %d i %d tfp %d fp�@%d\r\n", b_dummy, index, i, tfp, fp);
			exit( -1 );
		}

		printf("i: %d loop ends.\r\n", i );
	}
}

// From Head :
// 
// int index    :
// int file_end :
// FILE*     fp :
int found_level_001 (int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;

	tfp = fp;

	for ( i =index; i<file_end; i++ ) {
		printf("i: %d loop starts.\r\n", i );

		for ( j=0; j<255; j++ ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( a_compare( (char*)b_dummy, (char*)" " ) == 1 ) {

			found_level_002 ( i, file_end, fp ):
		} else if ( a_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
			printf("We found Eenter |%s| index %d i %d tfp %d fp�@%d\r\n", b_dummy, index, i, tfp, fp);
			exit( -1 );
		}

		printf("i: %d loop ends.\r\n", i );
	}
}

//
//
//
//
int found_start (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;

	printf("found_start: starts\r\n");

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	int a = found_level_001 ( 0, file_end, fp );

	printf("found_start: ends\r\n");
}

//
//
//
//
int found_level1 (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;

	printf("found_enter: starts\r\n");

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i =0; i<file_end; i++ ) {

		printf("i: %d loop starts.\r\n", i );

		for ( j=0; j<255; j++ ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( a_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
			printf("We found Eenter %s\r\n", b_dummy);
			exit( -1 );
		} else if ( a_compare( (char*)b_dummy, (char*)":" ) == 1 ) {
			printf("We found colon |%s|\r\n", b_dummy);
			exit( -1 );
		}

		printf("i: %d: |%d|%d|%d|%d| loop ends.\r\n", i, b_dummy[0], b_dummy[1], '\r', '\n' );

		// We could find flip side:
		//
		//
		if ( b_dummy[0] == 13 && b_dummy[1] == 10 ) {
			b_dummy[2] = '\0';
			printf("We found Eenter opposite side: |%s|\r\n", b_dummy);
			exit(-1);
		}
	}

	printf("found_enter: ends\r\n");
	return 0;
}

//
//
//
int a_compare (char* s1, char* s2 ) {
	int c, c1, c2;
	int i;
	char r1, r2;
	int result;
	int sep;

	c1 = array_count(s1);
	c2 = array_count(s2);

	if ( c1 < c2 ) {
		c = c1;
		r2 = s2[c1];	
		s2[c1] = '\0';	
		sep = 0;
	} if ( c1 == c2 ) {
		c = c1;
		sep = 1;
	} else {
		c = c2;
		r1 = s1[c2];	
		s1[c2] = '\0';	
		sep = 2;
	}

	printf("a_compare|%s||%s| 003\n", s1, s2);

	result = m_compare( s1, s2 );



	switch ( sep ) {
	case 0:
		printf("case sep=0\n");
		s2[c] = r1;
		break;
	case 1:
		printf("case sep=1\n");
		break;
	case 2:
		printf("case sep=2\n");
		s1[c] = r2;
		break;
	default:
		break;
	}

	printf("a_compare ends\n");
	return result;
}

//
//
//
//
//
int found_enter (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;

	printf("found_enter: starts\r\n");

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i =0; i<file_end; i++ ) {

		printf("i: %d loop starts.\r\n", i );

		for ( j=0; j<255; j++ ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( m_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
			printf("We found Eenter %s\r\n", b_dummy);
			exit( -1 );
		}

		printf("i: %d: |%d|%d|%d|%d| loop ends.\r\n", i, b_dummy[0], b_dummy[1], '\r', '\n' );

		// We could find flip side:
		//
		//
		if ( b_dummy[0] == 13 && b_dummy[1] == 10 ) {
			b_dummy[2] = '\0';
			printf("We found Eenter opposite side: |%s|\r\n", b_dummy);
			exit(-1);
		}
	}

	printf("found_enter: ends\r\n");
	return 0;
}

int analyze_main () {
	FILE *fp;
	int i;
	char dummy[256];
	char* filename = ".\\alphabet-001.txt";
	char* filename_split = ".\\001-split-001.txt";
//	char spit_line[10];
	char basic[3];

	basic[2] = '\0';

	fp = fopen(filename_split, "rb");
	int file_end = filesize ( fp );

	int start = 0;
	int j = 0;
	// first, we are going to find "spit_line".
	// each block should be stored as block name eve like "001-block---001.txt".
	// and we care following orders.
	//
	for ( i =0; i<file_end; i++ ) {
		printf("loop start i: %d: j: %d: \r\n", i, j );
		fread ( dummy, 1, 1, fp);

		dummy[1] = '\0';
		basic[1] = dummy[0];

		// find line end and space.
		if ( m_compare( (char*)basic, (char*)"\r\n" ) == 1 ) {
			lines[j][i- start - 1 ] = '\0'; //---\r\n if i= 4
			j++;
			start = i + 1;
			//printf("i %d j %d temporary end.\r\n");
			//exit(-1);
		} else {
			lines[j][ i - start ] = dummy[0];
			lines[j][ i - start + 1 ] = '\0';
		}

		printf("loop   end i: %d: |%s| j:%d|%s| basic|%s| start:%d\r\n", i, dummy, j, lines[j], basic, start);
		basic[0] = basic[1];
	}

//	printf("split_line: %s\r\n", spit_line);
	fclose(fp);

	for ( i =0; i<10; i++ ) {
		printf("lines[%d]|%s|\r\n", i, lines[i]);
	}


	/*fp = fopen(filename, "rb");
	file_end = filesize ( fp );
	for ( i =0; i<file_end; i++ ) {
		fread ( dummy, 1, 1, fp);
		dummy[1] = '\0';
		printf("%d: %s\r\n", i, dummy);
	}

	close(fp);*/
	return 0;
}

// 202007710
// START as character
// EOF
int retrieve (char* filename) {
	FILE *fp;
	int i;
	char dummy[256];
	char basic[3];

	printf("retrieve: %s starts.\r\n", filename);

	fp = fopen(filename, "rb");
	int file_end = filesize ( fp );
	int start = 0;
	int j = 0;
	int line_count = 0;
	// first, we are going to find "spit_line".
	// each block should be stored as block name eve like "001-block---001.txt".
	// and we care following orders.
	//
	printf("file_end %d\r\n", file_end );
	for ( i = 0; i<file_end && i<<100; i++ ) {
		printf("loop start i: %d: file_end %d: \r\n", i, file_end  );
		fread ( dummy, 1, 1, fp);

		dummy[1] = '\0';
		basic[1] = dummy[0];

		// find line end.
		if ( m_compare( (char*)basic, (char*)"\r\n" ) == 1 && line_count!= 0 ) {
			lines[j][i- start - 1 ] = '\0'; //---\r\n if i= 4

			char* a = (char*)lines[j];
			if ( i - start - 1 == 0 ) {
				printf("no word\r\n");
				exit(-1);
			} else {
				line_count++;
				//printf("line_count %d\r\n" line_count);
				exit(-1);
			}
			j++;
			start = i + 1;
		} else {
			lines[j][ i - start ] = dummy[0];
			lines[j][ i - start + 1 ] = '\0';
		}

		printf("loop ends i: %d: dummy: |%s| basic: |%s|\r\n", i, dummy, basic );
		basic[0] = basic[1];
	}

	printf("retrieve: %s ends.\r\n", filename);
	return 1;
}



int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

