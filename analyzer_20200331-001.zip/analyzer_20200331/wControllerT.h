#ifndef WCONTROLLERT_H
#define WCONTROLLERT_H

class wControllerT {

	public:
		wButtonController* m_btc;
		wCanvasController* m_canvas;

	public:
		void setKickEvent_001 ( int num, wKickEvent* kick_event) ;
		void setButtonController ( wButtonController* btc ) ;
		void setCanvasController ( wCanvasController* canvas ) ;
		void kickEvent_001();
		int Process ();
		int Process_001 () {}
};

#endif
