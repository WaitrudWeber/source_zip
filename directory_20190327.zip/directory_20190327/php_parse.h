#ifndef _PHP_PARSE_H_
#define _PHP_PARSE_H_

extern FILE *write_fp;
extern int php_filesize( FILE *fp ) ;
extern void php_file_list (std::string strPath ) ;
extern int php_analyzer ( int* short_mode, char* short_token ) ;

#endif
