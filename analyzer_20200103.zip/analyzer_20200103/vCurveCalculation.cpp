#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"

vPoint* vCurveCalculation::BattleField (vPoint* p1, vPoint* p2, vPoint* p3, vPoint* p4, float t) {
	vCalculation* calc = nullptr;

	printf("vCurveCalculation::BattleField: |%p|%p|%p|%p|", p1, p2, p3, p4 );
	// calculation, revisement
	float tt = t*t;

	vPoint* p5 = calc->scalize( p1, 1.0f - tt );	// anchor p1
	vPoint* p6 = calc->scalize ( p4, tt ); 			// anchor p4

	vPoint* point = calc->add ( p5, p6 );

	//consider, p2 and p3 which are controls points.

	printf("vCurveCalculation::BattleField: |%p|\r\n", point );
	return point;
}

// p1: Anchor
// p2: setting controls
//
// p3: Anchor(next)
// p4: setting controls
//
//      vCurveCalculation
//                         Position 
/* vPoint* vCurveCalculation::Position (vPoint* p1, vPoint* p2, vPoint p3, vPoint* p4, float t) {
	vCalculation* calc = nullptr;

	// calculation, revisement
	float tt = t*t;

	vPoint* p5 = calc->multiple ( p1, 1 - tt );
	vPoint* p6 = calc->multiple ( p3, tt );

	vPoint point calc->add ( p5, p6 );

	//consider, p2 and p3 which is controls point.

	return point;
}*/
