// https://github.com/WaitrudWeber/source_zip/blob/master/winmain-20190109.zip
// https://docs.microsoft.com/en-us/windows/desktop/dataxchg/using-the-clipboard

//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>

// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-h-in-mingw-what-to-use-instead
// #include <strsafe.h>


#include "resource.h"

#include "array_counter.h"
#include "clipboard.h"

#include "button.h"

#include "wEvent.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

//#include "wTextarea.h";
#include "something_word.h"
#include "thread_print.h"

// For display of 3D,
#include "vPoint.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h";
#include "vScreen.h"
#include "display_threeD.h"
#include "wCanvasController.h"

//------------------------------------------------
// Macro for switch
//------------------------------------------------
#define CASE        break;case
#define DEFAULT     break;default

//------------------------------------------------
// Constant for Screen
//------------------------------------------------
#define SCREEN_STYLE        (WS_OVERLAPPEDWINDOW ^ (WS_THICKFRAME|WS_MAXIMIZEBOX))
#define SCREEN_WIDTH        (640)       // Screen Width (32dot x 20)
#define SCREEN_HEIGHT       (480)       // Screen Height (32dot x 15)

//------------------------------------------------
// Define Error message
//------------------------------------------------
#define ERRMSG_TITLE        TEXT("WinMain Function")
#define ERRMSG_WINREG       TEXT("Window Class can not be set.")
#define ERRMSG_CREATE       TEXT("Window can not be created.")

#define BOX_ELLIPSE  0 
#define BOX_RECT     1 
 
#define CCH_MAXLABEL 80 
#define CX_MARGIN    12 
 
typedef struct tagLABELBOX {  // box 
    RECT rcText;    // coordinates of rectangle containing text 
    BOOL fSelected; // TRUE if the label is selected 
    BOOL fEdit;     // TRUE if text is selected 
    int nType;      // rectangular or elliptical 
    int ichCaret;   // caret position 
    int ichSel;     // with ichCaret, delimits selection 
    int nXCaret;    // window position corresponding to ichCaret 
    int nXSel;      // window position corresponding to ichSel 
    int cchLabel;   // length of text in atchLabel 
    TCHAR atchLabel[CCH_MAXLABEL]; 
} LABELBOX, *PLABELBOX;

wButton button1((char *)"File Open - o -");
wButton button2((char *)"Something Sentence - s -");
wButton button3((char *)"Something Word - w -");
wButton button4((char *)"Dictionary Link - d -");
wButton button5((char *)"Web Link - l -");
wButton button6((char *)"Print Html - p -");
wButton button7((char *)"Exit - e -");
wButton button8((char *)"Edit - Ctl -");
wButton button9((char *)"Display 3D - 3 -");

char* m_button_select;
int m_button_number_select;
HHOOK hMyHook;

void ButtonSelectDown ();
void ButtonSelectUp ();
// light = 0 means non-select
// light = 1 means select
void ButtonLight( int light, int bn );


void MyHookStart(HWND hWnd) ;
void MyHookEnd(HWND hWnd) ;
LRESULT CALLBACK MyHookProc(int nCode, WPARAM wp, LPARAM lp) ;
static void paintWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
void escape_action( int mode );

void wm_char( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, int m_mode, int btc_CursolNumber, int call_once_key, int key_w );
void paint_clipboard () ;
void ReplaceSelection (HWND hwnd, PLABELBOX pbox, LPTSTR lptstr) ;

VOID WINAPI EditPasteA(VOID) ;
VOID WINAPI EditPaste(VOID) ;

const char* wichStandardClipboardFormatsIsAvailable();

// char* concat( char *head, char *tail ) ;
char m_string[256];
int once_hook = 0;

WPARAM key_w;
LPARAM key_l;
int num_btn;

int key_state;

wButtonController btc;
wCanvasController canvas;
int call_once = 0;
int call_once_key = 0;

// x CString aaa;

int m_mode = -1;

//filename
TCHAR m_szDir[MAX_PATH];

char* m_pastestr;
char* m_replace_selection;

int succ_paste = 0;

UINT uFormat = (UINT)(-1);
UINT uLabelFormat = (UINT)(-1);

HWND hwnd;
HGLOBAL hglb;
HWND hwndOwner;
LPRECT lprc;

HWND hwndSelected;
HWND hwndMain;
HINSTANCE hInstanceMain;
int cyText = 10;

//
// handle of triger
int hTriger = 0;

void list_directory () {
	WIN32_FIND_DATA ffd;
	HANDLE hFind;
	TCHAR szDir[MAX_PATH];
	BOOL b;

	hFind = INVALID_HANDLE_VALUE;
	//hFind = FindFirstFile(szDir, &ffd);
	//hFind = FindFirstFile("c:\\aaa\\*", &ffd);
	hFind = FindFirstFile("c:\\*", &ffd);
	strcpy( m_szDir, ffd.cFileName  );
	strcat( m_szDir, " : " );

	b = FindNextFile( hFind, &ffd);
	strcat( m_szDir, ffd.cFileName  );
	strcat( m_szDir, " : " );

	b = FindNextFile( hFind, &ffd);
	strcat( m_szDir, ffd.cFileName  );
	strcat( m_szDir, " : " );

	// _tprintf(TEXT("  %s   <DIR>\n"), ffd.cFileName );
	//	_tcscpy_s(m_szDir, _countof(m_szDir), _T("Hello"));

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-h-in-mingw-what-to-use-instead
// #include <strsafe.h>
// StringCchCopy(szDir, MAX_PATH, ffd.cFileName);

	FindClose(hFind);
}

void initialize( int m ) {

	switch( btc.CursolNumber ) {
	case 0:
		list_directory ();
		break;
	case 2:
		something_word_initialize ();
		break;
	case 9:
		display_threeD_initialize ();
		break;
	default:
		break;
	}
}

static void paintWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	static char ex_str[2048];
	static char str[2048];
	static char num_str[2048];
	static char pastestr[1024];
//	char *cstr;
//	int l_keystate = -1;

	PAINTSTRUCT ps;
	RECT msg_key, msg_clip, msg_replace;
	FILE * pFile;
	RECT msg;
	int succ;

//	m_pastestr = pastestr;

	// debug, test clipboard in procedure.
//	WriteClip ( hWnd, (char *) "This is cilpboard." );
//	succ = ReadClip ( hWnd, pastestr );

	// display message
//	if ( succ == -1 ) { 
//		exit ( -1 );
//	}

	// display message
//	if ( succ == -2 ) { 
//		exit ( -1 );
//	}

	// debug, we could write a file in main procedure.
//	pFile = fopen ( "example.txt" , "wb" );
//	fputs ( pastestr, pFile );
//	fclose ( pFile );

	switch ( m_mode ) {

	// Explicit
	// Fully and clearly expressed; leaving nothing implied: 
	// That means curly braces.
	case -1:
	{
		itoa(key_w, num_str, 10);
		strcpy( str, "key param: ");
		strcat( str, num_str );

		itoa(key_l, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );

		itoa(key_state, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );

		itoa(btc.CursolNumber, num_str, 10);
		strcat( str, ":" );
		strcat( str, num_str );


		HDC hdc = BeginPaint(hWnd, &ps);
//		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);
//		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, 0);
		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );

		SelectObject(hdc, hPen);

		// 100
		SetRect( &msg_key, 300, 100, 400, 250 );
//		SetTextColor( hdc, RGB( 0, 0, 0) );
		DrawText( hdc, TEXT( str ), -1, &msg_key, DT_NOCLIP );

		// 200
		SetRect(&msg_clip, 300, 200, 400, 250);
		DrawText( hdc, TEXT( m_pastestr ), -1, &msg_clip, DT_NOCLIP);

		// 300
//		m_replace_selection = (char*)"m_replace_selectionA";
		SetRect(&msg_replace, 300, 300, 400, 350);
		DrawText( hdc, TEXT( m_replace_selection ), -1, &msg_replace, DT_NOCLIP);
//		DrawText( hdc, TEXT( "m_replace_selectionA" ), -1, &msg_clip, DT_NOCLIP);

		// message
		SetRect( &msg, 300, 400, 400, 450);
		if ( succ == -1 ) {

			DrawText( hdc, TEXT( "Could not read clipboard" ), -1, &msg, DT_NOCLIP);
		} else {

			ex_str[0] = '\0';
			itoa( btc.CursolNumber, num_str, 10);
			strcat( num_str, ":" );
			strcat( ex_str, num_str );
			itoa( succ_paste, num_str, 10);
			strcat( ex_str, num_str );
			DrawText( hdc, TEXT( ex_str ), -1, &msg, DT_NOCLIP);
		}

		btc.drawButtons( hdc );

		EndPaint(hWnd, &ps);
		break;
	}
	case 0:
	{
		HDC hdc = BeginPaint(hWnd, &ps);
		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );

		SelectObject(hdc, hPen);
		SetRect(&msg_clip, 300, 300, 400, 350);
		SetTextColor(hdc, RGB( 0, 0, 0));
		DrawText( hdc, TEXT( "Could you push Escape until this works." ), -1, &msg_clip, DT_NOCLIP);
		SetRect(&msg_clip, 300, 350, 400, 400);
		DrawText( hdc, m_szDir, -1, &msg_clip, DT_NOCLIP);
		break;
	}
	case 2:
	{
		paint_something_word_proc ( hWnd, uMsg, wParam, lParam);
		break;
	}
	default:
	{
		HDC hdc = BeginPaint(hWnd, &ps);
//		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, NULL);
		HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );

		SelectObject(hdc, hPen);
		SetRect(&msg_clip, 300, 300, 400, 350);
		SetTextColor(hdc, RGB( 0, 0, 0));
		DrawText( hdc, TEXT( "Could you push Escape until this works." ), -1, &msg_clip, DT_NOCLIP);
		break;
	}

	}
}

//------------------------------------------------
// Window Procedure
//------------------------------------------------
static LRESULT CALLBACK mainWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	wEvent evt;
	int succ;
	HDC     hDC;
	PAINTSTRUCT ps;

	evt.hWnd = hWnd;
	evt.uMsg = uMsg;
	evt.wParam = wParam;
	evt.lParam = lParam;
	evt.main_mode = m_mode;
	btc.setEvent ( &evt );
	canvas.setEvent ( &evt );

    switch ( uMsg ){
	case WM_CREATE:
		button1.setButton ( 0, 0,    200, 50 );
		button2.setButton ( 0, 50,   200, 50 );
		button3.setButton ( 0, 100,  200, 50 );
		button4.setButton ( 0, 150,  200, 50 );
		button5.setButton ( 0, 200,  200, 50 );
		button6.setButton ( 0, 250,  200, 50 );
		button7.setButton ( 0, 300,  200, 50 );
		button8.setButton ( 0, 350,  200, 50 );
		button9.setButton ( 0, 400,  200, 50 );

		if ( call_once == 0 ) {
			btc.addButton( &button1 );
			btc.addButton( &button2 );
			btc.addButton( &button3 );
			btc.addButton( &button4 );
			btc.addButton( &button5 );
			btc.addButton( &button6 );
			btc.addButton( &button7 );
			btc.addButton( &button8 );
			btc.addButton( &button9 );
			call_once = 1;
		}

		sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
		break;
   	case WM_PAINT:
		evt.hDc = BeginPaint( hWnd, &ps );
		evt.ps = &ps;
		btc.setEvent ( &evt ); // If you put this here, it works well. And, I don't know the reason. in 20180202
		canvas.setEvent ( &evt );
		printf("WM_PAINT: %d evt.uMsg:%d\r\n", uMsg, evt.uMsg);
		break;
    }

	btc.Process ();
	canvas.Process ();
	m_mode = evt.main_mode;



	//wmpaint_display_threeD_proc ( hWnd, uMsg, wParam, lParam );

	// 20190201
	// conformed this program goes through WM_PAINT in Process
	//if ( canvas.Processed == 1 ) {
	//	exit(-1);
	//}


    switch ( uMsg ){
   	case WM_PAINT:
		//event.hDc = BeginPaint( hWnd, &ps);
		//wmpaint_display_threeD_proc ( hWnd, &hDC, &ps, uMsg, wParam, lParam );
		//btc.Process ();
		EndPaint(hWnd, &ps);
		break;
   	case WM_KEYUP:
		InvalidateRect( hWnd, NULL, TRUE);
		break;

    }

	switch ( btc.Processed ) {
	case 0:
		break;
	case 1:
		btc.Processed = 0;
		return 0;
	case 2:
		btc.Processed = 0;
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	default:
		return 0;
	}

	return 0;

	// the below doesn't matter.
    switch ( uMsg ){
        CASE WM_CREATE:
            /*
            initialization
            */
        {
			button1.setButton ( 0, 0,    200, 50 );
			button2.setButton ( 0, 50,   200, 50 );
			button3.setButton ( 0, 100,  200, 50 );
			button4.setButton ( 0, 150,  200, 50 );
			button5.setButton ( 0, 200,  200, 50 );
			button6.setButton ( 0, 250,  200, 50 );
			button7.setButton ( 0, 300,  200, 50 );
			button8.setButton ( 0, 350,  200, 50 );
			button9.setButton ( 0, 400,  200, 50 );

			// Failure in WM_Create.
//			if ( once_hook == 0 ) {
//
//				once_hook = 1;
//				MyHookStart ( hWnd );
//
//			}

			if ( call_once == 0 ) {
				btc.addButton( &button1 );
				btc.addButton( &button2 );
				btc.addButton( &button3 );
				btc.addButton( &button4 );
				btc.addButton( &button5 );
				btc.addButton( &button6 );
				btc.addButton( &button7 );
				btc.addButton( &button8 );
				btc.addButton( &button9 );
				call_once = 1;
			}

			sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
			//printf("aaa");
        }
        CASE WM_CHAR:
        {
			// for debug. the below could pick up the event when I pushed keyboard on the 9th of May in 2018.
//			a = 0;
//			if (wParam == 0x0D || wParam == 0x08 || wParam == 0x09 || wParam == 0x1B) {
//				return (DefWindowProc(hWnd, message, wParam, lParam));
//			}
//			wsprintf((LPTSTR)msg_str, (LPCTSTR)str_org, (int)wParam);
//			strcat(str, msg_str);
//			InvalidateRect(hWnd, NULL, TRUE);

//			sprintf( m_string, "nCode:%d wp:%d\n", nCode, wParam );
//			sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
//			printf("aab");

			key_w = wParam;
			key_l = lParam;
//			num_btn = btc.number_button;


			// The cool man told me the below separating parameter at 27tj on September in 2018.
			// Judge, m_mode, btc.CursolNumber, call_once_key, key_w
			// Procedure needs wWnd.
			// 
			hTriger = 1;
			wm_char( hWnd, uMsg, wParam, lParam, m_mode, btc.CursolNumber, call_once_key, key_w );
			btc.Process ( );
			hTriger = 0;

			InvalidateRect(hWnd, NULL, TRUE);
		}
        CASE WM_CLOSE:
            /*
            Deposition
            */
            DestroyWindow( hWnd );
			//printf("aac");
        CASE WM_DESTROY:
            PostQuitMessage( 0 ); 
			//printf("aad");
        CASE WM_PAINT:
        {
			paintWindowProc( hWnd, uMsg, wParam, lParam );
			paint_clipboard();

//			//printf("aae");
//			sprintf(m_string, "aae");
        }
        CASE WM_COMMAND:
        {
        	uLabelFormat = LOWORD(wParam);
        	uFormat = LOWORD(wParam);
			if ( once_hook == 0 ) {

				sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
				once_hook = 1;
		        MessageBox(hWnd, "WM_COMMAND", "Inside", MB_OK);
				MyHookStart ( hWnd );

			}

            switch(LOWORD(wParam)) {
				case IDR_MYMENU:
					// SendMessage(hWnd, WM_CLOSE, 0, 0L);
					break;
				case ID_FILE_EXIT:
					break;
				case ID_STUFF_GO:
					break;
            }
        }
//        CASE WM_SYSCOMMAND:
//        {
//			if ( once_hook == 0 ) {
//
//		        MessageBox(hWnd, "WM_SYSCOMMAND", "Inside", MB_OK);
//				sprintf( m_string, "uMsg:%d wParam:%d\n", uMsg, wParam );
//				once_hook = 1;
//				MyHookStart ( hWnd );
//
//			}
//
//        }
        CASE WM_KEYUP:
        {
//			if ( call_once_key == 1 ) {
//				call_once_key = 0;
//				break;
//			}

			switch ( m_mode ) {
			case 2:
				// keyup_something_word ( hWnd, key_w, &m_mode );
				keyup_something_word ( hWnd, key_w, &m_mode );
				break;
			default:
				//  8 Backspace
				// 17 Ctl
				// 13 Enter
				// 27 ESC
				switch ( key_w ) {
				case 13:
					m_mode = btc.CursolNumber;
					initialize( m_mode );
					call_once_key = 1;
					break;
				case 17: // Changing mode to command mode means select button because it equals expectancy of events, in this case edit command.
					btc.selectButton( (char *) "Edit - Ctl -");
					break;
				case 27:
					escape_action( m_mode );
					//m_mode = -1; // means 
					// screen.
					call_once_key = 1;
					break;;
				case 37:
					exit(-1);
					break;
				case 38:
					btc.CursolNumber--;
					btc.selectButton( );
					call_once_key = 1;
					break;
				case 39:
					break;
				case 40:
					btc.CursolNumber++;
					btc.selectButton( );
					call_once_key = 1;
					break;
				}
				break;
			}

			InvalidateRect(hWnd, NULL, TRUE);
		}
        CASE WM_KEYDOWN:
        {
        // when key_w means arrow.
        // 37 left
        // 38 up
        // 39 right
        // 40 down

		// 65 A
		// 97 a

//			ButtonSelectDown () ;
// o		key_state = GetKeyState(VK_MENU) ;
//			key_state = GetKeyState(VK_LEFT) ;

// do not write here. write under wm\char if you want to get arrow.

/*
			switch ( key_w ) {
			case 37:
				exit(-1);
				break;
			case 38:
				btc.CursolNumber--;
				btc.setCursolNumber( btc.CursolNumber );
				break;
			case 39:
				break;
			case 40:
				btc.CursolNumber++;
				btc.setCursolNumber( btc.CursolNumber );
				break;
			}
*/


//			l_keystate = GetKeyState( VK_UP ) ;
//			if ( l_keystate != key_state ) {
//				btc.CursolNumber--;
//				btc.setCursolNumber( btc.CursolNumber );
//			}
//			key_state = l_keystate;

			key_w = wParam;
			key_l = lParam;

			//InvalidateRect(hWnd, NULL, TRUE);

		}
        CASE WM_ENDSESSION:
			PostMessage( hWnd, WM_CLOSE, 0, 0 );
			//printf("aag");
        CASE WM_LBUTTONDOWN:
        {
//			if (GetKeyState(VK_MENU) & 0x8000))
//			{
//				// ALT key is down.
//			}

			// x key_state = GetKeyState(VK_LEFT);
			// x key_state = ( GetKeyState(VK_LEFT) & 0x8000 );
			// x key_state = ( GetKeyState(VK_MENU) & 0x8000 );
			key_state = GetKeyState(VK_MENU) ;


//			if ( GetKeyState(VK_LEFT) & 0x8000))
//			{
//			}
//
//			SendMessage( hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
//			printf("aah");
        }
        CASE WM_LBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_TOPMOST,   0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
			//printf("aah");
        CASE WM_RBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
			//printf("aai");
		CASE WM_SIZE:
			if (uFormat == CF_OWNERDISPLAY) 
            { 
                hwndOwner = GetClipboardOwner(); 
                hglb = GlobalAlloc(GMEM_MOVEABLE, sizeof(RECT)); 
                lprc = (LPRECT)GlobalLock(hglb); 
                GetClientRect(hwnd, lprc); 
                GlobalUnlock(hglb); 
 
                SendMessage(hwndOwner, WM_SIZECLIPBOARD, 
                    (WPARAM) hwnd, (LPARAM) hglb); 
 
                GlobalFree(hglb); 
            } 
        DEFAULT:
			printf("DEFAULT\r\n");
            return DefWindowProc( hWnd, uMsg, wParam, lParam );

		// for check parameter
		// key_w = wParam;
		// key_l = lParam;

    }

    return 0;
}

void paint_clipboard () {
   static HWND hwndNextViewer; 

    HDC hdc; 
    HDC hdcMem; 
    PAINTSTRUCT ps; 
    LPPAINTSTRUCT lpps; 
    RECT rc; 
//    LPRECT lprc; 
    HGLOBAL hglb; 
    LPSTR lpstr; 
    HBITMAP hbm; 
    HENHMETAFILE hemf; 
    HWND hwndOwner; 
 
	switch (uFormat) 
	{
		case CF_OWNERDISPLAY: 
			hwndOwner = GetClipboardOwner(); 
			hglb = GlobalAlloc(GMEM_MOVEABLE, 
                        sizeof(PAINTSTRUCT)); 
			lpps = (LPPAINTSTRUCT)GlobalLock(hglb);
			memcpy(lpps, &ps, sizeof(PAINTSTRUCT)); 
			GlobalUnlock(hglb); 

			SendMessage(hwndOwner, WM_PAINTCLIPBOARD, 
			(WPARAM) hwnd, (LPARAM) hglb); 

			GlobalFree(hglb); 
			m_pastestr = (char *)"CF_OWNERDISPLAY";
			break; 

		case CF_BITMAP: 
			hdcMem = CreateCompatibleDC(hdc); 
			if (hdcMem != NULL) 
			{ 
				if (OpenClipboard(hwnd)) 
				{
					hbm = (HBITMAP) 
					GetClipboardData(uFormat); 
					SelectObject(hdcMem, hbm); 
					GetClientRect(hwnd, &rc); 

					BitBlt(hdc, 0, 0, rc.right, rc.bottom, 
						hdcMem, 0, 0, SRCCOPY); 
					CloseClipboard(); 
				}
				DeleteDC(hdcMem); 
			}
			m_pastestr = (char *)"CF_BITMAP";
			break; 

		case CF_TEXT: 
			if (OpenClipboard(hwnd)) 
			{
				hglb = GetClipboardData(uFormat); 
				lpstr = (LPSTR)GlobalLock(hglb); 

				GetClientRect(hwnd, &rc); 
				DrawText(hdc, lpstr, -1, &rc, DT_LEFT); 

				GlobalUnlock(hglb); 
				CloseClipboard(); 
			}
			m_pastestr = (char *)"CF_TEXT";
			break; 
		case CF_ENHMETAFILE: 
			if (OpenClipboard(hwnd)) 
			{ 
				hemf = (HENHMETAFILE)GetClipboardData(uFormat); 
				GetClientRect(hwnd, &rc); 
				PlayEnhMetaFile(hdc, hemf, &rc); 
				CloseClipboard(); 
			}
			m_pastestr = (char *)"CF_ENHMETAFILE";
			break; 
		case 0: 
			GetClientRect(hwnd, &rc); 
			DrawText(hdc, "The clipboard is empty.", -1, 
						&rc, DT_CENTER | DT_SINGLELINE | 
						DT_VCENTER); 
			m_pastestr = (char *)"CF_ZERO";
			break; 

		default: 
			GetClientRect(hwnd, &rc); 
			DrawText(hdc, "Unable to display format.", -1, 
						&rc, DT_CENTER | DT_SINGLELINE | 
						DT_VCENTER); 
			EndPaint(hwnd, &ps);
			m_pastestr = (char *)"CF_DEFAULT";
//			    else if (uFormat == uLabelFormat) 
//			hglb = GlobalAlloc(GMEM_MOVEABLE, sizeof(LABELBOX)); 
//			if (hglb == NULL) 
//				return; 
//			pbox = GlobalLock(hglb); 
//			memcpy(pbox, pboxLocalClip, sizeof(LABELBOX)); 
//			GlobalUnlock(hglb); 
//			SetClipboardData(uLabelFormat, hglb); 
//			break;
	}
}

void wm_char( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, int m_mode, int btc_CursolNumber, int call_once_key, int key_w )
{
	int succ;

	//
	// Send wTriger tp ButtonController
	btc.setTriger( hTriger );

	switch( m_mode ) {
		case 0:
			break;
		case 1:
			break;
		case 2:
			getchar_something_word_proc( hWnd, uMsg, wParam, lParam );
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		case 8:
			// do not write anything
			break;
		case 9:
			getchar_display_threeD_proc( hWnd, uMsg, wParam, lParam );
			break;
	}

	// for Edit
	if ( btc.CursolNumber == 7 ) {

		switch( key_w ) {
		case 'v':
			//succ_paste = ReadClip ( hWnd, m_pastestr );
			EditPaste();
			m_pastestr = m_concat(m_pastestr, ":did paste");
			break;
		case 'r':
			show_garbage_collection () ;
			m_pastestr = "show_garbage_collection () ;";
			// multithread_print();
			break;
		default:
			break;
		}

		if ( call_once_key == 1 ) {
			call_once_key = 0;
			//break;
		}


		switch( key_w ) {
		case 'o':
			btc.selectButton( (char *) "File Open - o -");
			break;
		case 's':
			btc.selectButton( (char *) "Something Sentence - s -");
			break;
		case 'w':
			btc.selectButton( (char *) "Something Word - w -");
			break;
		case 'd':
			btc.selectButton( (char *) "Dictionary Link - d -");
			break;
		case 'l':
			btc.selectButton( (char *) "Web Link - l -");
			break;
		case 'p':
			btc.selectButton( (char *) "Print Html - p -");
			break;
		case 'e':
			btc.selectButton( (char *) "Exit - e -");
			break;
		case '3':
			btc.selectButton( (char *) "Display 3D - 3 -");
			break;
		}


	}

	call_once_key = 1;
}

//
//
//
//
//
//
VOID WINAPI EditPasteA(VOID) 
{
    PLABELBOX pbox; 
    HGLOBAL   hglb; 
    LPTSTR    lptstr; 
    PLABELBOX pboxCopy; 
    int cx, cy; 
    HWND hwnd; 
	char num_str[1024];

    LPCTSTR atchClassChild = TEXT("Lesson5WndClass");

    pbox = hwndSelected == NULL ? NULL : 
        (PLABELBOX) GetWindowLong(hwndSelected, 0); 

    // If the application is in edit mode, 
    // get the clipboard text. 

	m_replace_selection = (char*)"DefaultA:";

    if (pbox != NULL && pbox->fEdit) 
    { 
		m_replace_selection = (char*)"DefaultB";
        if (!IsClipboardFormatAvailable(CF_TEXT)) 
            return; 
        if (!OpenClipboard(hwndMain)) 
            return; 

		m_replace_selection = (char*)"DefaultB";

        hglb = GetClipboardData(CF_TEXT); 
        if (hglb != NULL) 
        { 
			m_replace_selection = (char*)"DefaultC";
            lptstr = (LPTSTR)GlobalLock(hglb);
            m_replace_selection = lptstr;
            if (lptstr != NULL) 
            { 
                // Call the application-defined ReplaceSelection 
                // function to insert the text and repaint the 
                // window. 
 
                ReplaceSelection(hwndSelected, pbox, lptstr); 
                GlobalUnlock(hglb); 
            } 
        } 
        CloseClipboard(); 

        return; 
    } 

	m_replace_selection = (char*)"DefaultD";

    // If the application is not in edit mode, 
    // create a label window. 
 
    if (!IsClipboardFormatAvailable(uLabelFormat)) 
        return; 

	m_replace_selection = (char*)"DefaultE";

    if (!OpenClipboard(hwnd
    )) 
        return; 

//	m_replace_selection = (char*)"DefaultF";

    hglb = GetClipboardData(uLabelFormat); 
    if (hglb != NULL) 
    { 
        pboxCopy = (PLABELBOX)GlobalLock(hglb); 
        if (pboxCopy != NULL) 
        { 
            cx = pboxCopy->rcText.right + CX_MARGIN; 
            cy = pboxCopy->rcText.top * 2 + cyText; 
 
            hwnd = CreateWindowEx( 
                WS_EX_NOPARENTNOTIFY | WS_EX_TRANSPARENT, 
                atchClassChild, NULL, WS_CHILD, 0, 0, cx, cy, 
                hwndMain, NULL, hInstanceMain, NULL 
            ); 
            if (hwnd != NULL) 
            { 
                pbox = (PLABELBOX) GetWindowLong(hwnd, 0); 
                memcpy(pbox, pboxCopy, sizeof(LABELBOX)); 
                ShowWindow(hwnd, SW_SHOWNORMAL); 
                SetFocus(hwnd); 
            } 
            GlobalUnlock(hglb); 
        } 
    } 
    CloseClipboard();
}

const char* wichStandardClipboardFormatsIsAvailable()
{
	// Standard Clipboard Formats
	// CF_BITMAP			: 2
	// CF_DIB				: 8
	// CF_DIBV5				:17
	// CF_DIF				: 5
	// CF_DSPBITMAP			:0x0082
	// CF_DSPENHMETAFILE	:0x008E
	// CF_DSPMETAFILEPICT	:0x0082
	// CF_DSPTEXT			:0x0081
	// CF_ENHMETAFILE		:14
	// CF_GDIOBJFIRST		:0x0300
	// CF_GDIOBJLAST		:0x03FF
	// CF_HDROP				:15
	// CF_LOCALE			:16
	// CF_METAFILEPICT		:3
	// CF_OEMTEXT			:7
	// CF_OWNERDISPLAY		:0x0080
	// CF_PALETTE			:9
	// CF_PENDATA			:10
	// CF_PRIVATEFIRST		:0x0200
	// CF_PRIVATELAST		:0x02FF
	// CF_RIFF				:11
	// CF_SYLK				:4
	// CF_TEXT				:1
	// CF_TIFF				:6
	// CF_UNICODETEXT		:13
	// CF_PRIVATELAST		:0x02FF
	// CF_WAVE				:12

	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_BITMAP";
	}
	if ( IsClipboardFormatAvailable(CF_DIB) ) {
		return "CF_DIB";
	}
	if ( IsClipboardFormatAvailable(CF_DIBV5) ) {
		return "CF_DIBV5";
	}
	if ( IsClipboardFormatAvailable(CF_DIF) ) {
		return "CF_DIF";
	}
	if ( IsClipboardFormatAvailable(CF_DSPBITMAP) ) {
		return "CF_DSPBITMAP";
	}
	if ( IsClipboardFormatAvailable(CF_DSPENHMETAFILE) ) {
		return "CF_DSPENHMETAFILE";
	}
	if ( IsClipboardFormatAvailable(CF_DSPMETAFILEPICT) ) {
		return "CF_DSPMETAFILEPICT";
	}
	if ( IsClipboardFormatAvailable(CF_HDROP) ) {
		return "CF_HDROP";
	}
	if ( IsClipboardFormatAvailable(CF_GDIOBJFIRST) ) {
		return "CF_GDIOBJFIRST";
	}
	if ( IsClipboardFormatAvailable(CF_GDIOBJLAST) ) {
		return "CF_GDIOBJLAST";
	}
	if ( IsClipboardFormatAvailable(CF_HDROP) ) {
		return "CF_HDROP";
	}
	if ( IsClipboardFormatAvailable(CF_LOCALE) ) {
		return "CF_LOCALE";
	}
	if ( IsClipboardFormatAvailable(CF_METAFILEPICT) ) {
		return "CF_METAFILEPICT";
	}
	if ( IsClipboardFormatAvailable(CF_OEMTEXT) ) {
		return "CF_OEMTEXT";
	}
	if ( IsClipboardFormatAvailable(CF_OWNERDISPLAY) ) {
		return "CF_OWNERDISPLAY";
	}
	if ( IsClipboardFormatAvailable(CF_PALETTE) ) {
		return "CF_PALETTE";
	}
	if ( IsClipboardFormatAvailable(CF_RIFF) ) {
		return "CF_RIFF";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_SYLK";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_TEXT";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_UNICODETEXT";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_PRIVATELAST";
	}
	if ( IsClipboardFormatAvailable(CF_BITMAP) ) {
		return "CF_WAVE";
	}

	return "CF_NOT_STANDARD";
}

VOID WINAPI EditPaste(VOID) 
{
    PLABELBOX pbox; 
    HGLOBAL   hglb; 
    LPTSTR    lptstr; 
    PLABELBOX pboxCopy; 
    int cx, cy; 
    HWND hwnd;
    char num_str[1024];

	BOOL flag_CF_TEXT = true;

    LPCTSTR atchClassChild = TEXT("Lesson5WndClass");

    pbox = hwndSelected == NULL ? NULL : 
        (PLABELBOX) GetWindowLong(hwndSelected, 0); 

	// If the application is in edit mode, 
	// get the clipboard text. 
	m_replace_selection = (char*)"DefaultA:";

//	if (pbox == NULL ) return;
//
//    if (pbox != NULL && pbox->fEdit) 
//    if ( 1 && pbox->fEdit )

	// Add the below 20190111
	m_replace_selection = (char*)wichStandardClipboardFormatsIsAvailable ();
	return;

	if ( 1 )
    {
		m_replace_selection = (char*)"DefaultB";
        if (!IsClipboardFormatAvailable(CF_TEXT)) {
        	flag_CF_TEXT = false;
        }

		if ( flag_CF_TEXT == true ) {

			if (!OpenClipboard(hwndMain)) 
				return; 

			m_replace_selection = (char*)"DefaultC";

			hglb = GetClipboardData(CF_TEXT);
			if (hglb != NULL) 
			{ 
				m_replace_selection = (char*)"DefaultC";
				lptstr = (LPTSTR)GlobalLock(hglb);
				m_replace_selection = lptstr;
				if (lptstr != NULL) 
				{ 
                // Call the application-defined ReplaceSelection 
                // function to insert the text and repaint the 
                // window. 
 
					ReplaceSelection(hwndSelected, pbox, lptstr); 
					GlobalUnlock(hglb); 
				 
				}
				CloseClipboard(); 

				return;
			}
    	}
    }

	m_replace_selection = (char*)"Before uLabelFormat";

    // If the application is not in edit mode, 
    // create a label window. 

	// the below doesn't work well, so I commented out it.
//    if (!IsClipboardFormatAvailable(uLabelFormat)) 
//        return; 

	m_replace_selection = (char*)"DefaultE";

    if (!OpenClipboard(hwndMain)) 
        return; 

	m_replace_selection = (char*)"DefaultF";

// 
// int GetClipboardFormatNameA(
//   UINT  format,
//   LPSTR lpszFormatName,
//   int   cchMaxCount
// );


	int return_format_succeeds = GetClipboardFormatNameA(uLabelFormat, m_replace_selection, 5);
    CloseClipboard();
    return;

//	int return_format_succeeds = GetClipboardFormatNameA(uLabelFormat, m_pastestr, 1024);

    hglb = GetClipboardData(uLabelFormat); 
    if (hglb != NULL) 
    {
		m_replace_selection = (char*)"DefaultG";
        pboxCopy = (PLABELBOX)GlobalLock(hglb); 
        if (pboxCopy != NULL) 
        { 
            cx = pboxCopy->rcText.right + CX_MARGIN; 
            cy = pboxCopy->rcText.top * 2 + cyText; 

            hwnd = CreateWindowEx( 
                WS_EX_NOPARENTNOTIFY | WS_EX_TRANSPARENT, 
                atchClassChild, NULL, WS_CHILD, 0, 0, cx, cy, 
                hwndMain, NULL, hInstanceMain, NULL 
            ); 
            if (hwnd != NULL) 
            { 
                pbox = (PLABELBOX) GetWindowLong(hwnd, 0); 
                memcpy(pbox, pboxCopy, sizeof(LABELBOX)); 
                ShowWindow(hwnd, SW_SHOWNORMAL); 
                SetFocus(hwnd); 
            }
            GlobalUnlock(hglb); 
        }
    } else {
		m_replace_selection = (char*)"DefaultH";
    }

    CloseClipboard();
}

// insert the text and repaint the 
// window. 
void ReplaceSelection (HWND hwnd, PLABELBOX pbox, LPTSTR lptstr) {

// the Lootin came here at 20:14 20180109
//	m_replace_selection = (char*)"path\=ReplaceSelectionA";
	m_replace_selection = lptstr;

//	RECT rect;
//	PAINTSTRUCT ps;

//	HDC hdc = BeginPaint(hwnd, &ps);

//	SetRect( &rect, 200, 200, 400, 400 );
//	SetTextColor( hdc, RGB( 1, 0, 0) );
//	DrawText( hdc, TEXT( lptstr ), -1, &rect, DT_NOCLIP);
//	DrawText( hdc, TEXT( m_pastestr ), -1, &rect, DT_NOCLIP);
//	EndPaint(hwnd, &ps);

}

// 27 ESC
void escape_action( int mode ) {
	int result;

	if ( mode == 2 ) {
		result = something_word_escape ();
		if ( result == 1) {
			// to main window
			m_mode = -1;
		}
		return;
	}

	m_mode = -1; // means main screen.
}

void ButtonSelectDown () {
	ButtonLight( 0, m_button_number_select );
	m_button_number_select++;
	ButtonLight( 1, m_button_number_select );
}

void ButtonSelectUp () {
	ButtonLight( 0, m_button_number_select );
	m_button_number_select--;
	ButtonLight( 1, m_button_number_select );
}

// light = 0 means non-select
// light = 1 means select
void ButtonLight( int light, int bn ) {

	switch ( m_button_number_select ) {
	case 1:
		button1.setMode( light );
		break;
	case 2:
		button2.setMode( light );
		break;
	case 3:
		button3.setMode( light );
		break;
	case 4:
		button4.setMode( light );
		break;
	case 5:
		button5.setMode( light );
		break;
	case 6:
		button6.setMode( light );
		break;
	case 7:
		button7.setMode( light );
		break;
	case 8:
		button8.setMode( light );
		break;
	}

}

//------------------------------------------------
// Set Window Procedure
//------------------------------------------------
static ATOM funcWindowClass( HINSTANCE hInstance, LPCTSTR lpClassName )
{
    WNDCLASSEX wcex = { 0 };
    wcex.cbSize         = sizeof(WNDCLASSEX);
    wcex.style          = CS_DBLCLKS;
    wcex.lpfnWndProc    = mainWindowProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon( NULL, IDI_APPLICATION );
    wcex.hIconSm        = LoadIcon( NULL, IDI_APPLICATION );
    wcex.hCursor        = LoadCursor( NULL, IDC_ARROW );
    wcex.hbrBackground  = (HBRUSH)GetStockObject( WHITE_BRUSH );
    wcex.lpszMenuName   = "IDR_MYMENU";
    wcex.lpszClassName  = lpClassName;
    return RegisterClassEx( &wcex );
}

//------------------------------------------------
// Set Window Size
//------------------------------------------------
static VOID funcSetClientSize( HWND hWnd, LONG sx, LONG sy )
{
    RECT rc1;
    RECT rc2;
    
    GetWindowRect( hWnd, &rc1 );
    GetClientRect( hWnd, &rc2 );
    sx += ((rc1.right - rc1.left) - (rc2.right - rc2.left));
    sy += ((rc1.bottom - rc1.top) - (rc2.bottom - rc2.top));
    SetWindowPos( hWnd, NULL, 0, 0, sx, sy, (SWP_NOZORDER|SWP_NOOWNERZORDER|SWP_NOMOVE) );
}

//------------------------------------------------
// Creation of Window
//------------------------------------------------
static HWND funcCreateWindow( HINSTANCE hInstance, LPCTSTR lpClassName, LPCTSTR lpTitleName, int nCmdShow )
{
    HWND hWnd = CreateWindowEx(
        0,                  // Expandation of Window Style
        lpClassName,        // Window Class Name
        lpTitleName,        // Window Title
        SCREEN_STYLE,       // Window Style
        CW_USEDEFAULT,      // Horizental window position
        CW_USEDEFAULT,      // Vertical window position
        CW_USEDEFAULT,      // Window width
        CW_USEDEFAULT,      // Window height
        NULL,               // Parent window handle
        NULL,               // handle of Menu bar
        hInstance,          // handle of Instance
        NULL );             // Put parameter Creation of window

//    hwndMain = hWnd;
    if ( hWnd != NULL ){
        funcSetClientSize( hWnd, SCREEN_WIDTH, SCREEN_HEIGHT );
        ShowWindow( hWnd, nCmdShow );
        UpdateWindow( hWnd );
    }
    return hWnd;
}

//------------------------------------------------
// Main Function
//------------------------------------------------
extern int WINAPI _tWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow )
{

    LPCTSTR lpClassName = TEXT("Lesson5WndClass");
    LPCTSTR lpTitleName = TEXT("Tanion");
    MSG Msg;

    hInstanceMain = hInstance;
    // Set Window Class
    if ( funcWindowClass(hInstance,lpClassName) == 0 ){
        MessageBox( NULL, ERRMSG_WINREG, ERRMSG_TITLE, (MB_OK|MB_ICONERROR) );
        return -1;
    }
    // Creation of Window
    if ( funcCreateWindow(hInstance,lpClassName,lpTitleName,nCmdShow) == NULL ){
        MessageBox( NULL, ERRMSG_CREATE, ERRMSG_TITLE, (MB_OK|MB_ICONWARNING) );
        return -2;
    }
    // Message Loop
    while ( GetMessage(&Msg,NULL,0,0) > 0 ){
        TranslateMessage( &Msg );
        DispatchMessage( &Msg );
    }
    UNREFERENCED_PARAMETER( hPrevInstance );
    UNREFERENCED_PARAMETER( lpCmdLine );
    return Msg.wParam;
}

//------------------------------------------------------------------------------
// End of Lesson5.cpp
//------------------------------------------------------------------------------

void MyHookStart(HWND hWnd)
{
    HINSTANCE hInst;

    hInst = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);
    hMyHook = SetWindowsHookEx(WH_KEYBOARD,
        (HOOKPROC)MyHookProc,
        hInst,
        0);
    if (hMyHook == NULL)
        MessageBox(hWnd, "Failed to hook", "Error", MB_OK);

    return;
}

LRESULT CALLBACK MyHookProc(int nCode, WPARAM wp, LPARAM lp)
{

	sprintf( m_string, "nCode:%d wp:%d\n", nCode, wp );

    if (nCode < 0)
        return CallNextHookEx(hMyHook, nCode, wp, lp);
    if (wp >= 0x30 && wp <=0x39)
        return CallNextHookEx(hMyHook, nCode, wp, lp);

    MessageBeep(MB_OK);
    return TRUE;
}

void MyHookEnd(HWND hWnd)
{
    if (UnhookWindowsHookEx(hMyHook) != 0)
        MessageBox(hWnd, "Delete hook.", "OK", MB_OK);
    else
        MessageBox(hWnd, "Fail to delete hook", "Error", MB_OK);
    return;
}

/**
 *
 *  wParam, one of the: WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, or WM_SYSKEYUP
    lParam: pointer to a KBDLLHOOKSTRUCT structure

    (*) "The hook procedure should process a message in less time than the
    data entry specified in the LowLevelHooksTimeout value in the following registry key: 
    HKEY_CURRENT_USER\Control Panel\Desktop 

    The value is in milliseconds. If the hook procedure does not 
    return during this interval, the system will pass the message to the next hook."

 *
 */

/*
LRESULT CALLBACK
hook_proc( int code, WPARAM wParam, LPARAM lParam )
{
  static long ctrl_cnt = 0;
  static bool mmode = false;
  static DWORD time;

  KBDLLHOOKSTRUCT*  kbd = (KBDLLHOOKSTRUCT*)lParam;

  if (  code < 0
  ||   (kbd->flags & 0x10) // ignore injected events
     ) return CallNextHookEx( thehook, code, wParam, lParam );

  long ret = 1; // by default I swallow the keys
  if (  mmode  ) { // macro mode is ON
    if (  WM_KEYDOWN == wParam  )
      PostMessage(mainwnd, WM_MCR_ACCUM, kbd->vkCode, 0);

    if (  WM_KEYUP == wParam  )
      switch (kbd->vkCode) {
        case VK_ESCAPE:
          mmode = false;
          keys.removeall();
          PostMessage(
          wnd, WM_MCR_HIDE, 0, 0);
          break;

        case VK_RETURN:
          PostMessage(mainwnd, WM_MCR_EXEC, 0, 0);
          break;

        case VK_LCONTROL:
          mmode = false;
          PostMessage(mainwnd, WM_MCR_HIDE, 0, 0);
          PostMessage(mainwnd, WM_MCR_EXEC, 0, 0);
          break;
      }

    // Which non printable keys allow passing?
    switch( kbd->vkCode ) {
      case VK_LCONTROL:
      case VK_CAPITAL:
      case VK_LSHIFT:
      case VK_RSHIFT:
        ret = CallNextHookEx( thehook, code, wParam, lParam );
    }
  }
  else { // macro mode is OFF
    // Ctrl pressed 
    if (  kbd->vkCode == VK_LCONTROL && WM_KEYDOWN == wParam  ) {
      ctrl_cnt = 1;
      time = kbd->time;
    }

    // Prevent ctrl combinations to activate macro mode 
    if (  kbd->vkCode != VK_LCONTROL  )
      ctrl_cnt = 0;

    // Ctrl released 
    if (  ctrl_cnt == 1 && WM_KEYUP == wParam  ) {
      if (  kbd->time - time > 40  ) {
        mmode = true;
        PostMessage(mainwnd, WM_MCR_SHOW, 0, 0);
      }
    }

    ret = CallNextHookEx( thehook, code, wParam, lParam ); // let it pass
  }

  return ret;
}
*/

void SetNumLock( BOOL bState )
   {
      BYTE keyState[256];

      GetKeyboardState((LPBYTE)&keyState);
      if( (bState && !(keyState[VK_NUMLOCK] & 1)) ||
          (!bState && (keyState[VK_NUMLOCK] & 1)) )
      {
      // Simulate a key press
         keybd_event( VK_NUMLOCK,
                      0x45,
                      KEYEVENTF_EXTENDEDKEY | 0,
                      0 );

      // Simulate a key release
         keybd_event( VK_NUMLOCK,
                      0x45,
                      KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP,
                      0);
      }
   }

//------------------------------------------------
// Window Procedeure
//------------------------------------------------
// static LRESULT CALLBACK mainWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
// {
//     switch ( uMsg ){
//         CASE WM_CREATE:
//             /*
//             Initialization
//             */
//         CASE WM_CLOSE:
//             /*
//             Deposition
//             */
//             DestroyWindow( hWnd );
//         CASE WM_DESTROY:
//             PostQuitMessage( 0 );
//         CASE WM_PAINT:
//         {
//             PAINTSTRUCT     ps;
//             HDC             hDC;
//             
//             hDC = BeginPaint( hWnd, &ps );
//             /*
//             Drawing
//             */
//             EndPaint( hWnd, &ps );
//         }
//         CASE WM_ENDSESSION:         PostMessage( hWnd, WM_CLOSE, 0, 0 );
//         CASE WM_LBUTTONDOWN:        SendMessage( hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
//         CASE WM_LBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_TOPMOST,   0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
//         CASE WM_RBUTTONDBLCLK:      SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, (SWP_NOMOVE|SWP_NOSIZE) );
//         DEFAULT:                    return DefWindowProc( hWnd, uMsg, wParam, lParam );
//     }
//     return 0;
// }




