#ifndef _WORK_008_H_
#define _WORK_008_H_
class WORK_008 { 
	public:
		WORK_009 *iWORK_008=nullptr;

	public:
		SetWORK_009( WORK009 *lWORK009 ); 

};
#endif
