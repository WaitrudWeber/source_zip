
// https://waitrudweber.hatenablog.com/entry/2021/07/09/175334
// 
// 


#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"

#include "wTextarea.h"
#include "clipboard.h"

#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vAxex_2D.h"
#include "vIntersection.h"
#include "vScreen.h"

#include "vLine.h"

#include "vPointStructure.h"
#include "vPointLinear.h"
#include "vUtil.h"

#include "creation_of_objects.h"
#include "creation_of_axex.h"
#include "display_threeD.h"


int display_threeD_initialize () ;
int display_threeD_screen_initialize () ;

int getchar_something_word_proc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int getchar_display_threeD_proc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;

int wmpaint_display_threeD_proc_org ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;

int wmpaint_display_patches ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;


void GamePaint_006(HDC hDC) ;
void GamePaint_007(HDC hDC) ;
void GamePaint_008(HDC hDC, POINT* points) ;

void GamePaint_009(HDC hDC, vLine* line ) ;
void GamePaint_010(HDC hDC, vPoint* point ) ;
void GamePaint_011(HDC hDC, vLine* line ) ;


int getchar_up () ;
void Print_Global_Vertexes ( vPoint* points, int** numbering, int num_patches, int base_num_patches) ;

int m_thread_sleep ();

int display_mode = 1;



vPoint* pointss = nullptr;
int** patches = nullptr;
vLine* patch_lines = nullptr;

int num_patches = 0;
int base_num_patches = 0;
int num_patch_lines = 0;

vTriangle atri;
vTriangle screen_tri;
// static vPoint eye;

vPoint ray;
vPoint point_intersection;
float g_x, g_y;
int display_3d = 0;
//static vLine** lines = nullptr;		// axes in the 3-D.
//static vLine** lines_2D = nullptr;  // axes on the screen.

vLine** lines_patches = nullptr;
vLine** lines_patches_2D = nullptr;

vLine** lines = nullptr;		// axes in the 3-D.
vLine** lines_2D = nullptr;  // axes on the screen.

//20210810
vLine lines_001[30];
vLine lines_2D_001[30];

// 20210306
int line_index = 0;



vScreen* screen = nullptr;
HWND hWindow;

static int call_once_display_threeD_initialize = 0;
vLine* to_screen( vLine** v3d_line, int num ) ;
int count_screen( char* pchar_vline ) ;

void put_vertex(  vPoint* be_set, vPoint* p1 );

vPoint* vertexes = nullptr;
int** patch_num = nullptr;

// Curve
//static vPointLinear* CurveLines = new vPointLinear ();
static vPointLinear* CurveLines = nullptr;
static int memorized_CurveLines = 0;


static int init_lines = 0;


int CurveLines_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int NormalFaces_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int DisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int aDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int bDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int cDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int dDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int eDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int fDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int gDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int hDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int iDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int jDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int kDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int lDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int mDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
int nDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;

vLine* to_screen_line( vLine* ll ) ;
void create_lines( vPointLinear* curveLines, vLine** sl_lines, int num ) ;

int waitfor_wmpaint_display_threeD_proc () ;
int create_CurveLines( vLine** l_lines, int line_num ) ;

int print_screen ();
int print_lines ();


// 20210306
int convert_model_lines( vLine **lines, vLine **lines_2D, int line_index, int max_num ) ;
int create_model_lines( vLine **lines, int *line_index, int max_num ) ;
int create_curve_lines ( int num ) ;

// 20210810
int convert_model_lines_002( vLine *lines, vLine *lines_2D, int line_index, int max_num ) ;
int check_lines_002 ( vLine *l_lines, vLine *l_lines_2D, int l_line_index, int max_num ) ;

// 20210324
int to_screen_line_set( vLine* ll, vLine* result ) ;

int spin_screen() ;

int spreading_particles_initialize () ;

int create_vaxex_test () ;

int convert_AXEX_2D () ;



int m_thread_sleep () {
	Sleep(250);
}

int print_lines () {
	printf("print_lines () starts. lines|%p|\r\n", lines );
	if (init_lines == 1 ) {
		if ( lines == nullptr ) {
			printf("print_lines () ends: lines is null, so, it return -1.\r\n");
			return -1;
		}
		for ( int i=0; i<3; i++ ) {
			printf("lines[%d] = |%p|\r\n", i, lines[i]);
//			if ( lines[i] == 0) exit (-1);
			if ( lines[i] == 0) {
				printf("print_lines () ends: lines[%d] is null, so, it return -1.\r\n", i);
				return -1;
			}
		}
	}
	printf("print_lines () ends.\r\n");
}

int print_screen () {
	printf("eye: ");
	screen->eye.print();
	printf("lookat: ");
	screen->lookat.print();

	printf("up: ");
	screen->up.print();

	printf("U: ");
	screen->U.print();
	printf("V: ");
	screen->V.print();
	printf("Center C: ");
	screen->C.print();
}

// scope : 20190217
//
//
//
//
void put_vertex(  vPoint* be_set, vPoint* p1 ) {
	be_set->setPoint( p1->x, p1->y, p1->z );
}

//
//
//
//
//
int curve_initialization () {

	printf("starts curve_initialization()\r\n");

	printf("STARTS CurveLines->FirstCreation()\r\n");
	if ( CurveLines == nullptr ) {
		CurveLines = new vPointLinear ();
	}

	CurveLines->FirstCreation();
	printf("ENDS CurveLines->FirstCreation()\r\n");

	printf("STARTS CurveLines->PrintAnchors();\r\n");
	CurveLines->PrintAnchors();
	printf("ENDS CurveLines->PrintAnchors();\r\n");
	printf("STARTS CurveLines->PrintControls();\r\n");
	CurveLines->PrintControls();
	printf("ENDS CurveLines->PrintControls();\r\n");

	printf("ends curve_initialization()\r\n");
	//exit(-1);
}

//
int spreading_particles_initialize () {
	vUtil autil;
	vPoint* from = new vPoint ( 0.0f, 0.0f, 0.0f );
	vPoint* to = new vPoint ( 100.0f, 100.0f, 100.0f );
	vPoint** seed = nullptr;

	int number = 50;
	int a = autil.SpreadSeed( from, to, seed, &number);

	return 0;
}

// All qualified at 20190627:
//
//
//
//
int display_threeD_screen_initialize () {
	vPoint* eye = nullptr;

	if ( call_once_display_threeD_initialize == 0 ) {
		call_once_display_threeD_initialize = 1;
	} else {
		printf("exit because call_once_display_threeD_initialize = %d\r\n", call_once_display_threeD_initialize );
		return 1;
	}

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	screen = new vScreen ();
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen->put_U ( *U );
	screen->put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen->put_Up ( *up );

	screen->setWidth ( 640 );
	screen->setHeight ( 480 );
	screen->setEye ( *eye );
	screen->LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );
	screen->HowFarFromEve = 320.0f;

	screen->calculation_up_UV();
	screen->OntheScreen( &g_x, &g_y );

	if ( memorized_CurveLines == 0 ) {
		curve_initialization();
		memorized_CurveLines = 1;
	}

	printf("display_threeD_screen_initialize:memorized_CurveLines=%d\r\n", memorized_CurveLines );
}


int spin_screen() {
	vCalculation calc;
	static vPoint* cross_step = nullptr;
	vPoint* base_step_vector = nullptr;
	vPoint* step_vector = nullptr;

	printf("spin_screen() starts. screen=|%p|\r\n", screen );

	if (call_once_display_threeD_initialize == 0) {
		display_threeD_initialize();
		call_once_display_threeD_initialize = 1;
	}

	// distance from center to eye in Vector.
	vPoint* vdistance = calc.subtract ( &(screen->eye) , &(screen->C) );
	vPoint* n = calc.normal (*vdistance); // copy in sub, so *.

	// step base vector,  cross_step is up of spining which doesn't change.
//	if ( croos_step == nullptr ) {
//		step_vector = new vPoint ( 500.0f, 500.0f, 500.0f );
//		cross_step = calc.cross( n, step_vector );
//	}

	if ( cross_step == nullptr ) {
		printf("cross_step is nullptr\r\n");
		base_step_vector = new vPoint ( 10.0f, 10.0f, 10.0f ); // becoming first UP of spin.
		step_vector = calc.cross( &(screen->eye), base_step_vector );
		cross_step = calc.cross( n, step_vector ); // becoming RIGHT of spin.
		printf("cross_step is |%p|\r\n", cross_step );
	}

	vPoint* next_point = calc.add( cross_step, &(screen->eye) );

	// distance from center to eye in Vector.
	screen->eye.setPoint( next_point->x, next_point->y, next_point->z );
	screen->calculation_up_UV();

	// free area
	free(vdistance);
	free(n);
	free(step_vector);
	free(base_step_vector);
	free(next_point);

	printf("spin_screen() ends. screen=|%p|\r\n", screen );

	return 0;
}

//
//
//
//
//
int display_threeD_initialize () {
	vPoint eye;
	char *p_cc;

	if ( call_once_display_threeD_initialize == 0 ) {
		call_once_display_threeD_initialize = 1;
	} else {
		exit(-1);
	}

	printf("display_threeD_initialize start.\r\n");

	eye.setPoint( 500.0f, 500.0f, -500.0f);

	atri.p1.setPoint( 100.0f,   0.0f, 100.0f );
	atri.p2.setPoint( 200.0f, 200.0f, 200.0f );
	atri.p3.setPoint( 300.0f,   0.0f, 100.0f );

	screen = new vScreen ();
	vPoint* U= memorizevPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= memorizevPoint ( 0, 90.0f, 0 );
	screen->put_U ( *U );
	screen->put_V ( *V );

	printf("display_threeD_culculation up_UV starts.\r\n");
	screen->put_Up ( *( memorizevPoint(0.0f, 1.0f, 0.0f) ) );
	screen->put_C ( *( memorizevPoint( 0.0f, 0.0f, -50.0f) ));
	screen->setWidth ( 640 );
	screen->setHeight ( 480 );
	screen->setEye ( eye );
	screen->LookAt ( *(memorizevPoint( 0.0f, 0.0f, 0.0f )) );
	screen->HowFarFromEve = 320.0f;
	screen->calculation_up_UV();
	printf("display_threeD_culculation up_UV ends.\r\n");

	screen->OntheScreen( &g_x, &g_y );

	display_3d = 1;

	printf("display_threeD_initialize=000\r\n");


	lines = (vLine**) malloc ( sizeof(vLine*) * 3 );
	lines_2D = (vLine**) malloc ( sizeof(vLine*) * 3 );
	for( int i=0; i<3; i++ ) {
		printf("i:%d \r\n", i);
		lines[i] = new vLine();
		lines_2D[i] = new vLine();
	}
	//exit(-1);

	lines[0]->setLine( (memorizevPoint( -50.0f, 0.0f, 0.0f)), (memorizevPoint(300.0f,   0.0f, 0.0f)) );
	lines[1]->setLine( (memorizevPoint( 0.0f, -50.0f, 0.0f)), (memorizevPoint(  0.0f, 300.0f, 0.0f)) );
	lines[2]->setLine( (memorizevPoint( 0.0f, 0.0f, -50.0f)), (memorizevPoint(  0.0f, 0.0f, 300.0f)) );
	lines[0]->c1 = (char*) "x1";
	lines[0]->c2 = (char*) "x2";

	printf("display_threeD_initialize=001\r\n");

	lines_2D[0]->setLine( (memorizevPoint( 0.0f, 0.0f, 0.0f)), (memorizevPoint( 300.0f,   0.0f, 0.0f)) );
	lines_2D[1]->setLine( (memorizevPoint( 0.0f, 0.0f, 0.0f)), (memorizevPoint(   0.0f, 300.0f, 0.0f)) );
	lines_2D[2]->setLine( (memorizevPoint( 0.0f, 0.0f, 0.0f)), (memorizevPoint(   0.0f,   0.0f, 300.0f)) );

	printf("display_threeD_initialize=002\r\n");

	lines_patches = (vLine**) malloc ( sizeof(vLine*) * 3 );
	lines_patches_2D = (vLine**) malloc ( sizeof(vLine*) * 3 );

	printf("display_threeD_initialize=0021\r\n");

	for( int i=0; i<3; i++ ) {
		lines_patches[i] = new vLine();
		lines_patches_2D[i] = new vLine();
	}

	// commented out at 20190518
	lines_patches[0]->p1 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[0]->p2 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[1]->p1 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[1]->p2 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[2]->p1 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches[2]->p2 = memorizevPoint( 0.0f, 0.0f, 0.0f); 

	printf("display_threeD_initialize=0022\r\n");

	// x lines_patches[0]->setLine( new vPoint( 0.0f, 0.0f, 0.0f), new vPoint( 0.0f, 0.0f, 0.0f) );
	// x lines_patches[0]->setLine( new vPoint( 0.0f, 0.0f, 0.0f), new vPoint( 0.0f, 0.0f, 0.0f) );
	printf("lines_patches[2]->p2->x %f\r\n", lines_patches[2]->p2->x );

    printf("display_threeD_initialize=0023\r\n");

	// commented out at 20190518
	lines_patches_2D[0]->p1 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[0]->p2 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[1]->p1 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[1]->p2 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[2]->p1 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	lines_patches_2D[2]->p2 = memorizevPoint( 0.0f, 0.0f, 0.0f); 

	lines_patches_2D[0]->c1 = (char *) p_cc;
	lines_patches_2D[0]->c1 = (char *) copyof( "x1" );
	lines_patches_2D[0]->c2 = (char *) copyof( "x2" );
	lines_patches_2D[1]->c1 = (char *) copyof( "y1" );
	lines_patches_2D[1]->c2 = (char *) copyof( "y2" );
	lines_patches_2D[2]->c1 = (char *) copyof( "z1" );
	lines_patches_2D[2]->c2 = (char *) copyof( "z2" );

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	//point_intersection = intersection->Intersect( atri, eye, ray );

	printf("display_threeD_initialize=003\r\n");

	// Book a triangle patch
	num_patches = 1;
	patch_num = (int**) malloc( sizeof(int*) * 1 ) ;
	vertexes = (vPoint*) malloc( sizeof(vPoint) * 8 ) ;

	vertexes = memorizevPoint ( 0.0f, 0.0f, 0.0f );
	// scope put a vertex
	put_vertex( vertexes + 1, memorizevPoint ( 5.0f, 10.0f, 0.0f ));
	put_vertex( vertexes + 2, memorizevPoint ( 10.0f, 0.0f, 0.0f ));

	base_num_patches = 3;
	printf("display_threeD_initialize=001");
	Print_Global_Vertexes ( vertexes, patch_num, num_patches, base_num_patches );

	int* p_tri_patch = (int*) malloc( sizeof(int) * base_num_patches ) ;
	p_tri_patch[0] = 0;
	p_tri_patch[1] = 1;
	p_tri_patch[2] = 2;

	patch_num[0] = p_tri_patch;

	num_patch_lines = 0;
	num_patch_lines = base_num_patches*num_patches;


	if ( memorized_CurveLines == 0 )
		curve_initialization();

	memorized_CurveLines = 1;

	printf("display_threeD_initialize will return 0.\r\n");
	//exit(-1);

	return 0;
}

//
//
//
//
//
int get_cooordinate_on_screen ( vPoint lp, float* lx, float* ly ) {
	vCalculation calc;
//	vTriangle screen_tri;

	printf("get_cooordinate_on_screen starts.\r\n");

	if ( screen == nullptr ) {
		printf ("We can not memory screen params so that the program could exit in get_cooordinate_on_screen.\r\n");
		display_threeD_screen_initialize ();
		Sleep(100);
		printf ("We can memory screen params.\r\n");
//		exit(-1);
	}

	calc.subtract( &lp, &(screen->eye), &ray);
	calc.normal( &ray );
	// if ( ray.x == 0 && ray.y == 0 && ray.z == 0 ) return -1;

	screen_tri.p1.setPoint(lp.x, lp.y, lp.z );
	calc.add( &(screen->C), &(screen->U), &(screen_tri.p2) );
	calc.add( &(screen->C), &(screen->V), &(screen_tri.p3) );

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	vPoint* point_intersection = intersection->Intersect( screen_tri, screen->eye, ray );

	printf("intersection_001 = ");
	point_intersection->print();
//
//	vPoint result;
//	screen->setPoint(lp);
//	screen->OntheScreen( lp, &result );

	int result = screen->OntheScreen( *point_intersection, lx, ly );
	printf("get_cooordinate_on_screen ends. 001\r\n");

	delete ( point_intersection );

	printf("get_cooordinate_on_screen ends. 002\r\n");
	return 0;
}

//
//
//
//
//
int getchar_display_threeD_proc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
//	int key_w = wParam;

	printf("getchar = %d\r\n", wParam );
	//exit(-1);
	switch ( wParam ) {
	case 'j': // UP
		getchar_up ();
		break;
	case 40: // DOWN
		break;
	}

	return 0;
}

//
//
//
//
int getchar_up () {

	printf("getchar_up :\r\n");
	vPoint ray;
	vCalculation this_calc;

	float depth = this_calc.length ( this_calc.subtract( screen->eye, screen->lookat ) );

	this_calc.add( &(screen->eye), &(screen->up), &(screen->eye) );
	printf("screen->eye = ");
	screen->eye.print();

	this_calc.subtract( &(screen->eye), &(screen->lookat), &ray );
	this_calc.normal( ray );
	printf("ray = ");
	ray.print();
	this_calc.scale( &ray, depth, &ray );
	printf("ray = ");
	ray.print();
	this_calc.add( &(screen->lookat), &ray, &(screen->eye) );

	printf("screen->up = ");
	screen->up.print();
	printf("screen->eye = ");
	screen->eye.print();
	screen->calculation_up_UV();

	printf("screen->eye = ");
	screen->eye.print();
	printf("screen->lookat = ");
	screen->lookat.print();
//	exit(-1);
	return 0;
}

//
//
//
//
//
int wmpaint_display_threeD_proc_org ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	HDC     hDC;
	PAINTSTRUCT ps;

	// this is not called at 20190406
	// exit(-1);
	hDC = BeginPaint( hWnd, &ps);

	GamePaint_007( hDC );

	EndPaint(hWnd, &ps);
	return 0;
}

//
//
//
//
void Print_Global_Vertexes ( vPoint* points, int** numbering, int num_patches, int base_num_patches)
{
// 20190217
// p( 10.000000, 0.000000, 0.000000)
// p( 0.000000, 186447550218240.000000, -0.000000)
// p( 0.000000, 0.000000, 300.000000)

	int num = num_patches*base_num_patches;
	for(int i=0; i< num; i++ ) {
		( points + i )->print();
	}
}

//
//
//
//
//
int calculation_pathes () {

	vPointLinear mpl;

	float t = 0.0f;
	vPoint* c1 = new vPoint ( 0.0f, 0.0f, 0.0f );
	vPoint* c2 = new vPoint ( 0.0f, 0.0f, 0.0f );

	vPointLinear* pl = new vPointLinear();
	pl->calculation ();

	for ( int i=0; i< 100; i++ ) {
		double di = i;
		t = di/100.0 ;
//		vPoint result = (vPoint) pl->additional_positionP( c1, c2, t );
//		result = (vPoint) mpl.additional_positionP( c1, c2, t );

	}

	return 0;
}

//
//
//
//
//
int wmpaint_display_patches ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	calculation_pathes ();

	GamePaint_009( hDC, lines_patches_2D[0] );
}

//
//
//
//
//
//
int wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

	int result = waitfor_wmpaint_display_threeD_proc ();
	if ( result == 1 ) {
		//int curve_result = CurveLines_wmpaint_display_threeD_proc ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
		// printf("curve_result=%d\r\n", curve_result );
		dDisplayControls_wmpaint_display_threeD_proc ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
		// NormalFaces_wmpaint_display_threeD_proc ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
		// exit(-1);
	}

	return result;
}

//
//
//
//
//
int waitfor_wmpaint_display_threeD_proc () {

	for( int i=0; i<2; i++ ) {
		printf("memorized_CurveLines=%d\r\n", memorized_CurveLines );
		if ( memorized_CurveLines == 1 ) return 1;
		Sleep (1000);
	}

}

// Qualified: 20190710
//
//
//
//
//
int aDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("Allocation of local lines: %d %d\r\n", line_num, CurveLines->numPS );
	// Allocation: 20190708
	if ( line_num == 0 ) {

		l_lines = (vLine**) malloc( sizeof(vLine*) * ( CurveLines->numPS + 1 )  );
		for( int i=0; i<CurveLines->numPS; i++ ) {
			// x vLine* allocation_line = (vLine*) malloc ( sizeof(vLine) * 1 );
			// x vLine* allocation_line = new vLine();
			l_lines[i] = (vLine*) new vLine();
		}
		line_num = CurveLines->numPS;

		printf( "Allocated: 0 \r\n" );
	} else if (  line_num <= CurveLines->numPS ) {

		l_lines = (vLine**) realloc( l_lines, sizeof(vLine*) * CurveLines->numPS );
		for( int i=line_num; i<CurveLines->numPS; i++ ) {
			l_lines[i] = new vLine();
		}
		line_num = CurveLines->numPS;
	}

	printf("local lines:\r\n");
	for( int i=0; i<line_num; i++ ) {
		printf("i: %d ", i );
		l_lines[i]->print();
		// l_lines[i]->p1->print();
		// l_lines[i]->p2->print();
	}

	printf("aDisplayControls_wmpaint_display_threeD_proc ends\r\n");
}

//
//
//
//
//
//
int bDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("bDisplayControls_wmpaint_display_threeD_proc: Loop starts.\r\n");
	for( int i=0; i<10; i++) {
		vLine* line = new vLine();
		line->print();
	}
	printf("bDisplayControls_wmpaint_display_threeD_proc: Loop ends.\r\n");
}

// Qualified: 
// Re-checked: 20210117 :
//
//
//
//
int dDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("Allocation of local lines: %d %d\r\n", line_num, CurveLines->numPS );

	l_lines = (vLine**) CurveLines->generateControlsLines();
	line_num = CurveLines->line_num;

	printf("008 line_num = %d \r\n", line_num);
	for ( int i=0; i<line_num && i<10; i++ ) {
		printf("i %d / %d loop starts, 011\r\n", i, line_num );
		l_lines[i] = (vLine*)to_screen_line(l_lines[i]);
		GamePaint_011( hDC, l_lines[i] );
		if ( l_lines!= nullptr && l_lines[i] != nullptr && l_lines[i]->p1 != nullptr && l_lines[i]->p2 != nullptr ) {
			printf("i: %3d / %3d is painted: %f %f -> %f %f\r\n", i, line_num, l_lines[i]->p1->x, l_lines[i]->p1->y, l_lines[i]->p2->x, l_lines[i]->p2->y );
		}
//		printf("i %d / %d loop ends. 011\r\n", i, line_num );
//		exit(-1);
	}

	printf("dDisplayControls_wmpaint_display_threeD_proc ends.\r\n");
	exit(-1);
}

//
//
//
//
//
int eDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static vLine** ll_lines = nullptr;
	float x1, y1, z1, x2, y2, z2, dx, dy, dz;

	printf("eDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");

	if ( l_lines == nullptr ) {
		l_lines = (vLine**) malloc( sizeof(vLine*) * 10  );
		ll_lines = (vLine**) malloc( sizeof(vLine*) * 10  );
	}

	if ( l_lines != nullptr && ll_lines != nullptr ) {
		x1 = -200.f;
		y1 = -200.f;
		z1 = -200.f;
		dx = 40.0f;
		dy = 30.0f;
		dz = 25.0f;

		for ( int i = 0; i< 10; i++ ) {
			x2 = x1;
			y2 = y1;
			z2 = z1;
			x1 += dx;
			y1 += dy;
			z1 += dz;
			l_lines[i] = (vLine*) new vLine ( memorizevPoint( x2, y2, z2 ), memorizevPoint( x1, y1, z1 ) );
			//ll_lines[i] = (vLine*)to_screen_line(l_lines[i]);
		}
	}

	for( int i=0; i<10; i++ ) {
		l_lines[i]->p1->print();
		l_lines[i]->p2->print();
		GamePaint_011( hDC, ll_lines[i] );
	}

	printf("eDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
}

//
//
//
//
//
int fDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine* lines = nullptr;
	static vLine* l_lines = nullptr;
	float x1, y1, z1, x2, y2, z2, dx, dy, dz;

	printf("fDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");

	lines = new vLine ();
	lines = (vLine*) new vLine ( memorizevPoint( 200.0f, 200.0f, 0.0f ), memorizevPoint( 300.0f, 300.0f, 0.0f ) );

	l_lines = (vLine*)to_screen_line( lines );

	GamePaint_011( hDC, l_lines );

	printf("GamePaint_011: llines: ");
	l_lines->print();
	//exit(-1);

	return 0;
	printf("fDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
}

//
//
//
//
//
int gDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	int flg_axes = 0;
	int flg_object = 0;

	printf("gDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");

	static int init_lines = 0;


	// ID: 001001012
	if ( lines == nullptr ) {
		lines = (vLine**) malloc ( sizeof ( vLine* ) * MAX_LINE );
	}
	if ( lines_2D == nullptr ) {
		lines_2D = (vLine**) malloc ( sizeof ( vLine* ) * MAX_LINE );
	}
	for( int i =0; i<MAX_LINE ; i++) {
		lines[i] = nullptr;
		lines_2D[i] = nullptr;
	}

	if ( init_lines == 0 ) {
		lines[0] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
		lines[1] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
		lines[2] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );
		init_lines = 1;

		// ID: 001001012
		line_index = 3;
		int a = create_model_lines( lines, &line_index, MAX_LINE );
		printf("line_index = %d\ returned from create_model_lines.\r\n", line_index);
	}

	int b = convert_model_lines( lines, lines_2D, 0, line_index );
	printf("line_index = %d\ returned from create_model_lines.\r\n", line_index);

	switch( display_mode ) {
	case 0:
		flg_axes = 0;
		flg_object = 0;
		break;
	case 1:
		flg_axes = 1;
		flg_object = 01;
		break;
	case 2:
		flg_axes = 0;
		flg_object = 1;
		break;
	case 3:
		flg_axes = 1;
		flg_object = 1;
		break;
	} 

	printf("flg_axes %d flg_object %d\r\n", flg_axes, flg_object);
	if ( flg_axes == 1 ) {
		// Display axes from 0 to 3
		for ( int i = 0; i<3; i++ ) {
			GamePaint_011( hDC, lines_2D[i] );
		}
	}

	if ( flg_object == 1 ) {
		printf("to line_index = %d\r\n", line_index);
		for ( int i = 3; i<line_index; i++ ) {
			if (lines_2D[i] != nullptr ) {
				GamePaint_011( hDC, lines_2D[i] );
				lines_2D[i]->print();
			}
		}
	}

	printf("gDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
	return 0;
}

//
//
//
//
//
int hDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	int flg_axes = 0;
	int flg_object = 0;

	printf("hDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");

	// ID: 001001012
	if ( lines == nullptr ) {
		lines = (vLine**) malloc ( sizeof ( vLine* ) * MAX_LINE );
	}
	if ( lines_2D == nullptr ) {
		lines_2D = (vLine**) malloc ( sizeof ( vLine* ) * MAX_LINE );
	}
	for( int i =0; i<MAX_LINE ; i++) {
		lines[i] = nullptr;
		lines_2D[i] = nullptr;
	}

	if ( init_lines == 0 ) {
//		lines[0] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
//		lines[1] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
//		lines[2] = (vLine*) new vLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );

		lines[0] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
		lines[1] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
		lines[2] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );

		init_lines = 1;

		// ID: 001001012
		line_index = 3;
		printf("01: line_index = %d\ returned from create_model_lines.\r\n", line_index);
		for ( int i=0; i<3; i++ ) {
			printf("init: lines[%d] |%p|\r\n", i, lines[i]);
		}
//		exit(-1);
	}

	// if we don't have the linw, the program doesn't work well.
	for ( int i=0; i<3; i++ ) {
		printf("lines[%d] |%p|\r\n", i, (vLine*)lines[i]);
		if ( lines[i] == 0 ) {
			int a = print_lines ();
			return -1;
		}
	}

	printf("02: line_index = %d lines |%p| lines2D |%p|\r\n", line_index, lines, lines_2D );
	int b = convert_model_lines( lines, lines_2D, 0, line_index );
	printf("03: line_index = %d lines |%p| lines2D |%p|\r\n", line_index, lines, lines_2D );

	// Display axes from 0 to 3
	for ( int i = 0; i<3; i++ ) {
		GamePaint_011( hDC, lines_2D[i] );
	}

	printf("hDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
	return 0;
}

//
//
//
//
//
int iDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	int flg_axes = 0;
	int flg_object = 0;

	printf("iDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");


	if ( init_lines == 0 ) {
		// ID: 001001012
		if ( lines == nullptr ) {
			lines = (vLine**) malloc ( sizeof ( vLine* ) * MAX_LINE );
		}
		if ( lines_2D == nullptr ) {
			lines_2D = (vLine**) malloc ( sizeof ( vLine* ) * MAX_LINE );
		}
		for( int i =0; i<MAX_LINE ; i++) {
			lines[i] = nullptr;
			lines_2D[i] = nullptr;
		}

		lines[0] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
		lines[1] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
		lines[2] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );

		init_lines = 1;

		// ID: 001001012
		line_index = 3;
		printf("01: line_index = %d\ returned from create_model_lines.\r\n", line_index);
		for ( int i=0; i<3; i++ ) {
			printf("init: lines[%d] |%p|\r\n", i, lines[i]);
		}
//		exit(-1);
	}

	// if we don't have the linw, the program doesn't work well.
	for ( int i=0; i<3; i++ ) {
		printf("lines[%d] |%p|\r\n", i, (vLine*)lines[i]);
		if ( lines[i] == 0 ) {
			int a = print_lines ();
			return -1;
		}
	}

	printf("02: line_index = %d lines |%p| lines2D |%p|\r\n", line_index, lines, lines_2D );
	int b = convert_model_lines( lines, lines_2D, 0, line_index );
	printf("03: line_index = %d lines |%p| lines2D |%p|\r\n", line_index, lines, lines_2D );

	// Display axes from 0 to 3
	for ( int i = 0; i<3; i++ ) {
		GamePaint_011( hDC, lines_2D[i] );
	}

	printf("iDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
	return 0;
}

//
int jDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	printf("jDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");
	int a = 0;
	float X = 0;
	float Y = 0;
	float R = 0;

	if ( vCircle_2D_001 == NULL ) {
		a = initialize_vCircle_2D_001 ();
	}

	for ( int i=0; i<30; i++ ) {
		X = vCircle_2D_001[i]->x;
		Y = vCircle_2D_001[i]->y;
		R = vCircle_2D_001[i]->r;
		a = Ellipse(hDC, X-R, Y+R, X+R, Y-R);
	}

	printf("jDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
}

/*** Very thanks to:
search circle:
1: https://docs.microsoft.com/en-us/windows/win32/learnwin32/draw-circle-sample
2: https://www.daniweb.com/programming/software-development/code/216344/draw-a-circle-on-a-windows-form
3: https://stackoverflow.com/questions/14063463/win32-gdi-drawing-a-circle

a = Ellipse(DrawHDC,X-R,Y+R,X+R,Y-R);
Ellipse(backbuffDC, temp_shape.left, temp_shape.top, temp_shape.right, temp_shape.bottom);


https://docs.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-ellipse
***/

//
int kDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	int a;
	printf("kDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");

	if (call_once_display_threeD_initialize == 0) {
		display_threeD_initialize();
		call_once_display_threeD_initialize = 1;
	}

	if ( AXEX_2D_001 == NULL ) {
		Set_vScreen ( screen );
		a = initialize_vAxex_2D_001();
	}

	// 90
	line_index = 90;
	printf("k-02: line_index = %d lines |%p| lines2D |%p|\r\n", line_index, lines, lines_2D );
	int b = convert_model_lines( Line_AXEX, lines_2D, 0, line_index );
	printf("k-03: line_index = %d lines |%p| lines2D |%p|\r\n", line_index, lines, lines_2D );

	// Display axes from 0 to 3
	for ( int i = 0; i<line_index; i++ ) {
		GamePaint_011( hDC, lines_2D[i] );
	}

	printf("kDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
}

int lDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	printf("lDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");
	int a = 0;
	float X = 0;
	float Y = 0;
	float R = 0;

	printf("jDisplayControls_wmpaint_display_threeD_proc: middle: 002\r\n");
	if ( AXEX_2D_001 == NULL ) {
		printf("lDisplayControls_wmpaint_display_threeD_proc: middle: 002-01\r\n");
		a = initialize_vAxex_2D_001 ();
		printf("lDisplayControls_wmpaint_display_threeD_proc: middle: 002-02\r\n");
	}

	printf("jDisplayControls_wmpaint_display_threeD_proc: middle: 003\r\n");
	printf("|%p|\r\n", AXEX_2D_001);
	for ( int i=0; i<30; i++ ) {
		printf("lDisplayControls_wmpaint_display_threeD_proc: middle: 004 %d AXEX_2D_001[i]=|%p|\r\n", i, i, AXEX_2D_001[i]);
		X = AXEX_2D_001[i]->x;
		Y = AXEX_2D_001[i]->y;
		R = AXEX_2D_001[i]->r;
		a = Ellipse(hDC, X-R, Y+R, X+R, Y-R);
	}

	printf("lDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
}


int mDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	printf("mDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");

	static int call_once_m = 0;
	int a = 0;
	float x1 = 0.0f, y1 = 0.0f, z1 = 0.0f;
	float x2 = 0.0f, y2 = 0.0f, z2 = 0.0f;

	if ( AXEX_2D_001 == NULL ) {
		printf("mDisplayControls_wmpaint_display_threeD_proc: middle: 002-01\r\n");
		a = initialize_vAxex_2D_002 ();
		printf("mDisplayControls_wmpaint_display_threeD_proc: middle: 002-02\r\n");
	}

	printf("mDisplayControls_wmpaint_display_threeD_proc: middle: 002-03-01.\r\n");
	line_index = 12;
	printf("lines |%p| \r\n", lines );
	if ( call_once_m == 0 ) {
		printf ("malloc: lines: |%p| |%p| ends.\r\n", lines, lines_2D );

		lines = (vLine**) realloc ( lines, sizeof (vLine*) * line_index );
		if ( lines == NULL ) {
			printf ("lines_2D |%p| \r\n" , lines);
			exit(-1);
		}

		lines_2D = (vLine**) realloc ( lines_2D, sizeof (vLine*) * line_index );
		if ( lines_2D == NULL ) {
			printf ("lines_2D |%p| \r\n" , lines_2D);
			exit(-1);
		}

		printf ("malloc: lines: |%p| |%p| ends.\r\n", lines, lines_2D );
		for ( int i = 0; i<line_index; i++ ) {
			printf("i %d lines|%p| i %d lines_2D|%p| nullptr=|%p|\r\n", i, lines[i], i, lines_2D[i], nullptr);
			if ( lines[i] != nullptr ) {
				lines[i] = memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 0.0f ) );
				m_thread_sleep ();
			}
			if ( lines_2D[i] != nullptr ) {
				lines_2D[i] = memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 0.0f ) );
				m_thread_sleep ();
			}
			printf("i %d lines|%p| i %d lines_2D|%p|\r\n", i, lines[i], i, lines_2D[i]);
			if ( lines[i] == nullptr && lines_2D[i] == nullptr ) {
				printf("We can't allocate for lines memories. they are NULL after allocation loop.\r\n" );
				exit(-1);
			}

			printf("i %d lines|%p| i %d lines_2D|%p|\r\n", i, lines[i], i, lines_2D[i]);
		}
		printf ("malloc: lines: |%p| |%p| has finished. \r\n", lines, lines_2D );
		call_once_m = 1;
	}
	printf("mDisplayControls_wmpaint_display_threeD_proc: middle: 002-03-02.\r\n");

	for ( int i = 3; i<line_index; i++ ) {

		printf("m-02-01: i %d line_index = %d lines[%d]=|%p|/ lines |%p| lines2D[%d] =|%p| / lines2D |%p| AXEX_2D_001[%d]=|%p|\r\n", i, line_index, i, lines[i], lines, i, lines_2D[i], lines_2D, (i - 3)  / 3, AXEX_2D_001[ (i - 3)  / 3 ] );
		// right arrow is different, we don't know that reason.
		x1 = AXEX_2D_001[ (i - 3)  / 3 ]->center->x;
		y1 = AXEX_2D_001[ (i - 3)  / 3 ]->center->y;
		z1 = AXEX_2D_001[ (i - 3)  / 3 ]->center->z;
		printf("m-02-01-01: i %d line_index = %d lines[%d]=|%p|/ lines |%p| lines2D[%d] =|%p| / lines2D |%p|\r\n", i, line_index, i, lines[i], lines, i, lines_2D[i], lines_2D );
		x2 = x1 + AXEX_2D_001[ (i - 3)  / 3 ]->right->x * 30.0f;
		y2 = y1 + AXEX_2D_001[ (i - 3)  / 3 ]->right->y * 30.0f;
		z2 = z1 + AXEX_2D_001[ (i - 3)  / 3 ]->right->z * 30.0f ;
		printf("m-02-01-02: i %d line_index = %d lines[%d]=|%p|/ lines |%p| lines2D[%d] =|%p| / lines2D |%p|\r\n", i, line_index, i, lines[i], lines, i, lines_2D[i], lines_2D );
		lines[i]->setLine (  x1, y1, z1, x2, y2, z2 ) ;
		lines_2D[i]->setLine ( 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f );
		printf("m-02-01-03: i %d line_index = %d lines[%d]=|%p|/ lines |%p| lines2D[%d] =|%p| / lines2D |%p|\r\n", i, line_index, i, lines[i], lines, i, lines_2D[i], lines_2D );
		i++;

		printf("m-02-02: i %d line_index = %d lines[%d]=|%p|/ lines |%p| lines2D[%d] =|%p| / lines2D |%p|\r\n", i, line_index, i, lines[i], lines, i, lines_2D[i], lines_2D );
		x1 = AXEX_2D_001[ (i - 3)  / 3 ]->center->x;
		y1 = AXEX_2D_001[ (i - 3)  / 3 ]->center->y;
		z1 = AXEX_2D_001[ (i - 3)  / 3 ]->center->z;
		x2 = x1 + AXEX_2D_001[ (i - 3)  / 3 ]->up->x * 30.0f;
		y2 = y1 + AXEX_2D_001[ (i - 3)  / 3 ]->up->y * 30.0f;
		z2 = z1 + AXEX_2D_001[ (i - 3)  / 3 ]->up->z * 30.0f;
		lines[i]->setLine (  x1, y1, z1, x2, y2, z2 ) ;
		lines_2D[i]->setLine ( 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f );
		printf("m-02-02: i %d line_index = %d lines[%d]=|%p|/ lines |%p| lines2D[%d] =|%p| / lines2D |%p|\r\n", i, line_index, i, lines[i], lines, i, lines_2D[i], lines_2D );
		i++;

		printf("m-02-03: i %d line_index = %d lines[%d]=|%p|/ lines |%p| lines2D[%d] =|%p| / lines2D |%p|\r\n", i, line_index, i, lines[i], lines, i, lines_2D[i], lines_2D );
		x1 = AXEX_2D_001[ (i - 3)  / 3 ]->center->x;
		y1 = AXEX_2D_001[ (i - 3)  / 3 ]->center->y;
		z1 = AXEX_2D_001[ (i - 3)  / 3 ]->center->z;
		x2 = x1 + AXEX_2D_001[ (i - 3)  / 3 ]->depth->x * 30.0f;
		y2 = y1 + AXEX_2D_001[ (i - 3)  / 3 ]->depth->y * 30.0f;
		z2 = z1 + AXEX_2D_001[ (i - 3)  / 3 ]->depth->z * 30.0f ;
		lines[i]->setLine (  x1, y1, z1, x2, y2, z2 ) ;
		lines_2D[i]->setLine ( 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f );
		printf("m-02-03: i %d line_index = %d lines[%d]=|%p|/ lines |%p| lines2D[%d] =|%p| / lines2D |%p|\r\n", i, line_index, i, lines[i], lines, i, lines_2D[i], lines_2D );
	}

	printf("m-02: line_index = %d lines |%p| lines2D |%p|\r\n", line_index, lines, lines_2D );
	int b = convert_model_lines( lines, lines_2D, 3, line_index );
	printf("m-03: line_index = %d lines |%p| lines2D |%p|\r\n", line_index, lines, lines_2D );

	// Display axes from 4 to 15
	for ( int i = 3; i<line_index; i++ ) {
		GamePaint_011( hDC, lines_2D[i] );
	}

	printf("mDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
}




int nDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	printf("nDisplayControls_wmpaint_display_threeD_proc: starts.\r\n");

	line_index = 12;
	// Display axes from 4 to 15
	for ( int i = 3; i<line_index; i++ ) {
		GamePaint_011( hDC, &lines_2D_001[i] );
	}

	printf("nDisplayControls_wmpaint_display_threeD_proc: ends.\r\n");
}


int create_vaxex_test () {
	int a;
	printf("create_vaxex_test () starts.\r\n");

	if (call_once_display_threeD_initialize == 0) {
		display_threeD_initialize();
		call_once_display_threeD_initialize = 1;
	}

	if ( AXEX_2D_001 == NULL ) {
		Set_vScreen ( screen );
		a = initialize_vAxex_2D_001();
	}

	printf("create_vaxex_test () ends.\r\n");
	return 0;
}

int convert_AXEX_2D () {
	printf("convert_AXEX_2D: starts.\r\n");

	static int call_once_m = 0;
	int a = 0;
	float x1 = 0.0f, y1 = 0.0f, z1 = 0.0f;
	float x2 = 0.0f, y2 = 0.0f, z2 = 0.0f;
	static vPoint center( 300.f, 10.0f, 10.0f );

	printf("int convert_AXEX_2D () starts.\r\n");

	if ( call_once_m == 0 ) {
		printf("convert_AXEX_2D: middle: 002-01\r\n");
		a = initialize_vAxex_2D_003 ();
		call_once_m = 1;
		printf("convert_AXEX_2D: middle: 002-02\r\n");
//		exit(-1);
	} else {
		printf("convert_AXEX_2D: middle: 002-02-01\r\n");
		a = Approach_vAxex_2D ( &center );
		printf("center:\r\n");
		center.print();
		printf("convert_AXEX_2D: middle: 002-02-01\r\n");
	}

	printf("convert_AXEX_2D: middle: 002-03-01 AXEX_2D_002|%p| lines_2D_001|%p| lines_001|%p|.\r\n", AXEX_2D_002, lines_2D_001, lines_001);
	line_index = 12;

	for ( int i = 3; i<line_index; i++ ) {

		printf("n-02-01: i %d line_index = %d lines_001[%d]=|%p|/ lines_001 |%p| lines_0012D[%d] =|%p| / lines_0012D |%p| AXEX_2D_002[%d]=|%p|\r\n", i, line_index, i, lines_001[i], lines_001, i, lines_2D_001[i], lines_2D_001, (i - 1)  / 3, AXEX_2D_002[ i - 3 ] );
		// right arrow is different, we don't know that reason.
		// x
		x1 = AXEX_2D_002[ i/3 - 1 ].center->x;
		y1 = AXEX_2D_002[ i/3 - 1 ].center->y;
		z1 = AXEX_2D_002[ i/3 - 1 ].center->z;
		printf("n-02-01-01: i %d line_index = %d lines_001[%d]=|%p|/ lines_001 |%p| lines_0012D[%d] =|%p| / lines_0012D |%p|\r\n", i, line_index, i, lines_001[i], lines_001, i, lines_2D_001[i], lines_2D_001 );
		x2 = x1 + AXEX_2D_002[ i/3 - 1 ].right->x * 30.0f;
		y2 = y1 + AXEX_2D_002[ i/3 - 1 ].right->y * 30.0f;
		z2 = z1 + AXEX_2D_002[ i/3 - 1 ].right->z * 30.0f;
		printf("n-02-01-02: i %d line_index = %d lines_001[%d]=|%p|/ lines_001 |%p| lines_0012D[%d] =|%p| / lines_0012D |%p|\r\n", i, line_index, i, lines_001[i], lines_001, i, lines_2D_001[i], lines_2D_001 );
		lines_001[i].setLine (  x1, y1, z1, x2, y2, z2 ) ;
		lines_2D_001[i].setLine ( 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f );
		printf("n-02-01-03: i %d line_index = %d lines_001[%d]=|%p|/ lines_001 |%p| lines_0012D[%d] =|%p| / lines_0012D |%p|\r\n", i, line_index, i, lines_001[i], lines_001, i, lines_2D_001[i], lines_2D_001 );
		i++;

		printf("nn-02-02: i %d line_index = %d lines_001[%d]=|%p|/ lines_001 |%p| lines_0012D[%d] =|%p| / lines_0012D |%p|\r\n", i, line_index, i, lines_001[i], lines_001, i, lines_2D_001[i], lines_2D_001 );
		x1 = AXEX_2D_002[ i/3 - 1 ].center->x;
		y1 = AXEX_2D_002[ i/3 - 1  ].center->y;
		z1 = AXEX_2D_002[ i/3 - 1  ].center->z;
		x2 = x1 + AXEX_2D_002[ i/3 - 1  ].up->x * 30.0f;
		y2 = y1 + AXEX_2D_002[ i/3 - 1  ].up->y * 30.0f;
		z2 = z1 + AXEX_2D_002[ i/3 - 1  ].up->z * 30.0f;
		lines_001[i].setLine (  x1, y1, z1, x2, y2, z2 ) ;
		lines_2D_001[i].setLine ( 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f );
		printf("nn-02-02: i %d line_index = %d lines_001[%d]=|%p|/ lines_001 |%p| lines_0012D[%d] =|%p| / lines_0012D |%p|\r\n", i, line_index, i, lines_001[i], lines_001, i, lines_2D_001[i], lines_2D_001 );
		i++;

		printf("n-02-03: i %d line_index = %d lines_001[%d]=|%p|/ lines_001 |%p| lines_0012D[%d] =|%p| / lines_0012D |%p|\r\n", i, line_index, i, lines_001[i], lines_001, i, lines_2D_001[i], lines_2D_001 );
		x1 = AXEX_2D_002[ i/3 - 1  ].center->x;
		y1 = AXEX_2D_002[ i/3 - 1  ].center->y;
		z1 = AXEX_2D_002[ i/3 - 1  ].center->z;
		x2 = x1 + AXEX_2D_002[ i/3 - 1  ].depth->x * 30.0f;
		y2 = y1 + AXEX_2D_002[ i/3 - 1  ].depth->y * 30.0f;
		z2 = z1 + AXEX_2D_002[ i/3 - 1  ].depth->z * 30.0f ;
		lines_001[i].setLine (  x1, y1, z1, x2, y2, z2 ) ;
		lines_2D_001[i].setLine ( 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f );
		printf("n-02-03: i %d line_index = %d lines_001[%d]=|%p|/ lines_001 |%p| lines_0012D[%d] =|%p| / lines_0012D |%p|\r\n", i, line_index, i, lines_001[i], lines_001, i, lines_2D_001[i], lines_2D_001 );
	}

	int b = convert_model_lines_002( lines_001, lines_2D_001, 3, line_index ) ;
	int c = check_lines_002( lines_001, lines_2D_001, 3, line_index ) ;

	printf("convert_AXEX_2D: ends.\r\n");
	return 0;
}



//
//
//
//
//
int create_model_lines( vLine **lines, int *line_index, int max_num ) {
	int i, j;
	vCalculation calc;
	printf("int create_model_lines( vLine **lines, int *line_index, int max_num ) starts. *line_index=%d\r\n", *line_index);

	vPoint* o = memorizevPoint( 0.0f, 0.0f, 0.0f) ;
	vPoint* p = memorizevPoint( 0.0f, 0.0f, 0.0f) ;
	vPoint* a = memorizevPoint ( 50.0f, 10.0f, 45.0f );
	vPoint* up = memorizevPoint ( 0.0f, 1.0f, 0.0f );
	vPoint* right = memorizevPoint ( 1.0f, 0.0f, 0.0f );

	vPoint*** grid = (vPoint***) malloc (sizeof (vPoint**)* 5 );

	for( i = 0; i<5; i++ ) {
		grid[i] = (vPoint**) malloc (sizeof (vPoint*)* 5 );
	}

	calc.cross ( up, a, right );
	printf("a is going to print:\r\n");
	a->print();
	printf("right of a is going to print:\r\n");
	right->print();
//	exit(-1);

	for( i = 0; i<5; i++ ) {
		for( j = 0; j<5; j++ ) {
			printf("additional p calculation is going to print: i, j = %d , %d \r\n", i, j);
			//if ( i == 0 && j == 0 ) p = calc.add( o, p ); // dummy
			grid[i][j] = (vPoint*) p;
			grid[i][j]->print();
			p = calc.add( p, a);
		}
		printf("additional p calculation is going to print: i, j = %d , %d \r\n", i, j);
		p->print();
		p = calc.add( o, calc.scalize ( right, (float) i + 1 ) ); //20210324
		//if ( i == 1 ) exit(-1); //debug
	}

	for( i = 0; i<5; i++ ) {
		for( j = 0; j<5; j++ ) {
			printf("grid: i, j = %d , %d \r\n", i, j);
			grid[i][j]->print();
		}
	}

	// exit(-1); // well

	calc.Print_Point_Memories ();
//	vCalculation::Print_Point_Memories ();
	printf("*line_index=%d\r\n", *line_index );
//	exit(-1);

	for ( i=0; i< 4; i++ ) {
		for ( j=0; j< 4; j++ ) {
			printf(" i , j = %d, %d line_index %d \r\n", i, j , *line_index );
			lines[(*line_index)] = memorizevLine ( grid[i][j], grid[i+1][j]);
			lines[(*line_index)]->print();
			++(*line_index);
			lines[(*line_index)] = memorizevLine ( grid[i][j], grid[i][j+1]);
			lines[(*line_index)]->print();
			++(*line_index);
		}
	}

	calc.Print_Point_Memories ();
	//exit(-1);

	printf("last line, we are going to draw.\r\n");
	// last lines
	for ( j=0; j< 4; j++ ) {
		printf( "j = %d \r\n", j ); 
		lines[*line_index] = memorizevLine ( grid[4][j], grid[4][j+1]);
		lines[*line_index]->print();
		++(*line_index);
	}
	for ( i=0; i< 4; i++ ) {
		printf( "i = %d \r\n", i ); 
		lines[*line_index] = memorizevLine ( grid[i][4], grid[i + 1][4]);
		lines[*line_index]->print();
		++(*line_index);
	}

	//Debug 
	//lines[*line_index] = new vLine ( memorizevPoint(-50.0f, -30.0f, -45.0f), memorizevPoint( 30.0f, 10.0f, 35.0f) );
	//*line_index++;

	printf("int create_model_lines( vLine **lines, int *line_index, int max_num ) ends. *line_index=%d\r\n", *line_index);
	return 1;
}


//
int create_model_lines_001( vLine **lines, int *line_index, int max_num ) {
	int a;

	if ( CurveLines == nullptr ) {
		a = create_curve_lines ( 12 );
	}

	return 1;
}

//
int create_curve_lines ( int num ) {
	if ( CurveLines == nullptr ) {
		CurveLines = (vPointLinear*) malloc ( sizeof (vPointLinear) );
	}

	// Array of vPointStructure
	if ( CurveLines->aPS == nullptr ) {
		CurveLines->aPS = (vPointStructure**) malloc ( sizeof (vPointStructure*) * num );
		for ( int i=0; i<num; i++ ) {
			CurveLines->aPS[i] = new vPointStructure();
		}
	}

	return 1;
}

//
//
//
//
//
int convert_model_lines( vLine **lines, vLine **lines_2D, int line_index, int max_num ) {

	printf("int convert_model_lines( vLine **lines, vLine **lines_2D, int *line_index, int max_num ) starts.\r\n");
	printf("02-01: line_index = %d\ max_num %d lines |%p| lines2D |%p|\r\n", line_index, max_num, lines, lines_2D );

	// convertion
	for ( int i = line_index; i<max_num; i++ ) {
		//debug 20210311
//		if ( i == 2 ) {
//			printf("lines[%d]\r\n", i);
//			exit(-1);
//		}

		if ( lines != nullptr && lines[i] != nullptr && lines_2D != nullptr ) {
			if ( lines_2D[i] == nullptr ) {
				lines_2D[i] = (vLine*) to_screen_line ( lines[i] ) ;
			} else {
				int a =  to_screen_line_set ( lines[i], lines_2D[i] ) ;
			}
			if ( i == 4 ) {
				printf("i=4 after axes convertion is going to print:\r\n");
				lines[i]->print();
				lines_2D[i]->print();
				//exit(-1);
			}
		} else {
			printf("lines[%d] is not recognised \r\n", i);
			printf("lines[%d] |%p| \r\n", i, lines[i] );
			printf("lines_2D[%d] |%p| nullptr = |%p|\r\n", i, lines_2D[i], nullptr );
			exit(-1);
		}
	}

	printf("02-02: line_index = %d\ max_num %d lines |%p| lines2D |%p|\r\n", line_index, max_num, lines, lines_2D );
	printf("int convert_model_lines( vLine **lines, vLine **lines_2D, int *line_index, int max_num ) ends. from %d to %d \r\n", line_index, max_num );
	return 1;
}

//
int convert_model_lines_002( vLine *lines, vLine *lines_2D, int l_line_index, int max_num ) {

	printf("int convert_model_lines( vLine **lines, vLine **lines_2D, int *line_index, int max_num ) starts.\r\n");
//	printf("02-01: line_index = %d\ max_num %d lines |%p| lines2D |%p|\r\n", line_index, max_num, lines, lines_2D );

	// convertion
	for ( int i = l_line_index; i<max_num; i++ ) {
		int a =  to_screen_line_set ( &lines[i], &lines_2D[i] ) ;

	}

//	printf("02-02: line_index = %d\ max_num %d lines |%p| lines2D |%p|\r\n", line_index, max_num, lines, lines_2D );
	printf("int convert_model_lines( vLine **lines, vLine **lines_2D, int *line_index, int max_num ) ends. from %d to %d \r\n", line_index, max_num );
	return 1;
}

//
int check_lines_002 ( vLine *l_lines, vLine *l_lines_2D, int l_line_index, int max_num ) {
	vCalculation calc;
	vPoint vp;
	printf("int convert_model_lines( vLine **l_lines, vLine **l_lines_2D, int *line_index, int max_num ) starts.\r\n");

	// convertion
	for ( int i = l_line_index; i<max_num; i++ ) {
		int a = calc.subtract( (vPoint*)l_lines_2D[i].p1, (vPoint*)l_lines_2D[i].p2, &vp );
		if ( calc.length( &vp) > 30.0 ) {
			l_lines_2D[i].p1->print();
			printf(" is more 30.0f index in l_lines_2D %d.\r\n", i );
			exit(-1);
		}
		a = calc.subtract( (vPoint*)l_lines[i].p1, (vPoint*)l_lines[i].p2, &vp );
		if ( calc.length( &vp) > 30.0 ) {
			l_lines[i].p1->print();
			printf(" is more 30.0f index in l_lines %d.\r\n", i );
			exit(-1);
		}
	}

	printf("int convert_model_l_lines( vLine **l_lines, vLine **l_lines_2D, int *line_index, int max_num ) ends. from %d to %d \r\n", line_index, max_num );
	return 1;
}


// Qualified: 20190711
//
//
//
//
//
int cDisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("Allocation of local lines: %d %d\r\n", line_num, CurveLines->numPS );
	// Allocation: 20190708
	if ( line_num == 0 ) {

		l_lines = (vLine**) malloc( sizeof(vLine*) * ( CurveLines->numPS + 1 )  );
		for( int i=0; i<CurveLines->numPS; i++ ) {
			// x vLine* allocation_line = (vLine*) malloc ( sizeof(vLine) * 1 );
			// x vLine* allocation_line = new vLine();
			l_lines[i] = (vLine*) new vLine();
		}
		line_num = CurveLines->numPS;

		printf( "Allocated: 0 \r\n" );
	} else if (  line_num <= CurveLines->numPS ) {

		l_lines = (vLine**) realloc( l_lines, sizeof(vLine*) * CurveLines->numPS );
		for( int i=line_num; i<CurveLines->numPS; i++ ) {
			l_lines[i] = new vLine();
		}
		line_num = CurveLines->numPS;
	}

	printf("local lines:\r\n");
	for( int i=0; i<line_num; i++ ) {
		printf("i: %d ", i );
		l_lines[i]->setLine( (vPoint*) CurveLines->aPS[i]->C1, (vPoint*) CurveLines->aPS[i]->C2 );
		l_lines[i]->print();
		// l_lines[i]->p1->print();
		// l_lines[i]->p2->print();
	}

	printf("cDisplayControls_wmpaint_display_threeD_proc ends.\r\n");
}

//
//
//
//
//
//
int DisplayControls_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static char num_str[2048];
	static vLine** l_lines = nullptr;
	static int line_num = 0;

	if ( memorized_CurveLines == 0 ) return -1;
	// if ( l_lines != nullptr ) return 2;

	printf("Allocation of local lines: %d %d\r\n", line_num, CurveLines->numPS );
	// Allocation: 20190708
	if ( line_num == 0 ) {

		l_lines = (vLine**) malloc( sizeof(vLine*) * ( CurveLines->numPS + 1 )  );
		for( int i=0; i<CurveLines->numPS; i++ ) {
			vLine* allocation_line = (vLine*) malloc ( sizeof(vLine) * 1 );
			// x vLine* allocation_line = new vLine();
			// x l_lines[i] = (vLine*) new vLine();
		}
		line_num = CurveLines->numPS;

		printf( "Allocated: 0 \r\n" );
	} else if (  line_num <= CurveLines->numPS ) {

		l_lines = (vLine**) realloc( l_lines, sizeof(vLine*) * CurveLines->numPS );
		for( int i=line_num; i<CurveLines->numPS; i++ ) {
			l_lines[i] = new vLine();
		}
		line_num = CurveLines->numPS;
	}

	printf("create_lines:\r\n");
	create_lines ( (vPointLinear*)CurveLines, l_lines, CurveLines->numPS );

	printf("local lines:\r\n");
	for( int i=0; i<CurveLines->numPS; i++ ) {
		l_lines[i]->p1->print();
		l_lines[i]->p2->print();
		GamePaint_011( hDC, l_lines[i] );
	}

	exit(-1);
}

//
//
//
//
//
//
int NormalFaces_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static char num_str[2048];
	static vLine** l_lines = nullptr;

	if ( memorized_CurveLines == 0 ) return -1;
	if ( l_lines != nullptr ) return 2;

	l_lines = (vLine**) malloc( sizeof(vLine*) * CurveLines->numPS );
	for( int i=0; i<CurveLines->numPS; i++ ) {
		l_lines[i] = new vLine();
	}
	create_lines( (vPointLinear*)CurveLines, l_lines, CurveLines->numPS );
	//exit( -1 );

	for( int i=0; i<CurveLines->numPS; i++ ) {
		l_lines[i]->p1->print();
		l_lines[i]->p2->print();
		GamePaint_011( hDC, l_lines[i] );
	}

	//exit(-1);
}

//
//
//
//
//
void create_lines( vPointLinear* curveLines, vLine** l_lines, int num ) {
	static int line_num = 0;
	line_num = num;

	printf( "create_lines: START:\r\n" );
	vCalculation* calc = new vCalculation ();
	for( int i=0; i<num; i++ ) {
		printf ( "normal_faces i %d / %d: ", i, num );
		if ( curveLines->aPS[i]->Anchor == nullptr ) exit(-1);
		if ( curveLines->normal_faces[i] == nullptr ) exit(-1);

		//curveLines->normal_faces[i]->print();
		vPoint* p3 = new vPoint();
		calc->add( curveLines->aPS[i]->Anchor, (vPoint*)curveLines->normal_faces[i], p3 );
		p3->print();
		curveLines->aPS[i]->Anchor->print();
		l_lines[i]->setLine( (vPoint*)curveLines->aPS[i]->Anchor, p3 );
	}
	printf( "create_lines: END:\r\n" );
}


//
//
//
//
//
vLine* to_screen_line( vLine* ll ) {
	float fx[3], fy[3];

	printf("vLine* to_screen_line( vLine* ll ) starts.\r\n");

	vLine* l_ll = (vLine*) memorizevLine ( memorizevPoint ( ll->p1->x, ll->p1->y, ll->p1->z ), memorizevPoint ( ll->p2->x, ll->p2->y, ll->p2->z ) );

	get_cooordinate_on_screen ( *(l_ll->p1), &fx[0], &fy[0] );
	l_ll->p1->x = fx[0];
	l_ll->p1->y = fy[0];
	get_cooordinate_on_screen ( *(l_ll->p2), &fx[0], &fy[0] );
	l_ll->p2->x = fx[0];
	l_ll->p2->y = fy[0];

	printf("vLine* to_screen_line( vLine* ll ) ends.\r\n");

	return l_ll;
}

//
int to_screen_line_set( vLine* ll, vLine* result ) {
	float fx[3], fy[3];

	printf("int to_screen_line_set( vLine* ll, vLine* result ) starts.\r\n");

	if ( result == nullptr ) {
		printf("result is not memorized already.\r\n");
		result = (vLine*) memorizevLine ( memorizevPoint ( ll->p1->x, ll->p1->y, ll->p1->z ), memorizevPoint ( ll->p2->x, ll->p2->y, ll->p2->z ) );
		printf("result is not memorize.");
	} else {
		printf("result is memorized already, so that we could copy value ll-set  to result.\r\n");
		if ( result->p1 == nullptr ) {
			printf("result->p1 is nullptr.\r\n");
			exit(-1);
		}
		result->print();
		result->p1->setPoint( ll->p1->x, ll->p1->y, ll->p1->z  );
		result->p2->setPoint( ll->p2->x, ll->p2->y, ll->p2->z  );
		result->print();
	}

	get_cooordinate_on_screen ( *(result->p1), &fx[0], &fy[0] );
	result->p1->x = fx[0];
	result->p1->y = fy[0];
	get_cooordinate_on_screen ( *(result->p2), &fx[0], &fy[0] );
	result->p2->x = fx[0];
	result->p2->y = fy[0];

	printf("int to_screen_line_set( vLine* ll, vLine* result ) ends.\r\n");

	return 0;
}

//
//
//
//
//
//
int CurveLines_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	static vLine** l_lines = nullptr;
	static vLine* l = nullptr;

	if ( memorized_CurveLines == 0 ) return -1;

	printf("CurveLines->numPS=%d\r\n", CurveLines->numPS);

	l_lines = (vLine**) malloc( sizeof(vLine*) * CurveLines->numPS );
	for ( int i=0; i<CurveLines->numPS; i++ ) {
		printf("vLine:%d %d\r\n", i, l_lines[i] );
		l = new vLine(); // <- we can' do the left.
		Sleep(1000);
		printf("vLine allocation:%d %d\r\n", i, l );
		l_lines[i] = l;
	}
	printf("create_CurveLines: %d starts\r\n", CurveLines->numPS );
	create_CurveLines ( l_lines, CurveLines->numPS );
	printf("create_CurveLines: %d ends\r\n", CurveLines->numPS );
	//exit(-1);

	for( int i=0; i<CurveLines->numPS; i++ ) {
		GamePaint_011( hDC, l_lines[i] );
	}

}

//
//
//
//
//
//
int CurveLines_wmpaint_display_threeD_proc_org ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	float fx[3], fy[3];
	static vLine** l_lines = nullptr;
	static char num_str[2048];

	if ( memorized_CurveLines == 0 ) return -1;

	if ( l_lines != nullptr ) return 2; // return 2: means doesn't need to convert models.

	l_lines = (vLine**) malloc( sizeof(vLine*) * 6 );

	get_cooordinate_on_screen ( *(CurveLines->aPS[0]->Anchor), &fx[0], &fy[0] );

	// Allocation vLine which has vPoint p1 and p2.
	l_lines[ 0 ]->p1->x = fx[0];
	l_lines[ 0 ]->p1->y = fy[0];
	l_lines[ 0 ]->c1 = copyof("A0");

	for( int i=1; i<6; i++ ) {
		get_cooordinate_on_screen ( *(CurveLines->aPS[i]->Anchor), &fx[0], &fy[0] );
		l_lines[ i - 1 ]->p2->x = fx[0];
		l_lines[ i - 1 ]->p2->y = fy[0];
		l_lines[ i ]->p1->x = fx[0];
		l_lines[ i ]->p1->y = fy[0];
		l_lines[ i ]->c1 = copyof( m_concat( copyof("A"), itoa( i, num_str, 10 ) ) );
	}

	get_cooordinate_on_screen ( *(CurveLines->aPS[ 5 ]->Anchor), &fx[0], &fy[0] );
	l_lines[ 5 ]->p2->x = fx[0];
	l_lines[ 5 ]->p2->y = fy[0];
	l_lines[ 5 ]->c1 = copyof("A6");

	for( int i=0; i<6; i++ ) {
		GamePaint_011( hDC, l_lines[i] );
	}

}

//
//
//
//
//
int create_CurveLines( vLine** l_lines, int line_num ) {
	static float fx[3], fy[3];
	static char num_str[2048];

	if ( line_num == 0 ) return 0;

	if ( l_lines == nullptr ) {
		l_lines = (vLine**) malloc( sizeof(vLine*) * line_num );
	}
	get_cooordinate_on_screen ( *(CurveLines->aPS[0]->Anchor), &fx[0], &fy[0] );



	// Quallified here at 20190628.
	// Allocation vLine which has vPoint p1 and p2.
	l_lines[0] = new vLine();
	l_lines[ 0 ]->p1->x = fx[0];
	l_lines[ 0 ]->p1->y = fy[0];
	l_lines[ 0 ]->c1 = copyof("A0");

	printf("003\r\n");

	for( int i=1; i<line_num; i++ ) {
		get_cooordinate_on_screen ( *(CurveLines->aPS[i]->Anchor), &fx[0], &fy[0] );
		l_lines[ i - 1 ]->p2->x = fx[0];
		l_lines[ i - 1 ]->p2->y = fy[0];
		l_lines[ i ] = new vLine();
		l_lines[ i ]->p1->x = fx[0];
		l_lines[ i ]->p1->y = fy[0];
		l_lines[ i ]->c1 = copyof( m_concat( copyof("A"), itoa( i, num_str, 10 ) ) );
	}

	get_cooordinate_on_screen ( *(CurveLines->aPS[ line_num - 1 ]->Anchor), &fx[0], &fy[0] );
	l_lines[ line_num - 1 ]->p2->x = fx[0];
	l_lines[ line_num - 1 ]->p2->y = fy[0];
	l_lines[ line_num - 1 ]->c1 = copyof("A6");

	return 1;
}


//
// lines            :
// lines_2D         :
// lines_patches_2D :
// lines_patches    :
//
int F011_wmpaint_display_threeD_proc ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	float lx, ly;
	float fx[3], fy[3];
	POINT points[3];
	vCalculation l_calc;

	if ( display_3d == 0 ) return -1;

//	vLine* v3d_line = l_calc.Lines_from_Mesh( vertexes, patch_num, num_patches, base_num_patches );
	// Print Global Vertexesx
	Print_Global_Vertexes ( vertexes, patch_num, num_patches, base_num_patches );

	printf("atri.p1=");
	atri.p1.print();
	printf("atri.p2=");
	atri.p2.print();
	printf("atri.p3=");
	atri.p3.print();

	printf("screen C=");
	screen->C.print();

	get_cooordinate_on_screen ( atri.p1, &fx[0], &fy[0] );
	lines_patches_2D[0]->p1->x = fx[0];
	lines_patches_2D[0]->p1->y = fy[0];
	lines_patches_2D[2]->p2->x = fx[0];
	lines_patches_2D[2]->p2->y = fy[0];

	get_cooordinate_on_screen ( atri.p2, &fx[1], &fy[1] );
	lines_patches_2D[0]->p2->x = fx[1];
	lines_patches_2D[0]->p2->y = fy[1];
	lines_patches_2D[1]->p1->x = fx[1];
	lines_patches_2D[1]->p1->y = fy[1];

	get_cooordinate_on_screen ( atri.p3, &fx[2], &fy[2] );
	lines_patches_2D[1]->p2->x = fx[2];
	lines_patches_2D[1]->p2->y = fy[2];
	lines_patches_2D[2]->p1->x = fx[2];
	lines_patches_2D[2]->p1->y = fy[2];

	GamePaint_011( hDC, lines_patches_2D[0] );
	GamePaint_011( hDC, lines_patches_2D[1] );
	GamePaint_011( hDC, lines_patches_2D[2] );

	get_cooordinate_on_screen ( atri.p3, &fx[0], &fy[0] );
	lines_2D[0]->p1->x = fx[0];
	lines_2D[0]->p1->y = fy[0];
	lines_2D[1]->p1->x = fx[1];
	lines_2D[1]->p1->y = fy[1];
	lines_2D[2]->p1->x = fx[2];
	lines_2D[2]->p1->y = fy[2];
	lines_2D[0]->p2->x = fx[0];
	lines_2D[0]->p2->y = fy[0];
	lines_2D[1]->p2->x = fx[1];
	lines_2D[1]->p2->y = fy[1];
	lines_2D[2]->p2->x = fx[2];
	lines_2D[2]->p2->y = fy[2];

	GamePaint_011( hDC, lines_2D[0] );
	GamePaint_011( hDC, lines_2D[1] );
	GamePaint_011( hDC, lines_2D[2] );

	GamePaint_011( hDC, lines[0] );
	GamePaint_011( hDC, lines[1] );
	GamePaint_011( hDC, lines[2] );

	// vLine** v3d_line = l_calc.Lines_from_Mesh( vertexes, patch_num, num_patches, base_num_patches );
	// vLine* v2d_line = (vLine*) to_screen( v3d_line,  num_patches*base_num_patches );
	// GamePaint_009( hDC, v2d_line );

	return 0;
}





//
//
//
//
//
vLine* to_screen( vLine** v3d_line, int num ) {
	vLine* v2d_line = nullptr;
	vLine a;
	int b[3];
	vLine l[3];
	float x, y;

//	int num = sizeof(v3d_line) / sizeof( vLine ) ;
	a.p1 = new vPoint( 0.0f, 0.0f, 0.0f );

	v2d_line = (vLine*) malloc( sizeof(vLine) * num );
	for( int i=0; i<num; i++ ) {
		vLine* line = ( v2d_line + i ) ;
		line->p1 = new vPoint();
		line->p2 = new vPoint();
	}


	//printf("b=%d int size = %d\r\n", sizeof(b), sizeof(int) );
	//printf("l=%d vLine size = %d\r\n", sizeof(l), sizeof(vLine) );
	//printf("v2d_line=%d vLine size = %d conunt array %d\r\n", sizeof(v2d_line), sizeof(vLine), count_screen((char*)(&l[0])) );

//	printf("num=%d %d %d / %d sizeof a vLine %d &vLine %d\r\n", num, sizeof( v3d_line ), sizeof( *v3d_line ), sizeof( vLine ), sizeof(a), sizeof(&a) );

	printf("set of to_screen.\r\n");

	for ( int i=0; i<num; i++ ) {
		vLine* l1 = *( v3d_line + i );
		vLine* l2 = ( v2d_line + i );

		printf(" %d / %d \r\n", i, num );

		vPoint* p1 = l1->p1;
		vPoint* p2 = l1->p2;

		vPoint* d2_p1 = l2->p1;
		vPoint* d2_p2 = l2->p2;

		get_cooordinate_on_screen ( *(a.p1), &x, &y );

		// exit(-1);
		p1->print();

//		get_cooordinate_on_screen ( *(p1), &x, &y );
//		get_cooordinate_on_screen ( *p1, &( d2_p2->x ), &( d2_p2->y ) );
//		get_cooordinate_on_screen ( *(l1->p2), &(l2->p2->x), &(l2->p2->y) );

		// the below parts are all error.
//		get_cooordinate_on_screen ( *(l1->p1), &(l1->p1->x), &(l1->p1->y) );
//		get_cooordinate_on_screen ( *(l1->p2), &(l1->p2->x), &(l1->p2->y) );
//		get_cooordinate_on_screen ( *(l2->p1), &(l2->p1->x), &(l2->p1->y) );
//		get_cooordinate_on_screen ( *(l2->p2), &(l2->p2->x), &(l2->p2->y) );
	}

	printf("end of to_screen.\r\n");
	// exit(-1);

	return v2d_line;
}

//
//
//
//
//
int count_screen( char* pchar_vline ) {

	int result = 0;
	for( int i=0; i=256*256; i++ ) {
		result++;
		char* c = pchar_vline++;
		if ( *c == '\0' ) break;
	}

	return result;
}

// Very Thanks to: http://www.informit.com/articles/article.aspx?p=328647&seqNum=3
// int FillRect(HDC hDC, CONST RECT *lprc, HBRUSH hbr);
// BOOL Rectangle(HDC hDC, int xLeft, int yTop, int xRight, int yBottom);
// BOOL MoveToEx(HDC hDC, int x, int y, LPPOINT pt);
// BOOL LineTo(HDC hDC, int x, int y);
// BOOL TextOut(HDC hDC, int x, int y, LPCTSTR szString, int iLength);
// HPEN CreatePen(int iPenStyle, int iWidth, COLORREF crColor);
// HPEN hBluePen = CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
// HBRUSH hPurpleBrush = CreateSolidBrush(RGB(255, 0, 255));
// HPEN hPen = SelectObject(hDC, hBluePen);
// SelectObject(hDC, hPen);
// DeleteObject(hBluePen);
// HBRUSH hBrush = SelectObject(hDC, hPurpleBrush);
//  // *** Do some drawing here! ***
//  SelectObject(hDC, hBrush);
//  DeleteObject(hPurpleBrush);

// case WM_PAINT:
//  HDC     hDC;
//  PAINTSTRUCT ps;
//  hDC = BeginPaint(hWindow, &ps);

//  // Paint the game
//  GamePaint(hDC);
//
// EndPaint(hWindow, &ps);
// return 0;
//
//
//
//

//
//
//
//
//
void GamePaint_000(HDC hDC)
{
	MoveToEx(hDC, 0, 0, NULL);
	LineTo(hDC, 50, 50);
}

void GamePaint_001(HDC hDC)
{
	TextOut(hDC, 10, 10, TEXT("Michael Morrison"), 16);
}

void GamePaint_002(HDC hDC)
{
	RECT rect;
	GetClientRect(hWindow, &rect);
	DrawText(hDC, TEXT("Michael Morrison"), -1, &rect,
	DT_SINGLELINE | DT_CENTER | DT_VCENTER);
}

void GamePaint_003(HDC hDC)
{
	MoveToEx(hDC, 10, 40, NULL);
	LineTo(hDC, 44, 10);
	LineTo(hDC, 78, 40);
}

void GamePaint_004(HDC hDC)
{
	Rectangle(hDC, 16, 36, 72, 70);
	Rectangle(hDC, 34, 50, 54, 70);
}

void GamePaint_005(HDC hDC)
{
	Ellipse(hDC, 40, 55, 48, 65);
}

void GamePaint_006(HDC hDC)
{
	POINT points[3];
	points[0] = { 305, 10 };
	points[1] = { 355, 50 };
	points[2] = { 325, 55 };
	Polygon( hDC, points, 3 );
}

void GamePaint_007(HDC hDC) {
	RECT msg_clip;

	SetRect ( &msg_clip, 300, 0, 400, 50);
//	DrawText( hdc, TEXT( m_pastestr ), -1, &msg_clip, DT_NOCLIP);
	DrawText( hDC, TEXT( "GamePaint_007" ), -1, &msg_clip, DT_NOCLIP);
}

// 3 points :triangle
void GamePaint_008(HDC hDC, POINT* points)
{
	POINT p = points[0];
	printf("point 1: %ld %ld\r\n", p.x, p.y );
	Polygon( hDC, points, 3 );
}

void GamePaint_009(HDC hDC, vLine* line )
{
	vPoint *p1, *p2;
	p1 = line->p1;
	p2 = line->p2;

	printf("GamePaint_009: line : %f %f - %f %f\r\n", p1->x, p1->y, p2->x, p2->y );
//	printf("GamePaint_009: line : %f %f - %f %f\r\n", line->p1->x, line->p1->y, line->p2->x, line->p2->y );
	MoveToEx(hDC, (int)line->p1->x, (int)line->p1->y, NULL);
	LineTo(hDC, (int)(line->p2)->x, (int)(line->p2)->y );
}

//
//
//
// vPoint
//
void GamePaint_010(HDC hDC, vPoint* point ) {

	MoveToEx(hDC, (int)point->x, (int)point->y, NULL);
	LineTo(hDC, (int)point->x, (int)point->y );
}



// customized from GamePaint_009
//
//
//
//
void GamePaint_011(HDC hDC, vLine* line ) {

	int scale_2 = 30;
	static RECT rect_2, rect;

	printf("void GamePaint_011(HDC hDC, vLine* line ) starts.\r\n");

	if ( line == nullptr ) {
		printf("line is nullptr.\r\n ");
		exit(-1);
	} else if (line->p1 == nullptr ) {
		printf("line-p1 is nullptr.\r\n ");
		exit(-1);
	} else if (line->p2 == nullptr ) {
		printf("line-p2 is nullptr.\r\n ");
		exit(-1);
	}

	printf("Draw Line API starts.\r\n");
	MoveToEx(hDC, (int)line->p1->x, (int)line->p1->y, NULL);
	LineTo(hDC, (int)(line->p2)->x, (int)(line->p2)->y );
	printf("Draw Line API ends.\r\n");

	printf("Draw Text API starts.\r\n");
	if ( line->c1 != nullptr ) {
		printf("line->c1 |%p|\r\n", line->c1);
		SetRect( &rect, (int)line->p1->x - scale_2, (int)line->p1->y - scale_2, (int)line->p1->x + scale_2, (int)line->p1->y + scale_2 );
		//DrawText( hDC, TEXT( line->c1 ), -1, &rect, DT_NOCLIP );
	}

	if ( line->c2 != nullptr ) {
		printf("line->c2 |%p|\r\n", line->c2);
		SetRect( &rect_2, (int)line->p2->x - scale_2, (int)line->p2->y - scale_2, (int)line->p2->x + scale_2, (int)line->p2->y + scale_2 );
		//DrawText( hDC, TEXT( line->c2 ), -1, &rect_2, DT_NOCLIP );
	}
	printf("Draw Text API ends.\r\n");

	printf("void GamePaint_011(HDC hDC, vLine* line ) ends.\r\n");
	return;
}


