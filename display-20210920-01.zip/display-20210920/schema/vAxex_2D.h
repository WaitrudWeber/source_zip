#ifndef _VAXEX_2D_H_
#define _VAXEX_2D_H_

class Axex_2D {

public:
	vPoint *right = nullptr;
	vPoint *up = nullptr;
	vPoint *depth = nullptr;
	vPoint *eye_001 = nullptr;
	vPoint *center = nullptr;

private:
	float x, y, r, distance;
	vCalculation Calc;

public:
	Axex_2D ( float xx, float yy, float rr, float d_distance);
	int SetUp ( float xx, float yy, float zz ) ;
	int SetDepth ( float xx, float yy, float zz ) ;
	int SetEye ( float xx, float yy, float zz ) ;
	int SetCenter ( float xx, float yy, float zz ) ;
	int Calculation_Axex ( ) ;

};

#endif
