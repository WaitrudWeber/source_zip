#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "wTextarea.h"
#include "clipboard.h"
#include "Print.h"	//ADD: 20191228

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
//#include "vLine.h"
//#include "vCircle.h"

#include "vPointStructure.h"
#include "vPointLinear.h"
#include "display_threeD.h"

#include "vCalculation.h"
#include "v3dCalculation.h"


int main( int argc, char** argv ) {
	printf("main starts.\r\n");

	v3dCalculation* calc = new v3dCalculation ();
	calc->calculation_thread_018();

//	calc->calculation_thread_015();
//	calc->calculation_thread_014();
//	calc->calculation_thread_013();
//	calc->calculation_thread_012();
//	calc->calculation_thread_011();
//	calc->calculation_thread_007();
//	calc->calculation_thread_006();
//	calc->calculation_thread_005();
//	calc->calculation_thread_004();
//	calc->calculation_threed_003();
//	calc->calculation_threed_002();
//	calc->calculation_threed();

//	Sleep(3000);
	printf("main ends.\r\n");
	return 0;
}


