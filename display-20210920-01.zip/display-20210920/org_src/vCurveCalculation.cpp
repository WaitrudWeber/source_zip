#include <stdio.h>
#include <stdlib.h>
#include <windows.h> // ADD: 20191230

#include "array_counter.h"	// ADD: 20191230
#include "sender.h"			// ADD: 20191230
#include "Print.h"			// ADD: 20191230

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"

//
//
//
//
//
vPoint* vCurveCalculation::BattleField (vPoint* p1, vPoint* p2, vPoint* p3, vPoint* p4, float t) {
	vCalculation* calc = nullptr;

	printf("vCurveCalculation::BattleField: |%p|%p|%p|%p|", p1, p2, p3, p4 );
	// calculation, revisement
	float tt = t*t;
	float c=2.0f;

	// Linear
	vPoint* p5 = calc->scalize( p1, (1.0f - t) );	// anchor p1
	vPoint* p6 = calc->scalize ( p4, t ); 			// anchor p4

	vPoint* point = calc->add ( p5, p6 );

	//consider, p2 and p3 which are controls points.
	// Curve
	// if t=0:
	// curve_point=p1:
	// p2=0:
	// p3=0:
	// if t=1:
	// curve_point=p4:
	// p2=0:
	// p3=0:
	float graph = -( 1.0 /(0.5*0.5))*( t - 0.5 )*( t - 0.5 ) + 1.0;
	vPoint* p7 =  calc->subtract ( p2, p1 );
	vPoint* p8 =  calc->subtract ( p3, p4 );
	vPoint* p9 =  calc->scalize (  p7,  graph );
	vPoint* p10 = calc->scalize (  p8,  graph );
	vPoint* curve_point_001 = calc->add ( p9, p10 );
	vPoint* curve_point = calc->scalize( curve_point_001, 0.5f );

	vPoint* temp = calc->add( point, p9 );

	// Linear + Curve: Blend
	// Debug
	//vPoint* blend_001 = calc->add( curve_point, point );
	vPoint* blend_001 = calc->add( curve_point, point );
	vPoint* blend = calc->scalize( blend_001, 0.5f);

	level_error_msg = 2;
	// Calculated points printed.
	log_msg_003("p7=");
	p7->print();
	log_msg_003("p8=");
	p8->print();

	log_msg_003("curve_point=");
	curve_point->print();
	log_msg_003("blend=");
	blend->print();
	log_msg_003("blend_001=");
	blend_001->print();
	log_msg_003("point=");
	point->print();
	log_msg_003("t=%f graph=%f", t, graph);
	level_error_msg = 3;

	printf("vCurveCalculation::BattleField: |%p|\r\n", blend );

	//if ( t>0.8 ) 	exit(-1); //20191230

	// free
	// p5,p6, point, p7, p8, p9, p10, curve_point_001, curve_point, temp, blend_001, blend
	free(p5);
	free(p6);
	free(p7);
	free(p8);
	free(p9);
	free(p10);
	free(curve_point_001);
	free(curve_point);
	// free(temp);
	free(blend_001);
	// free(blend);

//	return point;
//	return curve_point;
	return temp;
}

// p1: Anchor
// p2: setting controls
//
// p3: Anchor(next)
// p4: setting controls
//
//      vCurveCalculation
//                         Position 
/* vPoint* vCurveCalculation::Position (vPoint* p1, vPoint* p2, vPoint p3, vPoint* p4, float t) {
	vCalculation* calc = nullptr;

	// calculation, revisement
	float tt = t*t;

	vPoint* p5 = calc->multiple ( p1, 1 - tt );
	vPoint* p6 = calc->multiple ( p3, tt );

	vPoint point calc->add ( p5, p6 );

	//consider, p2 and p3 which is controls point.

	return point;
}*/
