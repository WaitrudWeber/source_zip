#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// x(void*) func_entity = NULL;
void *func_entity = NULL;

int main_001 (FILE* fp) ;
int main_002 () ;
int main_003 () ;
int main_004 () ;
int main_005 () ;
int main_006 () ;
int main_007 () ;
int main_008 () ;
int main_009 () ;
int main_010 () ;
int main_011 () ;
int main_012 () ;
int main_013 () ;

int write_scheme_001 (FILE* fp) ;

int main () {
	int a;

//	a = main_010 ();
//	a = main_011 ();
	a = main_012 ();
//	a = main_013 ();

	return 0;
}

int main_013 () {
	int i,j,k, l, width, height, depth, index, num_start, num_all;
	char* c_tab = (char*) "	";
	char* c_tab_002 = (char*) "		";
	FILE *fp;
	int start_x = 10;
	int start_y = 10;
	int end_x = 640;
	int end_y = 480;

	printf("int main_013 starts.\r\n");
	width = 100;
	height = 80;

	fp = (FILE*)fopen ("001-print_scheme-functions-20230224-button-panels-005.cpp", "wb");

	// Diagnal Box
	// button1.setButton( 0, 0, 0, 0 );
	j=0;
	k=0;
	l=0;
	for ( k= start_x; k<end_y ; k+=height ) {
		for ( i= start_x; i<end_x ; i+=width ) {
			fprintf(fp, "%sbutton%d.setButton( %d , %d , %d , %d );\r\n\r\n", c_tab_002, j + 1, i, k, width, height );
			j++;
		}
		l++;
	}

	fprintf(fp, "// %d, %d \r\n\r\n", j , l  );
	fclose (fp );
	printf("int main_013 ends.\r\n");

	return 0;
}


int main_012 () {
	int i,j,k, width, height, depth, index, num_start, num_all;
	char* c_tab = (char*) "	";
	char* c_tab_002 = (char*) "		";
	FILE *fp;
	int start_x = 10;
	int end_x = 640;

	printf("int main_012 starts.\r\n");
	width = 100;

	fp = (FILE*)fopen ("001-print_scheme-functions-20230224-button-diagnal-004.cpp", "wb");

	// Diagnal Box
	// button1.setButton( 0, 0, 0, 0 );
	j=0;
	for ( i= start_x; i<end_x ; i+=width ) {
		fprintf(fp, "%sbutton%d.setButton( %d , %d , %d , %d );\r\n\r\n", c_tab_002, j + 1, i, i, width, width );
		j++;
	}

	fprintf(fp, "// diagnal %d width &d\r\n\r\n", j , i );
	fclose (fp );
	printf("int main_012 ends.\r\n");
	return 0;
}


int main_011 () {
	int i,j,k, width, height, depth, index, num_start, num_all;
	char* c_tab = (char*) "	";
	char* c_tab_002 = (char*) "		";
	FILE *fp;
	printf("int main_011 starts.\r\n");
	fp = (FILE*)fopen ("001-print_scheme-functions-20230224-004.cpp", "wb");
	fprintf(fp, "100\r\n\r\n" );
	fclose (fp );
	printf("int main_011 ends.\r\n");
	return 0;
}

int main_010 () {
	int i,j,k, width, height, depth, index, num_start, num_all;
	char* c_tab = (char*) "	";
	char* c_tab_002 = (char*) "		";
	FILE *fp;
	printf("int main_010 starts.\r\n");
	fp = (FILE*)fopen ("001-print_scheme-functions-20230202-004.cpp", "wb");

	index = 0;
	num_all = 30;
	num_start = 60;

	printf("index %d num_all %d num_start %d\r\n", index, num_all, num_start );

	for (index = num_start; index<num_all; index++ ){
		index = width*height* k + width*j + i;
//		fprintf(fp, "int calculation_thread_%03d ();\r\n",  index );
		printf("int calculation_thread_%03d ();\r\n",  index );
	}

	fprintf(fp, "\r\n\r\n" );

	for (index = num_start; index<num_all; index++ ){
/*		fprintf(fp, "int v3dCalculation::calculation_thread_%03d ()\r\n{\r\n",  index);
		fprintf(fp, "%sprintf(\"int calculation_thread_%03d () starts.\\r\\n\"\r\n",  c_tab, index);
		fprintf(fp, "%sprintf(\"int calculation_thread_%03d () ends.\\r\\n\"\r\n",  c_tab, index); */
//		fprintf(fp, "}\r\n\r\n");

		printf("int v3dCalculation::calculation_thread_%03d ()\r\n{\r\n",  index);
		printf("%sprintf(\"int calculation_thread_%03d () starts.\\r\\n\"\r\n",  c_tab, index);
		printf("%sprintf(\"int calculation_thread_%03d () ends.\\r\\n\"\r\n",  c_tab, index); 
		printf("}\r\n\r\n");
	}

	fclose (fp );
	printf("int main_010 ends.\r\n");
	return 0;
}

int main_009 () {
	int i,j,k, width, height, depth, index;
	char* c_tab = (char*) "	";
	char* c_tab_002 = (char*) "		";
	FILE *fp;
	printf("int main_009 starts.\r\n");
	fp = (FILE*)fopen ("001-print_scheme-functions-20230202-002.cpp", "wb");

	i = 0;
	j= 0;
	k = 0;
	width = 10;
	height = 10;
	depth = 10;
	index = 0;

	for ( k = 0; k<width; k++ ) 
	for ( j = 0; j<height; j++ ) 
	for ( i = 0; i<depth; i++ ) {
		index = width*height* k + width*j + i;
		fprintf(fp, "void *functionn_name_%05d();\r\n",  index );
	}

	fprintf(fp, "\r\n\r\n" );

	for ( k = 0; k<width; k++ ) 
	for ( j = 0; j<height; j++ ) 
	for ( i = 0; i<depth; i++ ) {
		index = width*height* k + width*j + i;
		fprintf(fp, "void *functionn_name_%05d()\r\n{\r\n",  index);
		fprintf(fp, "%sprintf(\"void *functionn_name_%05d() starts.\\r\\n\"\r\n",  c_tab, index);
		fprintf(fp, "%sprintf(\"void *functionn_name_%05d() ends.\\r\\n\"\r\n",  c_tab, index);
		fprintf(fp, "}\r\n\r\n");
	}

	fclose (fp );
	printf("int main_009 ends.\r\n");
	return 0;
}

int main_008 () {
	int i,j,k, width, height, depth, index;
	char* c_tab = (char*) "	";
	char* c_tab_002 = (char*) "		";
	FILE *fp;
	printf("int main_007 starts.\r\n");
	fp = (FILE*)fopen ("001-print_scheme-20230201-001.txt", "wb");

	i = 0;
	j= 0;
	k = 0;
	width = 10;
	height = 10;
	depth = 10;
	index = 0;

	for ( k = 0; k<width; k++ ) 
	for ( j = 0; j<height; j++ ) 
	for ( i = 0; i<depth; i++ ) {
		index = width*height* k + width*j + i;
		fprintf(fp, "%sprint_scheme[%5d].z = %d;\r\n", c_tab, index, k );
		fprintf(fp, "%sprint_scheme[%5d].y = %d;\r\n", c_tab, index, j );
		fprintf(fp, "%sprint_scheme[%5d].x = %d;\r\n", c_tab, index, i );
		fprintf(fp, "%sprint_scheme[%5d].fnc = (void*)functionn_name_%05d;\r\n", c_tab, index, index );
		fprintf(fp, "%sprint_scheme[%5d].cls = (class_base_all*)clsname_%05d;\r\n", c_tab, index, index );
	}

	fclose (fp );
	printf("int main_007 ends.\r\n");
	return 0;
}

// 001-merge_test-20220108-001.txt
//
int main_007 () {
	FILE *fp;
	int a, sz;
	char* dummy_001 = NULL;
	char* dummy_002 = NULL;

	fp = (FILE*)fopen ("001-merge_test-20220108-001.txt", "r");
	fseek(fp, 0L, SEEK_END);
	sz = ftell(fp);
	fseek(fp, 0L, SEEK_SET);

	printf("sz %d\r\n", sz);
	dummy_001 = (char*) malloc ( sizeof(char) * sz );
	if ( dummy_001 == NULL ) {
		printf("dummy_001 is NULL.\r\n");
		exit(-1);
	}

//	fread ( aaa, 1, sz, fp);
	fread ( dummy_001, 1, sz, fp);
	fclose (fp);

	printf("%s\r\n", dummy_001);


	fp = (FILE*)fopen ("001-merge_test-20220108-002.txt", "r");
	fseek(fp, 0L, SEEK_END);
	sz = ftell(fp);
	fseek(fp, 0L, SEEK_SET);

	printf("sz %d\r\n", sz);
	dummy_002 = (char*) malloc ( sizeof(char) * sz );
	if ( dummy_002 == NULL ) {
		printf("dummy_002 is NULL.\r\n");
		exit(-1);
	}

	// ($$codeblock)

	fclose (fp);
	printf("%s\r\n", dummy_001);


	printf("main ends.\r\n");
	return 0;
}

/*
int filesize( FILE *fp ) {
	err_msg_001("int filesize( FILE *fp ) startss.\r\n");

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	err_msg_001("sz %d\r\n", sz);
	err_msg_001("int filesize( FILE *fp ) ends.\r\n");
	return sz;
}

*/

//
int main_006 () {
	FILE *fp;
	int a;

	fp = (FILE*)fopen ("001-display-20220306-001.txt", "w");

	a = write_scheme_001 (fp) ;

	fclose (fp);
	printf("main ends.\r\n");
	return 0;
}

int write_scheme_001 (FILE* fp) {
	int i, j, k, l;
	char *tab = "	";
	int tabnum = 3;
	char *function_name = "Display_Object_";
	char *class_head_name = "vDisplayController_002::";
	char *return_param = "int";

	for ( i = 0; i<50; i++ ) {
		fprintf( fp,"%s", tab);
		fprintf( fp, "%s %s_%03d ();", return_param, function_name, i );
		fprintf( fp,"\r\n" );
	}

	fprintf( fp,"\r\n\r\n" );

	for ( i = 0; i<50; i++ ) {
		fprintf( fp,"%s %s", return_param, class_head_name );
		fprintf( fp,"%s", function_name );
		fprintf( fp, "_%03d() {\r\n", i );
		fprintf( fp,"%sreturn 0;\r\n", tab );
		fprintf( fp,"}\r\n" );
	}

	return 0;
}

int main_005 () {
	int i;
	for ( i=0; i<10; i++ ) {
		printf("i: %03d\r\n", i );
	}

	return 0;
}

int main_004 () {
	int i, j, k;
	char* tab = "	";
	char* tab_002 = "		";
	float x, y, z;
	double theta, r;
	double m_pi = 3.1415926535;
	double xx, yy;

	j = 0;
	r = 50.0;
	theta +=  ( m_pi * j )/ 16.0;

	for ( i = 'A'; i<'z'; i++ ) {
		xx = r * sin(theta);
		yy = r * cos(theta);
		printf("%scase %d:\r\n", tab, i );
		printf("%sbreak;\r\n", tab_002 );
		j++;
	}
}

int main_003 () {
	FILE *fp;
	int a;

	fp = (FILE*)fopen ("001-switch-case-20220306-001.txt", "w");
//	fread ( dummy, 1, a, fp);

	a = main_001 (fp) ;

	return 0;
}

int main_002 () {
	int i;

	for ( i =0; i<10; i++ ) {
		printf("case: %d // %c\r\n", i, (char)i );
	}
}

int main_001 (FILE* fp) {
	int i, j, k, l;
	char *tab = "	";
	int tabnum = 3;

	for( k=0; k<2; k++ )
		fprintf( fp,"%s", tab);
	fprintf( fp,"switch(SLOT_Number) {\r\n");

	for ( l=0; l<10; l++ ) {
		// case start
		for( k=0; k<2; k++ )
			fprintf( fp,"%s", tab);
		fprintf( fp,"case %d:\r\n", l);


		for( k=0; k<3; k++ )
			fprintf( fp,"%s", tab);
		fprintf( fp,"switch(Cursol_Number) {\r\n");

		// a: 65
		for ( i =0; i<4; i++ ) {

			for( k=0; k<3; k++ )
				fprintf( fp,"%s", tab);
			fprintf( fp,"case %d:\r\n", i);

			for( k=0; k<4; k++ )
				fprintf( fp,"%s", tab);

			fprintf( fp,"switch(WM_KEYUP) {\r\n");
			for ( j =65; j<65 + 26; j++ ) {
				for( k=0; k<4; k++ )
					fprintf( fp,"%s", tab);
				fprintf( fp,"case %d: // %c: cursol %d: slot %d:\r\n", j, j, i, l);

				for( k=0; k<4; k++ )
					fprintf( fp,"%s", tab);
				fprintf( fp,"break;\r\n");

			}
			for( k=0; k<4; k++ )
				fprintf( fp,"%s", tab);
			fprintf( fp,"}\r\n");

			for( k=0; k<3; k++ )
				fprintf( fp,"%s", tab);
			fprintf( fp,"break;\r\n");
		}
		for( k=0; k<3; k++ )
			fprintf( fp,"%s", tab);
		fprintf( fp,"}\r\n");

		// break; case end
		for( k=0; k<2; k++ )
			fprintf( fp,"%s", tab);
		fprintf( fp,"break;\r\n");

	}

	for( k=0; k<2; k++ )
		fprintf( fp,"%s", tab);
	fprintf( fp,"}\r\n");


	return 0;
}