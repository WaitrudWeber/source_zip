void WriteWaveData(void);
