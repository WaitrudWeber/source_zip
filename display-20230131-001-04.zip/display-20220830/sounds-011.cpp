// add the code of savetofile at 20220916.
#include "sounds-011.h"

//
void SoundEffect::dummy_function() {

	return;
}
//
