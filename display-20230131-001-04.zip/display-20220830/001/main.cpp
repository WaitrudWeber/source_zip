#include <windows.h>
#include <math.h>
#include <iostream>
#include <mmsystem.h>
//#include <amstream.h>
//#include <mmstream.h>

#include "array_counter.h"
#include "sender.h"
#include "Print.h"

#include "sounds-011.h"
#include "sounds-work-001.h"
#include "sounds_schema.h"

//#pragma comment(lib, "Winmm.lib")
//using namespace std;

//https://docs.microsoft.com/en-us/previous-versions/windows/desktop/api/mmstream/nn-mmstream-imultimediastream
//https://docs.microsoft.com/en-us/windows/win32/directshow/audio-streaming-sample-code
//https://www.exefiles.com/en/h/amstream-h/
//https://www.exefiles.com/en/h/mmstream-h/

int asbuffer[ 128 ];

int main_001(int argc, char** argv) ;

// Header inclusion is deferent as Play buffer record.
// twice sounds are right or not.
int main(int argc, char** argv) {
//	print_socket_msg = 1;
	err_msg_001("main starts.\r\n");
	SOUNDS_WORK_001* sounds_001 = new SOUNDS_WORK_001();
	sounds_001->Play();
	sounds_001->SetWORK_001 ();
	Sleep(3000);
	sound_011 = new SoundEffect ( asbuffer, 128, 4216 );
	sound_011->Play();
	Sleep(3000);
//	int a = main_058 ( argc, argv );
//	print_memories_002();
	char* temp = sound_011->get_m_data ();
	err_msg_001("get_BufferSize: %d\r\n", sound_011->get_BufferSize() );
	for ( int i =0; i<64; i++ ) {
		err_msg_001("m_data[%d]= %d\r\n", i, temp[i] );
	}


	char* temp_001 = sounds_001->get_m_buffer ();
	for ( int i =0; i<3584; i++ ) {
		temp_001[i] = temp[i];
	}
	for ( int i =0; i<64; i++ ) {
		err_msg_001("m_buffer[%d]= %d\r\n", i, temp_001[i] );
	}

	sounds_001->Play();
	Sleep(3000);
	err_msg_001("001: sounds_001->Play();\r\n");


	sound_011->Play();
	Sleep(3000);
	err_msg_001("011: sound_011->Play();\r\n");


	sound_011->Create_Sound();
	err_msg_001("011: sound_011->Create_Sound();\r\n");

	sound_011->Play();
	Sleep(3000);
	err_msg_001("011: sound_011->Play() + ;\r\n");

	err_msg_001("main ends.\r\n");
	return 0;
}


int main_001(int argc, char** argv) {

	err_msg_001("main starts.\r\n");
	initialize_sounds() ;

sound_000->Play();
//sound_001->Play();
sound_002->Play();
//sound_003->Play();
sound_004->Play();
sound_005->Play();
//sound_006->Play();
sound_007->Play();
//sound_008->Play();

//6
sound_009->Play();
//sound_010->Play();
sound_011->Play();
//8
sound_012->Play();

sound_013->Play();
//sound_014->Play();
sound_015->Play();
//sound_016->Play();
sound_017->Play();
sound_018->Play();
//sound_019->Play();
sound_020->Play();
//sound_021->Play();
sound_022->Play();
//sound_023->Play();
//8
sound_024->Play();

	err_msg_001("main ends.\r\n");
	return 0;
}

