#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files
#include <windows.h>
// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include <ctime>
#include <strsafe.h>
#include <mmsystem.h>

#include "wavewriter.h"


//#define MAX_THREADS 1
//#define BUF_SIZE 255

// Global variables.

HANDLE hData  = NULL;  // handle of waveform data memory
HPSTR  lpData = NULL;  // pointer to waveform data memory
WAVEFORMAT waveformat;

HWND hwndApp;

void WriteWaveData(void);

void WriteWaveData(void)
{
    HWAVEOUT    hWaveOut;
    HGLOBAL     hWaveHdr;
    LPWAVEHDR   lpWaveHdr;
    HMMIO       hmmio;
    UINT        wResult;
    HANDLE      hFormat;
    WAVEFORMAT  *pFormat;
    DWORD       dwDataSize;

    // Open a waveform device for output using window callback.

	pFormat = &waveformat;

	// sounds-011.h is succeed
	// if (waveOutOpen(&m_waveOut, WAVE_MAPPER, &m_waveFormat, (DWORD) m_done, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) 
    if (waveOutOpen((LPHWAVEOUT)&hWaveOut, WAVE_MAPPER,
//                    (LPWAVEFORMAT)pFormat,
                    (LPWAVEFORMATEX)pFormat,
                    (LONG)hwndApp, 0L, CALLBACK_WINDOW))
    {
        MessageBox(hwndApp,
                   "Failed to open waveform output device.",
                   NULL, MB_OK | MB_ICONEXCLAMATION);
        LocalUnlock(hFormat);
        LocalFree(hFormat);
        mmioClose(hmmio, 0);
        return;
    }

    // Allocate and lock memory for the waveform data.

    hData = GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE, dwDataSize );
    if (!hData)
    {
        MessageBox(hwndApp, "Out of memory.",
                   NULL, MB_OK | MB_ICONEXCLAMATION);
        mmioClose(hmmio, 0);
        return;
    }
//    if ((lpData = GlobalLock(hData)) == NULL)
    if ((lpData = (HPSTR)GlobalLock(hData)) == NULL)
    {
        MessageBox(hwndApp, "Failed to lock memory for data chunk.",
                   NULL, MB_OK | MB_ICONEXCLAMATION);
        GlobalFree(hData);
        mmioClose(hmmio, 0);
        return;
    }

    // Read the waveform data subchunk.
	if ((hmmio = mmioOpen("..\\sounds_resource\\thunder.wav", NULL, 
		MMIO_READ)) != NULL) {
		// File opened successfully. 
		MessageBox(hwndApp, "Failed to read data chunk.",
		NULL, MB_OK | MB_ICONEXCLAMATION);
	} else { 
		// File opened successfully. 
		MessageBox(hwndApp, "Failed to read data chunk.",
		NULL, MB_OK | MB_ICONEXCLAMATION);
	}

    if(mmioRead(hmmio, (HPSTR) lpData, dwDataSize) != (LRESULT)dwDataSize)
    {
        MessageBox(hwndApp, "Failed to read data chunk.",
                   NULL, MB_OK | MB_ICONEXCLAMATION);
        GlobalUnlock(hData);
        GlobalFree(hData);
        mmioClose(hmmio, 0);
        return;
    }

    // Allocate and lock memory for the header.

    hWaveHdr = GlobalAlloc(GMEM_MOVEABLE | GMEM_SHARE,
        (DWORD) sizeof(WAVEHDR));
    if (hWaveHdr == NULL)
    {
        GlobalUnlock(hData);
        GlobalFree(hData);
        MessageBox(hwndApp, "Not enough memory for header.",
            NULL, MB_OK | MB_ICONEXCLAMATION);
        return;
    }

    lpWaveHdr = (LPWAVEHDR) GlobalLock(hWaveHdr);
    if (lpWaveHdr == NULL)
    {
        GlobalUnlock(hData);
        GlobalFree(hData);
        MessageBox(hwndApp,
            "Failed to lock memory for header.",
            NULL, MB_OK | MB_ICONEXCLAMATION);
        return;
    }

    // After allocation, set up and prepare header.

    lpWaveHdr->lpData = lpData;
    lpWaveHdr->dwBufferLength = dwDataSize;
    lpWaveHdr->dwFlags = 0L;
    lpWaveHdr->dwLoops = 0L;
    waveOutPrepareHeader(hWaveOut, lpWaveHdr, sizeof(WAVEHDR));

	if ((hmmio = mmioOpen(".\\thunder-write-001.wav", NULL, 
		MMIO_WRITE)) != NULL) {
		// File opened successfully. 
		MessageBox(hwndApp, "Failed to read data chunk.",
		NULL, MB_OK | MB_ICONEXCLAMATION);
	} else { 
		// File opened successfully. 
		MessageBox(hwndApp, "Failed to read data chunk.",
		NULL, MB_OK | MB_ICONEXCLAMATION);
	}


    // Now the data block can be sent to the output device. The
    // waveOutWrite function returns immediately and waveform
    // data is sent to the output device in the background.

    wResult = waveOutWrite(hWaveOut, lpWaveHdr, sizeof(WAVEHDR));
    if (wResult != 0)
    {
        waveOutUnprepareHeader(hWaveOut, lpWaveHdr,
                               sizeof(WAVEHDR));
        GlobalUnlock( hData);
        GlobalFree(hData);
        MessageBox(hwndApp, "Failed to write block to device",
                   NULL, MB_OK | MB_ICONEXCLAMATION);
        return;
    }
}

