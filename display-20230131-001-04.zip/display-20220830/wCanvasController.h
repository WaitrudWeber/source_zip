#ifndef WCANVASCONTROLLER_H
#define WCANVASCONTROLLER_H

class wCanvasController {

	public:
		int Processed = 0;
		int DisplayGraph = 0;

	private:
		wEvent* event;
		char* m_data; // Sound data buffer
		int m_bufferSize; // Size of sound data buffer
		WAVEDATASETS *wavedatafmt_001;
		WAVEGRAPHDATASETS *wavegraphfmt_001;

	public:
		wCanvasController ();
		void kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
		void Process ();
		void ProcessWmPaint ();
		void ProcessWmChar();
		void setEvent( wEvent* evt );
		void Print_struct(wJavaStructure top ) ;
		void DisplayMusicData ();
		void SetMusicData( char* cm_data, int size);
		void ProcessWmPaint_Sounds_Graph () ;
		void SetWaveGraphDataSets (WAVEGRAPHDATASETS *asets) ;
		void SetWaveDataSets (WAVEDATASETS *asets) ;
		void CheckMSG(HDC hDC) ;
		void CheckMSG_001 (char* msg ) ;

};


#endif
