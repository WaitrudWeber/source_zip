// http://www.kumei.jp/c_lang/sdk2/sdk_168.htm

#include <windows.h>
#include <math.h>
#include <iostream>
#include <mmsystem.h>
#include <vfw.h>
//C:\MinGW\include\vfw.h
// x #include <vfwwdm.h>


//#include <amstream.h>
//#include <mmstream.h>
//#include <mmeapi.h>



#include "array_counter.h"
#include "sender.h"
#include "Print.h"

//#include "sounds-011.h"

//https://docs.microsoft.com/en-us/windows/win32/api/mmeapi/nf-mmeapi-waveinopen
HWAVEIN am_waveIn;
HANDLE am_done_002;
HANDLE am_done_003;
WAVEHDR wvhdr;


/* https://docs.microsoft.com/en-us/windows/win32/api/mmeapi/nf-mmeapi-waveinaddbuffer
MMRESULT waveInAddBuffer(
  HWAVEIN   hwi,
  LPWAVEHDR pwh,
  UINT      cbwh
);
*/

/* https://docs.microsoft.com/en-us/windows/win32/api/mmeapi/ns-mmeapi-wavehdr
typedef struct wavehdr_tag {
  LPSTR              lpData;
  DWORD              dwBufferLength;
  DWORD              dwBytesRecorded;
  DWORD_PTR          dwUser;
  DWORD              dwFlags;
  DWORD              dwLoops;
  struct wavehdr_tag *lpNext;
  DWORD_PTR          reserved;
} WAVEHDR, *PWAVEHDR, *NPWAVEHDR, *LPWAVEHDR;
*/

/*
typedef struct tWAVEFORMATEX {
  WORD  wFormatTag;
  WORD  nChannels;
  DWORD nSamplesPerSec;
  DWORD nAvgBytesPerSec;
  WORD  nBlockAlign;
  WORD  wBitsPerSample;
  WORD  cbSize;
} WAVEFORMATEX, *PWAVEFORMATEX, *NPWAVEFORMATEX, *LPWAVEFORMATEX;
*/
	// for the recording it from mic.
	void openWAV(const char *filename, int channel, int rate, int bits, int interval) {
		char* w_data;
		LPSTR lpstr_001;
		int aa, i;
//		closeWAV();
		
		// 
//		wvout = TVPCreateIStream(filename, TJS_BS_WRITE);


		// 
		WAVEFORMATEX waveForm;
		waveForm.wFormatTag      = WAVE_FORMAT_PCM;
		waveForm.nChannels       = channel;
		waveForm.nSamplesPerSec  = rate;
		waveForm.wBitsPerSample  = bits;
		waveForm.nBlockAlign     = waveForm.nChannels * waveForm.wBitsPerSample / 8;
		waveForm.nAvgBytesPerSec = waveForm.nSamplesPerSec * waveForm.nBlockAlign;

		// https://docs.microsoft.com/en-us/windows/win32/directshow/video-streaming-sample-code
		// https://docs.microsoft.com/en-us/windows/win32/directshow/audio-streaming-sample-code
		// https://docs.microsoft.com/en-us/windows/win32/medfound/wavsource-sample
		// https://docs.microsoft.com/en-us/windows/win32/api/mmeapi/nf-mmeapi-waveinopen
		// https://docs.microsoft.com/en-us/windows/win32/api/mfidl/nn-mfidl-imfmediastream
		// am_waveIn
// x		if (waveInOpen( NULL, WAVE_MAPPER, &waveForm, (DWORD)am_done_002, (DWORD)am_done_003, CALLBACK_NULL) != MMSYSERR_NOERROR) {
		if (waveInOpen(&am_waveIn, WAVE_MAPPER, &waveForm, (DWORD)am_done_002, (DWORD)am_done_003, CALLBACK_NULL) != MMSYSERR_NOERROR) {
// x		if (waveInOpen(&am_waveIn, WAVE_MAPPER, &waveForm, (DWORD)am_done_002, (DWORD)am_done_003, CALLBACK_FUNCTION) != MMSYSERR_NOERROR) {
// c:o s:x		if (waveInOpen(&am_waveIn, WAVE_MAPPER, &waveForm, (DWORD)am_done_002, (DWORD)0, CALLBACK_FUNCTION) != MMSYSERR_NOERROR) {
//		if (waveInOpen(&am_waveIn, WAVE_MAPPER, &waveForm, (DWORD)am_done_001, (DWORD)this, CALLBACK_FUNCTION) != MMSYSERR_NOERROR) {
//		if (waveInOpen(&am_waveIn, 0, &am_waveFormat, (DWORD) am_done, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) 
//		if (waveInOpen(&hwi, WAVE_MAPPER, &waveForm, (DWORD)waveInProc, (DWORD)this, CALLBACK_FUNCTION) != MMSYSERR_NOERROR) {
//			TVPThrowExceptionMessage(L"waveInOpen");
			 err_msg_001("002 Sound card cannot be opened.");
		}
		err_msg_001("waveInOpen:");

		// 
		int length = waveForm.nAvgBytesPerSec * interval / 1000;
		wvhdr.lpData         = new char[length];
//		wvhdr.lpData = w_data;
//		wvhdr.lpData = lpstr_001;
		wvhdr.dwBufferLength = length;
		wvhdr.dwFlags        = 0;
		wvhdr.reserved       = 0;

		// https://docs.microsoft.com/en-us/windows/win32/api/mmeapi/nf-mmeapi-waveinprepareheader
		if ( (aa = waveInPrepareHeader( am_waveIn, &wvhdr, sizeof(wvhdr)) )
		 == MMSYSERR_INVALHANDLE &&
		 aa == MMSYSERR_NODRIVER &&
		 aa == MMSYSERR_NOMEM )
		{
			 err_msg_001("003 Sound card as waveInPrepareHeader doesn't work well.  %d / %d / %d / %d", aa, MMSYSERR_INVALHANDLE, MMSYSERR_NODRIVER, MMSYSERR_NOMEM );
		}
		err_msg_001("waveInPrepareHeader: %d / %d / %d / %d", aa, MMSYSERR_INVALHANDLE, MMSYSERR_NODRIVER, MMSYSERR_NOMEM );

		// https://docs.microsoft.com/en-us/previous-versions/ms713725(v=vs.85)
		if ( (aa = waveInAddBuffer( am_waveIn, &wvhdr, sizeof(wvhdr)) )
		 == MMSYSERR_INVALHANDLE &&
		 aa == MMSYSERR_NODRIVER &&
		 aa == MMSYSERR_NOMEM &&
		 aa == WAVERR_UNPREPARED )
		{
			err_msg_001("waveInPrepareHeader: %d / %d / %d / %d / %d", aa, MMSYSERR_INVALHANDLE, MMSYSERR_NODRIVER, MMSYSERR_NOMEM, WAVERR_UNPREPARED );
		}
		err_msg_001("waveInAddBuffer: %d / %d / %d / %d / %d", aa, MMSYSERR_INVALHANDLE, MMSYSERR_NODRIVER, MMSYSERR_NOMEM, WAVERR_UNPREPARED );
		err_msg_001("buffer length %d", length );
		err_msg_001("buffer head %p", wvhdr.lpData );

//MMRESULT waveInStart(
//  HWAVEIN hwi 
//);

		waveInStart( am_waveIn );
		err_msg_001("waveInStart:");

		Sleep(3000);

		waveInStop( am_waveIn );
		err_msg_001("waveInStop:");


		for ( i=0; i<length; i+=10 )
			err_msg_001("buffer[%d] %d", i, wvhdr.lpData[i]);

//MMRESULT waveInStop(
//  HWAVEIN hwi 
//);

		// https://docs.microsoft.com/en-us/previous-versions/aa910175(v=msdn.10)
		// https://docs.microsoft.com/en-us/previous-versions/aa909811(v=msdn.10)
	}