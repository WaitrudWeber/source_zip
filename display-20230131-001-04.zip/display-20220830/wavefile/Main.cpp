#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdlib.h>

int main( int argc, char** argv ) {
	int i;
	FILE *rfp, *wfp;
	char dummy[255];
	printf("main starts.\r\n");

	rfp = (FILE*)fopen( "..\\..\\thunder.wav" ,"rb");
	wfp = (FILE*)fopen( ".\\thunder_wav_002.txt" ,"wb");
	char c = fread ( dummy, 1, 255,  rfp );


	for ( i=0; i<100; i++ ) {
		fprintf(wfp, "i:%d |%d|%c||\r\n", i, dummy[i], dummy[i] );
	}

	fprintf(wfp, "read 255: |%ld|\r\n", (long) rfp);
	fclose(rfp);
	fclose(wfp);
	printf("main ends.\r\n");
	return 0;
}

//https://waitrudweber.hatenablog.com/entry/2022/09/15/124757?_ga=2.233900439.886626742.1663213516-1342512393.1656416855
//https://waitrudweber.hatenablog.com/entry/2022/09/15/223945?_ga=2.196665765.886626742.1663213516-1342512393.1656416855