//
#include <tchar.h>
#include <windows.h>
//#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "wEvent.h"


// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
#include "vPointStructure.h"
#include "display_threeD.h"

#include "wavesound.h"
#include "cg_schema.h"

// https://waitrudweber.hatenablog.com/entry/2021/07/09/175334
// 
// 
int* cursol_001 = 0;
int* cursol_002 = 0; // we sould create button controler.


int *cg_m_mode = 0;
int *cg_command_char = 0;
int *cg_command_keyup = 0;

int *cg_display = 0;
wEvent *p_evt = nullptr;

void baselootin_000 ();
void baselootin_001 ();
void baselootin_002 ();
void baselootin_003 ();
void baselootin_004 ();
void baselootin_005 ();
void baselootin_006 ();
void baselootin_007 ();
void baselootin_008 ();
void baselootin_009 ();
void baselootin_010 ();
void baselootin_011 ();
void baselootin_012 ();
void baselootin_013 ();
void baselootin_014 ();
void baselootin_015 ();
void baselootin_016 ();
void baselootin_017 ();
void baselootin_018 ();
void baselootin_019 ();
void baselootin_020 ();
void baselootin_021 ();
void baselootin_022 ();
void baselootin_023 ();
void baselootin_024 ();
void baselootin_025 ();
void baselootin_026 ();
void baselootin_027 ();
void baselootin_028 ();
void baselootin_029 ();

void cg_setEvent ( wEvent* p_evt );

void cg_setEvent ( wEvent* evt ) {
	p_evt = evt;
}

void cg_schema () {
	printf("cg_schema () starts. p_evt = %p\r\n", p_evt);

	if ( p_evt == nullptr ) return;

	printf("cg_schema: p_evt->wParam: %d\r\n", p_evt->wParam);
	printf("cg_schema: p_evt->main_mode: %d\r\n", p_evt->main_mode);
//	printf("cg_schema: p_evt->main_mode_cg: %d\r\n", p_evt->main_mode_cg);

	switch (p_evt->main_mode) {
case 0:
	baselootin_000();
	break;
case 1:
	baselootin_001();
	break;
case 2:
	baselootin_002();
	break;
case 3:
	baselootin_003();
	break;
case 4:
	baselootin_004();
	break;
case 5:
	baselootin_005();
	break;
case 6:
	baselootin_006();
	break;
case 7:
	baselootin_007();
	break;
case 8:
	baselootin_008();
	break;
case 9:
	baselootin_009();
	break;
case 10:
	baselootin_010();
	break;
case 11:
	baselootin_011();
	break;
case 12:
	baselootin_012();
	break;
case 13:
	baselootin_013();
	break;
case 14:
	baselootin_014();
	break;
case 15:
	baselootin_015();
	break;
case 16:
	baselootin_016();
	break;
case 17:
	baselootin_017();
	break;
case 18:
	baselootin_018();
	break;
case 19:
	baselootin_019();
	break;
case 20:
	baselootin_020();
	break;
case 21:
	baselootin_021();
	break;
case 22:
	baselootin_022();
	break;
case 23:
	baselootin_023();
	break;
case 24:
	baselootin_024();
	break;
case 25:
	baselootin_025();
	break;
case 26:
	baselootin_026();
	break;
case 27:
	baselootin_027();
	break;
case 28:
	baselootin_028();
	break;
case 29:
	baselootin_029();
	break;
	}

	printf("cg_schema () ends.\r\n");

}


void baselootin_000 () {
	printf("baselootin_000: starts.\r\n");
	int a = print_lines () ;
	printf("baselootin_000: ends.\r\n");
}

void baselootin_001 () {
	printf("baselootin_001: starts.\r\n");
	printf("baselootin_001: ends.\r\n");
}

void baselootin_002 () {
	printf("baselootin_002: starts.\r\n");
	printf("baselootin_002: ends.\r\n");
}

void baselootin_003 () {
	int a;
	printf("baselootin_003: starts. p_evt->wParam = %d p_evt->wParam_Keyup = %d\r\n", p_evt->wParam, p_evt->wParam_Keyup );
//	printf("*cg_command_char=%d\r\n", *cg_command_char);
	//  8 Backspace
	// 17 Ctl
	// 13 Enter
	// 27 ESC
	// 37 LEFT
	// 38 UP
	// 39 RIGHT
	// 40 DOWN
	switch (p_evt->wParam_Keyup) {
	case 37:
		break;
	case 38:
		break;
	case 39:
		a = spin_screen();
		break;
	case 40:
		break;
	}
	printf("baselootin_003: ends.\r\n");
}

void baselootin_004 () {
	printf("baselootin_004: starts.\r\n");
	printf("baselootin_004: ends.\r\n");
}

void baselootin_005 () {
	printf("baselootin_005: starts.\r\n");
	printf("baselootin_005: ends.\r\n");
}

void baselootin_006 () {
	printf("baselootin_006: starts.\r\n");
	printf("baselootin_006: ends.\r\n");
}


void baselootin_007 () {
	printf("baselootin_007: starts.\r\n");
	printf("baselootin_007: ends.\r\n");
}

void baselootin_008 () {
	printf("baselootin_008: starts.\r\n");
	printf("baselootin_008: ends.\r\n");
}

void baselootin_009 () {
	printf("baselootin_009: starts.\r\n");
	printf("baselootin_009: ends.\r\n");
}

void baselootin_010 () {
	printf("baselootin_010: starts.\r\n");
	*cg_display = 0;
	printf("baselootin_010: ends.\r\n");
}

void baselootin_011 () {
	printf("baselootin_011: starts.\r\n");
	*cg_display = 1;
	printf("baselootin_011: ends.\r\n");
}

void baselootin_012 () {
	printf("baselootin_012: starts.\r\n");
	gDisplayControls_wmpaint_display_threeD_proc ( p_evt->hWnd, p_evt->hDc, p_evt->ps, *(p_evt->uMsg), p_evt->wParam, p_evt->lParam );
	printf("baselootin_012: ends.\r\n");
}

void baselootin_013 () {
	printf("baselootin_013: starts.\r\n");
	hDisplayControls_wmpaint_display_threeD_proc ( p_evt->hWnd, p_evt->hDc, p_evt->ps, *(p_evt->uMsg), p_evt->wParam, p_evt->lParam );
	printf("baselootin_013: ends.\r\n");
}

void baselootin_014 () {
	err_msg_001("baselootin_014: starts.\r\n");
	iDisplayControls_wmpaint_display_threeD_proc ( p_evt->hWnd, p_evt->hDc, p_evt->ps, *(p_evt->uMsg), p_evt->wParam, p_evt->lParam );
	err_msg_001("baselootin_014: ends.\r\n");
}

void baselootin_015 () {
	err_msg_001("baselootin_015: starts.\r\n");
	jDisplayControls_wmpaint_display_threeD_proc ( p_evt->hWnd, p_evt->hDc, p_evt->ps, *(p_evt->uMsg), p_evt->wParam, p_evt->lParam );
	err_msg_001("baselootin_015: ends.\r\n");
}

void baselootin_016 () {
	err_msg_001("baselootin_016: starts.\r\n");
	kDisplayControls_wmpaint_display_threeD_proc ( p_evt->hWnd, p_evt->hDc, p_evt->ps, *(p_evt->uMsg), p_evt->wParam, p_evt->lParam );
	err_msg_001("baselootin_016: ends.\r\n");
}

void baselootin_017 () {
	err_msg_001("baselootin_017: starts.\r\n");
	lDisplayControls_wmpaint_display_threeD_proc ( p_evt->hWnd, p_evt->hDc, p_evt->ps, *(p_evt->uMsg), p_evt->wParam, p_evt->lParam );
	err_msg_001("baselootin_017: ends.\r\n");
}

void baselootin_018 () {
	printf("baselootin_018: starts.\r\n");
	mDisplayControls_wmpaint_display_threeD_proc ( p_evt->hWnd, p_evt->hDc, p_evt->ps, *(p_evt->uMsg), p_evt->wParam, p_evt->lParam );
	printf("baselootin_018: ends.\r\n");
}

void baselootin_019 () {
	printf("baselootin_019: starts.\r\n");
	nDisplayControls_wmpaint_display_threeD_proc ( p_evt->hWnd, p_evt->hDc, p_evt->ps, *(p_evt->uMsg), p_evt->wParam, p_evt->lParam );
	printf("baselootin_019: ends.\r\n");
}

void baselootin_020 () {
	printf("baselootin_020: starts.\r\n");
	printf("baselootin_020: ends.\r\n");
}

void baselootin_021 () {
	printf("baselootin_021: starts.\r\n");
	printf("baselootin_021: ends.\r\n");
}

void baselootin_022 () {
	printf("baselootin_022: starts.\r\n");
	printf("baselootin_022: ends.\r\n");
}

void baselootin_023 () {
	err_msg_001("baselootin_023: starts.\r\n");
	int a = multithread ();
	err_msg_001("baselootin_023: ends.\r\n");
}

void baselootin_024 () {
	err_msg_001("baselootin_024: starts.\r\n");
	int a = no_playsound_multithread_002 ();
	err_msg_001("baselootin_024: ends.\r\n");
}

void baselootin_025 () {
	printf("baselootin_025: starts.\r\n");
	printf("baselootin_025: ends.\r\n");
}

void baselootin_026 () {
	printf("baselootin_026: starts.\r\n");
	printf("baselootin_026: ends.\r\n");
}

void baselootin_027 () {
	printf("baselootin_027: starts.\r\n");
	printf("baselootin_027: ends.\r\n");
}

void baselootin_028 () {
	printf("baselootin_028: starts.\r\n");
	printf("baselootin_028: ends.\r\n");
}

void baselootin_029 () {
	printf("baselootin_029: starts.\r\n");
	printf("baselootin_029: ends.\r\n");
}

