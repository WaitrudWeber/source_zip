#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <stdio.h>

#include "array_counter.h"
#include "wEvent.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
#include "something_word.h"

#include "vPointStructure.h"
#include "vPointLinear.h"

#include "display_threeD.h"

#include "sounds-011.h"

#include "wJavaStructure.h"
#include "wCanvasController.h"

//
//
//
//
wCanvasController::wCanvasController() {
}

//
//
//
//
void wCanvasController::Print_struct(wJavaStructure top ) {


}

//
//
//
//
void wCanvasController::setEvent( wEvent* evt ) {

	this->event = evt;

}

//
//
//
//
void wCanvasController::kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam ) {

}

//
//
//
//
void wCanvasController::Process () {
//	exit(1);
	Processed = 0;
//	switch ( *( this->event->uMsg ) ) {
	switch ( this->event->Type ) {
	case WM_PAINT:
		ProcessWmPaint ();
		Processed = 1;
		break;
	case WM_CHAR:
		ProcessWmChar ();
		Processed = 1;
		break;
	}

}

//
//
//
//
void wCanvasController::ProcessWmChar () {
	switch ( this->event->main_mode ) {
	case 2:
		//something_word
		getchar_display_threeD_proc ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		//exit(-1);
		break;
	case 8:
		getchar_display_threeD_proc ( event->hWnd, *( event->uMsg ), event->wParam, event->lParam );
		//display_threeD_initialize();
		break;
	}
}

//
//
//
//
void wCanvasController::ProcessWmPaint () {
//	exit(-1);
	SetTextColor( event->hDc, RGB( 0 , 0,  0 ) );

//	this->CheckMSG (event->hDc);

//	return;
	
	switch ( this->event->main_mode ) {
	case 2:
		//something_word
		wmpaint_somtehing_word_proc ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
		break;
	case 7:
		// wmpaint_display_patches ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
		ProcessWmPaint_Sounds_Graph ();
		break;
	case 8:
//		wmpaint_display_threeD_proc ( event->hWnd, event->hDc, event->ps, *( event->uMsg ), event->wParam, event->lParam );
//		// wmpaint_display_threeD_proc_org ( event->hWnd, event->uMsg, event->wParam, event->lParam );
//		if ( this->DisplayGraph == 1 ) {
//			this->DisplayMusicData ();
//		}
	case 11:
		ProcessWmPaint_Sounds_Graph ();
		break;
	}

}

void wCanvasController::ProcessWmPaint_Sounds_Graph () {

	printf("void wCanvasController::ProcessWmPaint_Sounds_Graph () starts.\r\n");
	HPEN hPen = CreatePen(PS_DASHDOTDOT, 2, RGB( 0, 0, 0 ) );
	SelectObject(this->event->hDc, hPen);

	this->CheckMSG (event->hDc);
	
	if (wavegraphfmt_001 == NULL || wavedatafmt_001== NULL ){
		this->CheckMSG_001 ( "wavegraphfmt_001 or wavedatafmt_001 is NULL,  so, it exits.\r\n" );
		return;
	}
	// 
	double a = ( 1.0  / wavedatafmt_001->data_size ) * ( wavegraphfmt_001->screen_axex_length_width ) ;
	double b = wavegraphfmt_001->radio * a;

	for ( int i = 0; i < wavegraphfmt_001->screen_axex_length_width ; i++ ) {
		if ( wavedatafmt_001->data_string == NULL ) {
			this->CheckMSG_001 ( "wavedatafmt_001->data_string is NULL, so, it exits.\r\n" );
			return;
		}
		double value = wavedatafmt_001->data_string [0][i] * wavegraphfmt_001->height_radio ;
		int x = wavegraphfmt_001->start_x + i;
		int y = wavegraphfmt_001->start_y - value;
		SetPixel(event->hDc, y, y, RGB( 0, 0, 255));
	}

	printf("void wCanvasController::ProcessWmPaint_Sounds_Graph () ends.\r\n");
}

void wCanvasController::SetWaveGraphDataSets (WAVEGRAPHDATASETS *asets) {
	printf("void wCanvasController::SetWaveGraphDataSets (WAVEGRAPHDATASETS asets) starts.\r\n");
	this->wavegraphfmt_001 = asets;
	printf("void wCanvasController::SetWaveGraphDataSets (WAVEGRAPHDATASETS asets) ends.\r\n");
}

void wCanvasController::SetWaveDataSets (WAVEDATASETS *asets) {
	printf("void wCanvasController::SetWaveDataSets (WAVEDATASETS asets) starts.\r\n");
	this->wavedatafmt_001 = asets;
	printf("void wCanvasController::SetWaveDataSets (WAVEDATASETS asets) ends.\r\n");
}

void wCanvasController::CheckMSG_001(char* msg ) {
	RECT msg_clip;
	SetRect ( &msg_clip, 300, 50, 400, 100);
	DrawText( event->hDc, TEXT( msg ), -1, &msg_clip, DT_NOCLIP);
}

void wCanvasController::CheckMSG(HDC hDC) {
	RECT msg_clip;

	SetRect ( &msg_clip, 300, 0, 400, 50);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 50, 400, 100);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 100, 400, 150);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 150, 400, 200);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 200, 400, 250);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 250, 400, 300);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
	SetRect ( &msg_clip, 300, 300, 400, 350);
	DrawText( hDC, TEXT( "Hello Seven" ), -1, &msg_clip, DT_NOCLIP);
//	exit(-1);
}


void wCanvasController:: DisplayMusicData () {
	int i;
	int Height, Width, Left, Start_x, Start_y, Max_Wdith, Max_Height;
	double x_Pos;
	int m_bufferSize;
	int* m_data;

	Height = 480;
	Width = 640;
	Left = 100;
	Start_x = Left;
	Start_y = Width / 2;

	Max_Wdith = Width - Left;
	Max_Height = 256;

	for ( i=0; i< m_bufferSize; i++ ) {
		x_Pos = ((double)i) / ((double)m_bufferSize);
		x_Pos *= Max_Wdith;
//		put_pixel ( (int)x_Pos, (int)m_data[i], 0 );
	}

}

void wCanvasController:: SetMusicData( char* cm_data, int size) {
	m_data = (char*)cm_data;
	m_bufferSize = size;
}


