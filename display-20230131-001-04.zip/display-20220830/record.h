
void openWAV(const char *filename, int channel, int rate, int bits, int interval) ;

