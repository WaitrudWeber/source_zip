// Very thanks to
//https://gist.github.com/kbjorklu/6317308
//http://www13.plala.or.jp/kymats/study/MULTIMEDIA/waveOut_getpos.html
//http://www13.plala.or.jp/kymats/study/MULTIMEDIA/waveOut_func.html
//http://eternalwindows.jp/winmm/wave/wave01.html
#define HALF_NOTE 1.059463094359 // HALF_NOTE ^ 12 = 2
#define PI 3.14159265358979

#include <Windows.h>
#include <math.h>
#include <iostream>

using namespace std;


typedef struct {
	int fmt_size = 0;
	int data_size = 0;
	char** fmt_string = NULL;
	char** data_string = NULL;
} WAVEDATASETS;

typedef struct {
	int screen_axex_length_width = 30;
	int screen_axex_strength_height = 0;
	double radio = 3.0;
	double height_radio = 0.3;
	int graph_sequence_pages_max = 1;
	int graph_sequence_pages_index = 0;
	int start_x = 100;
	int start_y = 148;
} WAVEGRAPHDATASETS;

class SoundEffect
{
public:
    SoundEffect()
    {
        m_data = NULL;
    }
    SoundEffect(const int noteInfo[], int fix_Arraysize, const int VALHZ)
    {
        // Initialize the sound format we will request from sound card
        m_waveFormat.wFormatTag = WAVE_FORMAT_PCM;     // Uncompressed sound format
        m_waveFormat.nChannels = 1;                    // 1 = Mono, 2 = Stereo
        m_waveFormat.wBitsPerSample = 8;               // Bits per sample per channel
        m_waveFormat.nSamplesPerSec = VALHZ;           // Sample Per Second
//        m_waveFormat.nSamplesPerSec = 11025;           // Sample Per Second
        m_waveFormat.nBlockAlign = m_waveFormat.nChannels * m_waveFormat.wBitsPerSample / 8;
        m_waveFormat.nAvgBytesPerSec = m_waveFormat.nSamplesPerSec * m_waveFormat.nBlockAlign;
        m_waveFormat.cbSize = 0;


		const int ramda = 8;
		int count_v = 0;

        int dataLength = 0, moment = (m_waveFormat.nSamplesPerSec / 75);
        double period = 2.0 * PI / (double) m_waveFormat.nSamplesPerSec;

        // Calculate how long we need the sound buffer to be
        for (int i = 1; i < fix_Arraysize; i += 2)
            dataLength += (noteInfo[i] != 0) ? noteInfo[i] * moment : moment;

        // Allocate the array
        m_data = new char[m_bufferSize = dataLength];

        int placeInData = 0;

        // Make the sound buffer
        for (int i = 0; i < fix_Arraysize; i += 2)
        {
            int relativePlaceInData = placeInData;

            while ((relativePlaceInData - placeInData) < ((noteInfo[i + 1] != 0) ? noteInfo[i + 1] * moment : moment))
            {
                // Generate the sound wave (as a sinusoid)
                // - x will have a range of -1 to +1
                double x = sin((relativePlaceInData - placeInData) * 55 * pow(HALF_NOTE, noteInfo[i]) * period);

				count_v = relativePlaceInData % ramda;

                // Scale x to a range of 0-255 (signed char) for 8 bit sound reproduction
                m_data[relativePlaceInData] = (char) (127 * x + 128);
                m_data[relativePlaceInData] /= ramda;
                m_data[relativePlaceInData] *= count_v;

                relativePlaceInData++;
            }

            placeInData = relativePlaceInData;
        }
    }
    SoundEffect(SoundEffect& otherInstance)
    {
        m_bufferSize = otherInstance.m_bufferSize;
        m_waveFormat = otherInstance.m_waveFormat;

        if (m_bufferSize > 0)
        {
            m_data = new char[m_bufferSize];

            for (int i = 0; i < otherInstance.m_bufferSize; i++)
                m_data[i] = otherInstance.m_data[i];
        }
    }
    ~SoundEffect()
    {
        if (m_bufferSize > 0)
            delete [] m_data;
    }

    SoundEffect& operator=(SoundEffect& otherInstance)
    {
        if (m_bufferSize > 0)
            delete [] m_data;

        m_bufferSize = otherInstance.m_bufferSize;
        m_waveFormat = otherInstance.m_waveFormat;

        if (m_bufferSize > 0)
        {
            m_data = new char[m_bufferSize];

            for (int i = 0; i < otherInstance.m_bufferSize; i++)
                m_data[i] = otherInstance.m_data[i];
        }

        return *this;
    }

	void Create_Sound () {
		int i;
		double devide = 8.0;
		double m_pi = 3.1415926535;
		double theta = 0.0;
		double value;
		
		for ( i=0; i< m_bufferSize; i++ ) {
			theta = ((double ) i ) *  m_pi * 2.0 / devide;
			value = ( sin(theta) + 1.0 ) * 128.0;
			m_data[i] = (char)value;
		}
	}

	void Add_Dither () {
		int i, j;
		double average;
		int dither = 3;

		for ( i=0; i< m_bufferSize; i+= dither ) {
			if ( i != 0 && (i % dither) == 0 ) {
				for ( j= i - dither; j< i; j++ )
					average += m_data[i];
			}
			if ( i != 0 && (i % dither) == 0 ) {
				average /= (double)dither;
				for ( j= i - dither; j< i; j++ ) { // Care of Param j
					m_data[j] = average;
				}
				average = 0.0;
			}
		}
	}

    void OpenFileMmio( char* file_name) {
//	    DWORD	dwDataSize;
//		HPSTR	lpData = NULL;  // pointer to waveform data memory
		char msg_buffer[255];
		MMCKINFO mmckinfoParent;  // parent chunk information 
		MMCKINFO mmckinfoFormatChunk; // Format chunk information structure 
		MMCKINFO mmckinfoDataChunk;  // Data chunk information structure 
		MMCKINFO mmckinfoRdibChunk;  // Rdib chunk information structure 
		int a;

		if ( (hmmio = mmioOpen( file_name, NULL, MMIO_READ )) != NULL ) {
			// File opened successfully. 
			sprintf( msg_buffer, "File open to read is %s handle|%d|\r\n", file_name, hmmio);
			MessageBox(hwndApp, msg_buffer,
			NULL, MB_OK | MB_ICONEXCLAMATION);

			mmckinfoParent.fccType = mmioFOURCC('W', 'A', 'V', 'E'); 
			if (mmioDescend(hmmio, (LPMMCKINFO) &mmckinfoParent, NULL, MMIO_FINDRIFF)==-1) 
			{ 
				MessageBox(hwndApp, "We cannot create a wave audio file format wave on the memory.",
				NULL, MB_OK | MB_ICONEXCLAMATION);
				mmioClose(hmmio, 0); 
				return; 
			}

			// fmt
			mmckinfoFormatChunk.ckid = mmioFOURCC('f', 'm', 't', ' '); 
			if (mmioDescend(hmmio, (LPMMCKINFO) &mmckinfoFormatChunk, &mmckinfoParent, MMIO_FINDRIFF)==-1) 
			{ 
				MessageBox(hwndApp, "We cannot create a wave audio file format fmt on the memory.",
				NULL, MB_OK | MB_ICONEXCLAMATION);
				mmioClose(hmmio, 0); 
				return; 
			}

			unsigned int fmtSize = mmckinfoFormatChunk.cksize;
			char* waveFmt = new char[fmtSize]; 
			sprintf( msg_buffer, "buffer size fmt is |%d|\r\n", fmtSize );
			MessageBox(hwndApp, msg_buffer,
				NULL, MB_OK | MB_ICONEXCLAMATION);

			if( (a = mmioRead(hmmio, (HPSTR) waveFmt, fmtSize ) != (LRESULT)fmtSize) == -1 ) 
			{
			sprintf( msg_buffer, "Failed to read data chunk = |%d|\r\n", a );
			MessageBox(hwndApp, msg_buffer,
				NULL, MB_OK | MB_ICONEXCLAMATION);
				mmioClose(hmmio, 0);
				return;
			}

			mmioAscend(hmmio, &mmckinfoFormatChunk, 0);

			// data
			mmckinfoDataChunk.ckid = mmioFOURCC('d', 'a', 't', 'a'); 
			if (mmioDescend(hmmio, (LPMMCKINFO) &mmckinfoDataChunk, &mmckinfoParent, MMIO_FINDCHUNK)==-1) 
			{ 
				MessageBox(hwndApp, "We cannot create a wave audio file format data on the memory.",
				NULL, MB_OK | MB_ICONEXCLAMATION);
				mmioClose(hmmio, 0); 
				return;
			}

			m_bufferSize = mmckinfoDataChunk.cksize; 
			sprintf( msg_buffer, "buffer size data is |%d|\r\n", m_bufferSize );
			MessageBox(hwndApp, msg_buffer,
				NULL, MB_OK | MB_ICONEXCLAMATION);

			if ( m_bufferSize > 1000 ) m_bufferSize = 1000;
			m_data = new char[m_bufferSize]; 

			if( (a = mmioRead(hmmio, (HPSTR) m_data, m_bufferSize ) != (LRESULT)m_bufferSize) == -1 ) 
			{
			sprintf( msg_buffer, "Failed to read data chunk = |%d|\r\n", a );
			MessageBox(hwndApp, msg_buffer,
				NULL, MB_OK | MB_ICONEXCLAMATION);
				mmioClose(hmmio, 0);
				return;
			}

		} else {
		    // File cannot be opened. 
			sprintf( msg_buffer, "Failed to open the file to read is %s handle|%d|\r\n", file_name, hmmio);
			MessageBox(hwndApp, msg_buffer,
			NULL, MB_OK | MB_ICONEXCLAMATION);
	        mmioClose(hmmio, 0);
	        return;
		}
		mmioClose(hmmio, 0);
	}

	// https://learn.microsoft.com/en-us/windows/win32/api/mmiscapi/nf-mmiscapi-mmiodescend
	// http://ja.uwenku.com/question/p-tnhrdyba-em.html
	// https://learn.microsoft.com/en-us/windows/win32/api/mmeapi/nf-mmeapi-waveoutprepareheader
	// https://learn.microsoft.com/en-us/windows/win32/api/mmiscapi/nf-mmiscapi-mmiowrite
	// https://learn.microsoft.com/en-us/previous-versions/ms712181(v=vs.85)
    void SaveToFileMmio( char* file_name) {
		char msg_buffer[255];
		MMCKINFO mmckinfoParent;  // parent chunk information 
		MMCKINFO mmckinfoDataChunk;
		MMCKINFO mmckinfoFormatChunk;
		char a_fmt[16];

		if ((hmmio = mmioOpen( file_name, NULL, 
	 	MMIO_WRITE | MMIO_CREATE)) != NULL) {
//		MMIO_CREATE)) != NULL) {
			// File opened successfully. 
			sprintf( msg_buffer, "File open to write is %s handle|%d|\r\n", file_name, hmmio);
			MessageBox(hwndApp, msg_buffer,
			NULL, MB_OK | MB_ICONEXCLAMATION);

			//
			//waveOutPrepareHeader( m_waveOut, &m_waveHeader, sizeof(WAVEHDR) );

			mmckinfoParent.fccType = mmioFOURCC('W', 'A', 'V', 'E'); 
			//RIFF
			if (mmioDescend(hmmio, (LPMMCKINFO) &mmckinfoParent, NULL, MMIO_FINDRIFF)==-1) 
			{ 
				MessageBox(hwndApp, "We cannot create a wave audio file format RIFF on the memory.",
				NULL, MB_OK | MB_ICONEXCLAMATION);
				mmioClose(hmmio, 0); 
				return; 
			}

			if ( mmioCreateChunk( hmmio, &mmckinfoParent, MMIO_CREATERIFF)  == -1 ) {
				sprintf( msg_buffer, "Failed to wirte RIFF is %s handle|%d|\r\n", file_name, hmmio);
				MessageBox(hwndApp, msg_buffer,
				NULL, MB_OK | MB_ICONEXCLAMATION);
			}


			//LIST
			if (mmioDescend(hmmio, (LPMMCKINFO) &mmckinfoParent, NULL, MMIO_FINDLIST)==-1) 
			{ 
				MessageBox(hwndApp, "We cannot create a wave audio file format LIST on the memory.",
				NULL, MB_OK | MB_ICONEXCLAMATION);
				mmioClose(hmmio, 0); 
				return; 
			}

			if ( mmioCreateChunk( hmmio, &mmckinfoParent, MMIO_CREATELIST)  == -1 ) {
				sprintf( msg_buffer, "Failed to wirte LIST is %s handle|%d|\r\n", file_name, hmmio);
				MessageBox(hwndApp, msg_buffer,
				NULL, MB_OK | MB_ICONEXCLAMATION);
			}

			// FMT
			mmckinfoFormatChunk.ckid = mmioFOURCC('f', 'm', 't', ' '); 
			if (mmioDescend(hmmio, (LPMMCKINFO) &mmckinfoFormatChunk, &mmckinfoParent, MMIO_FINDLIST)==-1) 
			{ 
				MessageBox(hwndApp, "We cannot create a wave audio file format fmt on the memory.",
				NULL, MB_OK | MB_ICONEXCLAMATION);
				mmioClose(hmmio, 0); 
				return; 
			}
			mmckinfoFormatChunk.cksize = 16;
			mmioCreateChunk(hmmio, &mmckinfoFormatChunk, 0 ); 
			mmioWrite(hmmio, a_fmt, 16 );  // *data size
			mmioAscend(hmmio, &mmckinfoFormatChunk, 0);

			// DATA
			mmckinfoDataChunk.ckid = mmioFOURCC('d', 'a', 't', 'a'); 
			if (mmioDescend(hmmio, (LPMMCKINFO) &mmckinfoDataChunk, &mmckinfoParent, MMIO_FINDLIST)==-1) 
			{ 
				MessageBox(hwndApp, "We cannot create a wave audio file format LIST on the memory.",
				NULL, MB_OK | MB_ICONEXCLAMATION);
				mmioClose(hmmio, 0); 
				return; 
			}
			mmckinfoDataChunk.cksize = m_bufferSize;

			// DATA
			//Creating data chunk and inserting information from source file 
			mmioCreateChunk(hmmio, &mmckinfoDataChunk, 0); 
			mmioWrite(hmmio, m_data, m_bufferSize);  // *data size
			mmioAscend(hmmio, &mmckinfoDataChunk, 0);

		} else { 
		    // File cannot be opened. 
			sprintf( msg_buffer, "Failed to open the file to write is %s handle|%d|\r\n", file_name, hmmio);
			MessageBox(hwndApp, msg_buffer,
			NULL, MB_OK | MB_ICONEXCLAMATION);
	        mmioClose(hmmio, 0);
	        return;
		}
		mmioClose(hmmio, 0);
    }

    void SaveToFile( char* file_name)
    {
   		FILE *fp, *wfp;

		wfp = fopen( file_name, "wb");
		fwrite( m_data, sizeof(char), m_bufferSize, wfp );
		fclose(wfp);
    }

    void Play()
    {
        // Create our "Sound is Done" event
        m_done = CreateEvent (0, FALSE, FALSE, 0);

        // Open the audio device
//        if (waveOutOpen(&m_waveOut, 0, &m_waveFormat, (DWORD) m_done, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) 
        if (waveOutOpen(&m_waveOut, WAVE_MAPPER, &m_waveFormat, (DWORD) m_done, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) 
        {
            cout << "Sound card cannot be opened." << endl;
            return;
        }

        // Create the wave header for our sound buffer
        m_waveHeader.lpData = m_data;
        m_waveHeader.dwBufferLength = m_bufferSize;
        m_waveHeader.dwFlags = 0;
        m_waveHeader.dwLoops = 0;

        // Prepare the header for playback on sound card
        if (waveOutPrepareHeader(m_waveOut, &m_waveHeader, sizeof(m_waveHeader)) != MMSYSERR_NOERROR)
        {
            cout << "Error preparing Header!" << endl;
            return;
        }

        // Play the sound!
        ResetEvent(m_done); // Reset our Event so it is non-signaled, it will be signaled again with buffer finished

        if (waveOutWrite(m_waveOut, &m_waveHeader, sizeof(m_waveHeader)) != MMSYSERR_NOERROR)
        {
            cout << "Error writing to sound card!" << endl;
            return;
        }

		cout << "wait for." << endl;
        // Wait until sound finishes playing
//        if (WaitForSingleObject(m_done, INFINITE) != WAIT_OBJECT_0)
        if (WaitForSingleObject(m_done, 2 * 1000) != WAIT_OBJECT_0)
        {
            cout << "Error waiting for sound to finish" << endl;
            return;
        }

        // Unprepare our wav head
        if (waveOutUnprepareHeader(m_waveOut, &m_waveHeader,sizeof(m_waveHeader)) != MMSYSERR_NOERROR)
        {
            cout << "Error unpreparing header!" << endl;
            return;
        }

        // Close the wav device
        if (waveOutClose(m_waveOut) != MMSYSERR_NOERROR)
        {
            cout << "Sound card cannot be closed!" << endl;
            return;
        }

        // Release our event handle
        CloseHandle(m_done);
    }

	int get_BufferSize () {
		//int result = m_waveFormat,nSamplesPerSec / 2;
		//return result;
		return m_bufferSize;
	}

	char* get_m_data () {
		//int result = m_waveFormat,nSamplesPerSec / 2;
		//return result;
		return m_data;
	}


private:
    HWAVEOUT m_waveOut; // Handle to sound card output
    WAVEFORMATEX m_waveFormat; // The sound format
    WAVEHDR m_waveHeader; // WAVE header for our sound data
    HANDLE m_done; // Event Handle that tells us the sound has finished being played.
                   // This is a very efficient way to put the program to sleep
                   // while the sound card is processing the sound buffer

    char* m_data; // Sound data buffer
    int m_bufferSize; // Size of sound data buffer
	HWND	hwndApp;
    HMMIO	hmmio;

public:
	WAVEDATASETS wavedatafmt;
	WAVEGRAPHDATASETS wavegraphfmt;

private:
	void dummy_function();
};


