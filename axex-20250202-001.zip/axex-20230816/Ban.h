#ifndef _BAN_H_
#define _BAN_H_

class Ban {

	public:
		int a000;

	public:
		int b000;

	public:
		int inside (int mx, int my, int* koma_x, int* koma_y ) ;

	private:
		int start_x = 200;
		int start_y = 200;
		int ban_width = 300;
		int ban_height = 300;

};

#endif
