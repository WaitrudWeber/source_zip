#ifndef _VRETURNABLEPARAM_H_
#define _VRETURNABLEPARAM_H_

	class vReturnableParam {
		public:
			vPoint **points;
			vLine **lines;
			int point_num = 0;
			int line_num = 0;

		public:
			void SetPointNum (int pn );
	};

#endif
