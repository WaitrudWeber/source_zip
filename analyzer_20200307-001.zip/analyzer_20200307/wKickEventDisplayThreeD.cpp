#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "array_counter.h"
#include "wTextarea.h"
#include "clipboard.h"
#include "Print.h"	//ADD: 20191228

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vCurveCalculation.h"
#include "vIntersection.h"
#include "vScreen.h"
//#include "vLine.h"
#include "vCircle.h"

#include "vPointStructure.h"
#include "vPointLinear.h"
#include "display_threeD.h"

#include "wKickEvent.h"
#include "wKickEventDisplayThreeD.h"
//#include "wKickEventDisplayThreeD.h"


void wKickEventDisplayThreeD::PreProcessor () {
	display_threeD_screen_initialize_OnRails();
}

void wKickEventDisplayThreeD::Processor_001 ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) {
	//int dDisplayControls_wmpaint_display_threeD_proc_OnRails ( HWND hWnd, HDC hDC, PAINTSTRUCT* ps, UINT uMsg, WPARAM wParam, LPARAM lParam ) ;
	dDisplayControls_wmpaint_display_threeD_proc_OnRails ( hWnd, hDC, ps, uMsg, wParam, lParam ) ;
}

void wKickEventDisplayThreeD::setPid ( int id ) {
	this->pid =id;
}

//
//
//
//
//
void wKickEventDisplayThreeD::Execute_001 () {

}

void wKickEventDisplayThreeD::Prefectured () {
	int a = display_threeD_screen_initialize_OnRails ();
}

