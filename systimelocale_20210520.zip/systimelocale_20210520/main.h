#ifndef _DEFINETEST_H
#define _DEFINETEST_H 1

#define __USE_GXX_DEFINETEST 1

#include <sys/types.h>

#endif
