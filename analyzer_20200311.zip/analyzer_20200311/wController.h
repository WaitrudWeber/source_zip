#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

class wController {
	public:
		int x, y, width, height;
		char* controllers_name;
		wButton* btn;

	private:
		int mode;

	public:
		wController ( char* cn );
		int addButton( wButton *btn);
		int Process();

	private:
		static int paintWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
};

