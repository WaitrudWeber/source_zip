#ifndef _V_DISPLAY_cONTROLLER_001_H_
#define _V_DISPLAY_cONTROLLER_001_H_

#include "vBox.h"
#include "wCanvasController.h"

class vDisplayController_001 {

	private:
		vPoint bones_001[10];
		int bones_max = 10;
		int bones_max_index = 0;
		wCanvasController* canvas = nullptr;
		vCalculation Calc;
		vScreenCG screen_006;

//		vBox box( 0.0f, 0.0f, 100.0f, 100.0f );

	public:
		int SetCanvas ( wCanvasController *l_canvas ) ;
		int PrintBones () ;
		int DisplayBones_002 () ;

} ;

#endif

