#ifndef _CREATION_OF_AXEX_H_
#define _CREATION_OF_AXEX_H_


extern vCircle_2D**	 vCircle_2D_001;
extern vAxex_2D** AXEX_2D_001;


#endif
