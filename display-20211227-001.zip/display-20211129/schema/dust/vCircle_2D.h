#ifndef _VCIRCLE_2D_H_
#define _VCIRCLE_2D_H_

class vCircle_2D {

private:
	float x, y, z;

public:
vCircle_2D (foat xx, foat yy,foat rr) {

	this->x = xx;
	this->y = yy;
	this->r = rr;

}

};

#endif
