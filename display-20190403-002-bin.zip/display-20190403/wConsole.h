#ifndef
#define WCONSOLE_H


#endif
