#ifndef WCANVASCONTROLLER_H
#define WCANVASCONTROLLER_H

class wCanvasController {

	public:
		int Processed = 0;

	private:
		wEvent* event;

	public:
		wCanvasController ();
		void kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
		void Process ();
		void ProcessWmPaint ();
		void ProcessWmChar();
		void setEvent( wEvent* evt );

};


#endif
