#include <stdio.h>
#include <stdlib.h>

int print_mouse_move_001 () ;

int print_mouse_move_001 () {
	FILE *fp;
	char* tab = "	";
	char* case_a = "case";
	char* case_b = ":";
	int i = 0;
	char** case_c = NULL;

	case_c = (char**) malloc ( sizeof(char*) * 10 );
	if ( case_c == NULL ) {
		printf("malloc is not allocated.\r\n");
		exit(-1);
	}
	case_c[0] = "WM_MOUSEMOVE";
	case_c[1] = "WM_PAINT";
	case_c[2] = "WM_KEYUP";
	case_c[3] = "WM_KEYDOWN";

	fp = (FILE*) fopen(".\\001-mouse_move-001-01\.txt", "wb");

	for ( i=0; i<4; i++ ) {
		fprintf( fp, "%s%s %s%s\r\n", (char*) tab,  case_a, case_c[i], case_b );
		fprintf( fp, "%s%sbreak;\r\n" , (char*) tab, (char*) tab);
	}

	fclose(fp);

	return 0;
}

