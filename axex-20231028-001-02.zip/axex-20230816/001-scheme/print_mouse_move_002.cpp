#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// https://www.ibm.com/docs/ja/i/7.1?topic=ssw_ibm_i_71/rtref/strcat.html

int print_mouse_move_002 () ;
const char *byte_to_binary( int x );

int print_mouse_move_002 () {
	FILE *fp;
	char* tab = "	";
	int i = 0;
	int num_a = 20;
	int x, width, y, height, end_x, end_y;
	int b = 1; // 1 -> 2 -> 4
	char* print_seperated = (char*) "printf(\"%s\\r\\n\");";
	char memorried[255];

	fp = (FILE*) fopen(".\\001-mouse_move-002-04\.txt", "wb");

	for ( i=0; i<num_a; i++ ) {
		fprintf( fp, "%s%sparam_a[%d] = \"a\";\r\n", tab, tab, i );
	}

	for ( i=0; i<num_a; i++ ) {
		fprintf( fp, "%s%sDrawText( (HDC) hDC, TEXT( param_a[%d] ), -1, &rect_xy[%d], DT_NOCLIP );\r\n", tab, tab, i, i );
	}

	for ( i=0; i<num_a; i++ ) {
		fprintf( fp, "%s%sInvalidateRect( hWnd, &rect_xy[%d], FALSE);\r\n", tab, tab, i);
	}

	x = 10;
	y = 10;
	width = 50;
	height = 50;
	for ( i=0; i<num_a; i++ ) {
		end_x = x + width;
		end_y = y + height;
		printf("x %d width %d y %d height % to (%d, %d)\r\n", x, width, y, height, end_x, end_y);
		printf( "%s%sSetRect( &rect_xy[%d], %d, %d, %d, %d );//04\r\n", tab, tab, i, x, y, end_x, end_y );
		fprintf( fp, "%s%sSetRect( &rect_xy[%d], %d, %d, %d, %d );//04\r\n", tab, tab, i, x, y, end_x, end_y );
		x += width;
		if ( y > 480 ) break;
		if ( x > 640 - width ) {
			y += height;
			x = 10;
			continue;
		}
	}


	for ( i=0; i<num_a; i++ ) {
		sprintf( memorried, print_seperated, byte_to_binary(b) );
		fprintf( fp, "%s%sif ( DRAW_PARAM && _DRAW_PARAM_%s_ ) {\r\n//\$%s\r\n%s%s%s%s\r\n%s%s} \r\n", tab, tab, byte_to_binary(b), byte_to_binary(b), tab, tab, tab, memorried, tab, tab );
		b *= 2;
	}

	b=1;
	for ( i=0; i<num_a; i++ ) {
		fprintf( fp, "#define _DRAW_PARAM_%s_ %d\r\n", byte_to_binary(b), b );
		b *= 2;
	}

	fclose(fp);

	return 0;
}

// https://stackoverflow.com/questions/111928/is-there-a-printf-converter-to-print-in-binary-format
const char *byte_to_binary
(
    int x
)
{
    static char b[33];
    b[0] = '\0';

    unsigned int z;
    unsigned long z_start;
    z_start = 256*256*256*128;

//    printf("z_start %d\r\n", z_start);

    for (z = 256*256*256*128; z > 0; z >>= 1)
    {
//   	printf("x %d z %d\r\n", x, z );
        strcat(b, ((x & z) == z) ? "1" : "0");
    }

	printf("b%s\r\n", b);
    return b;
}


