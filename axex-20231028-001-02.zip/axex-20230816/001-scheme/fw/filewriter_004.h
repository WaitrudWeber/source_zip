#ifndef _FILEWRITER_004_
#define _FILEWRITER_004_
//...
extern int filewriter_004 ();
extern int set_filewriter_004 ();
extern int initialize_filewriter_004 ();
#endif
