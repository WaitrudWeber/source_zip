// textarea controler needs the function which changes textarea cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "wTextarea.h"
#include "wTextareaController.h"

// CursolNumber is public.

wTextareaController::wTextareaController () {

	this->mode = 0;
	this->number_textarea = 42;
	AryTextarea = nullptr;

	this->Initialization_001 ();
	this->Initialization_002 ();
}

//
int wTextareaController::Initialization () {

	AryTextarea = (wTextarea**)malloc (sizeof(wTextarea*) * number_textarea );
	if ( AryTextarea == NULL ) {
		printf("We cannot allocate AryTextarea and it exits.\r\n");
		exit(-1);
	}

	return 0;
}

int wTextareaController::Initialization_002 () {

	AryTextarea[0]->setTextarea( 10 , 10 , 100 , 80 );

	AryTextarea[1]->setTextarea( 110 , 10 , 100 , 80 );

	AryTextarea[2]->setTextarea( 210 , 10 , 100 , 80 );

	AryTextarea[3]->setTextarea( 310 , 10 , 100 , 80 );

	AryTextarea[4]->setTextarea( 410 , 10 , 100 , 80 );

	AryTextarea[5]->setTextarea( 510 , 10 , 100 , 80 );

	AryTextarea[6]->setTextarea( 610 , 10 , 100 , 80 );

	AryTextarea[7]->setTextarea( 10 , 90 , 100 , 80 );

	AryTextarea[8]->setTextarea( 110 , 90 , 100 , 80 );

	AryTextarea[9]->setTextarea( 210 , 90 , 100 , 80 );

	AryTextarea[10]->setTextarea( 310 , 90 , 100 , 80 );

	AryTextarea[11]->setTextarea( 410 , 90 , 100 , 80 );

	AryTextarea[12]->setTextarea( 510 , 90 , 100 , 80 );

	AryTextarea[13]->setTextarea( 610 , 90 , 100 , 80 );

	AryTextarea[14]->setTextarea( 10 , 170 , 100 , 80 );

	AryTextarea[15]->setTextarea( 110 , 170 , 100 , 80 );

	AryTextarea[16]->setTextarea( 210 , 170 , 100 , 80 );

	AryTextarea[17]->setTextarea( 310 , 170 , 100 , 80 );

	AryTextarea[18]->setTextarea( 410 , 170 , 100 , 80 );

	AryTextarea[19]->setTextarea( 510 , 170 , 100 , 80 );

	AryTextarea[20]->setTextarea( 610 , 170 , 100 , 80 );

	AryTextarea[21]->setTextarea( 10 , 250 , 100 , 80 );

	AryTextarea[22]->setTextarea( 110 , 250 , 100 , 80 );

	AryTextarea[23]->setTextarea( 210 , 250 , 100 , 80 );

	AryTextarea[24]->setTextarea( 310 , 250 , 100 , 80 );

	AryTextarea[25]->setTextarea( 410 , 250 , 100 , 80 );

	AryTextarea[26]->setTextarea( 510 , 250 , 100 , 80 );

	AryTextarea[27]->setTextarea( 610 , 250 , 100 , 80 );

	AryTextarea[28]->setTextarea( 10 , 330 , 100 , 80 );

	AryTextarea[29]->setTextarea( 110 , 330 , 100 , 80 );

	AryTextarea[30]->setTextarea( 210 , 330 , 100 , 80 );

	AryTextarea[31]->setTextarea( 310 , 330 , 100 , 80 );

	AryTextarea[32]->setTextarea( 410 , 330 , 100 , 80 );

	AryTextarea[33]->setTextarea( 510 , 330 , 100 , 80 );

	AryTextarea[34]->setTextarea( 610 , 330 , 100 , 80 );

	AryTextarea[35]->setTextarea( 10 , 410 , 100 , 80 );

	AryTextarea[36]->setTextarea( 110 , 410 , 100 , 80 );

	AryTextarea[37]->setTextarea( 210 , 410 , 100 , 80 );

	AryTextarea[38]->setTextarea( 310 , 410 , 100 , 80 );

	AryTextarea[39]->setTextarea( 410 , 410 , 100 , 80 );

	AryTextarea[40]->setTextarea( 510 , 410 , 100 , 80 );

	AryTextarea[41]->setTextarea( 610 , 410 , 100 , 80 );

	return 0;
}

int wTextareaController::Initialization_001 () {

	AryTextarea[0] = new wTextarea ();
	AryTextarea[1] = new wTextarea ();
	AryTextarea[2] = new wTextarea ();
	AryTextarea[3] = new wTextarea ();
	AryTextarea[4] = new wTextarea ();
	AryTextarea[5] = new wTextarea ();
	AryTextarea[6] = new wTextarea ();
	AryTextarea[7] = new wTextarea ();
	AryTextarea[8] = new wTextarea ();
	AryTextarea[9] = new wTextarea ();
	AryTextarea[10] = new wTextarea ();
	AryTextarea[11] = new wTextarea ();
	AryTextarea[12] = new wTextarea ();
	AryTextarea[13] = new wTextarea ();
	AryTextarea[14] = new wTextarea ();
	AryTextarea[15] = new wTextarea ();
	AryTextarea[16] = new wTextarea ();
	AryTextarea[17] = new wTextarea ();
	AryTextarea[18] = new wTextarea ();
	AryTextarea[19] = new wTextarea ();
	AryTextarea[20] = new wTextarea ();
	AryTextarea[21] = new wTextarea ();
	AryTextarea[22] = new wTextarea ();
	AryTextarea[23] = new wTextarea ();
	AryTextarea[24] = new wTextarea ();
	AryTextarea[25] = new wTextarea ();
	AryTextarea[26] = new wTextarea ();
	AryTextarea[27] = new wTextarea ();
	AryTextarea[28] = new wTextarea ();
	AryTextarea[29] = new wTextarea ();
	AryTextarea[30] = new wTextarea ();
	AryTextarea[31] = new wTextarea ();
	AryTextarea[32] = new wTextarea ();
	AryTextarea[33] = new wTextarea ();
	AryTextarea[34] = new wTextarea ();
	AryTextarea[35] = new wTextarea ();
	AryTextarea[36] = new wTextarea ();
	AryTextarea[37] = new wTextarea ();
	AryTextarea[38] = new wTextarea ();
	AryTextarea[39] = new wTextarea ();
	AryTextarea[40] = new wTextarea ();
	AryTextarea[41] = new wTextarea ();

	return 0;
}

void wTextareaController::selectTextarea ( ) {

	if( this->CursolNumber < 0 ) {
		this->CursolNumber = this->number_textarea -1;
		//return;
	}

	if( this->CursolNumber >= this->number_textarea ) {
		this->CursolNumber = 0;
		//return;
	}

	for ( int i=0; i<this->number_textarea; i++ )
		AryTextarea[ i ]->setMode( 0 );

	AryTextarea[ this->CursolNumber ]->setMode( 1 );

}

void wTextareaController::selectTextarea ( char* btn_nm ) {
	int ret;

	for ( int i=0; i<this->number_textarea; i++ ) {
		
		ret = strcmp( AryTextarea[ i ]->textarea_name, btn_nm );
		if ( ret == 0 ) {
			CursolNumber = i;
			AryTextarea[ i ]->setMode( 1 );
		} else
			AryTextarea[ i ]->setMode( 0 );
	}
}

void wTextareaController::addTextarea ( wTextarea* t ) {
	if ( this->number_textarea ==0 || AryTextarea == nullptr ) {
		AryTextarea = ( wTextarea** ) malloc ( sizeof( wTextarea* ) * 1 );
		AryTextarea[ this->number_textarea ] = t;
		this->number_textarea = 1;
		return;
	}

	this->number_textarea++;
	AryTextarea = (wTextarea **) realloc( AryTextarea, this->number_textarea * sizeof(wTextarea *) );
	AryTextarea[ this->number_textarea - 1] = t;

}

void wTextareaController::drawTextareas ( HDC hdc ) {
	printf("void wTextareaController::drawTextareas ( HDC hdc ) starts.\r\n");

	// char *AryTextarea
	// this->AryTextarea equals AryTextarea.
	// this.AryTextarea equals AryTextarea.

	char *aname;

	// char text;
	// x text = this.AryTextarea;
	// x aname = this.AryTextarea;

	for ( int i=0; i<this->number_textarea; i++ ) {

		aname = AryTextarea[ i ]->textarea_name;
		AryTextarea[ i ]->paintTextarea( hdc, aname );
	}

	printf("void wTextareaController::drawTextareas ( HDC hdc ) ends.\r\n");
}


// void
