#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files
#include <windows.h>
// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include <ctime>
#include <strsafe.h>
#include <mmsystem.h>

#include "Print.h"

#define MAX_THREADS 1
#define BUF_SIZE 255

typedef struct MyData {
    int val1;
    int val2;
} MYDATA, *PMYDATA;

//#include <mmeapi.h>
#pragma comment(lib, "winmm.lib" )

DWORD WINAPI MyThreadFunction_001(LPVOID lpParam);
DWORD WINAPI MyThreadFunction_002(LPVOID lpParam);

int multithread();
int no_playsound_multithread_002();

double double_random();
void wErrorHandler_001(const char* c_char);
void ErrorHandler_001(LPTSTR lpszFunction);

int thread_dispose_001 = 0;
int sounds_number = 0;
int flg_do_not_touch = 0;
int flg_do_not_touch_bg = 0;
int flg_once_read = 0;
int flg_once_read_bg = 0;

//--- 20201016
HWND hwnd_001;
HINSTANCE hinst;
static MCI_OPEN_PARMS open, open2, open3;
static MCI_PLAY_PARMS play, play2, play3;
//--- 20201016

double double_random() {
    int i_rand;
    double one_rand;

    i_rand = rand();
    one_rand = (double)RAND_MAX;
    one_rand = (double)i_rand / one_rand;

    return one_rand;
}

// PlaySound(NULL, 0, 0);
int no_playsound_multithread_002()
{
    PMYDATA pDataArray[MAX_THREADS];
    DWORD   dwThreadIdArray[MAX_THREADS];
    HANDLE  hThreadArray[MAX_THREADS];

    // Create MAX_THREADS worker threads.
    for (int i = 0; i < MAX_THREADS; i++)
    {
        // Allocate memory for thread data.

        pDataArray[i] = (PMYDATA)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
            sizeof(MYDATA));

        if (pDataArray[i] == NULL)
        {
            // If the array allocation fails, the system is out of memory
            // so there is no point in trying to print an error message.
            // Just terminate execution.
            ExitProcess(2);
        }

        // Generate unique data for each thread to work with.

        pDataArray[i]->val1 = i;
        pDataArray[i]->val2 = i + 100;

        // Create the thread to begin execution on its own.

        hThreadArray[i] = CreateThread(
            NULL,                   // default security attributes
            0,                      // use default stack size  
            MyThreadFunction_002,       // thread function name
            pDataArray[i],          // argument to thread function 
            0,                      // use default creation flags 
            &dwThreadIdArray[i]);   // returns the thread identifier 


        // Check the return value for success.
        // If CreateThread fails, terminate execution. 
        // This will automatically clean up threads and memory. 

        if (hThreadArray[i] == NULL)
        {
//            wErrorHandler_001( (TCHAR) TEXT("CreateThread"));
            wErrorHandler_001( "CreateThread" );
            ExitProcess(3);
        }
    } // End of main thread creation loop.

    if (thread_dispose_001 == 1) {

        // Wait until all threads have terminated.
        WaitForMultipleObjects(MAX_THREADS, hThreadArray, TRUE, INFINITE);

        // Block2;
        // Close all thread handles and free memory allocations.

        for (int i = 0; i < MAX_THREADS; i++)
        {
            CloseHandle(hThreadArray[i]);
            if (pDataArray[i] != NULL)
            {
                HeapFree(GetProcessHeap(), 0, pDataArray[i]);
                pDataArray[i] = NULL;    // Ensure address will not be used angain.
            }
        }
    }

    return 0;
}

//---
//
int multithread()
{
    PMYDATA pDataArray[MAX_THREADS];
    DWORD   dwThreadIdArray[MAX_THREADS];
    HANDLE  hThreadArray[MAX_THREADS];


    // Create MAX_THREADS worker threads.
    for (int i = 0; i < MAX_THREADS; i++)
    {
        // Allocate memory for thread data.

        pDataArray[i] = (PMYDATA)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
            sizeof(MYDATA));

        if (pDataArray[i] == NULL)
        {
            // If the array allocation fails, the system is out of memory
            // so there is no point in trying to print an error message.
            // Just terminate execution.
            ExitProcess(2);
        }

        // Generate unique data for each thread to work with.

        pDataArray[i]->val1 = i;
        pDataArray[i]->val2 = i + 100;

        // Create the thread to begin execution on its own.

        hThreadArray[i] = CreateThread(
            NULL,                   // default security attributes
            0,                      // use default stack size  
            MyThreadFunction_001,       // thread function name
            pDataArray[i],          // argument to thread function 
            0,                      // use default creation flags 
            &dwThreadIdArray[i]);   // returns the thread identifier 


        // Check the return value for success.
        // If CreateThread fails, terminate execution. 
        // This will automatically clean up threads and memory. 

        if (hThreadArray[i] == NULL)
        {
//            wErrorHandler_001( (TCHAR) TEXT("CreateThread"));
            wErrorHandler_001( "CreateThread" );
            ExitProcess(3);
        }
    } // End of main thread creation loop.

    if (thread_dispose_001 == 1) {

        // Wait until all threads have terminated.
        WaitForMultipleObjects(MAX_THREADS, hThreadArray, TRUE, INFINITE);

        // Block2;
        // Close all thread handles and free memory allocations.

        for (int i = 0; i < MAX_THREADS; i++)
        {
            CloseHandle(hThreadArray[i]);
            if (pDataArray[i] != NULL)
            {
                HeapFree(GetProcessHeap(), 0, pDataArray[i]);
                pDataArray[i] = NULL;    // Ensure address will not be used angain.
            }
        }
    }


    return 0;
}
// Very thanks to:
// https://docs.microsoft.com/en-us/previous-versions/dd743680(v=vs.85)
DWORD WINAPI MyThreadFunction_001(LPVOID lpParam)
{
    HANDLE hStdout;
    PMYDATA pDataArray;
    TCHAR msgBuf[BUF_SIZE];
    size_t cchStringSize;
    DWORD dwChars;
    double one_rand;
    int i, j, s, t;
    int countinued;
    // Make sure there is a console to receive output results. 

	if ( flg_do_not_touch >= 1 ) {
		err_msg_001 ("it sounds still in this lootin.\r\n");
		return -1;
	} else {
		flg_do_not_touch = 1;
		err_msg_001 ("start flg_do_not_touch = %d\r\n", flg_do_not_touch);
	}

//    hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
//    if (hStdout == INVALID_HANDLE_VALUE)
//        return 1;

    // Cast the parameter to the correct data type.
    // The pointer is known to be valid because 
    // it was checked for NULL before the thread was created.

    pDataArray = (PMYDATA)lpParam;

    // Print the parameter values using thread-safe functions.

    //StringCchPrintf(msgBuf, BUF_SIZE, TEXT("Parameters = %d, %d\n"),
    //    pDataArray->val1, pDataArray->val2);

    //StringCchLength(msgBuf, BUF_SIZE, &cchStringSize);
    //WriteConsole(hStdout, msgBuf, (DWORD)cchStringSize, &dwChars, NULL);

    //boot_console_server();

    countinued = 0;
    for (i = 0; i < 100; i++) {
        // start back ground
        /*if (countinued == 0) {
            switch (sounds_number) {
            case 0:
                PlaySound(TEXT(".\\rain_start.wav"), NULL, SND_FILENAME);
                break;
            }
            countinued = 1;
        }*/
        t = double_random() * 3;
        s = double_random() * 10000;

        for (j = 0; j < t; j++) {
            // Play sounds set
            switch ( sounds_number ) {
            case 0:
//                PlaySound(TEXT(".\\thunder.wav"), NULL, SND_FILENAME);
//                PlaySound(TEXT(".\\thunder.wav"), NULL, SND_ASYNC | SND_NODEFAULT);
//                PlaySound(TEXT(".\\thunder.wav"), GetModuleHandle(NULL), SND_ALIAS | SND_APPLICATION);

				
                PlaySound(TEXT("..\\sounds_resource\\thunder.wav"), GetModuleHandle(NULL), SND_NOSTOP | SND_ASYNC | SND_ALIAS | SND_APPLICATION);

//                PlaySound(TEXT(".\\thunder.wav"), GetModuleHandle(NULL), SND_ASYNC | SND_ALIAS | SND_APPLICATION);
                break;
            case 1:
                break;
            default:
                break;
            }
        }
        Sleep(s);
    }

    Sleep(s);

    //PlaySound(TEXT(".\\thunder.wav"), NULL, SND_FILENAME);
    //PlaySound(TEXT(".\\thunder.wav"), NULL, SND_FILENAME);
    //PlaySound(TEXT(".\\thunder.wav"), NULL, SND_FILENAME);

    flg_do_not_touch = 0;
	err_msg_001 ("end flg_do_not_touch = %d\r\n", flg_do_not_touch);

    return 0;
}

//
//
DWORD WINAPI MyThreadFunction_002(LPVOID lpParam)
{
    HANDLE hStdout;
    PMYDATA pDataArray;
    TCHAR msgBuf[BUF_SIZE];
    size_t cchStringSize;
    DWORD dwChars;
    double one_rand;
    int i, j, s, t;
    int countinued;
    // Make sure there is a console to receive output results. 

//	if ( flg_do_not_touch >= 1 ) {
//		err_msg_001 ("it sounds still in this lootin.\r\n");
//		return -1;
//	} else {
//		flg_do_not_touch = 1;
//		err_msg_001 ("start flg_do_not_touch = %d\r\n", flg_do_not_touch);
//	}

	PlaySound(NULL, 0, 0);
	Sleep(1000);

    flg_do_not_touch = 0;
	err_msg_001 ("end flg_do_not_touch = %d\r\n", flg_do_not_touch);

    return 0;
}

//
//
// c_char: const char*
//
void wErrorHandler_001(const char* c_char) {

    //	TCHAR szAppName[] = TEXT( "TestApp" );
    //	LPSTR lpString= "TestApp";
    //	LPCSTR lpcString= "TestApp";
    LPSTR lpString = (LPSTR)c_char;
    //	lpcString = (LPCSTR) c_char;

    ErrorHandler_001((LPTSTR) lpString);
}

//
void ErrorHandler_001(LPTSTR lpszFunction)
{
    // Retrieve the system error message for the last-error code.

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
    DWORD dw = GetLastError();

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR)&lpMsgBuf,
        0, NULL);

    // Display the error message.

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT,
        (lstrlen((LPCTSTR)lpMsgBuf) + lstrlen((LPCTSTR)lpszFunction) + 40) * sizeof(TCHAR));
    StringCchPrintf((LPTSTR)lpDisplayBuf,
        LocalSize(lpDisplayBuf) / sizeof(TCHAR),
        TEXT("%s failed with error %d: %s"),
        lpszFunction, dw, lpMsgBuf);
    MessageBox(NULL, (LPCTSTR)lpDisplayBuf, TEXT("Error"), MB_OK);

    // Free error-handling buffer allocations.

    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
}