#ifndef _WORK_002_H_
#define _WORK_002_H_
class WORK_002 { 
	public:
		WORK_003 *iWORK_002=nullptr;

	public:
		SetWORK_003( WORK003 *lWORK003 ); 

};
#endif
