#include <windows.h>

#include<stdio.h>
#include <unistd.h>

#include <stdlib.h>
#include <time.h>

#include <math.h>

#include <mmsystem.h>
#include <vfw.h>


#include "timestamp.h"


#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"
#include "replace_main.h"

#include "replace_main.h"
#include "sounds-work-001.h"


//
// SOUNDSWORK00
//void SOUNDS_WORK_001::SetWORK_001( SOUNDS_WORK_001 *lSOUNDSWORK00 ){ 
void SOUNDS_WORK_001::SetWORK_001(  ){ 
	int i;
	double devide = 8.0;
	double m_pi = 3.1415926535;
	double theta = 0.0;
	double value;

	m_buffer = (char*) malloc ( sizeof(char) * num_buffer );
	if ( m_buffer == NULL ) {
		printf("m_buffer is NULL\r\n");
		exit(-1);
	}

	for ( i = 0; i<num_buffer; i++ ) {
		theta = ((double ) i ) *  m_pi * 2.0 / devide;
		value = ( sin(theta) + 1.0 ) * 255.0;
		m_buffer[i] = (char)value;
	}
}

    void SOUNDS_WORK_001::Play()
    {
        // Create our "Sound is Done" event
        m_done = CreateEvent (0, FALSE, FALSE, 0);

        // Open the audio device
//        if (waveOutOpen(&m_waveOut, 0, &m_waveFormat, (DWORD) m_done, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) 
        if (waveOutOpen(&m_waveOut, WAVE_MAPPER, &m_waveFormat, (DWORD) m_done, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) 
        {
            //cout << "Sound card cannot be opened." << endl;
            return;
        }

        // Create the wave header for our sound buffer
        m_waveHeader.lpData = m_buffer;
        m_waveHeader.dwBufferLength = num_buffer;
        m_waveHeader.dwFlags = 0;
        m_waveHeader.dwLoops = 0;

        // Prepare the header for playback on sound card
        if (waveOutPrepareHeader(m_waveOut, &m_waveHeader, sizeof(m_waveHeader)) != MMSYSERR_NOERROR)
        {
            //cout << "Error preparing Header!" << endl;
            return;
        }

        // Play the sound!
        ResetEvent(m_done); // Reset our Event so it is non-signaled, it will be signaled again with buffer finished

        if (waveOutWrite(m_waveOut, &m_waveHeader, sizeof(m_waveHeader)) != MMSYSERR_NOERROR)
        {
            //cout << "Error writing to sound card!" << endl;
            return;
        }

		//cout << "wait for." << endl;
        // Wait until sound finishes playing
//        if (WaitForSingleObject(m_done, INFINITE) != WAIT_OBJECT_0)
        if (WaitForSingleObject(m_done, 2 * 1000) != WAIT_OBJECT_0)
        {
            //cout << "Error waiting for sound to finish" << endl;
            return;
        }

        // Unprepare our wav head
        if (waveOutUnprepareHeader(m_waveOut, &m_waveHeader,sizeof(m_waveHeader)) != MMSYSERR_NOERROR)
        {
            //cout << "Error unpreparing header!" << endl;
            return;
        }

        // Close the wav device
        if (waveOutClose(m_waveOut) != MMSYSERR_NOERROR)
        {
            //cout << "Sound card cannot be closed!" << endl;
            return;
        }

        // Release our event handle
        CloseHandle(m_done);
    }


