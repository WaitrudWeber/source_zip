//
char* m_concat( char *head, char *tail ) {
	int nh, nt;
	static int alloc = 0;
	char* c_head;
	char* result = NULL;
	char* l_dummy_allocation_001 = NULL;

	printf("start function: m_concat:\r\n");

	nh = array_count( head );
	nt = array_count( tail );
	printf("array_count: %d %d | %s %s \r\n", nh, nt, head, tail);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		} else {
			break;
		}
	}

	if ( alloc == 0 ) {
		alloc = 1;
		for ( int i=0; i<100; i++) {
			l_dummy_allocation_001 = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
			if ( l_dummy_allocation_001 != NULL ) break;

			sleep(1);
			char* d_a = (char *) malloc( 1 );
			free(d_a);
		}
		alloc = 0;
	}

	if (l_dummy_allocation_001==NULL) {
		printf("l_dummy_allocation_001 is null.\r\n");
		exit(-1);
	}

	for( int i=0; i< nh; i++ ) {
		*( l_dummy_allocation_001 + i ) = *(head + i);
	}

	for( int i=0; i< nt; i++ ) {
		printf("function m_concat: i %d\r\n", i);
		*( l_dummy_allocation_001 + nh + i ) = *(tail + i);
	}

	// 2 + 2 = 4 p[4] = "\n"
	*( l_dummy_allocation_001 + nh + nt ) = '\0';
	result = copyof_002 (l_dummy_allocation_001);
	printf("011: result|%p|=|%d| l_dummy_allocation_001|%p|=|%d|\r\n", result, array_count(result), l_dummy_allocation_001, array_count(l_dummy_allocation_001) );
	free(l_dummy_allocation_001);

	printf("012: result|%p|=|%s|\r\n", result, array_count(result) );
	return result;
}
