#ifndef _WORK_001_H_
#define _WORK_001_H_
class WORK_001 { 
	public:
		WORK_002 *iWORK_001=nullptr;

	public:
		SetWORK_002( WORK002 *lWORK002 ); 

};
#endif
