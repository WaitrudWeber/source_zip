#include <stdio.h>
#include <stdlib.h>

#include "parse.h"

int m_mode = 0; // start outside class
int m_cnt_tkn = 0;
int m_count = 0;
int m_size = 0;
int m_line = 1;
int m_raw = 1;
char* m_filename;

char* token;

char* string_allocation (int size) ;
char* put_token (char c);
int initialize_parse ();
void m_counter ( char c );
int m_fread ( char* dummy, int a, FILE *fp) ;

/*
int main ( int argc, char *argv[] ) {

	FILE *fp;
	fp = fopen ( argv[1], "rb" );
	char dummy[1];

	m_size = 256;
	token = (char * )string_allocation ( m_size );


	for( int i=0; i<10; i++ ) {

		char c = fread ( dummy, 1, 1, fp);
		token = put_token ( dummy[0] );
//		printf( "%d %d\n", *token, token);
//		printf ("%s dummy=%s token[%d]=%d\n", dummy, token, i, token[i] );
	}

	return 0;
}
*/

int m_fread ( char* dummy, int a, FILE *fp) {
	fread ( dummy, 1, a, fp);
	char c = dummy[0];

	//printf("m_fread: %s c_num: %d line: %d raw: %d\n", dummy, c, m_line, m_raw );

	m_counter ( c );

	return 1;
}

int initialize_parse () {
	m_size = 256;
	token = (char * )string_allocation ( m_size );

	return 0;
}

char* put_token (char c) {
	char *dummy;

	// 20280420 problem solution temporarily.
	// 1. token[0] is line end.
	// 2. at least analyzer is trying to analyze program keyword ( means not skkipping ).
	if ( m_cnt_tkn == 0 && c == '\n' ) {
		printf( "m_mode: %d token[0] is line end. filename %s: line %d raw %d", m_mode, m_filename, m_line, m_raw );
		exit ( -1 );
	} 






	m_cnt_tkn++;
	//m_counter ( c );

	if ( m_size <= m_cnt_tkn ) {
		m_size *= 2;
		dummy = (char * )string_allocation ( m_size );
		for ( int i=0; i< m_size/2; i++) {
			*( dummy + i ) = *( token + i );
		}
		free(token);
		token = dummy;
	}

	*( token + m_cnt_tkn - 1) = c;
	*( token + m_cnt_tkn ) = '\0';

/*
	for( int i=0; i<m_count; i++ ) {
		printf ( "c %d i %d token[%d]=%d token: %s\n", c, i, i, token[ i ], token );
	}
*/

//	printf ( "c %d m_count %d token[%d]=%d token: %s\n", c, m_count - 1, m_count - 1, token[ m_count - 1 ], token );
	return token;
}

void m_counter ( char c ) {

	switch ( c ) {
	case '\n':
		m_line++;
		m_raw = 0;
		break;
	}

	m_raw++;
	m_count++;
}

/*
char* string_read ( FILE *fp, int size ) {

	if ( size > m_size ) {
		m_size = size;
	}

	token = (char * )string_allocation ( m_size );
	//result = fread ( buffer, 1, size, fp );
}
*/

char* string_allocation (int size) {
	char * buffer;

	buffer = (char*) malloc ( sizeof(char) * size );

	return buffer;
}



