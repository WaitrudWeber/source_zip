#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "parse.h"


/*

	0: libraries
	1: class
	2: method
	3: 

*/


int parse ( char* filename );
int parse_origin ( char* filename );

// do not use usually.
int parse_slash ( int index, int file_end, FILE *fp );
int parse_check_counter ( FILE *fp, int file_end );

int parse_libraries ( FILE *fp, int file_end  );
int parse_class ( FILE *fp, int file_end );
int parse_method ( FILE *fp, int file_end );

int parse_library_name ( FILE *fp, int file_end );
int parse_comment_out ( FILE *fp, int file_end );

int token_check( );
int filesize( FILE *fp );
int analyze ( char* tkn );

int analyze_libraries ( char* tkn );
int compare ( char* tkn, char* m );


int main ( int argc, char *argv[] ) {

	initialize_parse();
	m_filename = argv[1];
	parse ( argv[1] );

	//token_check ();

	return 0;
}

int token_check( ) {

	token[0] = 'a';

	printf("%d\n", token[0]);

	return 0;
}

int filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}

int parse_check_counter ( FILE *fp, int file_end ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		printf ( "i=%d c=%s c=%d m_count=%d m_cnt_tkn=%d m_size=%d\n", i, (char*)dummy, (int)dummy[0], m_count, m_cnt_tkn, m_size );

		token = put_token ( dummy[0] );
	}

	printf("token:%s\n", token );
	return 1;
}

int parse_libraries ( FILE *fp, int file_end ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
//		printf ( "i=%d fp=%d c=%s c=%d m_count=%d\n", i, *fp, (char*)dummy, (int)dummy[0], m_count);
//		printf ( "i=%d c=%s c=%d m_count=%d m_cnt_tkn=%d m_size=%d\n", i, (char*)dummy, (int)dummy[0], m_count, m_cnt_tkn, m_size );

		switch ( dummy[0] ) {
		case ' ':
			analyze_libraries ( token );
			parse_library_name ( fp, file_end );
			break;
		case '/':
			if ( parse_comment_out ( fp, file_end ) == 1 ) return 1;
			break;
		}

		token = put_token ( dummy[0] );
	}

	return 1;
}

int parse_comment_out ( FILE *fp, int file_end ) {
	char dummy[1];
	int flag = 0;
	// 0, 1  -> to line end.
	// 10, 11 -> to */.

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( flag ) {
		case 0:
			switch ( dummy[0] ) {
			case '/':
				flag = 1; // to line end
				break;
			case '*':
				flag = 10; // to */
				break;
			}
			break;
		case 1:
			switch ( dummy[0] ) {
			case '\n':
				return 1;
				break;
			default:
				break;
			}
			break;
		case 10:
			switch ( dummy[0] ) {
			case '*':
				flag = 11;
				break;
			default:
				break;
			}
			break;
		case 11:
			switch ( dummy[0] ) {
			case '/':
				return 1;
			default:
				flag = 10;
			}
			break;
		}

		//token = put_token ( dummy[0] );
	}

	printf("comment out end: line %d raw %d\n", m_line, m_raw);
	exit( -1 );
}

int parse_library_name ( FILE *fp, int file_end ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( dummy[0] ) {
//		case ' ':
//			break;
		case ';':
			break;
		}

		token = put_token ( dummy[0] );
	}
	printf ( "token=%s\n", token ) ;

	return 1;
}

int parse_class ( FILE *fp, int file_end  ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);

		switch ( dummy[0] ) {
		case ' ':
			break;
		case '/':
			break;
		}
	}

	return 1;
}

int parse_method ( FILE *fp, int file_end  ) {
	char dummy[1];

	for( int i=0; i<file_end; i++ ) {
		m_fread ( dummy, 1, fp);
		switch ( dummy[0] ) {
		case ' ':
			break;
		case '/':
			break;
		}
	}

	return 1;
}

int parse ( char* filename ) {

	FILE *fp;
//	char dummy[1];

	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end; i++ ) {
		switch ( m_mode ) {
		case 0:
			parse_libraries ( fp, file_end );
			break;
		case 1:
			parse_class ( fp, file_end );
			break;
		case 2:
			parse_method ( fp, file_end );
			break;
		}
	}

	fclose(fp);

	return 1;
}

int parse_origin ( char* filename ) {

	FILE *fp;
	fp = fopen ( filename, "rb" );
	char dummy[1];

	int file_end = filesize ( fp );

	for( int i=0; i<file_end; i++ ) {

		m_fread ( dummy, 1, fp);

		switch( dummy[0] ) {
		case ' ':
			analyze ( token ) ;
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		token = put_token ( dummy[0] );
//		printf( "%d %d\n", *token, token);
		printf ("dummy=%s token=%s token[%d]=%d token[%d]=%d\n", dummy, token, i, token[i], i + 1, token[ i + 1] );
	}

	printf("token=%s\n", token);

	for( int i=0; i<file_end; i++ ) {

		switch( dummy[0] ) {
		case ' ':
			break;
		case '/':
			parse_slash( i, file_end, fp);
			break;
		}

		printf( "%d\n", token[i] );
	}

	fclose(fp);

	return 0;
}


int analyze_libraries ( char* tkn ) {

	printf("analyze libraries line %d raw %d it's not keyword: %s\n", m_line, m_raw, tkn );
	exit(-1);


	if ( compare ( tkn, (char *)"package" )  == 1 ) {

		//printf("it's not keyword: %s\n", tkn );
	} else if ( compare ( tkn, (char *)"import" ) == 1 ) {

		//printf("it's not keyword: %s\n", tkn );
	} else {

		printf("line %d raw %d it's not keyword: %s\n", m_line, m_raw, tkn );
		exit(-1);
	}

	return 1;
}

int compare ( char* tkn, char* m ) {

	int count_t = array_count( m );
	int count_m = array_count( m );

	if ( count_t != count_m ) return -1;

	// match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) return -1;
	}

	return 1;
}

int analyze ( char* tkn ) {

	m_mode = 0;
	
	switch(m_mode) {
	case 0:
		// keyword outside class
		printf("%s\n", tkn );
		exit( -1 );
		//analyze_libraries( tkn );
		break;
	case 1:
		// name outside class
		break;
	case 2:
		break;
	}

	return 0;
}

int parse_slash ( int index, int file_end, FILE *fp ) {

	char dummy[1];

	for( int i=index; i<file_end; i++ ) {

		m_fread ( dummy, 1, fp);
	}

	return 0;
}



