#include <stdio.h>
#include <stdlib.h>

#include "vPoint.h"
#include "vLine.h"
#include "vCalculation.h"
#include "vRailCurtain.h"


void vRailCurtain::Calculation () {
	

}

void vRailCurtain::Initialization () {

	int width = 30;
	int height = 40;

	double d_width = 50.0f;
	double d_height = 50.0f;

	// 30 X 40
	this->points = (vPoint***) malloc ( sizeof(vPoint***) * width );
	for( int i=0; i<width; i++) {
		this->points[i] = (vPoint**) malloc ( sizeof (vPoint**) * height);
	}

	for( int i=0; i<width; i++) {
		for( int j=0; j<height; j++) {
//			this->points[i][j] = new vPoint();
			this->points[i][j] = memorizevPoint(  (float)d_width, 0.0f, (float)d_height );
			d_height += 50.0f;
		}
		d_width + 50.f;
	}

}


