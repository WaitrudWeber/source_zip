#ifndef _SENDER_H_
#define _SENDER_H_
//
//
//
//
//
extern int sender_main ( int argc, char **argv) ;
extern int set_sender_default_parameters ( int *argc, char **argv );

#endif
