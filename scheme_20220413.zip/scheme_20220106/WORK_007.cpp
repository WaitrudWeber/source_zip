#include "WORK_007.h"
#include "WORK_008.h"
void WORK_007::SetWORK_008( WORK008 *lWORK008 ){ 

}
