#include "WORK_002.h"
#include "WORK_003.h"
void WORK_002::SetWORK_003( WORK003 *lWORK003 ){ 

}
