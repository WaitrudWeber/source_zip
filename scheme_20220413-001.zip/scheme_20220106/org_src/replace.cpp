#include <stdio.h>
#include <windows.h>
#include <unistd.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "replace.h"

/*
typedef struct {
	FILE *fp;
	FILE *file_start;
	int index;
	int file_end_index;
} STRUCT_FILE; */

int filesize( FILE *fp ) ;

char lines[10][10];
char dummy[256];
char g_dummy[255];
static char*** csv = NULL;



int analyze_main () ;
int retrieve (char* filename) ;
int found_enter (char* filename) ;


int found_level1 (char* filename) ;
int a_compare (char* s1, char* s2 ) ;

int found_enter_002 (char* filename) ;
int found_enter_001 (char* filename) ;
int found_enter_003 (char* filename) ; // find "moov"
int found_enter_004 (char* filename) ; // find "---" and "\r\n"
int read_csv (char* filename ) ;
int read_csv_010 (char* filename ) ;


int found_level_001 (int index, int file_end, FILE *fp ) ;
int found_level_002 (int index, int file_end, FILE *fp ) ;
int found_start (char* filename) ;
char* read_to ( char* to, int index, int file_end, FILE *fp ) ;
int start_readline (char* filename ) ;

char get_char ( STRUCT_FILE structure_fp) ;
char* get_string ( STRUCT_FILE structure_fp, int num ) ;

int write_block( char* w_filename, char* c_string ) ;
int replace_csv_001 (char*** csv, char* form_file ) ;
int replace_csv ( char* form_file, char* write_file ) ;
char* read_all (char* filename ) ;
int print_csv () ;

int checkf_replace () ;
int checkf_set_csv () ;
int checkf_print_csv () ;

int check_null(char*** csv, int i, int j) ;
int print_csv_target(int i, int j ) ;
char* no_double_quote(char* string_001 ) ;

int m_thread_sleep ();

int m_thread_sleep () {
	Sleep(500);
}

int replace_main () {

	int ini = initialize_parse ();

	//int a = found_enter_003(".\\SANY0208\.MP4");
	//int a = found_enter_004(".\\001-20210114-004-C-001\.txt");
	int a = read_csv(".\\001-csv-20210210-001\.txt");
	int a_002 = print_csv ();
//	int b = replace_csv ( ".\\001-form-20210211-001\.txt");
	int c = print_csv ();

/*	int a001 = checkf_replace ();
	int b = checkf_set_csv ();
	int c = checkf_print_csv ();
	int d = replace_csv ( csv,  ".\\001-form-20210211-001\.txt");
	int e = checkf_print_csv ();
*/
	return 0;
}

int checkf_print_csv () {
	err_msg_001("checkf_print_csv starts.\r\n");
	print_csv ();
	err_msg_001("checkf_print_csv ends.\r\n");
}


int checkf_set_csv () {
	err_msg_001("checkf_set_csv starts.\r\n");

	char* c = "$set_string";

	if ( csv == NULL ) {
		csv = (char***) malloc( sizeof(char**) * 10 );
	}

	for( int i = 0; i<10; i++ ) {
		csv[i] = (char**) malloc ( sizeof(char**) * 10  );
	}

	for( int i=0; i<10; i++ ) {
		for( int j=0; j<10; j++ ) {
			csv[i][j] = (char*) copyof ("set_string");
		}
	}

	print_csv ();
	m_thread_sleep ();
	err_msg_001("checkf_set_csv ends.\r\n");
	return 0;
}

int checkf_replace () {
	err_msg_001("checkf replace starts.\r\n");
	char* c_str = m_replace ( (char*)"aaabbbccc", (char*)"aaa", (char*)"dd");
	c_str = m_replace ( c_str, "cc", "ee");

	err_msg_001("cstr: |%s|\r\n", c_str);

	err_msg_001("checkf replace ends.\r\n");
	return 0;
}

int print_csv () {
	err_msg_001("we are going to print csv:\r\n");
	print_csv_target( 0, 4 );
	for( int i =0; i<10; i++ ) {
		for( int j =0; j<10; j++ ) {
			if ( check_null ( csv, i, j ) == 1 ) 
				err_msg_001(" %d %d |%s|\r\n", i, j, csv[i][j] );
		}
	}
}

//
int print_csv_target(int i, int j ) {
	err_msg_001("int print_csv_target(int i, int j ) starts. %d %d \r\n", i, j );

	err_msg_001("csv %d %d |%s|\r\n" , i, j, csv[i][j]);

	err_msg_001("int print_csv_target(int i, int j ) ends. %d %d \r\n", i, j );
	return 1;
}

//
int check_null(char*** csv, int i, int j) {
	err_msg_001("int check_null(char*** csv, int i, int j) starts. %d %d \r\n", i, j );

	if (csv == NULL ) return -1;
	if (csv[i] == NULL ) return -1;
	if (csv[i][j] == NULL ) return -1;

	err_msg_001("int check_null(char*** csv, int i, int j) ends. |%s|\r\n", csv[i][j]);
	return 1;
}

//
// : https://www.cprogrammingbasics.com/itoa-function-in-c/
int replace_csv ( char* form_file, char* write_file ) {
	char str_num[10];
	char* string;
	err_msg_001("replace_csv starts.\r\n");
	m_thread_sleep();
	// if we read a file all, memorization is changed wrong.
	string = read_all(form_file);

	for( int i =0; i<3; i++ ) {
		for( int j =0; j<3; j++ ) {
			sprintf( str_num, "$%d%d", i, j );
//			err_msg_001("i %d j %d {%p} |%s|: ", i, j, csv[i][j], (char*)csv[i][j]);
			if ( csv[i][j] != nullptr ) {
				int a_001 = array_count ( string );
				string = m_replace ( string, str_num, no_double_quote( m_trim(csv[i][j]) ) );
				int a_002 = array_count ( string );
				// debug 20210316
				if ( abs ( a_001 - a_002 ) > 500 ) {
					err_msg_001("replaced string is changed a lot, so, it's going to exit.\r\n|%s|\r\n", string);
					exit(-1);
				}
			}

			err_msg_001("replace: %d %d |%s|%s|:\r\n|%s|\r\n", i, j, str_num, csv[i][j], string);
			m_thread_sleep();
		}
	}

	write_block( write_file, string );
	err_msg_001("replace_csv ends.\r\n");
	return -1;
}

//
// : https://www.cprogrammingbasics.com/itoa-function-in-c/
int replace_csv_001 (char*** csv, char* form_file ) {
	char str_num[10];
	char* string;
	err_msg_001("replace_csv starts.\r\n");
	m_thread_sleep();

	string = read_all(form_file);

	for( int i =0; i<3; i++ ) {
		for( int j =0; j<3; j++ ) {
			sprintf( str_num, "$%d%d", i, j );
			if ( csv[i][j] != nullptr )
				string = m_replace ( string, str_num, no_double_quote( m_trim(csv[i][j]) ) );

			err_msg_001("replace: %d %d |%s|%s|:\r\n|%s|\r\n", i, j, str_num, csv[i][j], string);
			m_thread_sleep();
		}
	}

	write_block( ".\\001-html-20210211-001\.txt", string );
	err_msg_001("replace_csv ends.\r\n");
	return -1;
}

//
char* no_double_quote(char* string_001 ) {
	static int count = 0;
	char* result;
	char* head = string_001;
	err_msg_001("head |%s|\r\n", head);
	char a = *string_001;
	int ac = array_count(string_001);
	char b = *(string_001 + ac - 1 );
	string_001 = head;
	err_msg_001("a|%d| b|%d| / ac = %d string_001|%s| head|%s|\r\n", a, b, ac, string_001, head);

	if ( a == b && a == '"' ) {
		result = m_substring ( string_001, 1, ac - 1);
		err_msg_001("takeout_double_quote return %s\r\n", result);
		//if ( m_contains (string_001, "He" ) == 1 ) exit(-1);
		return result;
	}

/*	err_msg_001("no_double_quote return |%s|\r\n", string_001);
	if ( m_contains (string_001, "He is" ) == 1 ) {
		err_msg_001("He is |%d|%d| b|%d| space|%d| m_trim|%s|\r\n", '\r', '\n', b, ' ', m_trim(string_001) );
		exit(-1);
	}
*/
	result = copyof(string_001);
	if ( count == 1 ) {
		err_msg_001("count %d result|%s|\r\n", count, result);
//		exit (-1);
	}
	count++;
	return result;
}

//
char* read_all (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;

	err_msg_001("read_all starts.\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <10000; i++ ) {

		err_msg_001("i: %d loop starts. ", i );
		err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 1);
		p_dummy[1] = '\0';

		p_dummy_token = put_token( p_dummy[0] );
	}

	fclose(structure_fp.fp);
	err_msg_001("read_all ends.\r\n");

	return p_dummy_token;
}

int read_csv_010 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;
	int quote = 0; // start:0, end:1
	int skip_kind = 0; // not work:0, skip space:1 
	int book = 0;
	int f_line_end = 0;
	int add_litter = 1;

	err_msg_001("read_cs_\010: starts.\r\n");

	if ( csv == NULL ) {
		csv = (char***) malloc( sizeof(char**) * 10 );
	}

	for( int i = 0; i<10; i++ ) {
		csv[i] = (char**) malloc ( sizeof(char**) * 10  );
	}

	err_msg_001("we are going to initialize csv:\r\n");
	// Initialize additional at 20210310.
	for( int i =0; i<10; i++ ) {
		for( int j =0; j<10; j++ ) {
			//err_msg_001("001 csv %d %d ", i, j);
			err_msg_001("001 csv %d %d \r\n", i, j);
			csv[i][j] = NULL;
			err_msg_001("|%s|\r\n", csv[i][j]);
		}
	}

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	int ini = initialize_parse ();

	err_msg_001("in read_csv at loop top,\r\n");
	err_msg_001("csv %d %d |%s|\r\n", 0, 4, csv[0][4]);

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		err_msg_001("i: %d loop starts. ", i );
		err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

		book = 0;
		canread = 1;
		add_litter = 1;
		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 1 ) {
			err_msg_001("we could find line end.\r\n");
			index++;
			i++;
			f_line_end = 1;
			book = 1;
			canread = 0;

			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "," ) == 1 && skip_kind==3 && canread == 1 ) {
			err_msg_001("we could find comma.csv|%p| and p_dummy_token |%p| but it should be going well, which means it doesn7t stop to reading between quates.\r\n", csv[index][col], p_dummy_token);
			add_litter = 1;
			canread = 0;

		} else if ( m_start_with ( (char*)p_dummy, "," ) == 1 && skip_kind==1 && canread == 1 ) {
			err_msg_001("we could find comma.csv|%p| and p_dummy_token |%p|\r\n", csv[index][col], p_dummy_token);
			clear_token();
			aFree ( p_dummy_token );

			add_litter = 0;
			skip_kind = 0;
			canread = 0;

			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "," ) == 1 && skip_kind==0 && canread == 1 ) {
			err_msg_001("we could find comma.csv|%p|<- as |%p|\r\n", csv[index][col], p_dummy_token);

			skip_kind = 0;
			add_litter = 0;
			book = 1;
			canread = 0;

			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && quote == 0 && canread == 1 ) {
			err_msg_001("we could find double quote at the start.\r\n");
			clear_token();
			aFree ( p_dummy_token );
			quote = 1;
			skip_kind = 3;
			canread = 0;

			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && quote == 1 && canread == 1 ) { // end of quate.
			err_msg_001("we could find double quote at the end.\r\n");

			skip_kind = 1;
			quote = 0;

			add_litter = 1;
			book = 1;
			canread = 0;

			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 1 ) {
			err_msg_001("Error: we could find enter before finding double quote end.\r\n");
			csv[index][col] = (char*) copyof_001(p_dummy_token);
			clear_token();
			i++;
			aFree ( p_dummy_token );
			m_thread_sleep();
			exit(-1);
		} else {
			err_msg_001("Any other default:\r\n");
		}

		if ( add_litter == 1 ) {
			err_msg_001("ADD Litter |%s||%c|\r\n", p_dummy_token, p_dummy[0] );
			p_dummy_token = put_token_010 ( p_dummy[0] );
			add_litter = 0;
		}

		if ( book == 1 ) {
			err_msg_001("BOOK |%s|\r\n", p_dummy_token );
			csv[index][col] = (char*) copyof_001(p_dummy_token);
			err_msg_001("set csv[%d][%d] = |%s|.\r\n", index, col, csv[index][col] );
			col++;
			clear_token();
			aFree ( p_dummy_token );
			book = 0;
			if ( f_line_end == 1 ) {
				col = 0;
				f_line_end = 0;
			}
		}

		err_msg_001("i: %d loop ends. \r\n", i );
	}

	err_msg_001("in read_csv,\r\n");
	err_msg_001("csv %d %d |%s|\r\n", 0, 4, csv[0][4]);
	print_csv_target( 0, 4 );
	print_csv();

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );
	err_msg_001("read_csv_010: ends.\r\n");
	return 0;
}



int read_csv (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];
	int index = 0;
	int col = 0;

	err_msg_001("read_csv: starts.\r\n");

	if ( csv == NULL ) {
		csv = (char***) malloc( sizeof(char**) * 10 );
	}

	for( int i = 0; i<10; i++ ) {
		csv[i] = (char**) malloc ( sizeof(char**) * 10  );
	}

	err_msg_001("we are going to initialize csv:\r\n");
	// Initialize additional at 20210310.
	for( int i =0; i<10; i++ ) {
		for( int j =0; j<10; j++ ) {
			//err_msg_001("001 csv %d %d ", i, j);
			err_msg_001("001 csv %d %d \r\n", i, j);
			csv[i][j] = NULL;
			err_msg_001("|%s|\r\n", csv[i][j]);
		}
	}

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 1;
	int ini = initialize_parse ();

	err_msg_001("in read_csv at loop top,\r\n");
	err_msg_001("csv %d %d |%s|\r\n", 0, 4, csv[0][4]);

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		err_msg_001("i: %d loop starts. ", i );
		err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 1 ) {
			err_msg_001("we could find line end.\r\n");
			csv[index][col] = (char*) copyof_001(p_dummy_token);
			err_msg_001("set csv[%d][%d] = |%s|.\r\n", index, col, csv[index][col] );
			clear_token();
			index++;
			col = 0;
			i++;
			aFree ( p_dummy_token );
			m_thread_sleep();
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "," ) == 1 && canread == 1  ) {
			err_msg_001("we could find comma.csv|%p|<- as |%p|\r\n", csv[index][col], p_dummy_token);
			csv[index][col] = (char*) copyof_001(p_dummy_token);
			err_msg_001("set csv[%d][%d] = |%s|.\r\n", index, col, csv[index][col] );
			col++;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
			continue;
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && canread == 1 ) {
			err_msg_001("we could find double quote at the start.\r\n");
			canread = 0;
			clear_token();
			aFree ( p_dummy_token );
			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "\"" ) == 1 && canread == 0 ) {
			err_msg_001("we could find double quote at the end.\r\n");
			canread = 1;
			m_thread_sleep();
		} else if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 0 ) {
			err_msg_001("Error: we could find enter before finding double quote end.\r\n");
			csv[index][col] = (char*) copyof_001(p_dummy_token);
			clear_token();
			i++;
			aFree ( p_dummy_token );
			m_thread_sleep();
			exit(-1);
		} else {
			err_msg_001("Any other default:\r\n");
		}

		p_dummy_token = put_token( p_dummy[0] );
	}

	err_msg_001("in read_csv,\r\n");
	err_msg_001("csv %d %d |%s|\r\n", 0, 4, csv[0][4]);
	print_csv_target( 0, 4 );
	print_csv();

	fclose ( structure_fp.fp );

	aFree ( p_dummy_token );
	err_msg_001("read_csv: ends.\r\n");
	return 0;
}

//
//
//
//
//
int found_enter_004 (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;
	int canread;
	char* block_string;
	int b_index = 0;
	char w_filename[255];

	err_msg_001("found_enter_004: starts.\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	canread = 0;

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <1000; i++ ) {

		err_msg_001("i: %d loop starts. ", i );
		err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1 && canread == 0 ) {
			err_msg_001("we could find line end.\r\n");
			canread = 1;
//			exit(-1);
		} else if ( m_start_with ( (char*)p_dummy, "---" ) == 1  && canread == 1 ) {
			err_msg_001("we could find canread=%d.\r\n", canread);
			canread = 2; // skip
			//block_string = copyof ( p_dummy_token ); //20210118
			sprintf(w_filename, "block-%04d-001-01.txt", b_index );
			err_msg_001("block %d %s |%s|\r\n", b_index, w_filename, block_string);
			b_index++;
//			exit(-1);
		} else if ( m_start_with ( (char*)p_dummy, "\r\n" ) == 1  && canread == 2 ) {

			err_msg_001("block %s |%s|\r\n", w_filename, p_dummy_token); //20210118
			write_block( w_filename, p_dummy_token);
			err_msg_001("write_block: %s\r\n", w_filename);
			canread = 1;
			int ini = initialize_parse ();
			m_thread_sleep();
			//exit(-1);
		}

		p_dummy_token = put_token( p_dummy[0] );

		err_msg_001("block %s |%s|\r\n", w_filename, p_dummy_token); //20210118
		write_block( w_filename, p_dummy_token);
		err_msg_001("write_block: %s\r\n", w_filename);

		err_msg_001("bi:%d canread=%d i: %d: |%s| |%s|\r\n", b_index, canread, i, p_dummy, p_dummy_token );
	}

	err_msg_001("found_enter_004: ends.\r\n");
	return 0;
}


//
//
//
int write_block( char* w_filename, char* c_string ) {
	FILE *wfp;
	int ac;

	err_msg_001("write_block starts.\r\n");

	wfp = fopen( w_filename, "wb");

	ac = array_count ( c_string );

	fwrite( c_string, sizeof(char), ac, wfp);
	err_msg_001("cstring:\r\n|%s|\r\n", c_string);

	fclose(wfp);

	err_msg_001("write_block ends.\r\n");
}

//
//
//
//
//
int found_enter_003 (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;
	char* p_dummy_token = NULL;

	err_msg_001("found_enter_003: starts\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;

	// Lootn check if we set 100 to the text file.
	for ( i =0; i<file_end && i <100; i++ ) {

		err_msg_001("i: %d loop starts. ", i );
		err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 4);
		p_dummy[4] = '\0';

		if ( m_compare( (char*)p_dummy, "moov" ) == 1 ) {
			err_msg_001("we could find moov.\r\n");
			exit(-1);
		}

		p_dummy_token = put_token(p_dummy[0]);

		err_msg_001("i: %d: |%s| |%s|\r\n", i, p_dummy, p_dummy_token );
	}

	err_msg_001("found_enter_003: ends\r\n");
	return 0;
}



//
//
//
//
//
int start_readline (char* filename ) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	char* a_line = NULL;

	err_msg_001("start_readline: starts: filename %s\r\n", filename);

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i = 0; i<file_end && i<100; i++ ) {
		a_line = read_to ( "\r\n", i, file_end, fp );
		err_msg_001("a_line %s\r\n", a_line);
	}

	err_msg_001("start_readline: ends\r\n");
}

//
//
//
//
//
char* read_to ( char* to, int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;
	int count = 0;

	err_msg_001("read_to starts to |%s|.\r\n", (char*) to);

	tfp = fp;
	for ( j=0; j<256; j++ ) {
		b_dummy[j] = '\0';
	}

	for ( i =index; i<file_end && count<100; i++ ) {
		err_msg_001("i: %d loop starts.\r\n", i );

		for ( j=254; j>=0; j-- ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		/*if ( a_compare( (char*)b_dummy, to ) == 1 ) {
			err_msg_001("We found |%s| as |%s| index %d i %d tfp %d fp %d\ return 2r\n", to, b_dummy, index, i, tfp, fp);
			//return NULL;
			exit(-1);
		}*/

		count++;
		err_msg_001("i: %d loop ends.\r\n", i );
	}
	err_msg_001("read_to ends.\r\n");

	return NULL;
}


// From Head :
// 
// int index    :
// int file_end :
// FILE*     fp :
int found_level_001 (int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;
	char keyword[2][5] = { "#", "/*" };
//	char* keyword[2] = { "---", "/*" };
	int count = 0;

	err_msg_001("found_level_001 starts.\r\n");

	tfp = fp;
	for ( j=0; j<256; j++ ) {
		b_dummy[j] = '\0';
	}

	for ( i =index; i<file_end && count<100; i++ ) {
		err_msg_001("i: %d loop starts.\r\n", i );

		for ( j=254; j>=0; j-- ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( a_compare( (char*)b_dummy, (char *)keyword[0] ) == 1 ) {
			err_msg_001("We found |%s| as |%s| index %d i %d tfp %d fp %d\ return 2r\n", keyword[0], b_dummy, index, i, tfp, fp);
			return 2;
		}

		count++;
		err_msg_001("i: %d loop ends.\r\n", i );
	}

	err_msg_001("found_level_001 ends.\r\n");
}

/*

// From Head :
// 
// int index    :
// int file_end :
// FILE*     fp :
int found_level_001 (int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;
//	char keyword[2][5] = { "#", "/*" };
	char* keyword[2] = { "#", "/*" };

	tfp = fp;
	for ( j=0; j<256; j++ ) {
		b_dummy[j] = '\0';
	}

	for ( i =index; i<file_end; i++ ) {
		err_msg_001("i: %d loop starts.\r\n", i );

		for ( j=254; j>=0; j-- ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

//		if ( a_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
		if ( a_compare( (char*)b_dummy, (char*)keyword[0] ) == 1 ) {
			err_msg_001("We found Sharp |%s| index %d i %d tfp %d fp�@%d\r\n", b_dummy, index, i, tfp, fp);
			found_level_002 ( i + 1, file_end, fp );
			exit( -1 );
		}

		err_msg_001("i: %d loop ends.\r\n", i );
	}
}
*/
// From Head :
// 
// int index    :
// int file_end :
// FILE*     fp :
int found_level_002 (int index, int file_end, FILE *fp ) {
	char b_dummy[256];
	int i, j ;
	FILE *tfp;
//	char keyword[2][5] = { "#", "/*" };
	char* keyword[2] = { "\r\n", "/*" };
	int count = 0;

	err_msg_001("found_level_002 starts.\r\n");

	tfp = fp;
	for ( j=0; j<256; j++ ) {
		b_dummy[j] = '\0';
	}

	for ( i =index; i<file_end && count < 100; i++ ) {
		err_msg_001("i: %d loop starts.\r\n", i );

		for ( j=254; j>=0; j-- ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = (char) dummy[0];

		// put_tokene is still useful if you don't like b_dummy.
		if ( a_compare( (char*)b_dummy, (char*)keyword[0] ) == 1 ) {
			err_msg_001("We found Enter |%s|%s| index %d i %d tfp %d fp�@%d count %d\r\n", b_dummy, keyword[0], index, i, tfp, fp, count);
			exit( -1 );
		}

		count++;
		err_msg_001("i: %d loop ends. |%s| next |%d| end|%d| count %d level_002\r\n", i,  b_dummy, b_dummy[1], b_dummy[count],  count );
	}

	for ( i =0; i<count; i++ ) {
		err_msg_001("i %d |%d| |%s| in level_002\r\n", i, b_dummy[i], b_dummy  );
	}

	err_msg_001("found_level_002 ends.\r\n");
}

//
//
//
//
int found_start (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	int a;

	err_msg_001("found_start: starts: filename %s\r\n", filename);

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i = 0; i<file_end && i<100; i++ ) {
		a = found_level_001 ( i, file_end, fp );

		switch ( a ) {
		case 1:
			a = found_level_001 ( i, file_end, fp );
			break;
		case 2:
			a = found_level_002 ( i, file_end, fp );
			break;
		}
	}

	err_msg_001("found_start: ends\r\n");
}

//
//
//
//
int found_level1 (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;

	err_msg_001("found_enter: starts\r\n");

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i =0; i<file_end; i++ ) {

		err_msg_001("i: %d loop starts.\r\n", i );

		for ( j=0; j<255; j++ ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( a_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
			err_msg_001("We found Eenter %s\r\n", b_dummy);
			exit( -1 );
		} else if ( a_compare( (char*)b_dummy, (char*)":" ) == 1 ) {
			err_msg_001("We found colon |%s|\r\n", b_dummy);
			exit( -1 );
		}

		err_msg_001("i: %d: |%d|%d|%d|%d| loop ends.\r\n", i, b_dummy[0], b_dummy[1], '\r', '\n' );

		// We could find flip side:
		//
		//
		if ( b_dummy[0] == 13 && b_dummy[1] == 10 ) {
			b_dummy[2] = '\0';
			err_msg_001("We found Eenter opposite side: |%s|\r\n", b_dummy);
			exit(-1);
		}
	}

	err_msg_001("found_enter: ends\r\n");
	return 0;
}

//
//
//
int a_compare (char* s1, char* s2 ) {
	int c, c1, c2;
	int i;
	char r1, r2;
	int result;
	int sep;

	c1 = array_count(s1);
	c2 = array_count(s2);

	if ( c1 < c2 ) {
		c = c1;
		r2 = s2[c1];	
		s2[c1] = '\0';	
		sep = 0;
	} if ( c1 == c2 ) {
		c = c1;
		sep = 1;
	} else {
		c = c2;
		r1 = s1[c2];	
		s1[c2] = '\0';	
		sep = 2;
	}

	err_msg_001("a_compare|%s||%s| 003\r\n", s1, s2);

	result = m_compare( s1, s2 );



	switch ( sep ) {
	case 0:
		err_msg_001("case sep=0\n");
		s2[c] = r1;
		break;
	case 1:
		err_msg_001("case sep=1\n");
		break;
	case 2:
		err_msg_001("case sep=2\n");
		s1[c] = r2;
		break;
	default:
		break;
	}

	err_msg_001("a_compare ends : result = %d\r\n", result);
	return result;
}

//
//
//
//
//
int found_enter_001 (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;

	err_msg_001("found_enter_001: starts\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;
	
	for ( i =0; i<file_end && i < 10; i++ ) {

		err_msg_001("i: %d loop starts. ", i );
		err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		dummy[0] = get_char( structure_fp );
		dummy[1] = '\0';


		err_msg_001("i: %d: |%s| \r\n", i, dummy);

	}

	// Lootn check if we set 100 to the text file.
	for ( i =100; i<file_end && i >90; i-- ) {

		err_msg_001("i: %d loop starts. ", i );
		err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		dummy[0] = get_char( structure_fp );
		dummy[1] = '\0';


		err_msg_001("i: %d: |%s| \r\n", i, dummy);

	}


	err_msg_001("found_enter_001: ends\r\n");
	return 0;
}

//
//
//
//
//
int found_enter_002 (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;
	STRUCT_FILE structure_fp;
	char c;
	char* p_dummy = NULL;

	err_msg_001("found_enter_002: starts\r\n");

	fp = fopen(filename, "rb");
	structure_fp.file_start = fp;
	structure_fp.fp = fp;

	file_end = filesize(fp);
	structure_fp.file_end_index = file_end;
	
	for ( i =0; i<file_end && i < 10; i++ ) {

		err_msg_001("i: %d loop starts. ", i );
		err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		dummy[0] = get_char( structure_fp );
		dummy[1] = '\0';


		err_msg_001("i: %d: |%s| \r\n", i, dummy);

	}

	// Lootn check if we set 100 to the text file.
	for ( i =100; i<file_end && i >90; i-- ) {

		err_msg_001("i: %d loop starts. ", i );
		err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

		structure_fp.index = i;
		p_dummy = get_string( structure_fp , 1);
		p_dummy[1] = '\0';

		err_msg_001("i: %d: |%s| \r\n", i, p_dummy);
	}


	err_msg_001("found_enter_002: ends\r\n");
	return 0;
}

char* skip_to ( STRUCT_FILE structure_fp, char* to_string ) {
	int i;
	char* token_001;

	err_msg_001("char* skip_to ( STRUCT_FILE structure_fp, char* to_string ) starts.\r\n");

	int ac = array_count ( to_string );
	for ( i =0; i<structure_fp.file_end_index; i++ ) {
		char* string_001 = get_string( structure_fp, ac );
		if ( m_compare( string_001, to_string ) == 1 ) {
			break;
		}
		token_001 = put_token ( string_001[0] );
	}

	put_memories ( token_001 );
	err_msg_001("token_001 %s\r\n", token_001 );
	err_msg_001("char* skip_to ( STRUCT_FILE structure_fp, char* to_string ) ends.\r\n");

	return token_001;
}

//
//
//
char* get_string ( STRUCT_FILE structure_fp, int num ) {
	long diff;
	char c;

	err_msg_001("char* get_string ( STRUCT_FILE structure_fp, int num ) starts.\r\n");

	diff = (long)structure_fp.fp - (long)structure_fp.file_start;

	// set
	//(long)structure_fp.file_start + (long)structure_fp.index;
	//	fseek(fp,0,SEEK_END);
	//	fseek(fp,0,SEEK_CUR);

	err_msg_001("struct_fp.fp |%d| struct_fp.index |%d|\r\n", structure_fp.fp , structure_fp.index);

	fseek( structure_fp.fp, structure_fp.index, SEEK_SET);
	fread ( g_dummy, 1, num, structure_fp.fp );

	err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

	err_msg_001("char* get_string ( STRUCT_FILE structure_fp, int num ) ends.\r\n");

	return g_dummy;
}

// https://bituse.info/c_func/48
//
//
char get_char ( STRUCT_FILE structure_fp) {
	long diff;
	char c;
	char dummy[255];

	err_msg_001("get_char starts.\r\n");

	diff = (long)structure_fp.fp - (long)structure_fp.file_start;

	// set
	//(long)structure_fp.file_start + (long)structure_fp.index;
	//	fseek(fp,0,SEEK_END);
	//	fseek(fp,0,SEEK_CUR);

	err_msg_001("struct_fp.fp |%d| struct_fp.index |%d|\r\n", structure_fp.fp , structure_fp.index);

	fseek( structure_fp.fp, structure_fp.index, SEEK_SET);
	fread ( dummy, 1, 1, structure_fp.fp );

	err_msg_001("struct_fp.fp |%d|\r\n", structure_fp.fp );

	err_msg_001("get_char ends.\r\n");

	return dummy[0];
}

//
//
//
//
//
int found_enter (char* filename) {
	FILE *fp;
	char b_dummy[256];
	int i, j ;
	int file_end;

	err_msg_001("found_enter: starts\r\n");

	fp = fopen(filename, "rb");
	file_end = filesize(fp);

	for ( i =0; i<file_end; i++ ) {

		err_msg_001("i: %d loop starts.\r\n", i );

		for ( j=0; j<255; j++ ) {
			b_dummy[ j + 1 ] = b_dummy[ j ];
		}

		fread ( dummy, 1, 1, fp);
		b_dummy[ 0 ] = dummy[0];

		if ( m_compare( (char*)b_dummy, (char*)"\r\n" ) == 1 ) {
			err_msg_001("We found Eenter %s\r\n", b_dummy);
			exit( -1 );
		}

		err_msg_001("i: %d: |%d|%d|%d|%d| loop ends.\r\n", i, b_dummy[0], b_dummy[1], '\r', '\n' );

		// We could find flip side:
		//
		//
		if ( b_dummy[0] == 13 && b_dummy[1] == 10 ) {
			b_dummy[2] = '\0';
			err_msg_001("We found Eenter opposite side: |%s|\r\n", b_dummy);
			exit(-1);
		}
	}

	err_msg_001("found_enter: ends\r\n");
	return 0;
}

int analyze_main () {
	FILE *fp;
	int i;
	char dummy[256];
	char* filename = ".\\alphabet-001.txt";
	char* filename_split = ".\\001-split-001.txt";
//	char spit_line[10];
	char basic[3];

	basic[2] = '\0';

	fp = fopen(filename_split, "rb");
	int file_end = filesize ( fp );

	int start = 0;
	int j = 0;
	// first, we are going to find "spit_line".
	// each block should be stored as block name eve like "001-block---001.txt".
	// and we care following orders.
	//
	for ( i =0; i<file_end; i++ ) {
		err_msg_001("loop start i: %d: j: %d: \r\n", i, j );
		fread ( dummy, 1, 1, fp);

		dummy[1] = '\0';
		basic[1] = dummy[0];

		// find line end and space.
		if ( m_compare( (char*)basic, (char*)"\r\n" ) == 1 ) {
			lines[j][i- start - 1 ] = '\0'; //---\r\n if i= 4
			j++;
			start = i + 1;
			//err_msg_001("i %d j %d temporary end.\r\n");
			//exit(-1);
		} else {
			lines[j][ i - start ] = dummy[0];
			lines[j][ i - start + 1 ] = '\0';
		}

		err_msg_001("loop   end i: %d: |%s| j:%d|%s| basic|%s| start:%d\r\n", i, dummy, j, lines[j], basic, start);
		basic[0] = basic[1];
	}

//	err_msg_001("split_line: %s\r\n", spit_line);
	fclose(fp);

	for ( i =0; i<10; i++ ) {
		err_msg_001("lines[%d]|%s|\r\n", i, lines[i]);
	}


	/*fp = fopen(filename, "rb");
	file_end = filesize ( fp );
	for ( i =0; i<file_end; i++ ) {
		fread ( dummy, 1, 1, fp);
		dummy[1] = '\0';
		err_msg_001("%d: %s\r\n", i, dummy);
	}

	close(fp);*/
	return 0;
}

// 202007710
// START as character
// EOF
int retrieve (char* filename) {
	FILE *fp;
	int i;
	char dummy[256];
	char basic[3];

	err_msg_001("retrieve: %s starts.\r\n", filename);

	fp = fopen(filename, "rb");
	int file_end = filesize ( fp );
	int start = 0;
	int j = 0;
	int line_count = 0;
	// first, we are going to find "spit_line".
	// each block should be stored as block name eve like "001-block---001.txt".
	// and we care following orders.
	//
	err_msg_001("file_end %d\r\n", file_end );
	for ( i = 0; i<file_end && i<100; i++ ) {
		err_msg_001("loop start i: %d: file_end %d: \r\n", i, file_end  );
		fread ( dummy, 1, 1, fp);

		dummy[1] = '\0';
		basic[1] = dummy[0];

		// find line end.
		if ( m_compare( (char*)basic, (char*)"\r\n" ) == 1 && line_count!= 0 ) {
			lines[j][i- start - 1 ] = '\0'; //---\r\n if i= 4

			char* a = (char*)lines[j];
			if ( i - start - 1 == 0 ) {
				err_msg_001("no word\r\n");
				exit(-1);
			} else {
				line_count++;
				//err_msg_001("line_count %d\r\n" line_count);
				exit(-1);
			}
			j++;
			start = i + 1;
		} else {
			lines[j][ i - start ] = dummy[0];
			lines[j][ i - start + 1 ] = '\0';
		}

		err_msg_001("loop ends i: %d: dummy: |%s| basic: |%s|\r\n", i, dummy, basic );
		basic[0] = basic[1];
	}

	err_msg_001("retrieve: %s ends.\r\n", filename);
	return 1;
}



int filesize( FILE *fp ) {
	err_msg_001("int filesize( FILE *fp ) startss.\r\n");

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	err_msg_001("sz %d\r\n", sz);
	err_msg_001("int filesize( FILE *fp ) ends.\r\n");
	return sz;
}

