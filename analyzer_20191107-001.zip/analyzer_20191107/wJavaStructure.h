#ifndef _W_JAVA_STRUCTURE_H_
#define _W_JAVA_STRUCTURE_H_

class wJavaStructure {

	public:

	private:
		char* ClassName = nullptr;
		int class_raw = 0;
		int class_line = 0;

	public:
		wJavaStructure();
		void set_ClassName ( char* filename, int raw, int line );

	private:

};

#endif
