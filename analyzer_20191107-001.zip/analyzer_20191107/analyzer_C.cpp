#include <stdio.h>
#include <stdlib.h>

#include <windows.h>

#include <ctime>

#include "Print.h"
#include "array_counter.h"
#include "aToken.h"

#include "wC_structure.h"

#include "analyzer_C.h"

// argv[0] : file name
//
//
//
//
int Analyzer::analyze_C (int argc, char** argv ) {

	this->parse(argv[0]);

	return 0;
}

//
//
//
//
//
//
int Analyzer::skip_to( char* skip_to, int *index , int file_end, FILE *fp) {
	aToken *iToken = nullptr;
	iToken = new aToken ();

	return iToken->skip_to( skip_to, index, file_end, fp);
}

//
//
//
//
//
//
int Analyzer::parse_001 ( char* filename ) {

	err_msg_006("Analyzer::parse\r\n" );

	return 0;
}

//
//
//
//
//
int Analyzer::parse ( char* filename ) {
	FILE *fp;
	aToken *iToken = nullptr;
	char *parse_token;
	int previous_index = 0;
	char dummy[256];
	char* a_token;

	int mode_token = 0;
	iToken = new aToken();
	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	int anz_count = 0;
	int inc_count = 0;

	Sleep(1000);

	level_error_msg = 2;
	set_level_error_msg = 3;
	// printf ("Analyzer::parse: starts.\r\n");
	err_msg_006 ("Analyzer::parse: starts.\r\n");

	for( int i=0; i<file_end && i<PARSE_NUM; i++ ) {
		//m_fread ( dummy, 1, fp);
		err_msg_006 ("Analyzer::parse: loop starts.\r\n");
		err_msg_006("M i: %d\r\n", i );
		parse_token = iToken->getToken( fp, &i, &file_end );
		err_msg_006 ("Analyzer::getToken ends.\r\n");

		if ( m_compare( (char*) "#define", parse_token ) == 1 ) {
			iToken->block_to( (char*)"\n", &i, file_end, fp);
			a_token = iToken->block;
			err_msg_006( "#define a_token: |%s|\r\n", a_token );
			// 20190923 printed and qualified.
			// dummy[0] = iToken->getChar( fp, &i, &file_end);
			// dummy[1] = '\0';
			// printf("#define next: i:%d  dummy: |%s|\r\n", i, dummy );
			// exit(-1);
			// end of m_fread: 1
			// #define next: i:1903  dummy: |#|
			anz_count++;
		} else if ( m_compare( (char*) "#include", parse_token ) == 1 ) {
			iToken->block_to( (char*)"\n", &i, file_end, fp);
			a_token = iToken->block;
			err_msg_006( "#include a_token: |%s|\r\n", a_token );
			inc_count++;
		} else if ( is_function_start( parse_token ) == 1 ) {
			
			err_msg_006( "is_function_start: parse_token: |%s| a_token: |%s|\r\n", parse_token, a_token );

			iToken->block_to_function_end( &i, file_end, fp );
			a_token = iToken->block;

			err_msg_006("memorization 000: index %d  max %d \r\n", index_wc, max_index_wc);
			if ( array_wC_structure == nullptr ) {
				max_index_wc = 10;
				index_wc = 0;
				array_wC_structure = (wC_structure**) malloc ( sizeof(wC_structure*) * max_index_wc );
			}
			err_msg_006("memorization001: index %d  max %d \r\n", index_wc, max_index_wc);
			array_wC_structure[index_wc] = new wC_structure();
			index_wc++;
			array_wC_structure[index_wc]->function_name = a_token;
			err_msg_006("memorization 002: index %d  max %d \r\n", index_wc, max_index_wc);

			//err_msg_006("Exit(-1): Analyzer::parse: %s\r\n", filename);
			//exit(-1);
		} else {
			err_msg_006( "else: parse_token: |%s| a_token: |%s|\r\n", parse_token, a_token );
			err_msg_006("Exit(-1): Analyzer::parse: %s i: %d / %d \r\n", filename, i, PARSE_NUM);
			exit(-1);
		}

		iToken->free_main_token ();

		if ( inc_count == 6 ) break;
		// if ( anz_count == 3 ) break;

		switch( mode_token ) {
		case 0:
			break;
		case 1:
			break;
		}
	}

	fclose(fp);

	err_msg_006("Analyzer::parse: ends.\r\n");

	return 1;

}

//
//
//
//
//
int Analyzer::is_function_start( char* parse_token ) {
	if ( m_compare( (char*) "int", parse_token ) == 1 ) {

		return 1;
	} else if ( m_compare( (char*) "void", parse_token ) == 1 ) {

		return 1;
	}

	return 0;
}

//
//
//
//
//
int Analyzer::parse_token ( char* filename ) {
	FILE *fp;
	aToken *iToken = nullptr;
	char *parse_token;
	int previous_index = 0;

	iToken = new aToken();
	fp = fopen ( filename, "rb" );
	int file_end = filesize ( fp );

	for( int i=0; i<file_end && i<PARSE_NUM; i++ ) {
		// DEBUG
		previous_index = i;

		// the below has problem at 20190913.
		parse_token = iToken->getToken( fp, &i, &file_end );
		printf("001 parse_token: |%s|\r\n", parse_token );
		// this cannot scope the below function, but sucope it in aDebug.cpp at 20190303
		// DEBUG_SUB( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// DEBUG ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// o debug_msg_001 ();
		// DEBUG_002 ( msg, "parse_token: |%s|\r\n", parse_token ) ;
		// printf("msg: |%s|\r\n", msg );
		// err_msg_001 ( "parse_token: |%s|", parse_token ) ;

		if ( m_compare( parse_token, (char *) "void" ) == 1 ) {

			printf("void\r\n");
			exit(-1);

		} else if ( m_compare( parse_token, (char *) "/*" ) == 1 ) {

			printf("001 comment out starts: i %d raw %d line %d\r\n", i, iToken->getRaw(), iToken->getLine() );
			int return_value = this->skip_to( "*/", &i , file_end, fp);
			printf("001 comment out ends: i %d raw %d line %d\r\n", i, iToken->getRaw(), iToken->getLine() );

			// reset token 001
			iToken->free_main_token();
			printf("002\r\n");
			free( parse_token );
			printf("003\r\n");

			//exit(-1);

		} else if ( m_compare( parse_token, (char *) "#define" ) == 1 ) {

			// We couldn't come here but well.
			printf("token: #define\r\n");
			exit(-1);

		} else {

			printf("else: %s \r\n", parse_token);
			printf("parse_token: |%s|\r\n", parse_token );
			iToken->free_main_token ();
			exit(-1);

		}

		printf("002 parse_token: |%s|\r\n", parse_token );

		// DEBUG
		if ( previous_index > i ) {
			printf("previous_index > i\r\n");
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		} else if ( previous_index == i ) {
			printf("i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		}

		printf("003 parse_token: |%s|\r\n", parse_token );
	}

	fclose(fp);

	return 1;
}

//
//
//
//
//
int Analyzer::filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}




