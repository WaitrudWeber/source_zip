#ifndef WCANVASCONTROLLER_H
#define WCANVASCONTROLLER_H

#include "wEvent.h"

class wCanvasController {

	public:
		int key_wParam_Keyup = 0;
		int Processed = 0;
		int ProcessedKeyup = 0;
		int AXEX_2D_002_Max  = 30;
		int AXEX_2D_002_Index  = 0;
		int AXEX_2D_002_Index_Selected  = 0;
		int AXEX_2D_LINE_Index = 0;

	private:
		int call_once_key = 0;
		vLine** axline = nullptr;
		int width = 640;
		int height = 480;
		int screen_x = 0;
		int screen_y = 0;
		int screen_width = 160;
		int screen_height = 90;

	private:
		wEvent* event;
//		vDisplayController vDisp;
//		wDisplayController wDisp;
		vAxex_2D vAxex_2D_002[30];
		unsigned char buffer[160][90][3];

	public:
		wCanvasController ();
		void kickEveentCanvases ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
		void Process ();
		void ProcessWmPaint ();
		void ProcessWmChar ();
		void ProcessWmKeyup ();
		void setEvent( wEvent* evt );
//		void Print_struct(wJavaStructure top ) ;
		void Set_vAxex_2D ( float x, float y );
		int Get_vAxex_2D ( int num, float *x, float *y );
		int GetSelected ();
		void Initialize_Axex ( ) ;
		void Initialize_Buffer ( ) ;
		void Set_Axex_Line( int x1, int y1, int x2, int y2 );
		int Draw_Buffer ( ) ;
		int Draw_Buffer_001 ( ) ;
		int Draw_Buffer_002 ( ) ;
		int Initialize_Buffer_001 () ;
		int Set_Buffer (int xx, int yy, int col, unsigned char vv ) ;
		void ProcessLinesWmPaint () ;
		void ProcessAxexWmPaint () ;

};


#endif
