#ifndef _W_METHOD_H_
#define _W_METHOD_H_

#include "wMethod.h"

class wMethod {

	public:
		wMethod ();
		void Set_Method_Place ( char* filename, int l, int r ) ;
		void Set_Method_Place ( char* method_name, char* l_filename, int l, int r ) ;
		void Set_Method_Header_Line ( char* head_line ) ;

	private:
		int raw = 0;
		int line = 0;
		char* filename = nullptr;
		char* MethodMame = nullptr;
		char* MethodHeaderLine = nullptr;

};

#endif
